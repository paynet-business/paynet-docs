var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t,t.exports),e=null),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=(n,r,o)=>(o=n==null?{}:e(i(n)),s(r||!n||!n.__esModule||!a.call(n,`default`)?t(o,`default`,{value:n,enumerable:!0}):o,n));(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var l=o((e=>{var t=Symbol.for(`react.element`),n=Symbol.for(`react.portal`),r=Symbol.for(`react.fragment`),i=Symbol.for(`react.strict_mode`),a=Symbol.for(`react.profiler`),o=Symbol.for(`react.provider`),s=Symbol.for(`react.context`),c=Symbol.for(`react.forward_ref`),l=Symbol.for(`react.suspense`),u=Symbol.for(`react.memo`),d=Symbol.for(`react.lazy`),f=Symbol.iterator;function p(e){return typeof e!=`object`||!e?null:(e=f&&e[f]||e[`@@iterator`],typeof e==`function`?e:null)}var m={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},h=Object.assign,g={};function _(e,t,n){this.props=e,this.context=t,this.refs=g,this.updater=n||m}_.prototype.isReactComponent={},_.prototype.setState=function(e,t){if(typeof e!=`object`&&typeof e!=`function`&&e!=null)throw Error(`setState(...): takes an object of state variables to update or a function which returns an object of state variables.`);this.updater.enqueueSetState(this,e,t,`setState`)},_.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,`forceUpdate`)};function v(){}v.prototype=_.prototype;function y(e,t,n){this.props=e,this.context=t,this.refs=g,this.updater=n||m}var b=y.prototype=new v;b.constructor=y,h(b,_.prototype),b.isPureReactComponent=!0;var x=Array.isArray,S=Object.prototype.hasOwnProperty,C={current:null},w={key:!0,ref:!0,__self:!0,__source:!0};function T(e,n,r){var i,a={},o=null,s=null;if(n!=null)for(i in n.ref!==void 0&&(s=n.ref),n.key!==void 0&&(o=``+n.key),n)S.call(n,i)&&!w.hasOwnProperty(i)&&(a[i]=n[i]);var c=arguments.length-2;if(c===1)a.children=r;else if(1<c){for(var l=Array(c),u=0;u<c;u++)l[u]=arguments[u+2];a.children=l}if(e&&e.defaultProps)for(i in c=e.defaultProps,c)a[i]===void 0&&(a[i]=c[i]);return{$$typeof:t,type:e,key:o,ref:s,props:a,_owner:C.current}}function E(e,n){return{$$typeof:t,type:e.type,key:n,ref:e.ref,props:e.props,_owner:e._owner}}function D(e){return typeof e==`object`&&!!e&&e.$$typeof===t}function O(e){var t={"=":`=0`,":":`=2`};return`$`+e.replace(/[=:]/g,function(e){return t[e]})}var k=/\/+/g;function A(e,t){return typeof e==`object`&&e&&e.key!=null?O(``+e.key):t.toString(36)}function j(e,r,i,a,o){var s=typeof e;(s===`undefined`||s===`boolean`)&&(e=null);var c=!1;if(e===null)c=!0;else switch(s){case`string`:case`number`:c=!0;break;case`object`:switch(e.$$typeof){case t:case n:c=!0}}if(c)return c=e,o=o(c),e=a===``?`.`+A(c,0):a,x(o)?(i=``,e!=null&&(i=e.replace(k,`$&/`)+`/`),j(o,r,i,``,function(e){return e})):o!=null&&(D(o)&&(o=E(o,i+(!o.key||c&&c.key===o.key?``:(``+o.key).replace(k,`$&/`)+`/`)+e)),r.push(o)),1;if(c=0,a=a===``?`.`:a+`:`,x(e))for(var l=0;l<e.length;l++){s=e[l];var u=a+A(s,l);c+=j(s,r,i,u,o)}else if(u=p(e),typeof u==`function`)for(e=u.call(e),l=0;!(s=e.next()).done;)s=s.value,u=a+A(s,l++),c+=j(s,r,i,u,o);else if(s===`object`)throw r=String(e),Error(`Objects are not valid as a React child (found: `+(r===`[object Object]`?`object with keys {`+Object.keys(e).join(`, `)+`}`:r)+`). If you meant to render a collection of children, use an array instead.`);return c}function M(e,t,n){if(e==null)return e;var r=[],i=0;return j(e,r,``,``,function(e){return t.call(n,e,i++)}),r}function N(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(t){(e._status===0||e._status===-1)&&(e._status=1,e._result=t)},function(t){(e._status===0||e._status===-1)&&(e._status=2,e._result=t)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var P={current:null},F={transition:null},ee={ReactCurrentDispatcher:P,ReactCurrentBatchConfig:F,ReactCurrentOwner:C};function I(){throw Error(`act(...) is not supported in production builds of React.`)}e.Children={map:M,forEach:function(e,t,n){M(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return M(e,function(){t++}),t},toArray:function(e){return M(e,function(e){return e})||[]},only:function(e){if(!D(e))throw Error(`React.Children.only expected to receive a single React element child.`);return e}},e.Component=_,e.Fragment=r,e.Profiler=a,e.PureComponent=y,e.StrictMode=i,e.Suspense=l,e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=ee,e.act=I,e.cloneElement=function(e,n,r){if(e==null)throw Error(`React.cloneElement(...): The argument must be a React element, but you passed `+e+`.`);var i=h({},e.props),a=e.key,o=e.ref,s=e._owner;if(n!=null){if(n.ref!==void 0&&(o=n.ref,s=C.current),n.key!==void 0&&(a=``+n.key),e.type&&e.type.defaultProps)var c=e.type.defaultProps;for(l in n)S.call(n,l)&&!w.hasOwnProperty(l)&&(i[l]=n[l]===void 0&&c!==void 0?c[l]:n[l])}var l=arguments.length-2;if(l===1)i.children=r;else if(1<l){c=Array(l);for(var u=0;u<l;u++)c[u]=arguments[u+2];i.children=c}return{$$typeof:t,type:e.type,key:a,ref:o,props:i,_owner:s}},e.createContext=function(e){return e={$$typeof:s,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:o,_context:e},e.Consumer=e},e.createElement=T,e.createFactory=function(e){var t=T.bind(null,e);return t.type=e,t},e.createRef=function(){return{current:null}},e.forwardRef=function(e){return{$$typeof:c,render:e}},e.isValidElement=D,e.lazy=function(e){return{$$typeof:d,_payload:{_status:-1,_result:e},_init:N}},e.memo=function(e,t){return{$$typeof:u,type:e,compare:t===void 0?null:t}},e.startTransition=function(e){var t=F.transition;F.transition={};try{e()}finally{F.transition=t}},e.unstable_act=I,e.useCallback=function(e,t){return P.current.useCallback(e,t)},e.useContext=function(e){return P.current.useContext(e)},e.useDebugValue=function(){},e.useDeferredValue=function(e){return P.current.useDeferredValue(e)},e.useEffect=function(e,t){return P.current.useEffect(e,t)},e.useId=function(){return P.current.useId()},e.useImperativeHandle=function(e,t,n){return P.current.useImperativeHandle(e,t,n)},e.useInsertionEffect=function(e,t){return P.current.useInsertionEffect(e,t)},e.useLayoutEffect=function(e,t){return P.current.useLayoutEffect(e,t)},e.useMemo=function(e,t){return P.current.useMemo(e,t)},e.useReducer=function(e,t,n){return P.current.useReducer(e,t,n)},e.useRef=function(e){return P.current.useRef(e)},e.useState=function(e){return P.current.useState(e)},e.useSyncExternalStore=function(e,t,n){return P.current.useSyncExternalStore(e,t,n)},e.useTransition=function(){return P.current.useTransition()},e.version=`18.3.1`})),u=o(((e,t)=>{t.exports=l()})),d=o((e=>{function t(e,t){var n=e.length;e.push(t);a:for(;0<n;){var r=n-1>>>1,a=e[r];if(0<i(a,t))e[r]=t,e[n]=a,n=r;else break a}}function n(e){return e.length===0?null:e[0]}function r(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;a:for(var r=0,a=e.length,o=a>>>1;r<o;){var s=2*(r+1)-1,c=e[s],l=s+1,u=e[l];if(0>i(c,n))l<a&&0>i(u,c)?(e[r]=u,e[l]=n,r=l):(e[r]=c,e[s]=n,r=s);else if(l<a&&0>i(u,n))e[r]=u,e[l]=n,r=l;else break a}}return t}function i(e,t){var n=e.sortIndex-t.sortIndex;return n===0?e.id-t.id:n}if(typeof performance==`object`&&typeof performance.now==`function`){var a=performance;e.unstable_now=function(){return a.now()}}else{var o=Date,s=o.now();e.unstable_now=function(){return o.now()-s}}var c=[],l=[],u=1,d=null,f=3,p=!1,m=!1,h=!1,g=typeof setTimeout==`function`?setTimeout:null,_=typeof clearTimeout==`function`?clearTimeout:null,v=typeof setImmediate<`u`?setImmediate:null;typeof navigator<`u`&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function y(e){for(var i=n(l);i!==null;){if(i.callback===null)r(l);else if(i.startTime<=e)r(l),i.sortIndex=i.expirationTime,t(c,i);else break;i=n(l)}}function b(e){if(h=!1,y(e),!m){if(n(c)!==null)m=!0,M(x);else{var t=n(l);t!==null&&N(b,t.startTime-e)}}}function x(t,i){m=!1,h&&(h=!1,_(w),w=-1),p=!0;var a=f;try{for(y(i),d=n(c);d!==null&&(!(d.expirationTime>i)||t&&!D());){var o=d.callback;if(typeof o==`function`){d.callback=null,f=d.priorityLevel;var s=o(d.expirationTime<=i);i=e.unstable_now(),typeof s==`function`?d.callback=s:d===n(c)&&r(c),y(i)}else r(c);d=n(c)}if(d!==null)var u=!0;else{var g=n(l);g!==null&&N(b,g.startTime-i),u=!1}return u}finally{d=null,f=a,p=!1}}var S=!1,C=null,w=-1,T=5,E=-1;function D(){return!(e.unstable_now()-E<T)}function O(){if(C!==null){var t=e.unstable_now();E=t;var n=!0;try{n=C(!0,t)}finally{n?k():(S=!1,C=null)}}else S=!1}var k;if(typeof v==`function`)k=function(){v(O)};else if(typeof MessageChannel<`u`){var A=new MessageChannel,j=A.port2;A.port1.onmessage=O,k=function(){j.postMessage(null)}}else k=function(){g(O,0)};function M(e){C=e,S||(S=!0,k())}function N(t,n){w=g(function(){t(e.unstable_now())},n)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(e){e.callback=null},e.unstable_continueExecution=function(){m||p||(m=!0,M(x))},e.unstable_forceFrameRate=function(e){0>e||125<e?console.error(`forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`):T=0<e?Math.floor(1e3/e):5},e.unstable_getCurrentPriorityLevel=function(){return f},e.unstable_getFirstCallbackNode=function(){return n(c)},e.unstable_next=function(e){switch(f){case 1:case 2:case 3:var t=3;break;default:t=f}var n=f;f=t;try{return e()}finally{f=n}},e.unstable_pauseExecution=function(){},e.unstable_requestPaint=function(){},e.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=f;f=e;try{return t()}finally{f=n}},e.unstable_scheduleCallback=function(r,i,a){var o=e.unstable_now();switch(typeof a==`object`&&a?(a=a.delay,a=typeof a==`number`&&0<a?o+a:o):a=o,r){case 1:var s=-1;break;case 2:s=250;break;case 5:s=1073741823;break;case 4:s=1e4;break;default:s=5e3}return s=a+s,r={id:u++,callback:i,priorityLevel:r,startTime:a,expirationTime:s,sortIndex:-1},a>o?(r.sortIndex=a,t(l,r),n(c)===null&&r===n(l)&&(h?(_(w),w=-1):h=!0,N(b,a-o))):(r.sortIndex=s,t(c,r),m||p||(m=!0,M(x))),r},e.unstable_shouldYield=D,e.unstable_wrapCallback=function(e){var t=f;return function(){var n=f;f=t;try{return e.apply(this,arguments)}finally{f=n}}}})),f=o(((e,t)=>{t.exports=d()})),p=o((e=>{var t=u(),n=f();function r(e){for(var t=`https://reactjs.org/docs/error-decoder.html?invariant=`+e,n=1;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n]);return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}var i=new Set,a={};function o(e,t){s(e,t),s(e+`Capture`,t)}function s(e,t){for(a[e]=t,e=0;e<t.length;e++)i.add(t[e])}var c=typeof window<`u`&&window.document!==void 0&&window.document.createElement!==void 0,l=Object.prototype.hasOwnProperty,d=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,p={},m={};function h(e){return l.call(m,e)?!0:l.call(p,e)?!1:d.test(e)?m[e]=!0:(p[e]=!0,!1)}function g(e,t,n,r){if(n!==null&&n.type===0)return!1;switch(typeof t){case`function`:case`symbol`:return!0;case`boolean`:return r?!1:n===null?(e=e.toLowerCase().slice(0,5),e!==`data-`&&e!==`aria-`):!n.acceptsBooleans;default:return!1}}function _(e,t,n,r){if(t==null||g(e,t,n,r))return!0;if(r)return!1;if(n!==null)switch(n.type){case 3:return!t;case 4:return!1===t;case 5:return isNaN(t);case 6:return isNaN(t)||1>t}return!1}function v(e,t,n,r,i,a,o){this.acceptsBooleans=t===2||t===3||t===4,this.attributeName=r,this.attributeNamespace=i,this.mustUseProperty=n,this.propertyName=e,this.type=t,this.sanitizeURL=a,this.removeEmptyString=o}var y={};`children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style`.split(` `).forEach(function(e){y[e]=new v(e,0,!1,e,null,!1,!1)}),[[`acceptCharset`,`accept-charset`],[`className`,`class`],[`htmlFor`,`for`],[`httpEquiv`,`http-equiv`]].forEach(function(e){var t=e[0];y[t]=new v(t,1,!1,e[1],null,!1,!1)}),[`contentEditable`,`draggable`,`spellCheck`,`value`].forEach(function(e){y[e]=new v(e,2,!1,e.toLowerCase(),null,!1,!1)}),[`autoReverse`,`externalResourcesRequired`,`focusable`,`preserveAlpha`].forEach(function(e){y[e]=new v(e,2,!1,e,null,!1,!1)}),`allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope`.split(` `).forEach(function(e){y[e]=new v(e,3,!1,e.toLowerCase(),null,!1,!1)}),[`checked`,`multiple`,`muted`,`selected`].forEach(function(e){y[e]=new v(e,3,!0,e,null,!1,!1)}),[`capture`,`download`].forEach(function(e){y[e]=new v(e,4,!1,e,null,!1,!1)}),[`cols`,`rows`,`size`,`span`].forEach(function(e){y[e]=new v(e,6,!1,e,null,!1,!1)}),[`rowSpan`,`start`].forEach(function(e){y[e]=new v(e,5,!1,e.toLowerCase(),null,!1,!1)});var b=/[\-:]([a-z])/g;function x(e){return e[1].toUpperCase()}`accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height`.split(` `).forEach(function(e){var t=e.replace(b,x);y[t]=new v(t,1,!1,e,null,!1,!1)}),`xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type`.split(` `).forEach(function(e){var t=e.replace(b,x);y[t]=new v(t,1,!1,e,`http://www.w3.org/1999/xlink`,!1,!1)}),[`xml:base`,`xml:lang`,`xml:space`].forEach(function(e){var t=e.replace(b,x);y[t]=new v(t,1,!1,e,`http://www.w3.org/XML/1998/namespace`,!1,!1)}),[`tabIndex`,`crossOrigin`].forEach(function(e){y[e]=new v(e,1,!1,e.toLowerCase(),null,!1,!1)}),y.xlinkHref=new v(`xlinkHref`,1,!1,`xlink:href`,`http://www.w3.org/1999/xlink`,!0,!1),[`src`,`href`,`action`,`formAction`].forEach(function(e){y[e]=new v(e,1,!1,e.toLowerCase(),null,!0,!0)});function S(e,t,n,r){var i=y.hasOwnProperty(t)?y[t]:null;(i===null?r||!(2<t.length)||t[0]!==`o`&&t[0]!==`O`||t[1]!==`n`&&t[1]!==`N`:i.type!==0)&&(_(t,n,i,r)&&(n=null),r||i===null?h(t)&&(n===null?e.removeAttribute(t):e.setAttribute(t,``+n)):i.mustUseProperty?e[i.propertyName]=n===null?i.type!==3&&``:n:(t=i.attributeName,r=i.attributeNamespace,n===null?e.removeAttribute(t):(i=i.type,n=i===3||i===4&&!0===n?``:``+n,r?e.setAttributeNS(r,t,n):e.setAttribute(t,n))))}var C=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,w=Symbol.for(`react.element`),T=Symbol.for(`react.portal`),E=Symbol.for(`react.fragment`),D=Symbol.for(`react.strict_mode`),O=Symbol.for(`react.profiler`),k=Symbol.for(`react.provider`),A=Symbol.for(`react.context`),j=Symbol.for(`react.forward_ref`),M=Symbol.for(`react.suspense`),N=Symbol.for(`react.suspense_list`),P=Symbol.for(`react.memo`),F=Symbol.for(`react.lazy`),ee=Symbol.for(`react.offscreen`),I=Symbol.iterator;function L(e){return typeof e!=`object`||!e?null:(e=I&&e[I]||e[`@@iterator`],typeof e==`function`?e:null)}var R=Object.assign,te;function ne(e){if(te===void 0)try{throw Error()}catch(e){var t=e.stack.trim().match(/\n( *(at )?)/);te=t&&t[1]||``}return`
`+te+e}var re=!1;function z(e,t){if(!e||re)return``;re=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(t){if(t=function(){throw Error()},Object.defineProperty(t.prototype,"props",{set:function(){throw Error()}}),typeof Reflect==`object`&&Reflect.construct){try{Reflect.construct(t,[])}catch(e){var r=e}Reflect.construct(e,[],t)}else{try{t.call()}catch(e){r=e}e.call(t.prototype)}}else{try{throw Error()}catch(e){r=e}e()}}catch(t){if(t&&r&&typeof t.stack==`string`){for(var i=t.stack.split(`
`),a=r.stack.split(`
`),o=i.length-1,s=a.length-1;1<=o&&0<=s&&i[o]!==a[s];)s--;for(;1<=o&&0<=s;o--,s--)if(i[o]!==a[s]){if(o!==1||s!==1)do if(o--,s--,0>s||i[o]!==a[s]){var c=`
`+i[o].replace(` at new `,` at `);return e.displayName&&c.includes(`<anonymous>`)&&(c=c.replace(`<anonymous>`,e.displayName)),c}while(1<=o&&0<=s);break}}}finally{re=!1,Error.prepareStackTrace=n}return(e=e?e.displayName||e.name:``)?ne(e):``}function ie(e){switch(e.tag){case 5:return ne(e.type);case 16:return ne(`Lazy`);case 13:return ne(`Suspense`);case 19:return ne(`SuspenseList`);case 0:case 2:case 15:return e=z(e.type,!1),e;case 11:return e=z(e.type.render,!1),e;case 1:return e=z(e.type,!0),e;default:return``}}function ae(e){if(e==null)return null;if(typeof e==`function`)return e.displayName||e.name||null;if(typeof e==`string`)return e;switch(e){case E:return`Fragment`;case T:return`Portal`;case O:return`Profiler`;case D:return`StrictMode`;case M:return`Suspense`;case N:return`SuspenseList`}if(typeof e==`object`)switch(e.$$typeof){case A:return(e.displayName||`Context`)+`.Consumer`;case k:return(e._context.displayName||`Context`)+`.Provider`;case j:var t=e.render;return e=e.displayName,e||=(e=t.displayName||t.name||``,e===``?`ForwardRef`:`ForwardRef(`+e+`)`),e;case P:return t=e.displayName||null,t===null?ae(e.type)||`Memo`:t;case F:t=e._payload,e=e._init;try{return ae(e(t))}catch{}}return null}function oe(e){var t=e.type;switch(e.tag){case 24:return`Cache`;case 9:return(t.displayName||`Context`)+`.Consumer`;case 10:return(t._context.displayName||`Context`)+`.Provider`;case 18:return`DehydratedFragment`;case 11:return e=t.render,e=e.displayName||e.name||``,t.displayName||(e===``?`ForwardRef`:`ForwardRef(`+e+`)`);case 7:return`Fragment`;case 5:return t;case 4:return`Portal`;case 3:return`Root`;case 6:return`Text`;case 16:return ae(t);case 8:return t===D?`StrictMode`:`Mode`;case 22:return`Offscreen`;case 12:return`Profiler`;case 21:return`Scope`;case 13:return`Suspense`;case 19:return`SuspenseList`;case 25:return`TracingMarker`;case 1:case 0:case 17:case 2:case 14:case 15:if(typeof t==`function`)return t.displayName||t.name||null;if(typeof t==`string`)return t}return null}function se(e){switch(typeof e){case`boolean`:case`number`:case`string`:case`undefined`:return e;case`object`:return e;default:return``}}function ce(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()===`input`&&(t===`checkbox`||t===`radio`)}function le(e){var t=ce(e)?`checked`:`value`,n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),r=``+e[t];if(!e.hasOwnProperty(t)&&n!==void 0&&typeof n.get==`function`&&typeof n.set==`function`){var i=n.get,a=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return i.call(this)},set:function(e){r=``+e,a.call(this,e)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(e){r=``+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function ue(e){e._valueTracker||=le(e)}function de(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r=``;return e&&(r=ce(e)?e.checked?`true`:`false`:e.value),e=r,e!==n&&(t.setValue(e),!0)}function fe(e){if(e||=typeof document<`u`?document:void 0,e===void 0)return null;try{return e.activeElement||e.body}catch{return e.body}}function pe(e,t){var n=t.checked;return R({},t,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:n??e._wrapperState.initialChecked})}function me(e,t){var n=t.defaultValue==null?``:t.defaultValue,r=t.checked==null?t.defaultChecked:t.checked;n=se(t.value==null?n:t.value),e._wrapperState={initialChecked:r,initialValue:n,controlled:t.type===`checkbox`||t.type===`radio`?t.checked!=null:t.value!=null}}function he(e,t){t=t.checked,t!=null&&S(e,`checked`,t,!1)}function ge(e,t){he(e,t);var n=se(t.value),r=t.type;if(n!=null)r===`number`?(n===0&&e.value===``||e.value!=n)&&(e.value=``+n):e.value!==``+n&&(e.value=``+n);else if(r===`submit`||r===`reset`){e.removeAttribute(`value`);return}t.hasOwnProperty(`value`)?ve(e,t.type,n):t.hasOwnProperty(`defaultValue`)&&ve(e,t.type,se(t.defaultValue)),t.checked==null&&t.defaultChecked!=null&&(e.defaultChecked=!!t.defaultChecked)}function _e(e,t,n){if(t.hasOwnProperty(`value`)||t.hasOwnProperty(`defaultValue`)){var r=t.type;if(!(r!==`submit`&&r!==`reset`||t.value!==void 0&&t.value!==null))return;t=``+e._wrapperState.initialValue,n||t===e.value||(e.value=t),e.defaultValue=t}n=e.name,n!==``&&(e.name=``),e.defaultChecked=!!e._wrapperState.initialChecked,n!==``&&(e.name=n)}function ve(e,t,n){(t!==`number`||fe(e.ownerDocument)!==e)&&(n==null?e.defaultValue=``+e._wrapperState.initialValue:e.defaultValue!==``+n&&(e.defaultValue=``+n))}var ye=Array.isArray;function be(e,t,n,r){if(e=e.options,t){t={};for(var i=0;i<n.length;i++)t[`$`+n[i]]=!0;for(n=0;n<e.length;n++)i=t.hasOwnProperty(`$`+e[n].value),e[n].selected!==i&&(e[n].selected=i),i&&r&&(e[n].defaultSelected=!0)}else{for(n=``+se(n),t=null,i=0;i<e.length;i++){if(e[i].value===n){e[i].selected=!0,r&&(e[i].defaultSelected=!0);return}t!==null||e[i].disabled||(t=e[i])}t!==null&&(t.selected=!0)}}function xe(e,t){if(t.dangerouslySetInnerHTML!=null)throw Error(r(91));return R({},t,{value:void 0,defaultValue:void 0,children:``+e._wrapperState.initialValue})}function Se(e,t){var n=t.value;if(n==null){if(n=t.children,t=t.defaultValue,n!=null){if(t!=null)throw Error(r(92));if(ye(n)){if(1<n.length)throw Error(r(93));n=n[0]}t=n}t??=``,n=t}e._wrapperState={initialValue:se(n)}}function Ce(e,t){var n=se(t.value),r=se(t.defaultValue);n!=null&&(n=``+n,n!==e.value&&(e.value=n),t.defaultValue==null&&e.defaultValue!==n&&(e.defaultValue=n)),r!=null&&(e.defaultValue=``+r)}function we(e){var t=e.textContent;t===e._wrapperState.initialValue&&t!==``&&t!==null&&(e.value=t)}function Te(e){switch(e){case`svg`:return`http://www.w3.org/2000/svg`;case`math`:return`http://www.w3.org/1998/Math/MathML`;default:return`http://www.w3.org/1999/xhtml`}}function B(e,t){return e==null||e===`http://www.w3.org/1999/xhtml`?Te(t):e===`http://www.w3.org/2000/svg`&&t===`foreignObject`?`http://www.w3.org/1999/xhtml`:e}var Ee,De=function(e){return typeof MSApp<`u`&&MSApp.execUnsafeLocalFunction?function(t,n,r,i){MSApp.execUnsafeLocalFunction(function(){return e(t,n,r,i)})}:e}(function(e,t){if(e.namespaceURI!==`http://www.w3.org/2000/svg`||`innerHTML`in e)e.innerHTML=t;else{for(Ee||=document.createElement(`div`),Ee.innerHTML=`<svg>`+t.valueOf().toString()+`</svg>`,t=Ee.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;t.firstChild;)e.appendChild(t.firstChild)}});function Oe(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var ke={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},Ae=[`Webkit`,`ms`,`Moz`,`O`];Object.keys(ke).forEach(function(e){Ae.forEach(function(t){t=t+e.charAt(0).toUpperCase()+e.substring(1),ke[t]=ke[e]})});function je(e,t,n){return t==null||typeof t==`boolean`||t===``?``:n||typeof t!=`number`||t===0||ke.hasOwnProperty(e)&&ke[e]?(``+t).trim():t+`px`}function Me(e,t){for(var n in e=e.style,t)if(t.hasOwnProperty(n)){var r=n.indexOf(`--`)===0,i=je(n,t[n],r);n===`float`&&(n=`cssFloat`),r?e.setProperty(n,i):e[n]=i}}var Ne=R({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function Pe(e,t){if(t){if(Ne[e]&&(t.children!=null||t.dangerouslySetInnerHTML!=null))throw Error(r(137,e));if(t.dangerouslySetInnerHTML!=null){if(t.children!=null)throw Error(r(60));if(typeof t.dangerouslySetInnerHTML!=`object`||!(`__html`in t.dangerouslySetInnerHTML))throw Error(r(61))}if(t.style!=null&&typeof t.style!=`object`)throw Error(r(62))}}function Fe(e,t){if(e.indexOf(`-`)===-1)return typeof t.is==`string`;switch(e){case`annotation-xml`:case`color-profile`:case`font-face`:case`font-face-src`:case`font-face-uri`:case`font-face-format`:case`font-face-name`:case`missing-glyph`:return!1;default:return!0}}var Ie=null;function Le(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Re=null,ze=null,Be=null;function Ve(e){if(e=Ri(e)){if(typeof Re!=`function`)throw Error(r(280));var t=e.stateNode;t&&(t=Bi(t),Re(e.stateNode,e.type,t))}}function He(e){ze?Be?Be.push(e):Be=[e]:ze=e}function Ue(){if(ze){var e=ze,t=Be;if(Be=ze=null,Ve(e),t)for(e=0;e<t.length;e++)Ve(t[e])}}function We(e,t){return e(t)}function Ge(){}var Ke=!1;function qe(e,t,n){if(Ke)return e(t,n);Ke=!0;try{return We(e,t,n)}finally{Ke=!1,(ze!==null||Be!==null)&&(Ge(),Ue())}}function Je(e,t){var n=e.stateNode;if(n===null)return null;var i=Bi(n);if(i===null)return null;n=i[t];a:switch(t){case`onClick`:case`onClickCapture`:case`onDoubleClick`:case`onDoubleClickCapture`:case`onMouseDown`:case`onMouseDownCapture`:case`onMouseMove`:case`onMouseMoveCapture`:case`onMouseUp`:case`onMouseUpCapture`:case`onMouseEnter`:(i=!i.disabled)||(e=e.type,i=e!==`button`&&e!==`input`&&e!==`select`&&e!==`textarea`),e=!i;break a;default:e=!1}if(e)return null;if(n&&typeof n!=`function`)throw Error(r(231,t,typeof n));return n}var Ye=!1;if(c)try{var Xe={};Object.defineProperty(Xe,"passive",{get:function(){Ye=!0}}),window.addEventListener(`test`,Xe,Xe),window.removeEventListener(`test`,Xe,Xe)}catch{Ye=!1}function Ze(e,t,n,r,i,a,o,s,c){var l=Array.prototype.slice.call(arguments,3);try{t.apply(n,l)}catch(e){this.onError(e)}}var Qe=!1,$e=null,et=!1,tt=null,nt={onError:function(e){Qe=!0,$e=e}};function rt(e,t,n,r,i,a,o,s,c){Qe=!1,$e=null,Ze.apply(nt,arguments)}function it(e,t,n,i,a,o,s,c,l){if(rt.apply(this,arguments),Qe){if(Qe){var u=$e;Qe=!1,$e=null}else throw Error(r(198));et||(et=!0,tt=u)}}function at(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function ot(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function st(e){if(at(e)!==e)throw Error(r(188))}function ct(e){var t=e.alternate;if(!t){if(t=at(e),t===null)throw Error(r(188));return t===e?e:null}for(var n=e,i=t;;){var a=n.return;if(a===null)break;var o=a.alternate;if(o===null){if(i=a.return,i!==null){n=i;continue}break}if(a.child===o.child){for(o=a.child;o;){if(o===n)return st(a),e;if(o===i)return st(a),t;o=o.sibling}throw Error(r(188))}if(n.return!==i.return)n=a,i=o;else{for(var s=!1,c=a.child;c;){if(c===n){s=!0,n=a,i=o;break}if(c===i){s=!0,i=a,n=o;break}c=c.sibling}if(!s){for(c=o.child;c;){if(c===n){s=!0,n=o,i=a;break}if(c===i){s=!0,i=o,n=a;break}c=c.sibling}if(!s)throw Error(r(189))}}if(n.alternate!==i)throw Error(r(190))}if(n.tag!==3)throw Error(r(188));return n.stateNode.current===n?e:t}function lt(e){return e=ct(e),e===null?null:ut(e)}function ut(e){if(e.tag===5||e.tag===6)return e;for(e=e.child;e!==null;){var t=ut(e);if(t!==null)return t;e=e.sibling}return null}var dt=n.unstable_scheduleCallback,ft=n.unstable_cancelCallback,pt=n.unstable_shouldYield,mt=n.unstable_requestPaint,V=n.unstable_now,ht=n.unstable_getCurrentPriorityLevel,gt=n.unstable_ImmediatePriority,_t=n.unstable_UserBlockingPriority,vt=n.unstable_NormalPriority,yt=n.unstable_LowPriority,bt=n.unstable_IdlePriority,xt=null,H=null;function St(e){if(H&&typeof H.onCommitFiberRoot==`function`)try{H.onCommitFiberRoot(xt,e,void 0,(e.current.flags&128)==128)}catch{}}var Ct=Math.clz32?Math.clz32:Et,wt=Math.log,Tt=Math.LN2;function Et(e){return e>>>=0,e===0?32:31-(wt(e)/Tt|0)|0}var Dt=64,Ot=4194304;function kt(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return e&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function At(e,t){var n=e.pendingLanes;if(n===0)return 0;var r=0,i=e.suspendedLanes,a=e.pingedLanes,o=n&268435455;if(o!==0){var s=o&~i;s===0?(a&=o,a!==0&&(r=kt(a))):r=kt(s)}else o=n&~i,o===0?a!==0&&(r=kt(a)):r=kt(o);if(r===0)return 0;if(t!==0&&t!==r&&(t&i)===0&&(i=r&-r,a=t&-t,i>=a||i===16&&a&4194240))return t;if(r&4&&(r|=n&16),t=e.entangledLanes,t!==0)for(e=e.entanglements,t&=r;0<t;)n=31-Ct(t),i=1<<n,r|=e[n],t&=~i;return r}function jt(e,t){switch(e){case 1:case 2:case 4:return t+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Mt(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,i=e.expirationTimes,a=e.pendingLanes;0<a;){var o=31-Ct(a),s=1<<o,c=i[o];c===-1?((s&n)===0||(s&r)!==0)&&(i[o]=jt(s,t)):c<=t&&(e.expiredLanes|=s),a&=~s}}function Nt(e){return e=e.pendingLanes&-1073741825,e===0?e&1073741824?1073741824:0:e}function Pt(){var e=Dt;return Dt<<=1,!(Dt&4194240)&&(Dt=64),e}function Ft(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function It(e,t,n){e.pendingLanes|=t,t!==536870912&&(e.suspendedLanes=0,e.pingedLanes=0),e=e.eventTimes,t=31-Ct(t),e[t]=n}function Lt(e,t){var n=e.pendingLanes&~t;e.pendingLanes=t,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=t,e.mutableReadLanes&=t,e.entangledLanes&=t,t=e.entanglements;var r=e.eventTimes;for(e=e.expirationTimes;0<n;){var i=31-Ct(n),a=1<<i;t[i]=0,r[i]=-1,e[i]=-1,n&=~a}}function Rt(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-Ct(n),i=1<<r;i&t|e[r]&t&&(e[r]|=t),n&=~i}}var U=0;function zt(e){return e&=-e,1<e?4<e?e&268435455?16:536870912:4:1}var Bt,Vt,Ht,Ut,Wt,Gt=!1,Kt=[],qt=null,Jt=null,Yt=null,Xt=new Map,Zt=new Map,Qt=[],$t=`mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit`.split(` `);function en(e,t){switch(e){case`focusin`:case`focusout`:qt=null;break;case`dragenter`:case`dragleave`:Jt=null;break;case`mouseover`:case`mouseout`:Yt=null;break;case`pointerover`:case`pointerout`:Xt.delete(t.pointerId);break;case`gotpointercapture`:case`lostpointercapture`:Zt.delete(t.pointerId)}}function tn(e,t,n,r,i,a){return e===null||e.nativeEvent!==a?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:a,targetContainers:[i]},t!==null&&(t=Ri(t),t!==null&&Vt(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,i!==null&&t.indexOf(i)===-1&&t.push(i),e)}function nn(e,t,n,r,i){switch(t){case`focusin`:return qt=tn(qt,e,t,n,r,i),!0;case`dragenter`:return Jt=tn(Jt,e,t,n,r,i),!0;case`mouseover`:return Yt=tn(Yt,e,t,n,r,i),!0;case`pointerover`:var a=i.pointerId;return Xt.set(a,tn(Xt.get(a)||null,e,t,n,r,i)),!0;case`gotpointercapture`:return a=i.pointerId,Zt.set(a,tn(Zt.get(a)||null,e,t,n,r,i)),!0}return!1}function rn(e){var t=Li(e.target);if(t!==null){var n=at(t);if(n!==null){if(t=n.tag,t===13){if(t=ot(n),t!==null){e.blockedOn=t,Wt(e.priority,function(){Ht(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function an(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=gn(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);Ie=r,n.target.dispatchEvent(r),Ie=null}else return t=Ri(n),t!==null&&Vt(t),e.blockedOn=n,!1;t.shift()}return!0}function on(e,t,n){an(e)&&n.delete(t)}function sn(){Gt=!1,qt!==null&&an(qt)&&(qt=null),Jt!==null&&an(Jt)&&(Jt=null),Yt!==null&&an(Yt)&&(Yt=null),Xt.forEach(on),Zt.forEach(on)}function cn(e,t){e.blockedOn===t&&(e.blockedOn=null,Gt||(Gt=!0,n.unstable_scheduleCallback(n.unstable_NormalPriority,sn)))}function ln(e){function t(t){return cn(t,e)}if(0<Kt.length){cn(Kt[0],e);for(var n=1;n<Kt.length;n++){var r=Kt[n];r.blockedOn===e&&(r.blockedOn=null)}}for(qt!==null&&cn(qt,e),Jt!==null&&cn(Jt,e),Yt!==null&&cn(Yt,e),Xt.forEach(t),Zt.forEach(t),n=0;n<Qt.length;n++)r=Qt[n],r.blockedOn===e&&(r.blockedOn=null);for(;0<Qt.length&&(n=Qt[0],n.blockedOn===null);)rn(n),n.blockedOn===null&&Qt.shift()}var un=C.ReactCurrentBatchConfig,dn=!0;function fn(e,t,n,r){var i=U,a=un.transition;un.transition=null;try{U=1,mn(e,t,n,r)}finally{U=i,un.transition=a}}function pn(e,t,n,r){var i=U,a=un.transition;un.transition=null;try{U=4,mn(e,t,n,r)}finally{U=i,un.transition=a}}function mn(e,t,n,r){if(dn){var i=gn(e,t,n,r);if(i===null)li(e,t,r,hn,n),en(e,r);else if(nn(i,e,t,n,r))r.stopPropagation();else if(en(e,r),t&4&&-1<$t.indexOf(e)){for(;i!==null;){var a=Ri(i);if(a!==null&&Bt(a),a=gn(e,t,n,r),a===null&&li(e,t,r,hn,n),a===i)break;i=a}i!==null&&r.stopPropagation()}else li(e,t,r,null,n)}}var hn=null;function gn(e,t,n,r){if(hn=null,e=Le(r),e=Li(e),e!==null){if(t=at(e),t===null)e=null;else if(n=t.tag,n===13){if(e=ot(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}return hn=e,null}function _n(e){switch(e){case`cancel`:case`click`:case`close`:case`contextmenu`:case`copy`:case`cut`:case`auxclick`:case`dblclick`:case`dragend`:case`dragstart`:case`drop`:case`focusin`:case`focusout`:case`input`:case`invalid`:case`keydown`:case`keypress`:case`keyup`:case`mousedown`:case`mouseup`:case`paste`:case`pause`:case`play`:case`pointercancel`:case`pointerdown`:case`pointerup`:case`ratechange`:case`reset`:case`resize`:case`seeked`:case`submit`:case`touchcancel`:case`touchend`:case`touchstart`:case`volumechange`:case`change`:case`selectionchange`:case`textInput`:case`compositionstart`:case`compositionend`:case`compositionupdate`:case`beforeblur`:case`afterblur`:case`beforeinput`:case`blur`:case`fullscreenchange`:case`focus`:case`hashchange`:case`popstate`:case`select`:case`selectstart`:return 1;case`drag`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`mousemove`:case`mouseout`:case`mouseover`:case`pointermove`:case`pointerout`:case`pointerover`:case`scroll`:case`toggle`:case`touchmove`:case`wheel`:case`mouseenter`:case`mouseleave`:case`pointerenter`:case`pointerleave`:return 4;case`message`:switch(ht()){case gt:return 1;case _t:return 4;case vt:case yt:return 16;case bt:return 536870912;default:return 16}default:return 16}}var vn=null,yn=null,bn=null;function xn(){if(bn)return bn;var e,t=yn,n=t.length,r,i=`value`in vn?vn.value:vn.textContent,a=i.length;for(e=0;e<n&&t[e]===i[e];e++);var o=n-e;for(r=1;r<=o&&t[n-r]===i[a-r];r++);return bn=i.slice(e,1<r?1-r:void 0)}function Sn(e){var t=e.keyCode;return`charCode`in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Cn(){return!0}function wn(){return!1}function Tn(e){function t(t,n,r,i,a){for(var o in this._reactName=t,this._targetInst=r,this.type=n,this.nativeEvent=i,this.target=a,this.currentTarget=null,e)e.hasOwnProperty(o)&&(t=e[o],this[o]=t?t(i):i[o]);return this.isDefaultPrevented=(i.defaultPrevented==null?!1===i.returnValue:i.defaultPrevented)?Cn:wn,this.isPropagationStopped=wn,this}return R(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():typeof e.returnValue!=`unknown`&&(e.returnValue=!1),this.isDefaultPrevented=Cn)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():typeof e.cancelBubble!=`unknown`&&(e.cancelBubble=!0),this.isPropagationStopped=Cn)},persist:function(){},isPersistent:Cn}),t}var En={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Dn=Tn(En),On=R({},En,{view:0,detail:0}),kn=Tn(On),An,jn,Mn,Nn=R({},On,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Wn,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return`movementX`in e?e.movementX:(e!==Mn&&(Mn&&e.type===`mousemove`?(An=e.screenX-Mn.screenX,jn=e.screenY-Mn.screenY):jn=An=0,Mn=e),An)},movementY:function(e){return`movementY`in e?e.movementY:jn}}),Pn=Tn(Nn),Fn=Tn(R({},Nn,{dataTransfer:0})),In=Tn(R({},On,{relatedTarget:0})),Ln=Tn(R({},En,{animationName:0,elapsedTime:0,pseudoElement:0})),Rn=Tn(R({},En,{clipboardData:function(e){return`clipboardData`in e?e.clipboardData:window.clipboardData}})),zn=Tn(R({},En,{data:0})),Bn={Esc:`Escape`,Spacebar:` `,Left:`ArrowLeft`,Up:`ArrowUp`,Right:`ArrowRight`,Down:`ArrowDown`,Del:`Delete`,Win:`OS`,Menu:`ContextMenu`,Apps:`ContextMenu`,Scroll:`ScrollLock`,MozPrintableKey:`Unidentified`},Vn={8:`Backspace`,9:`Tab`,12:`Clear`,13:`Enter`,16:`Shift`,17:`Control`,18:`Alt`,19:`Pause`,20:`CapsLock`,27:`Escape`,32:` `,33:`PageUp`,34:`PageDown`,35:`End`,36:`Home`,37:`ArrowLeft`,38:`ArrowUp`,39:`ArrowRight`,40:`ArrowDown`,45:`Insert`,46:`Delete`,112:`F1`,113:`F2`,114:`F3`,115:`F4`,116:`F5`,117:`F6`,118:`F7`,119:`F8`,120:`F9`,121:`F10`,122:`F11`,123:`F12`,144:`NumLock`,145:`ScrollLock`,224:`Meta`},Hn={Alt:`altKey`,Control:`ctrlKey`,Meta:`metaKey`,Shift:`shiftKey`};function Un(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=Hn[e])?!!t[e]:!1}function Wn(){return Un}var Gn=Tn(R({},On,{key:function(e){if(e.key){var t=Bn[e.key]||e.key;if(t!==`Unidentified`)return t}return e.type===`keypress`?(e=Sn(e),e===13?`Enter`:String.fromCharCode(e)):e.type===`keydown`||e.type===`keyup`?Vn[e.keyCode]||`Unidentified`:``},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Wn,charCode:function(e){return e.type===`keypress`?Sn(e):0},keyCode:function(e){return e.type===`keydown`||e.type===`keyup`?e.keyCode:0},which:function(e){return e.type===`keypress`?Sn(e):e.type===`keydown`||e.type===`keyup`?e.keyCode:0}})),Kn=Tn(R({},Nn,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),qn=Tn(R({},On,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Wn})),Jn=Tn(R({},En,{propertyName:0,elapsedTime:0,pseudoElement:0})),Yn=Tn(R({},Nn,{deltaX:function(e){return`deltaX`in e?e.deltaX:`wheelDeltaX`in e?-e.wheelDeltaX:0},deltaY:function(e){return`deltaY`in e?e.deltaY:`wheelDeltaY`in e?-e.wheelDeltaY:`wheelDelta`in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0})),Xn=[9,13,27,32],Zn=c&&`CompositionEvent`in window,Qn=null;c&&`documentMode`in document&&(Qn=document.documentMode);var $n=c&&`TextEvent`in window&&!Qn,er=c&&(!Zn||Qn&&8<Qn&&11>=Qn),tr=` `,nr=!1;function rr(e,t){switch(e){case`keyup`:return Xn.indexOf(t.keyCode)!==-1;case`keydown`:return t.keyCode!==229;case`keypress`:case`mousedown`:case`focusout`:return!0;default:return!1}}function ir(e){return e=e.detail,typeof e==`object`&&`data`in e?e.data:null}var ar=!1;function or(e,t){switch(e){case`compositionend`:return ir(t);case`keypress`:return t.which===32?(nr=!0,tr):null;case`textInput`:return e=t.data,e===tr&&nr?null:e;default:return null}}function sr(e,t){if(ar)return e===`compositionend`||!Zn&&rr(e,t)?(e=xn(),bn=yn=vn=null,ar=!1,e):null;switch(e){case`paste`:return null;case`keypress`:if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case`compositionend`:return er&&t.locale!==`ko`?null:t.data;default:return null}}var cr={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function lr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t===`input`?!!cr[e.type]:t===`textarea`}function ur(e,t,n,r){He(r),t=di(t,`onChange`),0<t.length&&(n=new Dn(`onChange`,`change`,null,n,r),e.push({event:n,listeners:t}))}var dr=null,fr=null;function pr(e){ii(e,0)}function mr(e){if(de(zi(e)))return e}function hr(e,t){if(e===`change`)return t}var gr=!1;if(c){var _r;if(c){var vr=`oninput`in document;if(!vr){var yr=document.createElement(`div`);yr.setAttribute(`oninput`,`return;`),vr=typeof yr.oninput==`function`}_r=vr}else _r=!1;gr=_r&&(!document.documentMode||9<document.documentMode)}function br(){dr&&(dr.detachEvent(`onpropertychange`,xr),fr=dr=null)}function xr(e){if(e.propertyName===`value`&&mr(fr)){var t=[];ur(t,fr,e,Le(e)),qe(pr,t)}}function Sr(e,t,n){e===`focusin`?(br(),dr=t,fr=n,dr.attachEvent(`onpropertychange`,xr)):e===`focusout`&&br()}function Cr(e){if(e===`selectionchange`||e===`keyup`||e===`keydown`)return mr(fr)}function wr(e,t){if(e===`click`)return mr(t)}function Tr(e,t){if(e===`input`||e===`change`)return mr(t)}function Er(e,t){return e===t&&(e!==0||1/e==1/t)||e!==e&&t!==t}var Dr=typeof Object.is==`function`?Object.is:Er;function Or(e,t){if(Dr(e,t))return!0;if(typeof e!=`object`||!e||typeof t!=`object`||!t)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var i=n[r];if(!l.call(t,i)||!Dr(e[i],t[i]))return!1}return!0}function kr(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Ar(e,t){var n=kr(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}a:{for(;n;){if(n.nextSibling){n=n.nextSibling;break a}n=n.parentNode}n=void 0}n=kr(n)}}function jr(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?jr(e,t.parentNode):`contains`in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Mr(){for(var e=window,t=fe();t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href==`string`}catch{n=!1}if(n)e=t.contentWindow;else break;t=fe(e.document)}return t}function Nr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t===`input`&&(e.type===`text`||e.type===`search`||e.type===`tel`||e.type===`url`||e.type===`password`)||t===`textarea`||e.contentEditable===`true`)}function Pr(e){var t=Mr(),n=e.focusedElem,r=e.selectionRange;if(t!==n&&n&&n.ownerDocument&&jr(n.ownerDocument.documentElement,n)){if(r!==null&&Nr(n)){if(t=r.start,e=r.end,e===void 0&&(e=t),`selectionStart`in n)n.selectionStart=t,n.selectionEnd=Math.min(e,n.value.length);else if(e=(t=n.ownerDocument||document)&&t.defaultView||window,e.getSelection){e=e.getSelection();var i=n.textContent.length,a=Math.min(r.start,i);r=r.end===void 0?a:Math.min(r.end,i),!e.extend&&a>r&&(i=r,r=a,a=i),i=Ar(n,a);var o=Ar(n,r);i&&o&&(e.rangeCount!==1||e.anchorNode!==i.node||e.anchorOffset!==i.offset||e.focusNode!==o.node||e.focusOffset!==o.offset)&&(t=t.createRange(),t.setStart(i.node,i.offset),e.removeAllRanges(),a>r?(e.addRange(t),e.extend(o.node,o.offset)):(t.setEnd(o.node,o.offset),e.addRange(t)))}}for(t=[],e=n;e=e.parentNode;)e.nodeType===1&&t.push({element:e,left:e.scrollLeft,top:e.scrollTop});for(typeof n.focus==`function`&&n.focus(),n=0;n<t.length;n++)e=t[n],e.element.scrollLeft=e.left,e.element.scrollTop=e.top}}var Fr=c&&`documentMode`in document&&11>=document.documentMode,Ir=null,Lr=null,Rr=null,zr=!1;function Br(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;zr||Ir==null||Ir!==fe(r)||(r=Ir,`selectionStart`in r&&Nr(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),Rr&&Or(Rr,r)||(Rr=r,r=di(Lr,`onSelect`),0<r.length&&(t=new Dn(`onSelect`,`select`,null,t,n),e.push({event:t,listeners:r}),t.target=Ir)))}function Vr(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n[`Webkit`+e]=`webkit`+t,n[`Moz`+e]=`moz`+t,n}var Hr={animationend:Vr(`Animation`,`AnimationEnd`),animationiteration:Vr(`Animation`,`AnimationIteration`),animationstart:Vr(`Animation`,`AnimationStart`),transitionend:Vr(`Transition`,`TransitionEnd`)},Ur={},Wr={};c&&(Wr=document.createElement(`div`).style,`AnimationEvent`in window||(delete Hr.animationend.animation,delete Hr.animationiteration.animation,delete Hr.animationstart.animation),`TransitionEvent`in window||delete Hr.transitionend.transition);function Gr(e){if(Ur[e])return Ur[e];if(!Hr[e])return e;var t=Hr[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in Wr)return Ur[e]=t[n];return e}var Kr=Gr(`animationend`),qr=Gr(`animationiteration`),Jr=Gr(`animationstart`),Yr=Gr(`transitionend`),Xr=new Map,Zr=`abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);function Qr(e,t){Xr.set(e,t),o(t,[e])}for(var $r=0;$r<Zr.length;$r++){var ei=Zr[$r];Qr(ei.toLowerCase(),`on`+(ei[0].toUpperCase()+ei.slice(1)))}Qr(Kr,`onAnimationEnd`),Qr(qr,`onAnimationIteration`),Qr(Jr,`onAnimationStart`),Qr(`dblclick`,`onDoubleClick`),Qr(`focusin`,`onFocus`),Qr(`focusout`,`onBlur`),Qr(Yr,`onTransitionEnd`),s(`onMouseEnter`,[`mouseout`,`mouseover`]),s(`onMouseLeave`,[`mouseout`,`mouseover`]),s(`onPointerEnter`,[`pointerout`,`pointerover`]),s(`onPointerLeave`,[`pointerout`,`pointerover`]),o(`onChange`,`change click focusin focusout input keydown keyup selectionchange`.split(` `)),o(`onSelect`,`focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)),o(`onBeforeInput`,[`compositionend`,`keypress`,`textInput`,`paste`]),o(`onCompositionEnd`,`compositionend focusout keydown keypress keyup mousedown`.split(` `)),o(`onCompositionStart`,`compositionstart focusout keydown keypress keyup mousedown`.split(` `)),o(`onCompositionUpdate`,`compositionupdate focusout keydown keypress keyup mousedown`.split(` `));var ti=`abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `),ni=new Set(`cancel close invalid load scroll toggle`.split(` `).concat(ti));function ri(e,t,n){var r=e.type||`unknown-event`;e.currentTarget=n,it(r,t,void 0,e),e.currentTarget=null}function ii(e,t){t=!!(t&4);for(var n=0;n<e.length;n++){var r=e[n],i=r.event;r=r.listeners;a:{var a=void 0;if(t)for(var o=r.length-1;0<=o;o--){var s=r[o],c=s.instance,l=s.currentTarget;if(s=s.listener,c!==a&&i.isPropagationStopped())break a;ri(i,s,l),a=c}else for(o=0;o<r.length;o++){if(s=r[o],c=s.instance,l=s.currentTarget,s=s.listener,c!==a&&i.isPropagationStopped())break a;ri(i,s,l),a=c}}}if(et)throw e=tt,et=!1,tt=null,e}function W(e,t){var n=t[Pi];n===void 0&&(n=t[Pi]=new Set);var r=e+`__bubble`;n.has(r)||(ci(t,e,2,!1),n.add(r))}function ai(e,t,n){var r=0;t&&(r|=4),ci(n,e,r,t)}var oi=`_reactListening`+Math.random().toString(36).slice(2);function si(e){if(!e[oi]){e[oi]=!0,i.forEach(function(t){t!==`selectionchange`&&(ni.has(t)||ai(t,!1,e),ai(t,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[oi]||(t[oi]=!0,ai(`selectionchange`,!1,t))}}function ci(e,t,n,r){switch(_n(t)){case 1:var i=fn;break;case 4:i=pn;break;default:i=mn}n=i.bind(null,t,n,e),i=void 0,!Ye||t!==`touchstart`&&t!==`touchmove`&&t!==`wheel`||(i=!0),r?i===void 0?e.addEventListener(t,n,!0):e.addEventListener(t,n,{capture:!0,passive:i}):i===void 0?e.addEventListener(t,n,!1):e.addEventListener(t,n,{passive:i})}function li(e,t,n,r,i){var a=r;if(!(t&1)&&!(t&2)&&r!==null)a:for(;;){if(r===null)return;var o=r.tag;if(o===3||o===4){var s=r.stateNode.containerInfo;if(s===i||s.nodeType===8&&s.parentNode===i)break;if(o===4)for(o=r.return;o!==null;){var c=o.tag;if((c===3||c===4)&&(c=o.stateNode.containerInfo,c===i||c.nodeType===8&&c.parentNode===i))return;o=o.return}for(;s!==null;){if(o=Li(s),o===null)return;if(c=o.tag,c===5||c===6){r=a=o;continue a}s=s.parentNode}}r=r.return}qe(function(){var r=a,i=Le(n),o=[];a:{var s=Xr.get(e);if(s!==void 0){var c=Dn,l=e;switch(e){case`keypress`:if(Sn(n)===0)break a;case`keydown`:case`keyup`:c=Gn;break;case`focusin`:l=`focus`,c=In;break;case`focusout`:l=`blur`,c=In;break;case`beforeblur`:case`afterblur`:c=In;break;case`click`:if(n.button===2)break a;case`auxclick`:case`dblclick`:case`mousedown`:case`mousemove`:case`mouseup`:case`mouseout`:case`mouseover`:case`contextmenu`:c=Pn;break;case`drag`:case`dragend`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`dragstart`:case`drop`:c=Fn;break;case`touchcancel`:case`touchend`:case`touchmove`:case`touchstart`:c=qn;break;case Kr:case qr:case Jr:c=Ln;break;case Yr:c=Jn;break;case`scroll`:c=kn;break;case`wheel`:c=Yn;break;case`copy`:case`cut`:case`paste`:c=Rn;break;case`gotpointercapture`:case`lostpointercapture`:case`pointercancel`:case`pointerdown`:case`pointermove`:case`pointerout`:case`pointerover`:case`pointerup`:c=Kn}var u=!!(t&4),d=!u&&e===`scroll`,f=u?s===null?null:s+`Capture`:s;u=[];for(var p=r,m;p!==null;){m=p;var h=m.stateNode;if(m.tag===5&&h!==null&&(m=h,f!==null&&(h=Je(p,f),h!=null&&u.push(ui(p,h,m)))),d)break;p=p.return}0<u.length&&(s=new c(s,l,null,n,i),o.push({event:s,listeners:u}))}}if(!(t&7)){a:{if(s=e===`mouseover`||e===`pointerover`,c=e===`mouseout`||e===`pointerout`,s&&n!==Ie&&(l=n.relatedTarget||n.fromElement)&&(Li(l)||l[Ni]))break a;if((c||s)&&(s=i.window===i?i:(s=i.ownerDocument)?s.defaultView||s.parentWindow:window,c?(l=n.relatedTarget||n.toElement,c=r,l=l?Li(l):null,l!==null&&(d=at(l),l!==d||l.tag!==5&&l.tag!==6)&&(l=null)):(c=null,l=r),c!==l)){if(u=Pn,h=`onMouseLeave`,f=`onMouseEnter`,p=`mouse`,(e===`pointerout`||e===`pointerover`)&&(u=Kn,h=`onPointerLeave`,f=`onPointerEnter`,p=`pointer`),d=c==null?s:zi(c),m=l==null?s:zi(l),s=new u(h,p+`leave`,c,n,i),s.target=d,s.relatedTarget=m,h=null,Li(i)===r&&(u=new u(f,p+`enter`,l,n,i),u.target=m,u.relatedTarget=d,h=u),d=h,c&&l)b:{for(u=c,f=l,p=0,m=u;m;m=fi(m))p++;for(m=0,h=f;h;h=fi(h))m++;for(;0<p-m;)u=fi(u),p--;for(;0<m-p;)f=fi(f),m--;for(;p--;){if(u===f||f!==null&&u===f.alternate)break b;u=fi(u),f=fi(f)}u=null}else u=null;c!==null&&pi(o,s,c,u,!1),l!==null&&d!==null&&pi(o,d,l,u,!0)}}a:{if(s=r?zi(r):window,c=s.nodeName&&s.nodeName.toLowerCase(),c===`select`||c===`input`&&s.type===`file`)var g=hr;else if(lr(s)){if(gr)g=Tr;else{g=Cr;var _=Sr}}else(c=s.nodeName)&&c.toLowerCase()===`input`&&(s.type===`checkbox`||s.type===`radio`)&&(g=wr);if(g&&=g(e,r)){ur(o,g,n,i);break a}_&&_(e,s,r),e===`focusout`&&(_=s._wrapperState)&&_.controlled&&s.type===`number`&&ve(s,`number`,s.value)}switch(_=r?zi(r):window,e){case`focusin`:(lr(_)||_.contentEditable===`true`)&&(Ir=_,Lr=r,Rr=null);break;case`focusout`:Rr=Lr=Ir=null;break;case`mousedown`:zr=!0;break;case`contextmenu`:case`mouseup`:case`dragend`:zr=!1,Br(o,n,i);break;case`selectionchange`:if(Fr)break;case`keydown`:case`keyup`:Br(o,n,i)}var v;if(Zn)b:{switch(e){case`compositionstart`:var y=`onCompositionStart`;break b;case`compositionend`:y=`onCompositionEnd`;break b;case`compositionupdate`:y=`onCompositionUpdate`;break b}y=void 0}else ar?rr(e,n)&&(y=`onCompositionEnd`):e===`keydown`&&n.keyCode===229&&(y=`onCompositionStart`);y&&(er&&n.locale!==`ko`&&(ar||y!==`onCompositionStart`?y===`onCompositionEnd`&&ar&&(v=xn()):(vn=i,yn=`value`in vn?vn.value:vn.textContent,ar=!0)),_=di(r,y),0<_.length&&(y=new zn(y,e,null,n,i),o.push({event:y,listeners:_}),v?y.data=v:(v=ir(n),v!==null&&(y.data=v)))),(v=$n?or(e,n):sr(e,n))&&(r=di(r,`onBeforeInput`),0<r.length&&(i=new zn(`onBeforeInput`,`beforeinput`,null,n,i),o.push({event:i,listeners:r}),i.data=v))}ii(o,t)})}function ui(e,t,n){return{instance:e,listener:t,currentTarget:n}}function di(e,t){for(var n=t+`Capture`,r=[];e!==null;){var i=e,a=i.stateNode;i.tag===5&&a!==null&&(i=a,a=Je(e,n),a!=null&&r.unshift(ui(e,a,i)),a=Je(e,t),a!=null&&r.push(ui(e,a,i))),e=e.return}return r}function fi(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5);return e||null}function pi(e,t,n,r,i){for(var a=t._reactName,o=[];n!==null&&n!==r;){var s=n,c=s.alternate,l=s.stateNode;if(c!==null&&c===r)break;s.tag===5&&l!==null&&(s=l,i?(c=Je(n,a),c!=null&&o.unshift(ui(n,c,s))):i||(c=Je(n,a),c!=null&&o.push(ui(n,c,s)))),n=n.return}o.length!==0&&e.push({event:t,listeners:o})}var mi=/\r\n?/g,hi=/\u0000|\uFFFD/g;function gi(e){return(typeof e==`string`?e:``+e).replace(mi,`
`).replace(hi,``)}function _i(e,t,n){if(t=gi(t),gi(e)!==t&&n)throw Error(r(425))}function vi(){}var yi=null,bi=null;function xi(e,t){return e===`textarea`||e===`noscript`||typeof t.children==`string`||typeof t.children==`number`||typeof t.dangerouslySetInnerHTML==`object`&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Si=typeof setTimeout==`function`?setTimeout:void 0,Ci=typeof clearTimeout==`function`?clearTimeout:void 0,wi=typeof Promise==`function`?Promise:void 0,Ti=typeof queueMicrotask==`function`?queueMicrotask:wi===void 0?Si:function(e){return wi.resolve(null).then(e).catch(Ei)};function Ei(e){setTimeout(function(){throw e})}function Di(e,t){var n=t,r=0;do{var i=n.nextSibling;if(e.removeChild(n),i&&i.nodeType===8){if(n=i.data,n===`/$`){if(r===0){e.removeChild(i),ln(t);return}r--}else n!==`$`&&n!==`$?`&&n!==`$!`||r++}n=i}while(n);ln(t)}function Oi(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t===`$`||t===`$!`||t===`$?`)break;if(t===`/$`)return null}}return e}function ki(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`$`||n===`$!`||n===`$?`){if(t===0)return e;t--}else n===`/$`&&t++}e=e.previousSibling}return null}var Ai=Math.random().toString(36).slice(2),ji=`__reactFiber$`+Ai,Mi=`__reactProps$`+Ai,Ni=`__reactContainer$`+Ai,Pi=`__reactEvents$`+Ai,Fi=`__reactListeners$`+Ai,Ii=`__reactHandles$`+Ai;function Li(e){var t=e[ji];if(t)return t;for(var n=e.parentNode;n;){if(t=n[Ni]||n[ji]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=ki(e);e!==null;){if(n=e[ji])return n;e=ki(e)}return t}e=n,n=e.parentNode}return null}function Ri(e){return e=e[ji]||e[Ni],!e||e.tag!==5&&e.tag!==6&&e.tag!==13&&e.tag!==3?null:e}function zi(e){if(e.tag===5||e.tag===6)return e.stateNode;throw Error(r(33))}function Bi(e){return e[Mi]||null}var Vi=[],Hi=-1;function Ui(e){return{current:e}}function G(e){0>Hi||(e.current=Vi[Hi],Vi[Hi]=null,Hi--)}function K(e,t){Hi++,Vi[Hi]=e.current,e.current=t}var Wi={},Gi=Ui(Wi),Ki=Ui(!1),qi=Wi;function Ji(e,t){var n=e.type.contextTypes;if(!n)return Wi;var r=e.stateNode;if(r&&r.__reactInternalMemoizedUnmaskedChildContext===t)return r.__reactInternalMemoizedMaskedChildContext;var i={},a;for(a in n)i[a]=t[a];return r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=t,e.__reactInternalMemoizedMaskedChildContext=i),i}function Yi(e){return e=e.childContextTypes,e!=null}function Xi(){G(Ki),G(Gi)}function Zi(e,t,n){if(Gi.current!==Wi)throw Error(r(168));K(Gi,t),K(Ki,n)}function Qi(e,t,n){var i=e.stateNode;if(t=t.childContextTypes,typeof i.getChildContext!=`function`)return n;for(var a in i=i.getChildContext(),i)if(!(a in t))throw Error(r(108,oe(e)||`Unknown`,a));return R({},n,i)}function $i(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||Wi,qi=Gi.current,K(Gi,e),K(Ki,Ki.current),!0}function ea(e,t,n){var i=e.stateNode;if(!i)throw Error(r(169));n?(e=Qi(e,t,qi),i.__reactInternalMemoizedMergedChildContext=e,G(Ki),G(Gi),K(Gi,e)):G(Ki),K(Ki,n)}var ta=null,na=!1,ra=!1;function ia(e){ta===null?ta=[e]:ta.push(e)}function aa(e){na=!0,ia(e)}function oa(){if(!ra&&ta!==null){ra=!0;var e=0,t=U;try{var n=ta;for(U=1;e<n.length;e++){var r=n[e];do r=r(!0);while(r!==null)}ta=null,na=!1}catch(t){throw ta!==null&&(ta=ta.slice(e+1)),dt(gt,oa),t}finally{U=t,ra=!1}}return null}var sa=[],ca=0,la=null,ua=0,da=[],fa=0,pa=null,ma=1,ha=``;function ga(e,t){sa[ca++]=ua,sa[ca++]=la,la=e,ua=t}function _a(e,t,n){da[fa++]=ma,da[fa++]=ha,da[fa++]=pa,pa=e;var r=ma;e=ha;var i=32-Ct(r)-1;r&=~(1<<i),n+=1;var a=32-Ct(t)+i;if(30<a){var o=i-i%5;a=(r&(1<<o)-1).toString(32),r>>=o,i-=o,ma=1<<32-Ct(t)+i|n<<i|r,ha=a+e}else ma=1<<a|n<<i|r,ha=e}function va(e){e.return!==null&&(ga(e,1),_a(e,1,0))}function ya(e){for(;e===la;)la=sa[--ca],sa[ca]=null,ua=sa[--ca],sa[ca]=null;for(;e===pa;)pa=da[--fa],da[fa]=null,ha=da[--fa],da[fa]=null,ma=da[--fa],da[fa]=null}var ba=null,xa=null,q=!1,Sa=null;function Ca(e,t){var n=Kl(5,null,null,0);n.elementType=`DELETED`,n.stateNode=t,n.return=e,t=e.deletions,t===null?(e.deletions=[n],e.flags|=16):t.push(n)}function wa(e,t){switch(e.tag){case 5:var n=e.type;return t=t.nodeType!==1||n.toLowerCase()!==t.nodeName.toLowerCase()?null:t,t!==null&&(e.stateNode=t,ba=e,xa=Oi(t.firstChild),!0);case 6:return t=e.pendingProps===``||t.nodeType!==3?null:t,t!==null&&(e.stateNode=t,ba=e,xa=null,!0);case 13:return t=t.nodeType===8?t:null,t!==null&&(n=pa===null?null:{id:ma,overflow:ha},e.memoizedState={dehydrated:t,treeContext:n,retryLane:1073741824},n=Kl(18,null,null,0),n.stateNode=t,n.return=e,e.child=n,ba=e,xa=null,!0);default:return!1}}function Ta(e){return!!(e.mode&1)&&!(e.flags&128)}function Ea(e){if(q){var t=xa;if(t){var n=t;if(!wa(e,t)){if(Ta(e))throw Error(r(418));t=Oi(n.nextSibling);var i=ba;t&&wa(e,t)?Ca(i,n):(e.flags=e.flags&-4097|2,q=!1,ba=e)}}else{if(Ta(e))throw Error(r(418));e.flags=e.flags&-4097|2,q=!1,ba=e}}}function Da(e){for(e=e.return;e!==null&&e.tag!==5&&e.tag!==3&&e.tag!==13;)e=e.return;ba=e}function Oa(e){if(e!==ba)return!1;if(!q)return Da(e),q=!0,!1;var t;if((t=e.tag!==3)&&!(t=e.tag!==5)&&(t=e.type,t=t!==`head`&&t!==`body`&&!xi(e.type,e.memoizedProps)),t&&=xa){if(Ta(e))throw ka(),Error(r(418));for(;t;)Ca(e,t),t=Oi(t.nextSibling)}if(Da(e),e.tag===13){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(r(317));a:{for(e=e.nextSibling,t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`/$`){if(t===0){xa=Oi(e.nextSibling);break a}t--}else n!==`$`&&n!==`$!`&&n!==`$?`||t++}e=e.nextSibling}xa=null}}else xa=ba?Oi(e.stateNode.nextSibling):null;return!0}function ka(){for(var e=xa;e;)e=Oi(e.nextSibling)}function Aa(){xa=ba=null,q=!1}function ja(e){Sa===null?Sa=[e]:Sa.push(e)}var Ma=C.ReactCurrentBatchConfig;function Na(e,t,n){if(e=n.ref,e!==null&&typeof e!=`function`&&typeof e!=`object`){if(n._owner){if(n=n._owner,n){if(n.tag!==1)throw Error(r(309));var i=n.stateNode}if(!i)throw Error(r(147,e));var a=i,o=``+e;return t!==null&&t.ref!==null&&typeof t.ref==`function`&&t.ref._stringRef===o?t.ref:(t=function(e){var t=a.refs;e===null?delete t[o]:t[o]=e},t._stringRef=o,t)}if(typeof e!=`string`)throw Error(r(284));if(!n._owner)throw Error(r(290,e))}return e}function Pa(e,t){throw e=Object.prototype.toString.call(t),Error(r(31,e===`[object Object]`?`object with keys {`+Object.keys(t).join(`, `)+`}`:e))}function Fa(e){var t=e._init;return t(e._payload)}function Ia(e){function t(t,n){if(e){var r=t.deletions;r===null?(t.deletions=[n],t.flags|=16):r.push(n)}}function n(n,r){if(!e)return null;for(;r!==null;)t(n,r),r=r.sibling;return null}function i(e,t){for(e=new Map;t!==null;)t.key===null?e.set(t.index,t):e.set(t.key,t),t=t.sibling;return e}function a(e,t){return e=Yl(e,t),e.index=0,e.sibling=null,e}function o(t,n,r){return t.index=r,e?(r=t.alternate,r===null?(t.flags|=2,n):(r=r.index,r<n?(t.flags|=2,n):r)):(t.flags|=1048576,n)}function s(t){return e&&t.alternate===null&&(t.flags|=2),t}function c(e,t,n,r){return t===null||t.tag!==6?(t=$l(n,e.mode,r),t.return=e,t):(t=a(t,n),t.return=e,t)}function l(e,t,n,r){var i=n.type;return i===E?d(e,t,n.props.children,r,n.key):t!==null&&(t.elementType===i||typeof i==`object`&&i&&i.$$typeof===F&&Fa(i)===t.type)?(r=a(t,n.props),r.ref=Na(e,t,n),r.return=e,r):(r=Xl(n.type,n.key,n.props,null,e.mode,r),r.ref=Na(e,t,n),r.return=e,r)}function u(e,t,n,r){return t===null||t.tag!==4||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?(t=eu(n,e.mode,r),t.return=e,t):(t=a(t,n.children||[]),t.return=e,t)}function d(e,t,n,r,i){return t===null||t.tag!==7?(t=Zl(n,e.mode,r,i),t.return=e,t):(t=a(t,n),t.return=e,t)}function f(e,t,n){if(typeof t==`string`&&t!==``||typeof t==`number`)return t=$l(``+t,e.mode,n),t.return=e,t;if(typeof t==`object`&&t){switch(t.$$typeof){case w:return n=Xl(t.type,t.key,t.props,null,e.mode,n),n.ref=Na(e,null,t),n.return=e,n;case T:return t=eu(t,e.mode,n),t.return=e,t;case F:var r=t._init;return f(e,r(t._payload),n)}if(ye(t)||L(t))return t=Zl(t,e.mode,n,null),t.return=e,t;Pa(e,t)}return null}function p(e,t,n,r){var i=t===null?null:t.key;if(typeof n==`string`&&n!==``||typeof n==`number`)return i===null?c(e,t,``+n,r):null;if(typeof n==`object`&&n){switch(n.$$typeof){case w:return n.key===i?l(e,t,n,r):null;case T:return n.key===i?u(e,t,n,r):null;case F:return i=n._init,p(e,t,i(n._payload),r)}if(ye(n)||L(n))return i===null?d(e,t,n,r,null):null;Pa(e,n)}return null}function m(e,t,n,r,i){if(typeof r==`string`&&r!==``||typeof r==`number`)return e=e.get(n)||null,c(t,e,``+r,i);if(typeof r==`object`&&r){switch(r.$$typeof){case w:return e=e.get(r.key===null?n:r.key)||null,l(t,e,r,i);case T:return e=e.get(r.key===null?n:r.key)||null,u(t,e,r,i);case F:var a=r._init;return m(e,t,n,a(r._payload),i)}if(ye(r)||L(r))return e=e.get(n)||null,d(t,e,r,i,null);Pa(t,r)}return null}function h(r,a,s,c){for(var l=null,u=null,d=a,h=a=0,g=null;d!==null&&h<s.length;h++){d.index>h?(g=d,d=null):g=d.sibling;var _=p(r,d,s[h],c);if(_===null){d===null&&(d=g);break}e&&d&&_.alternate===null&&t(r,d),a=o(_,a,h),u===null?l=_:u.sibling=_,u=_,d=g}if(h===s.length)return n(r,d),q&&ga(r,h),l;if(d===null){for(;h<s.length;h++)d=f(r,s[h],c),d!==null&&(a=o(d,a,h),u===null?l=d:u.sibling=d,u=d);return q&&ga(r,h),l}for(d=i(r,d);h<s.length;h++)g=m(d,r,h,s[h],c),g!==null&&(e&&g.alternate!==null&&d.delete(g.key===null?h:g.key),a=o(g,a,h),u===null?l=g:u.sibling=g,u=g);return e&&d.forEach(function(e){return t(r,e)}),q&&ga(r,h),l}function g(a,s,c,l){var u=L(c);if(typeof u!=`function`)throw Error(r(150));if(c=u.call(c),c==null)throw Error(r(151));for(var d=u=null,h=s,g=s=0,_=null,v=c.next();h!==null&&!v.done;g++,v=c.next()){h.index>g?(_=h,h=null):_=h.sibling;var y=p(a,h,v.value,l);if(y===null){h===null&&(h=_);break}e&&h&&y.alternate===null&&t(a,h),s=o(y,s,g),d===null?u=y:d.sibling=y,d=y,h=_}if(v.done)return n(a,h),q&&ga(a,g),u;if(h===null){for(;!v.done;g++,v=c.next())v=f(a,v.value,l),v!==null&&(s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return q&&ga(a,g),u}for(h=i(a,h);!v.done;g++,v=c.next())v=m(h,a,g,v.value,l),v!==null&&(e&&v.alternate!==null&&h.delete(v.key===null?g:v.key),s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return e&&h.forEach(function(e){return t(a,e)}),q&&ga(a,g),u}function _(e,r,i,o){if(typeof i==`object`&&i&&i.type===E&&i.key===null&&(i=i.props.children),typeof i==`object`&&i){switch(i.$$typeof){case w:a:{for(var c=i.key,l=r;l!==null;){if(l.key===c){if(c=i.type,c===E){if(l.tag===7){n(e,l.sibling),r=a(l,i.props.children),r.return=e,e=r;break a}}else if(l.elementType===c||typeof c==`object`&&c&&c.$$typeof===F&&Fa(c)===l.type){n(e,l.sibling),r=a(l,i.props),r.ref=Na(e,l,i),r.return=e,e=r;break a}n(e,l);break}t(e,l),l=l.sibling}i.type===E?(r=Zl(i.props.children,e.mode,o,i.key),r.return=e,e=r):(o=Xl(i.type,i.key,i.props,null,e.mode,o),o.ref=Na(e,r,i),o.return=e,e=o)}return s(e);case T:a:{for(l=i.key;r!==null;){if(r.key===l){if(r.tag===4&&r.stateNode.containerInfo===i.containerInfo&&r.stateNode.implementation===i.implementation){n(e,r.sibling),r=a(r,i.children||[]),r.return=e,e=r;break a}n(e,r);break}t(e,r),r=r.sibling}r=eu(i,e.mode,o),r.return=e,e=r}return s(e);case F:return l=i._init,_(e,r,l(i._payload),o)}if(ye(i))return h(e,r,i,o);if(L(i))return g(e,r,i,o);Pa(e,i)}return typeof i==`string`&&i!==``||typeof i==`number`?(i=``+i,r!==null&&r.tag===6?(n(e,r.sibling),r=a(r,i),r.return=e,e=r):(n(e,r),r=$l(i,e.mode,o),r.return=e,e=r),s(e)):n(e,r)}return _}var La=Ia(!0),Ra=Ia(!1),za=Ui(null),Ba=null,Va=null,Ha=null;function Ua(){Ha=Va=Ba=null}function Wa(e){var t=za.current;G(za),e._currentValue=t}function Ga(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)===t?r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t):(e.childLanes|=t,r!==null&&(r.childLanes|=t)),e===n)break;e=e.return}}function Ka(e,t){Ba=e,Ha=Va=null,e=e.dependencies,e!==null&&e.firstContext!==null&&((e.lanes&t)!==0&&(Ps=!0),e.firstContext=null)}function qa(e){var t=e._currentValue;if(Ha!==e){if(e={context:e,memoizedValue:t,next:null},Va===null){if(Ba===null)throw Error(r(308));Va=e,Ba.dependencies={lanes:0,firstContext:e}}else Va=Va.next=e}return t}var Ja=null;function Ya(e){Ja===null?Ja=[e]:Ja.push(e)}function Xa(e,t,n,r){var i=t.interleaved;return i===null?(n.next=n,Ya(t)):(n.next=i.next,i.next=n),t.interleaved=n,Za(e,r)}function Za(e,t){e.lanes|=t;var n=e.alternate;for(n!==null&&(n.lanes|=t),n=e,e=e.return;e!==null;)e.childLanes|=t,n=e.alternate,n!==null&&(n.childLanes|=t),n=e,e=e.return;return n.tag===3?n.stateNode:null}var Qa=!1;function $a(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function eo(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function to(e,t){return{eventTime:e,lane:t,tag:0,payload:null,callback:null,next:null}}function no(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,Z&2){var i=r.pending;return i===null?t.next=t:(t.next=i.next,i.next=t),r.pending=t,Za(e,n)}return i=r.interleaved,i===null?(t.next=t,Ya(r)):(t.next=i.next,i.next=t),r.interleaved=t,Za(e,n)}function ro(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,n&4194240)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Rt(e,n)}}function io(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var i=null,a=null;if(n=n.firstBaseUpdate,n!==null){do{var o={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};a===null?i=a=o:a=a.next=o,n=n.next}while(n!==null);a===null?i=a=t:a=a.next=t}else i=a=t;n={baseState:r.baseState,firstBaseUpdate:i,lastBaseUpdate:a,shared:r.shared,effects:r.effects},e.updateQueue=n}else e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}function ao(e,t,n,r){var i=e.updateQueue;Qa=!1;var a=i.firstBaseUpdate,o=i.lastBaseUpdate,s=i.shared.pending;if(s!==null){i.shared.pending=null;var c=s,l=c.next;c.next=null,o===null?a=l:o.next=l,o=c;var u=e.alternate;u!==null&&(u=u.updateQueue,s=u.lastBaseUpdate,s!==o&&(s===null?u.firstBaseUpdate=l:s.next=l,u.lastBaseUpdate=c))}if(a!==null){var d=i.baseState;o=0,u=l=c=null,s=a;do{var f=s.lane,p=s.eventTime;if((r&f)===f){u!==null&&(u=u.next={eventTime:p,lane:0,tag:s.tag,payload:s.payload,callback:s.callback,next:null});a:{var m=e,h=s;switch(f=t,p=n,h.tag){case 1:if(m=h.payload,typeof m==`function`){d=m.call(p,d,f);break a}d=m;break a;case 3:m.flags=m.flags&-65537|128;case 0:if(m=h.payload,f=typeof m==`function`?m.call(p,d,f):m,f==null)break a;d=R({},d,f);break a;case 2:Qa=!0}}s.callback!==null&&s.lane!==0&&(e.flags|=64,f=i.effects,f===null?i.effects=[s]:f.push(s))}else p={eventTime:p,lane:f,tag:s.tag,payload:s.payload,callback:s.callback,next:null},u===null?(l=u=p,c=d):u=u.next=p,o|=f;if(s=s.next,s===null){if(s=i.shared.pending,s===null)break;f=s,s=f.next,f.next=null,i.lastBaseUpdate=f,i.shared.pending=null}}while(1);if(u===null&&(c=d),i.baseState=c,i.firstBaseUpdate=l,i.lastBaseUpdate=u,t=i.shared.interleaved,t!==null){i=t;do o|=i.lane,i=i.next;while(i!==t)}else a===null&&(i.shared.lanes=0);Yc|=o,e.lanes=o,e.memoizedState=d}}function oo(e,t,n){if(e=t.effects,t.effects=null,e!==null)for(t=0;t<e.length;t++){var i=e[t],a=i.callback;if(a!==null){if(i.callback=null,i=n,typeof a!=`function`)throw Error(r(191,a));a.call(i)}}}var so={},co=Ui(so),lo=Ui(so),uo=Ui(so);function fo(e){if(e===so)throw Error(r(174));return e}function po(e,t){switch(K(uo,t),K(lo,e),K(co,so),e=t.nodeType,e){case 9:case 11:t=(t=t.documentElement)?t.namespaceURI:B(null,``);break;default:e=e===8?t.parentNode:t,t=e.namespaceURI||null,e=e.tagName,t=B(t,e)}G(co),K(co,t)}function mo(){G(co),G(lo),G(uo)}function ho(e){fo(uo.current);var t=fo(co.current),n=B(t,e.type);t!==n&&(K(lo,e),K(co,n))}function go(e){lo.current===e&&(G(co),G(lo))}var J=Ui(0);function _o(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||n.data===`$?`||n.data===`$!`))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!==void 0){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var vo=[];function yo(){for(var e=0;e<vo.length;e++)vo[e]._workInProgressVersionPrimary=null;vo.length=0}var bo=C.ReactCurrentDispatcher,xo=C.ReactCurrentBatchConfig,So=0,Y=null,Co=null,wo=null,To=!1,Eo=!1,Do=0,Oo=0;function ko(){throw Error(r(321))}function Ao(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!Dr(e[n],t[n]))return!1;return!0}function jo(e,t,n,i,a,o){if(So=o,Y=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,bo.current=e===null||e.memoizedState===null?ms:hs,e=n(i,a),Eo){o=0;do{if(Eo=!1,Do=0,25<=o)throw Error(r(301));o+=1,wo=Co=null,t.updateQueue=null,bo.current=gs,e=n(i,a)}while(Eo)}if(bo.current=ps,t=Co!==null&&Co.next!==null,So=0,wo=Co=Y=null,To=!1,t)throw Error(r(300));return e}function Mo(){var e=Do!==0;return Do=0,e}function No(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return wo===null?Y.memoizedState=wo=e:wo=wo.next=e,wo}function Po(){if(Co===null){var e=Y.alternate;e=e===null?null:e.memoizedState}else e=Co.next;var t=wo===null?Y.memoizedState:wo.next;if(t!==null)wo=t,Co=e;else{if(e===null)throw Error(r(310));Co=e,e={memoizedState:Co.memoizedState,baseState:Co.baseState,baseQueue:Co.baseQueue,queue:Co.queue,next:null},wo===null?Y.memoizedState=wo=e:wo=wo.next=e}return wo}function Fo(e,t){return typeof t==`function`?t(e):t}function Io(e){var t=Po(),n=t.queue;if(n===null)throw Error(r(311));n.lastRenderedReducer=e;var i=Co,a=i.baseQueue,o=n.pending;if(o!==null){if(a!==null){var s=a.next;a.next=o.next,o.next=s}i.baseQueue=a=o,n.pending=null}if(a!==null){o=a.next,i=i.baseState;var c=s=null,l=null,u=o;do{var d=u.lane;if((So&d)===d)l!==null&&(l=l.next={lane:0,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),i=u.hasEagerState?u.eagerState:e(i,u.action);else{var f={lane:d,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null};l===null?(c=l=f,s=i):l=l.next=f,Y.lanes|=d,Yc|=d}u=u.next}while(u!==null&&u!==o);l===null?s=i:l.next=c,Dr(i,t.memoizedState)||(Ps=!0),t.memoizedState=i,t.baseState=s,t.baseQueue=l,n.lastRenderedState=i}if(e=n.interleaved,e!==null){a=e;do o=a.lane,Y.lanes|=o,Yc|=o,a=a.next;while(a!==e)}else a===null&&(n.lanes=0);return[t.memoizedState,n.dispatch]}function Lo(e){var t=Po(),n=t.queue;if(n===null)throw Error(r(311));n.lastRenderedReducer=e;var i=n.dispatch,a=n.pending,o=t.memoizedState;if(a!==null){n.pending=null;var s=a=a.next;do o=e(o,s.action),s=s.next;while(s!==a);Dr(o,t.memoizedState)||(Ps=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),n.lastRenderedState=o}return[o,i]}function Ro(){}function zo(e,t){var n=Y,i=Po(),a=t(),o=!Dr(i.memoizedState,a);if(o&&(i.memoizedState=a,Ps=!0),i=i.queue,Zo(Ho.bind(null,n,i,e),[e]),i.getSnapshot!==t||o||wo!==null&&wo.memoizedState.tag&1){if(n.flags|=2048,Ko(9,Vo.bind(null,n,i,a,t),void 0,null),Uc===null)throw Error(r(349));So&30||Bo(n,t,a)}return a}function Bo(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=Y.updateQueue,t===null?(t={lastEffect:null,stores:null},Y.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function Vo(e,t,n,r){t.value=n,t.getSnapshot=r,Uo(t)&&Wo(e)}function Ho(e,t,n){return n(function(){Uo(t)&&Wo(e)})}function Uo(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Dr(e,n)}catch{return!0}}function Wo(e){var t=Za(e,1);t!==null&&hl(t,e,1,-1)}function Go(e){var t=No();return typeof e==`function`&&(e=e()),t.memoizedState=t.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:Fo,lastRenderedState:e},t.queue=e,e=e.dispatch=ls.bind(null,Y,e),[t.memoizedState,e]}function Ko(e,t,n,r){return e={tag:e,create:t,destroy:n,deps:r,next:null},t=Y.updateQueue,t===null?(t={lastEffect:null,stores:null},Y.updateQueue=t,t.lastEffect=e.next=e):(n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e)),e}function qo(){return Po().memoizedState}function Jo(e,t,n,r){var i=No();Y.flags|=e,i.memoizedState=Ko(1|t,n,void 0,r===void 0?null:r)}function Yo(e,t,n,r){var i=Po();r=r===void 0?null:r;var a=void 0;if(Co!==null){var o=Co.memoizedState;if(a=o.destroy,r!==null&&Ao(r,o.deps)){i.memoizedState=Ko(t,n,a,r);return}}Y.flags|=e,i.memoizedState=Ko(1|t,n,a,r)}function Xo(e,t){return Jo(8390656,8,e,t)}function Zo(e,t){return Yo(2048,8,e,t)}function Qo(e,t){return Yo(4,2,e,t)}function $o(e,t){return Yo(4,4,e,t)}function es(e,t){if(typeof t==`function`)return e=e(),t(e),function(){t(null)};if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function ts(e,t,n){return n=n==null?null:n.concat([e]),Yo(4,4,es.bind(null,t,e),n)}function ns(){}function rs(e,t){var n=Po();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&Ao(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function is(e,t){var n=Po();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&Ao(t,r[1])?r[0]:(e=e(),n.memoizedState=[e,t],e)}function as(e,t,n){return So&21?(Dr(n,t)||(n=Pt(),Y.lanes|=n,Yc|=n,e.baseState=!0),t):(e.baseState&&(e.baseState=!1,Ps=!0),e.memoizedState=n)}function os(e,t){var n=U;U=n!==0&&4>n?n:4,e(!0);var r=xo.transition;xo.transition={};try{e(!1),t()}finally{U=n,xo.transition=r}}function ss(){return Po().memoizedState}function cs(e,t,n){var r=ml(e);if(n={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null},us(e))ds(t,n);else if(n=Xa(e,t,n,r),n!==null){var i=pl();hl(n,e,r,i),fs(n,t,r)}}function ls(e,t,n){var r=ml(e),i={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null};if(us(e))ds(t,i);else{var a=e.alternate;if(e.lanes===0&&(a===null||a.lanes===0)&&(a=t.lastRenderedReducer,a!==null))try{var o=t.lastRenderedState,s=a(o,n);if(i.hasEagerState=!0,i.eagerState=s,Dr(s,o)){var c=t.interleaved;c===null?(i.next=i,Ya(t)):(i.next=c.next,c.next=i),t.interleaved=i;return}}catch{}n=Xa(e,t,i,r),n!==null&&(i=pl(),hl(n,e,r,i),fs(n,t,r))}}function us(e){var t=e.alternate;return e===Y||t!==null&&t===Y}function ds(e,t){Eo=To=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function fs(e,t,n){if(n&4194240){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Rt(e,n)}}var ps={readContext:qa,useCallback:ko,useContext:ko,useEffect:ko,useImperativeHandle:ko,useInsertionEffect:ko,useLayoutEffect:ko,useMemo:ko,useReducer:ko,useRef:ko,useState:ko,useDebugValue:ko,useDeferredValue:ko,useTransition:ko,useMutableSource:ko,useSyncExternalStore:ko,useId:ko,unstable_isNewReconciler:!1},ms={readContext:qa,useCallback:function(e,t){return No().memoizedState=[e,t===void 0?null:t],e},useContext:qa,useEffect:Xo,useImperativeHandle:function(e,t,n){return n=n==null?null:n.concat([e]),Jo(4194308,4,es.bind(null,t,e),n)},useLayoutEffect:function(e,t){return Jo(4194308,4,e,t)},useInsertionEffect:function(e,t){return Jo(4,2,e,t)},useMemo:function(e,t){var n=No();return t=t===void 0?null:t,e=e(),n.memoizedState=[e,t],e},useReducer:function(e,t,n){var r=No();return t=n===void 0?t:n(t),r.memoizedState=r.baseState=t,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:t},r.queue=e,e=e.dispatch=cs.bind(null,Y,e),[r.memoizedState,e]},useRef:function(e){var t=No();return e={current:e},t.memoizedState=e},useState:Go,useDebugValue:ns,useDeferredValue:function(e){return No().memoizedState=e},useTransition:function(){var e=Go(!1),t=e[0];return e=os.bind(null,e[1]),No().memoizedState=e,[t,e]},useMutableSource:function(){},useSyncExternalStore:function(e,t,n){var i=Y,a=No();if(q){if(n===void 0)throw Error(r(407));n=n()}else{if(n=t(),Uc===null)throw Error(r(349));So&30||Bo(i,t,n)}a.memoizedState=n;var o={value:n,getSnapshot:t};return a.queue=o,Xo(Ho.bind(null,i,o,e),[e]),i.flags|=2048,Ko(9,Vo.bind(null,i,o,n,t),void 0,null),n},useId:function(){var e=No(),t=Uc.identifierPrefix;if(q){var n=ha,r=ma;n=(r&~(1<<32-Ct(r)-1)).toString(32)+n,t=`:`+t+`R`+n,n=Do++,0<n&&(t+=`H`+n.toString(32)),t+=`:`}else n=Oo++,t=`:`+t+`r`+n.toString(32)+`:`;return e.memoizedState=t},unstable_isNewReconciler:!1},hs={readContext:qa,useCallback:rs,useContext:qa,useEffect:Zo,useImperativeHandle:ts,useInsertionEffect:Qo,useLayoutEffect:$o,useMemo:is,useReducer:Io,useRef:qo,useState:function(){return Io(Fo)},useDebugValue:ns,useDeferredValue:function(e){return as(Po(),Co.memoizedState,e)},useTransition:function(){return[Io(Fo)[0],Po().memoizedState]},useMutableSource:Ro,useSyncExternalStore:zo,useId:ss,unstable_isNewReconciler:!1},gs={readContext:qa,useCallback:rs,useContext:qa,useEffect:Zo,useImperativeHandle:ts,useInsertionEffect:Qo,useLayoutEffect:$o,useMemo:is,useReducer:Lo,useRef:qo,useState:function(){return Lo(Fo)},useDebugValue:ns,useDeferredValue:function(e){var t=Po();return Co===null?t.memoizedState=e:as(t,Co.memoizedState,e)},useTransition:function(){return[Lo(Fo)[0],Po().memoizedState]},useMutableSource:Ro,useSyncExternalStore:zo,useId:ss,unstable_isNewReconciler:!1};function _s(e,t){if(e&&e.defaultProps){for(var n in t=R({},t),e=e.defaultProps,e)t[n]===void 0&&(t[n]=e[n]);return t}return t}function vs(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:R({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var ys={isMounted:function(e){return(e=e._reactInternals)?at(e)===e:!1},enqueueSetState:function(e,t,n){e=e._reactInternals;var r=pl(),i=ml(e),a=to(r,i);a.payload=t,n!=null&&(a.callback=n),t=no(e,a,i),t!==null&&(hl(t,e,i,r),ro(t,e,i))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=pl(),i=ml(e),a=to(r,i);a.tag=1,a.payload=t,n!=null&&(a.callback=n),t=no(e,a,i),t!==null&&(hl(t,e,i,r),ro(t,e,i))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=pl(),r=ml(e),i=to(n,r);i.tag=2,t!=null&&(i.callback=t),t=no(e,i,r),t!==null&&(hl(t,e,r,n),ro(t,e,r))}};function bs(e,t,n,r,i,a,o){return e=e.stateNode,typeof e.shouldComponentUpdate==`function`?e.shouldComponentUpdate(r,a,o):t.prototype&&t.prototype.isPureReactComponent?!Or(n,r)||!Or(i,a):!0}function xs(e,t,n){var r=!1,i=Wi,a=t.contextType;return typeof a==`object`&&a?a=qa(a):(i=Yi(t)?qi:Gi.current,r=t.contextTypes,a=(r=r!=null)?Ji(e,i):Wi),t=new t(n,a),e.memoizedState=t.state!==null&&t.state!==void 0?t.state:null,t.updater=ys,e.stateNode=t,t._reactInternals=e,r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=i,e.__reactInternalMemoizedMaskedChildContext=a),t}function Ss(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps==`function`&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps==`function`&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&ys.enqueueReplaceState(t,t.state,null)}function Cs(e,t,n,r){var i=e.stateNode;i.props=n,i.state=e.memoizedState,i.refs={},$a(e);var a=t.contextType;typeof a==`object`&&a?i.context=qa(a):(a=Yi(t)?qi:Gi.current,i.context=Ji(e,a)),i.state=e.memoizedState,a=t.getDerivedStateFromProps,typeof a==`function`&&(vs(e,t,a,n),i.state=e.memoizedState),typeof t.getDerivedStateFromProps==`function`||typeof i.getSnapshotBeforeUpdate==`function`||typeof i.UNSAFE_componentWillMount!=`function`&&typeof i.componentWillMount!=`function`||(t=i.state,typeof i.componentWillMount==`function`&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount==`function`&&i.UNSAFE_componentWillMount(),t!==i.state&&ys.enqueueReplaceState(i,i.state,null),ao(e,n,i,r),i.state=e.memoizedState),typeof i.componentDidMount==`function`&&(e.flags|=4194308)}function ws(e,t){try{var n=``,r=t;do n+=ie(r),r=r.return;while(r);var i=n}catch(e){i=`
Error generating stack: `+e.message+`
`+e.stack}return{value:e,source:t,stack:i,digest:null}}function Ts(e,t,n){return{value:e,source:null,stack:n??null,digest:t??null}}function Es(e,t){try{console.error(t.value)}catch(e){setTimeout(function(){throw e})}}var Ds=typeof WeakMap==`function`?WeakMap:Map;function Os(e,t,n){n=to(-1,n),n.tag=3,n.payload={element:null};var r=t.value;return n.callback=function(){rl||(rl=!0,il=r),Es(e,t)},n}function ks(e,t,n){n=to(-1,n),n.tag=3;var r=e.type.getDerivedStateFromError;if(typeof r==`function`){var i=t.value;n.payload=function(){return r(i)},n.callback=function(){Es(e,t)}}var a=e.stateNode;return a!==null&&typeof a.componentDidCatch==`function`&&(n.callback=function(){Es(e,t),typeof r!=`function`&&(al===null?al=new Set([this]):al.add(this));var n=t.stack;this.componentDidCatch(t.value,{componentStack:n===null?``:n})}),n}function As(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new Ds;var i=new Set;r.set(t,i)}else i=r.get(t),i===void 0&&(i=new Set,r.set(t,i));i.has(n)||(i.add(n),e=zl.bind(null,e,t,n),t.then(e,e))}function js(e){do{var t;if((t=e.tag===13)&&(t=e.memoizedState,t=t===null||t.dehydrated!==null),t)return e;e=e.return}while(e!==null);return null}function Ms(e,t,n,r,i){return e.mode&1?(e.flags|=65536,e.lanes=i,e):(e===t?e.flags|=65536:(e.flags|=128,n.flags|=131072,n.flags&=-52805,n.tag===1&&(n.alternate===null?n.tag=17:(t=to(-1,1),t.tag=2,no(n,t,1))),n.lanes|=1),e)}var Ns=C.ReactCurrentOwner,Ps=!1;function Fs(e,t,n,r){t.child=e===null?Ra(t,null,n,r):La(t,e.child,n,r)}function Is(e,t,n,r,i){n=n.render;var a=t.ref;return Ka(t,i),r=jo(e,t,n,r,a,i),n=Mo(),e!==null&&!Ps?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~i,nc(e,t,i)):(q&&n&&va(t),t.flags|=1,Fs(e,t,r,i),t.child)}function Ls(e,t,n,r,i){if(e===null){var a=n.type;return typeof a==`function`&&!ql(a)&&a.defaultProps===void 0&&n.compare===null&&n.defaultProps===void 0?(t.tag=15,t.type=a,Rs(e,t,a,r,i)):(e=Xl(n.type,null,r,t,t.mode,i),e.ref=t.ref,e.return=t,t.child=e)}if(a=e.child,(e.lanes&i)===0){var o=a.memoizedProps;if(n=n.compare,n=n===null?Or:n,n(o,r)&&e.ref===t.ref)return nc(e,t,i)}return t.flags|=1,e=Yl(a,r),e.ref=t.ref,e.return=t,t.child=e}function Rs(e,t,n,r,i){if(e!==null){var a=e.memoizedProps;if(Or(a,r)&&e.ref===t.ref){if(Ps=!1,t.pendingProps=r=a,(e.lanes&i)!==0)e.flags&131072&&(Ps=!0);else return t.lanes=e.lanes,nc(e,t,i)}}return Vs(e,t,n,r,i)}function zs(e,t,n){var r=t.pendingProps,i=r.children,a=e===null?null:e.memoizedState;if(r.mode===`hidden`){if(!(t.mode&1))t.memoizedState={baseLanes:0,cachePool:null,transitions:null},K(Kc,Gc),Gc|=n;else{if(!(n&1073741824))return e=a===null?n:a.baseLanes|n,t.lanes=t.childLanes=1073741824,t.memoizedState={baseLanes:e,cachePool:null,transitions:null},t.updateQueue=null,K(Kc,Gc),Gc|=e,null;t.memoizedState={baseLanes:0,cachePool:null,transitions:null},r=a===null?n:a.baseLanes,K(Kc,Gc),Gc|=r}}else a===null?r=n:(r=a.baseLanes|n,t.memoizedState=null),K(Kc,Gc),Gc|=r;return Fs(e,t,i,n),t.child}function Bs(e,t){var n=t.ref;(e===null&&n!==null||e!==null&&e.ref!==n)&&(t.flags|=512,t.flags|=2097152)}function Vs(e,t,n,r,i){var a=Yi(n)?qi:Gi.current;return a=Ji(t,a),Ka(t,i),n=jo(e,t,n,r,a,i),r=Mo(),e!==null&&!Ps?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~i,nc(e,t,i)):(q&&r&&va(t),t.flags|=1,Fs(e,t,n,i),t.child)}function Hs(e,t,n,r,i){if(Yi(n)){var a=!0;$i(t)}else a=!1;if(Ka(t,i),t.stateNode===null)tc(e,t),xs(t,n,r),Cs(t,n,r,i),r=!0;else if(e===null){var o=t.stateNode,s=t.memoizedProps;o.props=s;var c=o.context,l=n.contextType;typeof l==`object`&&l?l=qa(l):(l=Yi(n)?qi:Gi.current,l=Ji(t,l));var u=n.getDerivedStateFromProps,d=typeof u==`function`||typeof o.getSnapshotBeforeUpdate==`function`;d||typeof o.UNSAFE_componentWillReceiveProps!=`function`&&typeof o.componentWillReceiveProps!=`function`||(s!==r||c!==l)&&Ss(t,o,r,l),Qa=!1;var f=t.memoizedState;o.state=f,ao(t,r,o,i),c=t.memoizedState,s!==r||f!==c||Ki.current||Qa?(typeof u==`function`&&(vs(t,n,u,r),c=t.memoizedState),(s=Qa||bs(t,n,s,r,f,c,l))?(d||typeof o.UNSAFE_componentWillMount!=`function`&&typeof o.componentWillMount!=`function`||(typeof o.componentWillMount==`function`&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount==`function`&&o.UNSAFE_componentWillMount()),typeof o.componentDidMount==`function`&&(t.flags|=4194308)):(typeof o.componentDidMount==`function`&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=c),o.props=r,o.state=c,o.context=l,r=s):(typeof o.componentDidMount==`function`&&(t.flags|=4194308),r=!1)}else{o=t.stateNode,eo(e,t),s=t.memoizedProps,l=t.type===t.elementType?s:_s(t.type,s),o.props=l,d=t.pendingProps,f=o.context,c=n.contextType,typeof c==`object`&&c?c=qa(c):(c=Yi(n)?qi:Gi.current,c=Ji(t,c));var p=n.getDerivedStateFromProps;(u=typeof p==`function`||typeof o.getSnapshotBeforeUpdate==`function`)||typeof o.UNSAFE_componentWillReceiveProps!=`function`&&typeof o.componentWillReceiveProps!=`function`||(s!==d||f!==c)&&Ss(t,o,r,c),Qa=!1,f=t.memoizedState,o.state=f,ao(t,r,o,i);var m=t.memoizedState;s!==d||f!==m||Ki.current||Qa?(typeof p==`function`&&(vs(t,n,p,r),m=t.memoizedState),(l=Qa||bs(t,n,l,r,f,m,c)||!1)?(u||typeof o.UNSAFE_componentWillUpdate!=`function`&&typeof o.componentWillUpdate!=`function`||(typeof o.componentWillUpdate==`function`&&o.componentWillUpdate(r,m,c),typeof o.UNSAFE_componentWillUpdate==`function`&&o.UNSAFE_componentWillUpdate(r,m,c)),typeof o.componentDidUpdate==`function`&&(t.flags|=4),typeof o.getSnapshotBeforeUpdate==`function`&&(t.flags|=1024)):(typeof o.componentDidUpdate!=`function`||s===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!=`function`||s===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=m),o.props=r,o.state=m,o.context=c,r=l):(typeof o.componentDidUpdate!=`function`||s===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!=`function`||s===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),r=!1)}return Us(e,t,n,r,a,i)}function Us(e,t,n,r,i,a){Bs(e,t);var o=!!(t.flags&128);if(!r&&!o)return i&&ea(t,n,!1),nc(e,t,a);r=t.stateNode,Ns.current=t;var s=o&&typeof n.getDerivedStateFromError!=`function`?null:r.render();return t.flags|=1,e!==null&&o?(t.child=La(t,e.child,null,a),t.child=La(t,null,s,a)):Fs(e,t,s,a),t.memoizedState=r.state,i&&ea(t,n,!0),t.child}function Ws(e){var t=e.stateNode;t.pendingContext?Zi(e,t.pendingContext,t.pendingContext!==t.context):t.context&&Zi(e,t.context,!1),po(e,t.containerInfo)}function Gs(e,t,n,r,i){return Aa(),ja(i),t.flags|=256,Fs(e,t,n,r),t.child}var Ks={dehydrated:null,treeContext:null,retryLane:0};function qs(e){return{baseLanes:e,cachePool:null,transitions:null}}function Js(e,t,n){var r=t.pendingProps,i=J.current,a=!1,o=!!(t.flags&128),s;if((s=o)||(s=e!==null&&e.memoizedState===null?!1:!!(i&2)),s?(a=!0,t.flags&=-129):(e===null||e.memoizedState!==null)&&(i|=1),K(J,i&1),e===null)return Ea(t),e=t.memoizedState,e!==null&&(e=e.dehydrated,e!==null)?(t.lanes=t.mode&1?e.data===`$!`?8:1073741824:1,null):(o=r.children,e=r.fallback,a?(r=t.mode,a=t.child,o={mode:`hidden`,children:o},!(r&1)&&a!==null?(a.childLanes=0,a.pendingProps=o):a=Ql(o,r,0,null),e=Zl(e,r,n,null),a.return=t,e.return=t,a.sibling=e,t.child=a,t.child.memoizedState=qs(n),t.memoizedState=Ks,e):Ys(t,o));if(i=e.memoizedState,i!==null&&(s=i.dehydrated,s!==null))return Zs(e,t,o,r,s,i,n);if(a){a=r.fallback,o=t.mode,i=e.child,s=i.sibling;var c={mode:`hidden`,children:r.children};return!(o&1)&&t.child!==i?(r=t.child,r.childLanes=0,r.pendingProps=c,t.deletions=null):(r=Yl(i,c),r.subtreeFlags=i.subtreeFlags&14680064),s===null?(a=Zl(a,o,n,null),a.flags|=2):a=Yl(s,a),a.return=t,r.return=t,r.sibling=a,t.child=r,r=a,a=t.child,o=e.child.memoizedState,o=o===null?qs(n):{baseLanes:o.baseLanes|n,cachePool:null,transitions:o.transitions},a.memoizedState=o,a.childLanes=e.childLanes&~n,t.memoizedState=Ks,r}return a=e.child,e=a.sibling,r=Yl(a,{mode:`visible`,children:r.children}),!(t.mode&1)&&(r.lanes=n),r.return=t,r.sibling=null,e!==null&&(n=t.deletions,n===null?(t.deletions=[e],t.flags|=16):n.push(e)),t.child=r,t.memoizedState=null,r}function Ys(e,t){return t=Ql({mode:`visible`,children:t},e.mode,0,null),t.return=e,e.child=t}function Xs(e,t,n,r){return r!==null&&ja(r),La(t,e.child,null,n),e=Ys(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function Zs(e,t,n,i,a,o,s){if(n)return t.flags&256?(t.flags&=-257,i=Ts(Error(r(422))),Xs(e,t,s,i)):t.memoizedState===null?(o=i.fallback,a=t.mode,i=Ql({mode:`visible`,children:i.children},a,0,null),o=Zl(o,a,s,null),o.flags|=2,i.return=t,o.return=t,i.sibling=o,t.child=i,t.mode&1&&La(t,e.child,null,s),t.child.memoizedState=qs(s),t.memoizedState=Ks,o):(t.child=e.child,t.flags|=128,null);if(!(t.mode&1))return Xs(e,t,s,null);if(a.data===`$!`){if(i=a.nextSibling&&a.nextSibling.dataset,i)var c=i.dgst;return i=c,o=Error(r(419)),i=Ts(o,i,void 0),Xs(e,t,s,i)}if(c=(s&e.childLanes)!==0,Ps||c){if(i=Uc,i!==null){switch(s&-s){case 4:a=2;break;case 16:a=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:a=32;break;case 536870912:a=268435456;break;default:a=0}a=(a&(i.suspendedLanes|s))===0?a:0,a!==0&&a!==o.retryLane&&(o.retryLane=a,Za(e,a),hl(i,e,a,-1))}return kl(),i=Ts(Error(r(421))),Xs(e,t,s,i)}return a.data===`$?`?(t.flags|=128,t.child=e.child,t=Vl.bind(null,e),a._reactRetry=t,null):(e=o.treeContext,xa=Oi(a.nextSibling),ba=t,q=!0,Sa=null,e!==null&&(da[fa++]=ma,da[fa++]=ha,da[fa++]=pa,ma=e.id,ha=e.overflow,pa=t),t=Ys(t,i.children),t.flags|=4096,t)}function Qs(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),Ga(e.return,t,n)}function $s(e,t,n,r,i){var a=e.memoizedState;a===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:i}:(a.isBackwards=t,a.rendering=null,a.renderingStartTime=0,a.last=r,a.tail=n,a.tailMode=i)}function ec(e,t,n){var r=t.pendingProps,i=r.revealOrder,a=r.tail;if(Fs(e,t,r.children,n),r=J.current,r&2)r=r&1|2,t.flags|=128;else{if(e!==null&&e.flags&128)a:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Qs(e,n,t);else if(e.tag===19)Qs(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break a;for(;e.sibling===null;){if(e.return===null||e.return===t)break a;e=e.return}e.sibling.return=e.return,e=e.sibling}r&=1}if(K(J,r),!(t.mode&1))t.memoizedState=null;else switch(i){case`forwards`:for(n=t.child,i=null;n!==null;)e=n.alternate,e!==null&&_o(e)===null&&(i=n),n=n.sibling;n=i,n===null?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null),$s(t,!1,i,n,a);break;case`backwards`:for(n=null,i=t.child,t.child=null;i!==null;){if(e=i.alternate,e!==null&&_o(e)===null){t.child=i;break}e=i.sibling,i.sibling=n,n=i,i=e}$s(t,!0,n,null,a);break;case`together`:$s(t,!1,null,null,void 0);break;default:t.memoizedState=null}return t.child}function tc(e,t){!(t.mode&1)&&e!==null&&(e.alternate=null,t.alternate=null,t.flags|=2)}function nc(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Yc|=t.lanes,(n&t.childLanes)===0)return null;if(e!==null&&t.child!==e.child)throw Error(r(153));if(t.child!==null){for(e=t.child,n=Yl(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=Yl(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function rc(e,t,n){switch(t.tag){case 3:Ws(t),Aa();break;case 5:ho(t);break;case 1:Yi(t.type)&&$i(t);break;case 4:po(t,t.stateNode.containerInfo);break;case 10:var r=t.type._context,i=t.memoizedProps.value;K(za,r._currentValue),r._currentValue=i;break;case 13:if(r=t.memoizedState,r!==null)return r.dehydrated===null?(n&t.child.childLanes)===0?(K(J,J.current&1),e=nc(e,t,n),e===null?null:e.sibling):Js(e,t,n):(K(J,J.current&1),t.flags|=128,null);K(J,J.current&1);break;case 19:if(r=(n&t.childLanes)!==0,e.flags&128){if(r)return ec(e,t,n);t.flags|=128}if(i=t.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),K(J,J.current),r)break;return null;case 22:case 23:return t.lanes=0,zs(e,t,n)}return nc(e,t,n)}var ic=function(e,t){for(var n=t.child;n!==null;){if(n.tag===5||n.tag===6)e.appendChild(n.stateNode);else if(n.tag!==4&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return;n=n.return}n.sibling.return=n.return,n=n.sibling}},ac=function(e,t,n,r){var i=e.memoizedProps;if(i!==r){e=t.stateNode,fo(co.current);var o=null;switch(n){case`input`:i=pe(e,i),r=pe(e,r),o=[];break;case`select`:i=R({},i,{value:void 0}),r=R({},r,{value:void 0}),o=[];break;case`textarea`:i=xe(e,i),r=xe(e,r),o=[];break;default:typeof i.onClick!=`function`&&typeof r.onClick==`function`&&(e.onclick=vi)}Pe(n,r);var s;for(u in n=null,i)if(!r.hasOwnProperty(u)&&i.hasOwnProperty(u)&&i[u]!=null){if(u===`style`){var c=i[u];for(s in c)c.hasOwnProperty(s)&&(n||={},n[s]=``)}else u!==`dangerouslySetInnerHTML`&&u!==`children`&&u!==`suppressContentEditableWarning`&&u!==`suppressHydrationWarning`&&u!==`autoFocus`&&(a.hasOwnProperty(u)?o||=[]:(o||=[]).push(u,null))}for(u in r){var l=r[u];if(c=i?.[u],r.hasOwnProperty(u)&&l!==c&&(l!=null||c!=null)){if(u===`style`){if(c){for(s in c)!c.hasOwnProperty(s)||l&&l.hasOwnProperty(s)||(n||={},n[s]=``);for(s in l)l.hasOwnProperty(s)&&c[s]!==l[s]&&(n||={},n[s]=l[s])}else n||(o||=[],o.push(u,n)),n=l}else u===`dangerouslySetInnerHTML`?(l=l?l.__html:void 0,c=c?c.__html:void 0,l!=null&&c!==l&&(o||=[]).push(u,l)):u===`children`?typeof l!=`string`&&typeof l!=`number`||(o||=[]).push(u,``+l):u!==`suppressContentEditableWarning`&&u!==`suppressHydrationWarning`&&(a.hasOwnProperty(u)?(l!=null&&u===`onScroll`&&W(`scroll`,e),o||c===l||(o=[])):(o||=[]).push(u,l))}}n&&(o||=[]).push(`style`,n);var u=o;(t.updateQueue=u)&&(t.flags|=4)}},oc=function(e,t,n,r){n!==r&&(t.flags|=4)};function sc(e,t){if(!q)switch(e.tailMode){case`hidden`:t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case`collapsed`:n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function cc(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags&14680064,r|=i.flags&14680064,i.return=e,i=i.sibling;else for(i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags,r|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function lc(e,t,n){var i=t.pendingProps;switch(ya(t),t.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return cc(t),null;case 1:return Yi(t.type)&&Xi(),cc(t),null;case 3:return i=t.stateNode,mo(),G(Ki),G(Gi),yo(),i.pendingContext&&(i.context=i.pendingContext,i.pendingContext=null),(e===null||e.child===null)&&(Oa(t)?t.flags|=4:e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,Sa!==null&&(yl(Sa),Sa=null))),cc(t),null;case 5:go(t);var o=fo(uo.current);if(n=t.type,e!==null&&t.stateNode!=null)ac(e,t,n,i,o),e.ref!==t.ref&&(t.flags|=512,t.flags|=2097152);else{if(!i){if(t.stateNode===null)throw Error(r(166));return cc(t),null}if(e=fo(co.current),Oa(t)){i=t.stateNode,n=t.type;var s=t.memoizedProps;switch(i[ji]=t,i[Mi]=s,e=!!(t.mode&1),n){case`dialog`:W(`cancel`,i),W(`close`,i);break;case`iframe`:case`object`:case`embed`:W(`load`,i);break;case`video`:case`audio`:for(o=0;o<ti.length;o++)W(ti[o],i);break;case`source`:W(`error`,i);break;case`img`:case`image`:case`link`:W(`error`,i),W(`load`,i);break;case`details`:W(`toggle`,i);break;case`input`:me(i,s),W(`invalid`,i);break;case`select`:i._wrapperState={wasMultiple:!!s.multiple},W(`invalid`,i);break;case`textarea`:Se(i,s),W(`invalid`,i)}for(var c in Pe(n,s),o=null,s)if(s.hasOwnProperty(c)){var l=s[c];c===`children`?typeof l==`string`?i.textContent!==l&&(!0!==s.suppressHydrationWarning&&_i(i.textContent,l,e),o=[`children`,l]):typeof l==`number`&&i.textContent!==``+l&&(!0!==s.suppressHydrationWarning&&_i(i.textContent,l,e),o=[`children`,``+l]):a.hasOwnProperty(c)&&l!=null&&c===`onScroll`&&W(`scroll`,i)}switch(n){case`input`:ue(i),_e(i,s,!0);break;case`textarea`:ue(i),we(i);break;case`select`:case`option`:break;default:typeof s.onClick==`function`&&(i.onclick=vi)}i=o,t.updateQueue=i,i!==null&&(t.flags|=4)}else{c=o.nodeType===9?o:o.ownerDocument,e===`http://www.w3.org/1999/xhtml`&&(e=Te(n)),e===`http://www.w3.org/1999/xhtml`?n===`script`?(e=c.createElement(`div`),e.innerHTML=`<script><\/script>`,e=e.removeChild(e.firstChild)):typeof i.is==`string`?e=c.createElement(n,{is:i.is}):(e=c.createElement(n),n===`select`&&(c=e,i.multiple?c.multiple=!0:i.size&&(c.size=i.size))):e=c.createElementNS(e,n),e[ji]=t,e[Mi]=i,ic(e,t,!1,!1),t.stateNode=e;a:{switch(c=Fe(n,i),n){case`dialog`:W(`cancel`,e),W(`close`,e),o=i;break;case`iframe`:case`object`:case`embed`:W(`load`,e),o=i;break;case`video`:case`audio`:for(o=0;o<ti.length;o++)W(ti[o],e);o=i;break;case`source`:W(`error`,e),o=i;break;case`img`:case`image`:case`link`:W(`error`,e),W(`load`,e),o=i;break;case`details`:W(`toggle`,e),o=i;break;case`input`:me(e,i),o=pe(e,i),W(`invalid`,e);break;case`option`:o=i;break;case`select`:e._wrapperState={wasMultiple:!!i.multiple},o=R({},i,{value:void 0}),W(`invalid`,e);break;case`textarea`:Se(e,i),o=xe(e,i),W(`invalid`,e);break;default:o=i}for(s in Pe(n,o),l=o,l)if(l.hasOwnProperty(s)){var u=l[s];s===`style`?Me(e,u):s===`dangerouslySetInnerHTML`?(u=u?u.__html:void 0,u!=null&&De(e,u)):s===`children`?typeof u==`string`?(n!==`textarea`||u!==``)&&Oe(e,u):typeof u==`number`&&Oe(e,``+u):s!==`suppressContentEditableWarning`&&s!==`suppressHydrationWarning`&&s!==`autoFocus`&&(a.hasOwnProperty(s)?u!=null&&s===`onScroll`&&W(`scroll`,e):u!=null&&S(e,s,u,c))}switch(n){case`input`:ue(e),_e(e,i,!1);break;case`textarea`:ue(e),we(e);break;case`option`:i.value!=null&&e.setAttribute(`value`,``+se(i.value));break;case`select`:e.multiple=!!i.multiple,s=i.value,s==null?i.defaultValue!=null&&be(e,!!i.multiple,i.defaultValue,!0):be(e,!!i.multiple,s,!1);break;default:typeof o.onClick==`function`&&(e.onclick=vi)}switch(n){case`button`:case`input`:case`select`:case`textarea`:i=!!i.autoFocus;break a;case`img`:i=!0;break a;default:i=!1}}i&&(t.flags|=4)}t.ref!==null&&(t.flags|=512,t.flags|=2097152)}return cc(t),null;case 6:if(e&&t.stateNode!=null)oc(e,t,e.memoizedProps,i);else{if(typeof i!=`string`&&t.stateNode===null)throw Error(r(166));if(n=fo(uo.current),fo(co.current),Oa(t)){if(i=t.stateNode,n=t.memoizedProps,i[ji]=t,(s=i.nodeValue!==n)&&(e=ba,e!==null))switch(e.tag){case 3:_i(i.nodeValue,n,!!(e.mode&1));break;case 5:!0!==e.memoizedProps.suppressHydrationWarning&&_i(i.nodeValue,n,!!(e.mode&1))}s&&(t.flags|=4)}else i=(n.nodeType===9?n:n.ownerDocument).createTextNode(i),i[ji]=t,t.stateNode=i}return cc(t),null;case 13:if(G(J),i=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(q&&xa!==null&&t.mode&1&&!(t.flags&128))ka(),Aa(),t.flags|=98560,s=!1;else if(s=Oa(t),i!==null&&i.dehydrated!==null){if(e===null){if(!s)throw Error(r(318));if(s=t.memoizedState,s=s===null?null:s.dehydrated,!s)throw Error(r(317));s[ji]=t}else Aa(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;cc(t),s=!1}else Sa!==null&&(yl(Sa),Sa=null),s=!0;if(!s)return t.flags&65536?t:null}return t.flags&128?(t.lanes=n,t):(i=i!==null,i!==(e!==null&&e.memoizedState!==null)&&i&&(t.child.flags|=8192,t.mode&1&&(e===null||J.current&1?qc===0&&(qc=3):kl())),t.updateQueue!==null&&(t.flags|=4),cc(t),null);case 4:return mo(),e===null&&si(t.stateNode.containerInfo),cc(t),null;case 10:return Wa(t.type._context),cc(t),null;case 17:return Yi(t.type)&&Xi(),cc(t),null;case 19:if(G(J),s=t.memoizedState,s===null)return cc(t),null;if(i=!!(t.flags&128),c=s.rendering,c===null){if(i)sc(s,!1);else{if(qc!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(c=_o(e),c!==null){for(t.flags|=128,sc(s,!1),i=c.updateQueue,i!==null&&(t.updateQueue=i,t.flags|=4),t.subtreeFlags=0,i=n,n=t.child;n!==null;)s=n,e=i,s.flags&=14680066,c=s.alternate,c===null?(s.childLanes=0,s.lanes=e,s.child=null,s.subtreeFlags=0,s.memoizedProps=null,s.memoizedState=null,s.updateQueue=null,s.dependencies=null,s.stateNode=null):(s.childLanes=c.childLanes,s.lanes=c.lanes,s.child=c.child,s.subtreeFlags=0,s.deletions=null,s.memoizedProps=c.memoizedProps,s.memoizedState=c.memoizedState,s.updateQueue=c.updateQueue,s.type=c.type,e=c.dependencies,s.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),n=n.sibling;return K(J,J.current&1|2),t.child}e=e.sibling}s.tail!==null&&V()>tl&&(t.flags|=128,i=!0,sc(s,!1),t.lanes=4194304)}}else{if(!i){if(e=_o(c),e!==null){if(t.flags|=128,i=!0,n=e.updateQueue,n!==null&&(t.updateQueue=n,t.flags|=4),sc(s,!0),s.tail===null&&s.tailMode===`hidden`&&!c.alternate&&!q)return cc(t),null}else 2*V()-s.renderingStartTime>tl&&n!==1073741824&&(t.flags|=128,i=!0,sc(s,!1),t.lanes=4194304)}s.isBackwards?(c.sibling=t.child,t.child=c):(n=s.last,n===null?t.child=c:n.sibling=c,s.last=c)}return s.tail===null?(cc(t),null):(t=s.tail,s.rendering=t,s.tail=t.sibling,s.renderingStartTime=V(),t.sibling=null,n=J.current,K(J,i?n&1|2:n&1),t);case 22:case 23:return Tl(),i=t.memoizedState!==null,e!==null&&e.memoizedState!==null!==i&&(t.flags|=8192),i&&t.mode&1?Gc&1073741824&&(cc(t),t.subtreeFlags&6&&(t.flags|=8192)):cc(t),null;case 24:return null;case 25:return null}throw Error(r(156,t.tag))}function uc(e,t){switch(ya(t),t.tag){case 1:return Yi(t.type)&&Xi(),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return mo(),G(Ki),G(Gi),yo(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 5:return go(t),null;case 13:if(G(J),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(r(340));Aa()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return G(J),null;case 4:return mo(),null;case 10:return Wa(t.type._context),null;case 22:case 23:return Tl(),null;case 24:return null;default:return null}}var dc=!1,fc=!1,pc=typeof WeakSet==`function`?WeakSet:Set,X=null;function mc(e,t){var n=e.ref;if(n!==null){if(typeof n==`function`)try{n(null)}catch(n){$(e,t,n)}else n.current=null}}function hc(e,t,n){try{n()}catch(n){$(e,t,n)}}var gc=!1;function _c(e,t){if(yi=dn,e=Mr(),Nr(e)){if(`selectionStart`in e)var n={start:e.selectionStart,end:e.selectionEnd};else a:{n=(n=e.ownerDocument)&&n.defaultView||window;var i=n.getSelection&&n.getSelection();if(i&&i.rangeCount!==0){n=i.anchorNode;var a=i.anchorOffset,o=i.focusNode;i=i.focusOffset;try{n.nodeType,o.nodeType}catch{n=null;break a}var s=0,c=-1,l=-1,u=0,d=0,f=e,p=null;b:for(;;){for(var m;f!==n||a!==0&&f.nodeType!==3||(c=s+a),f!==o||i!==0&&f.nodeType!==3||(l=s+i),f.nodeType===3&&(s+=f.nodeValue.length),(m=f.firstChild)!==null;)p=f,f=m;for(;;){if(f===e)break b;if(p===n&&++u===a&&(c=s),p===o&&++d===i&&(l=s),(m=f.nextSibling)!==null)break;f=p,p=f.parentNode}f=m}n=c===-1||l===-1?null:{start:c,end:l}}else n=null}n||={start:0,end:0}}else n=null;for(bi={focusedElem:e,selectionRange:n},dn=!1,X=t;X!==null;)if(t=X,e=t.child,t.subtreeFlags&1028&&e!==null)e.return=t,X=e;else for(;X!==null;){t=X;try{var h=t.alternate;if(t.flags&1024)switch(t.tag){case 0:case 11:case 15:break;case 1:if(h!==null){var g=h.memoizedProps,_=h.memoizedState,v=t.stateNode;v.__reactInternalSnapshotBeforeUpdate=v.getSnapshotBeforeUpdate(t.elementType===t.type?g:_s(t.type,g),_)}break;case 3:var y=t.stateNode.containerInfo;y.nodeType===1?y.textContent=``:y.nodeType===9&&y.documentElement&&y.removeChild(y.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(r(163))}}catch(e){$(t,t.return,e)}if(e=t.sibling,e!==null){e.return=t.return,X=e;break}X=t.return}return h=gc,gc=!1,h}function vc(e,t,n){var r=t.updateQueue;if(r=r===null?null:r.lastEffect,r!==null){var i=r=r.next;do{if((i.tag&e)===e){var a=i.destroy;i.destroy=void 0,a!==void 0&&hc(t,n,a)}i=i.next}while(i!==r)}}function yc(e,t){if(t=t.updateQueue,t=t===null?null:t.lastEffect,t!==null){var n=t=t.next;do{if((n.tag&e)===e){var r=n.create;n.destroy=r()}n=n.next}while(n!==t)}}function bc(e){var t=e.ref;if(t!==null){var n=e.stateNode;switch(e.tag){case 5:e=n;break;default:e=n}typeof t==`function`?t(e):t.current=e}}function xc(e){var t=e.alternate;t!==null&&(e.alternate=null,xc(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&(delete t[ji],delete t[Mi],delete t[Pi],delete t[Fi],delete t[Ii])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function Sc(e){return e.tag===5||e.tag===3||e.tag===4}function Cc(e){a:for(;;){for(;e.sibling===null;){if(e.return===null||Sc(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.flags&2||e.child===null||e.tag===4)continue a;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function wc(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.nodeType===8?n.parentNode.insertBefore(e,t):n.insertBefore(e,t):(n.nodeType===8?(t=n.parentNode,t.insertBefore(e,n)):(t=n,t.appendChild(e)),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=vi));else if(r!==4&&(e=e.child,e!==null))for(wc(e,t,n),e=e.sibling;e!==null;)wc(e,t,n),e=e.sibling}function Tc(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(r!==4&&(e=e.child,e!==null))for(Tc(e,t,n),e=e.sibling;e!==null;)Tc(e,t,n),e=e.sibling}var Ec=null,Dc=!1;function Oc(e,t,n){for(n=n.child;n!==null;)kc(e,t,n),n=n.sibling}function kc(e,t,n){if(H&&typeof H.onCommitFiberUnmount==`function`)try{H.onCommitFiberUnmount(xt,n)}catch{}switch(n.tag){case 5:fc||mc(n,t);case 6:var r=Ec,i=Dc;Ec=null,Oc(e,t,n),Ec=r,Dc=i,Ec!==null&&(Dc?(e=Ec,n=n.stateNode,e.nodeType===8?e.parentNode.removeChild(n):e.removeChild(n)):Ec.removeChild(n.stateNode));break;case 18:Ec!==null&&(Dc?(e=Ec,n=n.stateNode,e.nodeType===8?Di(e.parentNode,n):e.nodeType===1&&Di(e,n),ln(e)):Di(Ec,n.stateNode));break;case 4:r=Ec,i=Dc,Ec=n.stateNode.containerInfo,Dc=!0,Oc(e,t,n),Ec=r,Dc=i;break;case 0:case 11:case 14:case 15:if(!fc&&(r=n.updateQueue,r!==null&&(r=r.lastEffect,r!==null))){i=r=r.next;do{var a=i,o=a.destroy;a=a.tag,o!==void 0&&(a&2||a&4)&&hc(n,t,o),i=i.next}while(i!==r)}Oc(e,t,n);break;case 1:if(!fc&&(mc(n,t),r=n.stateNode,typeof r.componentWillUnmount==`function`))try{r.props=n.memoizedProps,r.state=n.memoizedState,r.componentWillUnmount()}catch(e){$(n,t,e)}Oc(e,t,n);break;case 21:Oc(e,t,n);break;case 22:n.mode&1?(fc=(r=fc)||n.memoizedState!==null,Oc(e,t,n),fc=r):Oc(e,t,n);break;default:Oc(e,t,n)}}function Ac(e){var t=e.updateQueue;if(t!==null){e.updateQueue=null;var n=e.stateNode;n===null&&(n=e.stateNode=new pc),t.forEach(function(t){var r=Hl.bind(null,e,t);n.has(t)||(n.add(t),t.then(r,r))})}}function jc(e,t){var n=t.deletions;if(n!==null)for(var i=0;i<n.length;i++){var a=n[i];try{var o=e,s=t,c=s;a:for(;c!==null;){switch(c.tag){case 5:Ec=c.stateNode,Dc=!1;break a;case 3:Ec=c.stateNode.containerInfo,Dc=!0;break a;case 4:Ec=c.stateNode.containerInfo,Dc=!0;break a}c=c.return}if(Ec===null)throw Error(r(160));kc(o,s,a),Ec=null,Dc=!1;var l=a.alternate;l!==null&&(l.return=null),a.return=null}catch(e){$(a,t,e)}}if(t.subtreeFlags&12854)for(t=t.child;t!==null;)Mc(t,e),t=t.sibling}function Mc(e,t){var n=e.alternate,i=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(jc(t,e),Nc(e),i&4){try{vc(3,e,e.return),yc(3,e)}catch(t){$(e,e.return,t)}try{vc(5,e,e.return)}catch(t){$(e,e.return,t)}}break;case 1:jc(t,e),Nc(e),i&512&&n!==null&&mc(n,n.return);break;case 5:if(jc(t,e),Nc(e),i&512&&n!==null&&mc(n,n.return),e.flags&32){var a=e.stateNode;try{Oe(a,``)}catch(t){$(e,e.return,t)}}if(i&4&&(a=e.stateNode,a!=null)){var o=e.memoizedProps,s=n===null?o:n.memoizedProps,c=e.type,l=e.updateQueue;if(e.updateQueue=null,l!==null)try{c===`input`&&o.type===`radio`&&o.name!=null&&he(a,o),Fe(c,s);var u=Fe(c,o);for(s=0;s<l.length;s+=2){var d=l[s],f=l[s+1];d===`style`?Me(a,f):d===`dangerouslySetInnerHTML`?De(a,f):d===`children`?Oe(a,f):S(a,d,f,u)}switch(c){case`input`:ge(a,o);break;case`textarea`:Ce(a,o);break;case`select`:var p=a._wrapperState.wasMultiple;a._wrapperState.wasMultiple=!!o.multiple;var m=o.value;m==null?p!==!!o.multiple&&(o.defaultValue==null?be(a,!!o.multiple,o.multiple?[]:``,!1):be(a,!!o.multiple,o.defaultValue,!0)):be(a,!!o.multiple,m,!1)}a[Mi]=o}catch(t){$(e,e.return,t)}}break;case 6:if(jc(t,e),Nc(e),i&4){if(e.stateNode===null)throw Error(r(162));a=e.stateNode,o=e.memoizedProps;try{a.nodeValue=o}catch(t){$(e,e.return,t)}}break;case 3:if(jc(t,e),Nc(e),i&4&&n!==null&&n.memoizedState.isDehydrated)try{ln(t.containerInfo)}catch(t){$(e,e.return,t)}break;case 4:jc(t,e),Nc(e);break;case 13:jc(t,e),Nc(e),a=e.child,a.flags&8192&&(o=a.memoizedState!==null,a.stateNode.isHidden=o,!o||a.alternate!==null&&a.alternate.memoizedState!==null||(el=V())),i&4&&Ac(e);break;case 22:if(d=n!==null&&n.memoizedState!==null,e.mode&1?(fc=(u=fc)||d,jc(t,e),fc=u):jc(t,e),Nc(e),i&8192){if(u=e.memoizedState!==null,(e.stateNode.isHidden=u)&&!d&&e.mode&1)for(X=e,d=e.child;d!==null;){for(f=X=d;X!==null;){switch(p=X,m=p.child,p.tag){case 0:case 11:case 14:case 15:vc(4,p,p.return);break;case 1:mc(p,p.return);var h=p.stateNode;if(typeof h.componentWillUnmount==`function`){i=p,n=p.return;try{t=i,h.props=t.memoizedProps,h.state=t.memoizedState,h.componentWillUnmount()}catch(e){$(i,n,e)}}break;case 5:mc(p,p.return);break;case 22:if(p.memoizedState!==null){Lc(f);continue}}m===null?Lc(f):(m.return=p,X=m)}d=d.sibling}a:for(d=null,f=e;;){if(f.tag===5){if(d===null){d=f;try{a=f.stateNode,u?(o=a.style,typeof o.setProperty==`function`?o.setProperty(`display`,`none`,`important`):o.display=`none`):(c=f.stateNode,l=f.memoizedProps.style,s=l!=null&&l.hasOwnProperty(`display`)?l.display:null,c.style.display=je(`display`,s))}catch(t){$(e,e.return,t)}}}else if(f.tag===6){if(d===null)try{f.stateNode.nodeValue=u?``:f.memoizedProps}catch(t){$(e,e.return,t)}}else if((f.tag!==22&&f.tag!==23||f.memoizedState===null||f===e)&&f.child!==null){f.child.return=f,f=f.child;continue}if(f===e)break a;for(;f.sibling===null;){if(f.return===null||f.return===e)break a;d===f&&(d=null),f=f.return}d===f&&(d=null),f.sibling.return=f.return,f=f.sibling}}break;case 19:jc(t,e),Nc(e),i&4&&Ac(e);break;case 21:break;default:jc(t,e),Nc(e)}}function Nc(e){var t=e.flags;if(t&2){try{a:{for(var n=e.return;n!==null;){if(Sc(n)){var i=n;break a}n=n.return}throw Error(r(160))}switch(i.tag){case 5:var a=i.stateNode;i.flags&32&&(Oe(a,``),i.flags&=-33),Tc(e,Cc(e),a);break;case 3:case 4:var o=i.stateNode.containerInfo;wc(e,Cc(e),o);break;default:throw Error(r(161))}}catch(t){$(e,e.return,t)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Pc(e,t,n){X=e,Fc(e,t,n)}function Fc(e,t,n){for(var r=!!(e.mode&1);X!==null;){var i=X,a=i.child;if(i.tag===22&&r){var o=i.memoizedState!==null||dc;if(!o){var s=i.alternate,c=s!==null&&s.memoizedState!==null||fc;s=dc;var l=fc;if(dc=o,(fc=c)&&!l)for(X=i;X!==null;)o=X,c=o.child,o.tag===22&&o.memoizedState!==null||c===null?Rc(i):(c.return=o,X=c);for(;a!==null;)X=a,Fc(a,t,n),a=a.sibling;X=i,dc=s,fc=l}Ic(e,t,n)}else i.subtreeFlags&8772&&a!==null?(a.return=i,X=a):Ic(e,t,n)}}function Ic(e){for(;X!==null;){var t=X;if(t.flags&8772){var n=t.alternate;try{if(t.flags&8772)switch(t.tag){case 0:case 11:case 15:fc||yc(5,t);break;case 1:var i=t.stateNode;if(t.flags&4&&!fc){if(n===null)i.componentDidMount();else{var a=t.elementType===t.type?n.memoizedProps:_s(t.type,n.memoizedProps);i.componentDidUpdate(a,n.memoizedState,i.__reactInternalSnapshotBeforeUpdate)}}var o=t.updateQueue;o!==null&&oo(t,o,i);break;case 3:var s=t.updateQueue;if(s!==null){if(n=null,t.child!==null)switch(t.child.tag){case 5:n=t.child.stateNode;break;case 1:n=t.child.stateNode}oo(t,s,n)}break;case 5:var c=t.stateNode;if(n===null&&t.flags&4){n=c;var l=t.memoizedProps;switch(t.type){case`button`:case`input`:case`select`:case`textarea`:l.autoFocus&&n.focus();break;case`img`:l.src&&(n.src=l.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(t.memoizedState===null){var u=t.alternate;if(u!==null){var d=u.memoizedState;if(d!==null){var f=d.dehydrated;f!==null&&ln(f)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(r(163))}fc||t.flags&512&&bc(t)}catch(e){$(t,t.return,e)}}if(t===e){X=null;break}if(n=t.sibling,n!==null){n.return=t.return,X=n;break}X=t.return}}function Lc(e){for(;X!==null;){var t=X;if(t===e){X=null;break}var n=t.sibling;if(n!==null){n.return=t.return,X=n;break}X=t.return}}function Rc(e){for(;X!==null;){var t=X;try{switch(t.tag){case 0:case 11:case 15:var n=t.return;try{yc(4,t)}catch(e){$(t,n,e)}break;case 1:var r=t.stateNode;if(typeof r.componentDidMount==`function`){var i=t.return;try{r.componentDidMount()}catch(e){$(t,i,e)}}var a=t.return;try{bc(t)}catch(e){$(t,a,e)}break;case 5:var o=t.return;try{bc(t)}catch(e){$(t,o,e)}}}catch(e){$(t,t.return,e)}if(t===e){X=null;break}var s=t.sibling;if(s!==null){s.return=t.return,X=s;break}X=t.return}}var zc=Math.ceil,Bc=C.ReactCurrentDispatcher,Vc=C.ReactCurrentOwner,Hc=C.ReactCurrentBatchConfig,Z=0,Uc=null,Q=null,Wc=0,Gc=0,Kc=Ui(0),qc=0,Jc=null,Yc=0,Xc=0,Zc=0,Qc=null,$c=null,el=0,tl=1/0,nl=null,rl=!1,il=null,al=null,ol=!1,sl=null,cl=0,ll=0,ul=null,dl=-1,fl=0;function pl(){return Z&6?V():dl===-1?dl=V():dl}function ml(e){return e.mode&1?Z&2&&Wc!==0?Wc&-Wc:Ma.transition===null?(e=U,e===0&&(e=window.event,e=e===void 0?16:_n(e.type)),e):(fl===0&&(fl=Pt()),fl):1}function hl(e,t,n,i){if(50<ll)throw ll=0,ul=null,Error(r(185));It(e,n,i),Z&2&&e===Uc||(e===Uc&&(!(Z&2)&&(Xc|=n),qc===4&&xl(e,Wc)),gl(e,i),n===1&&Z===0&&!(t.mode&1)&&(tl=V()+500,na&&oa()))}function gl(e,t){var n=e.callbackNode;Mt(e,t);var r=At(e,e===Uc?Wc:0);if(r===0)n!==null&&ft(n),e.callbackNode=null,e.callbackPriority=0;else if(t=r&-r,e.callbackPriority!==t){if(n!=null&&ft(n),t===1)e.tag===0?aa(Sl.bind(null,e)):ia(Sl.bind(null,e)),Ti(function(){!(Z&6)&&oa()}),n=null;else{switch(zt(r)){case 1:n=gt;break;case 4:n=_t;break;case 16:n=vt;break;case 536870912:n=bt;break;default:n=vt}n=Wl(n,_l.bind(null,e))}e.callbackPriority=t,e.callbackNode=n}}function _l(e,t){if(dl=-1,fl=0,Z&6)throw Error(r(327));var n=e.callbackNode;if(Ll()&&e.callbackNode!==n)return null;var i=At(e,e===Uc?Wc:0);if(i===0)return null;if(i&30||(i&e.expiredLanes)!==0||t)t=Al(e,i);else{t=i;var a=Z;Z|=2;var o=Ol();(Uc!==e||Wc!==t)&&(nl=null,tl=V()+500,El(e,t));do try{Ml();break}catch(t){Dl(e,t)}while(1);Ua(),Bc.current=o,Z=a,Q===null?(Uc=null,Wc=0,t=qc):t=0}if(t!==0){if(t===2&&(a=Nt(e),a!==0&&(i=a,t=vl(e,a))),t===1)throw n=Jc,El(e,0),xl(e,i),gl(e,V()),n;if(t===6)xl(e,i);else{if(a=e.current.alternate,!(i&30)&&!bl(a)&&(t=Al(e,i),t===2&&(o=Nt(e),o!==0&&(i=o,t=vl(e,o))),t===1))throw n=Jc,El(e,0),xl(e,i),gl(e,V()),n;switch(e.finishedWork=a,e.finishedLanes=i,t){case 0:case 1:throw Error(r(345));case 2:Fl(e,$c,nl);break;case 3:if(xl(e,i),(i&130023424)===i&&(t=el+500-V(),10<t)){if(At(e,0)!==0)break;if(a=e.suspendedLanes,(a&i)!==i){pl(),e.pingedLanes|=e.suspendedLanes&a;break}e.timeoutHandle=Si(Fl.bind(null,e,$c,nl),t);break}Fl(e,$c,nl);break;case 4:if(xl(e,i),(i&4194240)===i)break;for(t=e.eventTimes,a=-1;0<i;){var s=31-Ct(i);o=1<<s,s=t[s],s>a&&(a=s),i&=~o}if(i=a,i=V()-i,i=(120>i?120:480>i?480:1080>i?1080:1920>i?1920:3e3>i?3e3:4320>i?4320:1960*zc(i/1960))-i,10<i){e.timeoutHandle=Si(Fl.bind(null,e,$c,nl),i);break}Fl(e,$c,nl);break;case 5:Fl(e,$c,nl);break;default:throw Error(r(329))}}}return gl(e,V()),e.callbackNode===n?_l.bind(null,e):null}function vl(e,t){var n=Qc;return e.current.memoizedState.isDehydrated&&(El(e,t).flags|=256),e=Al(e,t),e!==2&&(t=$c,$c=n,t!==null&&yl(t)),e}function yl(e){$c===null?$c=e:$c.push.apply($c,e)}function bl(e){for(var t=e;;){if(t.flags&16384){var n=t.updateQueue;if(n!==null&&(n=n.stores,n!==null))for(var r=0;r<n.length;r++){var i=n[r],a=i.getSnapshot;i=i.value;try{if(!Dr(a(),i))return!1}catch{return!1}}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function xl(e,t){for(t&=~Zc,t&=~Xc,e.suspendedLanes|=t,e.pingedLanes&=~t,e=e.expirationTimes;0<t;){var n=31-Ct(t),r=1<<n;e[n]=-1,t&=~r}}function Sl(e){if(Z&6)throw Error(r(327));Ll();var t=At(e,0);if(!(t&1))return gl(e,V()),null;var n=Al(e,t);if(e.tag!==0&&n===2){var i=Nt(e);i!==0&&(t=i,n=vl(e,i))}if(n===1)throw n=Jc,El(e,0),xl(e,t),gl(e,V()),n;if(n===6)throw Error(r(345));return e.finishedWork=e.current.alternate,e.finishedLanes=t,Fl(e,$c,nl),gl(e,V()),null}function Cl(e,t){var n=Z;Z|=1;try{return e(t)}finally{Z=n,Z===0&&(tl=V()+500,na&&oa())}}function wl(e){sl!==null&&sl.tag===0&&!(Z&6)&&Ll();var t=Z;Z|=1;var n=Hc.transition,r=U;try{if(Hc.transition=null,U=1,e)return e()}finally{U=r,Hc.transition=n,Z=t,!(Z&6)&&oa()}}function Tl(){Gc=Kc.current,G(Kc)}function El(e,t){e.finishedWork=null,e.finishedLanes=0;var n=e.timeoutHandle;if(n!==-1&&(e.timeoutHandle=-1,Ci(n)),Q!==null)for(n=Q.return;n!==null;){var r=n;switch(ya(r),r.tag){case 1:r=r.type.childContextTypes,r!=null&&Xi();break;case 3:mo(),G(Ki),G(Gi),yo();break;case 5:go(r);break;case 4:mo();break;case 13:G(J);break;case 19:G(J);break;case 10:Wa(r.type._context);break;case 22:case 23:Tl()}n=n.return}if(Uc=e,Q=e=Yl(e.current,null),Wc=Gc=t,qc=0,Jc=null,Zc=Xc=Yc=0,$c=Qc=null,Ja!==null){for(t=0;t<Ja.length;t++)if(n=Ja[t],r=n.interleaved,r!==null){n.interleaved=null;var i=r.next,a=n.pending;if(a!==null){var o=a.next;a.next=i,r.next=o}n.pending=r}Ja=null}return e}function Dl(e,t){do{var n=Q;try{if(Ua(),bo.current=ps,To){for(var i=Y.memoizedState;i!==null;){var a=i.queue;a!==null&&(a.pending=null),i=i.next}To=!1}if(So=0,wo=Co=Y=null,Eo=!1,Do=0,Vc.current=null,n===null||n.return===null){qc=1,Jc=t,Q=null;break}a:{var o=e,s=n.return,c=n,l=t;if(t=Wc,c.flags|=32768,typeof l==`object`&&l&&typeof l.then==`function`){var u=l,d=c,f=d.tag;if(!(d.mode&1)&&(f===0||f===11||f===15)){var p=d.alternate;p?(d.updateQueue=p.updateQueue,d.memoizedState=p.memoizedState,d.lanes=p.lanes):(d.updateQueue=null,d.memoizedState=null)}var m=js(s);if(m!==null){m.flags&=-257,Ms(m,s,c,o,t),m.mode&1&&As(o,u,t),t=m,l=u;var h=t.updateQueue;if(h===null){var g=new Set;g.add(l),t.updateQueue=g}else h.add(l);break a}if(!(t&1)){As(o,u,t),kl();break a}l=Error(r(426))}else if(q&&c.mode&1){var _=js(s);if(_!==null){!(_.flags&65536)&&(_.flags|=256),Ms(_,s,c,o,t),ja(ws(l,c));break a}}o=l=ws(l,c),qc!==4&&(qc=2),Qc===null?Qc=[o]:Qc.push(o),o=s;do{switch(o.tag){case 3:o.flags|=65536,t&=-t,o.lanes|=t;var v=Os(o,l,t);io(o,v);break a;case 1:c=l;var y=o.type,b=o.stateNode;if(!(o.flags&128)&&(typeof y.getDerivedStateFromError==`function`||b!==null&&typeof b.componentDidCatch==`function`&&(al===null||!al.has(b)))){o.flags|=65536,t&=-t,o.lanes|=t;var x=ks(o,c,t);io(o,x);break a}}o=o.return}while(o!==null)}Pl(n)}catch(e){t=e,Q===n&&n!==null&&(Q=n=n.return);continue}break}while(1)}function Ol(){var e=Bc.current;return Bc.current=ps,e===null?ps:e}function kl(){(qc===0||qc===3||qc===2)&&(qc=4),Uc===null||!(Yc&268435455)&&!(Xc&268435455)||xl(Uc,Wc)}function Al(e,t){var n=Z;Z|=2;var i=Ol();(Uc!==e||Wc!==t)&&(nl=null,El(e,t));do try{jl();break}catch(t){Dl(e,t)}while(1);if(Ua(),Z=n,Bc.current=i,Q!==null)throw Error(r(261));return Uc=null,Wc=0,qc}function jl(){for(;Q!==null;)Nl(Q)}function Ml(){for(;Q!==null&&!pt();)Nl(Q)}function Nl(e){var t=Ul(e.alternate,e,Gc);e.memoizedProps=e.pendingProps,t===null?Pl(e):Q=t,Vc.current=null}function Pl(e){var t=e;do{var n=t.alternate;if(e=t.return,t.flags&32768){if(n=uc(n,t),n!==null){n.flags&=32767,Q=n;return}if(e!==null)e.flags|=32768,e.subtreeFlags=0,e.deletions=null;else{qc=6,Q=null;return}}else if(n=lc(n,t,Gc),n!==null){Q=n;return}if(t=t.sibling,t!==null){Q=t;return}Q=t=e}while(t!==null);qc===0&&(qc=5)}function Fl(e,t,n){var r=U,i=Hc.transition;try{Hc.transition=null,U=1,Il(e,t,n,r)}finally{Hc.transition=i,U=r}return null}function Il(e,t,n,i){do Ll();while(sl!==null);if(Z&6)throw Error(r(327));n=e.finishedWork;var a=e.finishedLanes;if(n===null)return null;if(e.finishedWork=null,e.finishedLanes=0,n===e.current)throw Error(r(177));e.callbackNode=null,e.callbackPriority=0;var o=n.lanes|n.childLanes;if(Lt(e,o),e===Uc&&(Q=Uc=null,Wc=0),!(n.subtreeFlags&2064)&&!(n.flags&2064)||ol||(ol=!0,Wl(vt,function(){return Ll(),null})),o=!!(n.flags&15990),n.subtreeFlags&15990||o){o=Hc.transition,Hc.transition=null;var s=U;U=1;var c=Z;Z|=4,Vc.current=null,_c(e,n),Mc(n,e),Pr(bi),dn=!!yi,bi=yi=null,e.current=n,Pc(n,e,a),mt(),Z=c,U=s,Hc.transition=o}else e.current=n;if(ol&&(ol=!1,sl=e,cl=a),o=e.pendingLanes,o===0&&(al=null),St(n.stateNode,i),gl(e,V()),t!==null)for(i=e.onRecoverableError,n=0;n<t.length;n++)a=t[n],i(a.value,{componentStack:a.stack,digest:a.digest});if(rl)throw rl=!1,e=il,il=null,e;return cl&1&&e.tag!==0&&Ll(),o=e.pendingLanes,o&1?e===ul?ll++:(ll=0,ul=e):ll=0,oa(),null}function Ll(){if(sl!==null){var e=zt(cl),t=Hc.transition,n=U;try{if(Hc.transition=null,U=16>e?16:e,sl===null)var i=!1;else{if(e=sl,sl=null,cl=0,Z&6)throw Error(r(331));var a=Z;for(Z|=4,X=e.current;X!==null;){var o=X,s=o.child;if(X.flags&16){var c=o.deletions;if(c!==null){for(var l=0;l<c.length;l++){var u=c[l];for(X=u;X!==null;){var d=X;switch(d.tag){case 0:case 11:case 15:vc(8,d,o)}var f=d.child;if(f!==null)f.return=d,X=f;else for(;X!==null;){d=X;var p=d.sibling,m=d.return;if(xc(d),d===u){X=null;break}if(p!==null){p.return=m,X=p;break}X=m}}}var h=o.alternate;if(h!==null){var g=h.child;if(g!==null){h.child=null;do{var _=g.sibling;g.sibling=null,g=_}while(g!==null)}}X=o}}if(o.subtreeFlags&2064&&s!==null)s.return=o,X=s;else b:for(;X!==null;){if(o=X,o.flags&2048)switch(o.tag){case 0:case 11:case 15:vc(9,o,o.return)}var v=o.sibling;if(v!==null){v.return=o.return,X=v;break b}X=o.return}}var y=e.current;for(X=y;X!==null;){s=X;var b=s.child;if(s.subtreeFlags&2064&&b!==null)b.return=s,X=b;else b:for(s=y;X!==null;){if(c=X,c.flags&2048)try{switch(c.tag){case 0:case 11:case 15:yc(9,c)}}catch(e){$(c,c.return,e)}if(c===s){X=null;break b}var x=c.sibling;if(x!==null){x.return=c.return,X=x;break b}X=c.return}}if(Z=a,oa(),H&&typeof H.onPostCommitFiberRoot==`function`)try{H.onPostCommitFiberRoot(xt,e)}catch{}i=!0}return i}finally{U=n,Hc.transition=t}}return!1}function Rl(e,t,n){t=ws(n,t),t=Os(e,t,1),e=no(e,t,1),t=pl(),e!==null&&(It(e,1,t),gl(e,t))}function $(e,t,n){if(e.tag===3)Rl(e,e,n);else for(;t!==null;){if(t.tag===3){Rl(t,e,n);break}if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError==`function`||typeof r.componentDidCatch==`function`&&(al===null||!al.has(r))){e=ws(n,e),e=ks(t,e,1),t=no(t,e,1),e=pl(),t!==null&&(It(t,1,e),gl(t,e));break}}t=t.return}}function zl(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),t=pl(),e.pingedLanes|=e.suspendedLanes&n,Uc===e&&(Wc&n)===n&&(qc===4||qc===3&&(Wc&130023424)===Wc&&500>V()-el?El(e,0):Zc|=n),gl(e,t)}function Bl(e,t){t===0&&(e.mode&1?(t=Ot,Ot<<=1,!(Ot&130023424)&&(Ot=4194304)):t=1);var n=pl();e=Za(e,t),e!==null&&(It(e,t,n),gl(e,n))}function Vl(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Bl(e,n)}function Hl(e,t){var n=0;switch(e.tag){case 13:var i=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:i=e.stateNode;break;default:throw Error(r(314))}i!==null&&i.delete(t),Bl(e,n)}var Ul=function(e,t,n){if(e!==null){if(e.memoizedProps!==t.pendingProps||Ki.current)Ps=!0;else{if((e.lanes&n)===0&&!(t.flags&128))return Ps=!1,rc(e,t,n);Ps=!!(e.flags&131072)}}else Ps=!1,q&&t.flags&1048576&&_a(t,ua,t.index);switch(t.lanes=0,t.tag){case 2:var i=t.type;tc(e,t),e=t.pendingProps;var a=Ji(t,Gi.current);Ka(t,n),a=jo(null,t,i,e,a,n);var o=Mo();return t.flags|=1,typeof a==`object`&&a&&typeof a.render==`function`&&a.$$typeof===void 0?(t.tag=1,t.memoizedState=null,t.updateQueue=null,Yi(i)?(o=!0,$i(t)):o=!1,t.memoizedState=a.state!==null&&a.state!==void 0?a.state:null,$a(t),a.updater=ys,t.stateNode=a,a._reactInternals=t,Cs(t,i,e,n),t=Us(null,t,i,!0,o,n)):(t.tag=0,q&&o&&va(t),Fs(null,t,a,n),t=t.child),t;case 16:i=t.elementType;a:{switch(tc(e,t),e=t.pendingProps,a=i._init,i=a(i._payload),t.type=i,a=t.tag=Jl(i),e=_s(i,e),a){case 0:t=Vs(null,t,i,e,n);break a;case 1:t=Hs(null,t,i,e,n);break a;case 11:t=Is(null,t,i,e,n);break a;case 14:t=Ls(null,t,i,_s(i.type,e),n);break a}throw Error(r(306,i,``))}return t;case 0:return i=t.type,a=t.pendingProps,a=t.elementType===i?a:_s(i,a),Vs(e,t,i,a,n);case 1:return i=t.type,a=t.pendingProps,a=t.elementType===i?a:_s(i,a),Hs(e,t,i,a,n);case 3:a:{if(Ws(t),e===null)throw Error(r(387));i=t.pendingProps,o=t.memoizedState,a=o.element,eo(e,t),ao(t,i,null,n);var s=t.memoizedState;if(i=s.element,o.isDehydrated){if(o={element:i,isDehydrated:!1,cache:s.cache,pendingSuspenseBoundaries:s.pendingSuspenseBoundaries,transitions:s.transitions},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){a=ws(Error(r(423)),t),t=Gs(e,t,i,n,a);break a}if(i!==a){a=ws(Error(r(424)),t),t=Gs(e,t,i,n,a);break a}for(xa=Oi(t.stateNode.containerInfo.firstChild),ba=t,q=!0,Sa=null,n=Ra(t,null,i,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling}else{if(Aa(),i===a){t=nc(e,t,n);break a}Fs(e,t,i,n)}t=t.child}return t;case 5:return ho(t),e===null&&Ea(t),i=t.type,a=t.pendingProps,o=e===null?null:e.memoizedProps,s=a.children,xi(i,a)?s=null:o!==null&&xi(i,o)&&(t.flags|=32),Bs(e,t),Fs(e,t,s,n),t.child;case 6:return e===null&&Ea(t),null;case 13:return Js(e,t,n);case 4:return po(t,t.stateNode.containerInfo),i=t.pendingProps,e===null?t.child=La(t,null,i,n):Fs(e,t,i,n),t.child;case 11:return i=t.type,a=t.pendingProps,a=t.elementType===i?a:_s(i,a),Is(e,t,i,a,n);case 7:return Fs(e,t,t.pendingProps,n),t.child;case 8:return Fs(e,t,t.pendingProps.children,n),t.child;case 12:return Fs(e,t,t.pendingProps.children,n),t.child;case 10:a:{if(i=t.type._context,a=t.pendingProps,o=t.memoizedProps,s=a.value,K(za,i._currentValue),i._currentValue=s,o!==null){if(Dr(o.value,s)){if(o.children===a.children&&!Ki.current){t=nc(e,t,n);break a}}else for(o=t.child,o!==null&&(o.return=t);o!==null;){var c=o.dependencies;if(c!==null){s=o.child;for(var l=c.firstContext;l!==null;){if(l.context===i){if(o.tag===1){l=to(-1,n&-n),l.tag=2;var u=o.updateQueue;if(u!==null){u=u.shared;var d=u.pending;d===null?l.next=l:(l.next=d.next,d.next=l),u.pending=l}}o.lanes|=n,l=o.alternate,l!==null&&(l.lanes|=n),Ga(o.return,n,t),c.lanes|=n;break}l=l.next}}else if(o.tag===10)s=o.type===t.type?null:o.child;else if(o.tag===18){if(s=o.return,s===null)throw Error(r(341));s.lanes|=n,c=s.alternate,c!==null&&(c.lanes|=n),Ga(s,n,t),s=o.sibling}else s=o.child;if(s!==null)s.return=o;else for(s=o;s!==null;){if(s===t){s=null;break}if(o=s.sibling,o!==null){o.return=s.return,s=o;break}s=s.return}o=s}}Fs(e,t,a.children,n),t=t.child}return t;case 9:return a=t.type,i=t.pendingProps.children,Ka(t,n),a=qa(a),i=i(a),t.flags|=1,Fs(e,t,i,n),t.child;case 14:return i=t.type,a=_s(i,t.pendingProps),a=_s(i.type,a),Ls(e,t,i,a,n);case 15:return Rs(e,t,t.type,t.pendingProps,n);case 17:return i=t.type,a=t.pendingProps,a=t.elementType===i?a:_s(i,a),tc(e,t),t.tag=1,Yi(i)?(e=!0,$i(t)):e=!1,Ka(t,n),xs(t,i,a),Cs(t,i,a,n),Us(null,t,i,!0,e,n);case 19:return ec(e,t,n);case 22:return zs(e,t,n)}throw Error(r(156,t.tag))};function Wl(e,t){return dt(e,t)}function Gl(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Kl(e,t,n,r){return new Gl(e,t,n,r)}function ql(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Jl(e){if(typeof e==`function`)return+!!ql(e);if(e!=null){if(e=e.$$typeof,e===j)return 11;if(e===P)return 14}return 2}function Yl(e,t){var n=e.alternate;return n===null?(n=Kl(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&14680064,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n}function Xl(e,t,n,i,a,o){var s=2;if(i=e,typeof e==`function`)ql(e)&&(s=1);else if(typeof e==`string`)s=5;else a:switch(e){case E:return Zl(n.children,a,o,t);case D:s=8,a|=8;break;case O:return e=Kl(12,n,t,a|2),e.elementType=O,e.lanes=o,e;case M:return e=Kl(13,n,t,a),e.elementType=M,e.lanes=o,e;case N:return e=Kl(19,n,t,a),e.elementType=N,e.lanes=o,e;case ee:return Ql(n,a,o,t);default:if(typeof e==`object`&&e)switch(e.$$typeof){case k:s=10;break a;case A:s=9;break a;case j:s=11;break a;case P:s=14;break a;case F:s=16,i=null;break a}throw Error(r(130,e==null?e:typeof e,``))}return t=Kl(s,n,t,a),t.elementType=e,t.type=i,t.lanes=o,t}function Zl(e,t,n,r){return e=Kl(7,e,r,t),e.lanes=n,e}function Ql(e,t,n,r){return e=Kl(22,e,r,t),e.elementType=ee,e.lanes=n,e.stateNode={isHidden:!1},e}function $l(e,t,n){return e=Kl(6,e,null,t),e.lanes=n,e}function eu(e,t,n){return t=Kl(4,e.children===null?[]:e.children,e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function tu(e,t,n,r,i){this.tag=t,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=Ft(0),this.expirationTimes=Ft(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Ft(0),this.identifierPrefix=r,this.onRecoverableError=i,this.mutableSourceEagerHydrationData=null}function nu(e,t,n,r,i,a,o,s,c){return e=new tu(e,t,n,s,c),t===1?(t=1,!0===a&&(t|=8)):t=0,a=Kl(3,null,null,t),e.current=a,a.stateNode=e,a.memoizedState={element:r,isDehydrated:n,cache:null,transitions:null,pendingSuspenseBoundaries:null},$a(a),e}function ru(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:T,key:r==null?null:``+r,children:e,containerInfo:t,implementation:n}}function iu(e){if(!e)return Wi;e=e._reactInternals;a:{if(at(e)!==e||e.tag!==1)throw Error(r(170));var t=e;do{switch(t.tag){case 3:t=t.stateNode.context;break a;case 1:if(Yi(t.type)){t=t.stateNode.__reactInternalMemoizedMergedChildContext;break a}}t=t.return}while(t!==null);throw Error(r(171))}if(e.tag===1){var n=e.type;if(Yi(n))return Qi(e,n,t)}return t}function au(e,t,n,r,i,a,o,s,c){return e=nu(n,r,!0,e,i,a,o,s,c),e.context=iu(null),n=e.current,r=pl(),i=ml(n),a=to(r,i),a.callback=t??null,no(n,a,i),e.current.lanes=i,It(e,i,r),gl(e,r),e}function ou(e,t,n,r){var i=t.current,a=pl(),o=ml(i);return n=iu(n),t.context===null?t.context=n:t.pendingContext=n,t=to(a,o),t.payload={element:e},r=r===void 0?null:r,r!==null&&(t.callback=r),e=no(i,t,o),e!==null&&(hl(e,i,o,a),ro(e,i,o)),o}function su(e){if(e=e.current,!e.child)return null;switch(e.child.tag){case 5:return e.child.stateNode;default:return e.child.stateNode}}function cu(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function lu(e,t){cu(e,t),(e=e.alternate)&&cu(e,t)}function uu(){return null}var du=typeof reportError==`function`?reportError:function(e){console.error(e)};function fu(e){this._internalRoot=e}pu.prototype.render=fu.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(r(409));ou(e,t,null,null)},pu.prototype.unmount=fu.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;wl(function(){ou(null,e,null,null)}),t[Ni]=null}};function pu(e){this._internalRoot=e}pu.prototype.unstable_scheduleHydration=function(e){if(e){var t=Ut();e={blockedOn:null,target:e,priority:t};for(var n=0;n<Qt.length&&t!==0&&t<Qt[n].priority;n++);Qt.splice(n,0,e),n===0&&rn(e)}};function mu(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function hu(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11&&(e.nodeType!==8||e.nodeValue!==` react-mount-point-unstable `))}function gu(){}function _u(e,t,n,r,i){if(i){if(typeof r==`function`){var a=r;r=function(){var e=su(o);a.call(e)}}var o=au(t,r,e,0,null,!1,!1,``,gu);return e._reactRootContainer=o,e[Ni]=o.current,si(e.nodeType===8?e.parentNode:e),wl(),o}for(;i=e.lastChild;)e.removeChild(i);if(typeof r==`function`){var s=r;r=function(){var e=su(c);s.call(e)}}var c=nu(e,0,!1,null,null,!1,!1,``,gu);return e._reactRootContainer=c,e[Ni]=c.current,si(e.nodeType===8?e.parentNode:e),wl(function(){ou(t,c,n,r)}),c}function vu(e,t,n,r,i){var a=n._reactRootContainer;if(a){var o=a;if(typeof i==`function`){var s=i;i=function(){var e=su(o);s.call(e)}}ou(t,o,e,i)}else o=_u(n,t,e,i,r);return su(o)}Bt=function(e){switch(e.tag){case 3:var t=e.stateNode;if(t.current.memoizedState.isDehydrated){var n=kt(t.pendingLanes);n!==0&&(Rt(t,n|1),gl(t,V()),!(Z&6)&&(tl=V()+500,oa()))}break;case 13:wl(function(){var t=Za(e,1);t!==null&&hl(t,e,1,pl())}),lu(e,1)}},Vt=function(e){if(e.tag===13){var t=Za(e,134217728);t!==null&&hl(t,e,134217728,pl()),lu(e,134217728)}},Ht=function(e){if(e.tag===13){var t=ml(e),n=Za(e,t);n!==null&&hl(n,e,t,pl()),lu(e,t)}},Ut=function(){return U},Wt=function(e,t){var n=U;try{return U=e,t()}finally{U=n}},Re=function(e,t,n){switch(t){case`input`:if(ge(e,n),t=n.name,n.type===`radio`&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll(`input[name=`+JSON.stringify(``+t)+`][type="radio"]`),t=0;t<n.length;t++){var i=n[t];if(i!==e&&i.form===e.form){var a=Bi(i);if(!a)throw Error(r(90));de(i),ge(i,a)}}}break;case`textarea`:Ce(e,n);break;case`select`:t=n.value,t!=null&&be(e,!!n.multiple,t,!1)}},We=Cl,Ge=wl;var yu={usingClientEntryPoint:!1,Events:[Ri,zi,Bi,He,Ue,Cl]},bu={findFiberByHostInstance:Li,bundleType:0,version:`18.3.1`,rendererPackageName:`react-dom`},xu={bundleType:bu.bundleType,version:bu.version,rendererPackageName:bu.rendererPackageName,rendererConfig:bu.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:C.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return e=lt(e),e===null?null:e.stateNode},findFiberByHostInstance:bu.findFiberByHostInstance||uu,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:`18.3.1-next-f1338f8080-20240426`};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`){var Su=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Su.isDisabled&&Su.supportsFiber)try{xt=Su.inject(xu),H=Su}catch{}}e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=yu,e.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!mu(t))throw Error(r(200));return ru(e,t,null,n)},e.createRoot=function(e,t){if(!mu(e))throw Error(r(299));var n=!1,i=``,a=du;return t!=null&&(!0===t.unstable_strictMode&&(n=!0),t.identifierPrefix!==void 0&&(i=t.identifierPrefix),t.onRecoverableError!==void 0&&(a=t.onRecoverableError)),t=nu(e,1,!1,null,null,n,!1,i,a),e[Ni]=t.current,si(e.nodeType===8?e.parentNode:e),new fu(t)},e.findDOMNode=function(e){if(e==null)return null;if(e.nodeType===1)return e;var t=e._reactInternals;if(t===void 0)throw typeof e.render==`function`?Error(r(188)):(e=Object.keys(e).join(`,`),Error(r(268,e)));return e=lt(t),e=e===null?null:e.stateNode,e},e.flushSync=function(e){return wl(e)},e.hydrate=function(e,t,n){if(!hu(t))throw Error(r(200));return vu(null,e,t,!0,n)},e.hydrateRoot=function(e,t,n){if(!mu(e))throw Error(r(405));var i=n!=null&&n.hydratedSources||null,a=!1,o=``,s=du;if(n!=null&&(!0===n.unstable_strictMode&&(a=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onRecoverableError!==void 0&&(s=n.onRecoverableError)),t=au(t,null,e,1,n??null,a,!1,o,s),e[Ni]=t.current,si(e),i)for(e=0;e<i.length;e++)n=i[e],a=n._getVersion,a=a(n._source),t.mutableSourceEagerHydrationData==null?t.mutableSourceEagerHydrationData=[n,a]:t.mutableSourceEagerHydrationData.push(n,a);return new pu(t)},e.render=function(e,t,n){if(!hu(t))throw Error(r(200));return vu(null,e,t,!1,n)},e.unmountComponentAtNode=function(e){if(!hu(e))throw Error(r(40));return e._reactRootContainer?(wl(function(){vu(null,null,e,!1,function(){e._reactRootContainer=null,e[Ni]=null})}),!0):!1},e.unstable_batchedUpdates=Cl,e.unstable_renderSubtreeIntoContainer=function(e,t,n,i){if(!hu(n))throw Error(r(200));if(e==null||e._reactInternals===void 0)throw Error(r(38));return vu(e,t,n,!1,i)},e.version=`18.3.1-next-f1338f8080-20240426`})),m=o(((e,t)=>{function n(){if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE==`function`)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}n(),t.exports=p()})),h=o((e=>{var t=m();e.createRoot=t.createRoot,e.hydrateRoot=t.hydrateRoot})),g={xmlns:`http://www.w3.org/2000/svg`,width:24,height:24,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:2,strokeLinecap:`round`,strokeLinejoin:`round`},_=c(u()),v=e=>e.replace(/([a-z0-9])([A-Z])/g,`$1-$2`).toLowerCase().trim(),y=(e,t)=>{let n=(0,_.forwardRef)(({color:n=`currentColor`,size:r=24,strokeWidth:i=2,absoluteStrokeWidth:a,className:o=``,children:s,...c},l)=>(0,_.createElement)(`svg`,{ref:l,...g,width:r,height:r,stroke:n,strokeWidth:a?Number(i)*24/Number(r):i,className:[`lucide`,`lucide-${v(e)}`,o].join(` `),...c},[...t.map(([e,t])=>(0,_.createElement)(e,t)),...Array.isArray(s)?s:[s]]));return n.displayName=`${e}`,n},b=y(`AlertCircle`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`line`,{x1:`12`,x2:`12`,y1:`8`,y2:`12`,key:`1pkeuh`}],[`line`,{x1:`12`,x2:`12.01`,y1:`16`,y2:`16`,key:`4dfq90`}]]),x=y(`ArrowLeft`,[[`path`,{d:`m12 19-7-7 7-7`,key:`1l729n`}],[`path`,{d:`M19 12H5`,key:`x3x0zl`}]]),S=y(`ArrowRight`,[[`path`,{d:`M5 12h14`,key:`1ays0h`}],[`path`,{d:`m12 5 7 7-7 7`,key:`xquz4c`}]]),C=y(`Bell`,[[`path`,{d:`M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9`,key:`1qo2s2`}],[`path`,{d:`M10.3 21a1.94 1.94 0 0 0 3.4 0`,key:`qgo35s`}]]),w=y(`BookOpen`,[[`path`,{d:`M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z`,key:`vv98re`}],[`path`,{d:`M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z`,key:`1cyq3y`}]]),T=y(`Bot`,[[`path`,{d:`M12 8V4H8`,key:`hb8ula`}],[`rect`,{width:`16`,height:`12`,x:`4`,y:`8`,rx:`2`,key:`enze0r`}],[`path`,{d:`M2 14h2`,key:`vft8re`}],[`path`,{d:`M20 14h2`,key:`4cs60a`}],[`path`,{d:`M15 13v2`,key:`1xurst`}],[`path`,{d:`M9 13v2`,key:`rq6x2g`}]]),E=y(`CheckCircle`,[[`path`,{d:`M22 11.08V12a10 10 0 1 1-5.93-9.14`,key:`g774vq`}],[`path`,{d:`m9 11 3 3L22 4`,key:`1pflzl`}]]),D=y(`Check`,[[`path`,{d:`M20 6 9 17l-5-5`,key:`1gmf2c`}]]),O=y(`ChevronDown`,[[`path`,{d:`m6 9 6 6 6-6`,key:`qrunsl`}]]),k=y(`ChevronRight`,[[`path`,{d:`m9 18 6-6-6-6`,key:`mthhwq`}]]),A=y(`Code`,[[`polyline`,{points:`16 18 22 12 16 6`,key:`z7tu5w`}],[`polyline`,{points:`8 6 2 12 8 18`,key:`1eg1df`}]]),j=y(`Copy`,[[`rect`,{width:`14`,height:`14`,x:`8`,y:`8`,rx:`2`,ry:`2`,key:`17jyea`}],[`path`,{d:`M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2`,key:`zix9uf`}]]),M=y(`CreditCard`,[[`rect`,{width:`20`,height:`14`,x:`2`,y:`5`,rx:`2`,key:`ynyp8z`}],[`line`,{x1:`2`,x2:`22`,y1:`10`,y2:`10`,key:`1b3vmo`}]]),N=y(`Download`,[[`path`,{d:`M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4`,key:`ih7n3h`}],[`polyline`,{points:`7 10 12 15 17 10`,key:`2ggqvy`}],[`line`,{x1:`12`,x2:`12`,y1:`15`,y2:`3`,key:`1vk2je`}]]),P=y(`ExternalLink`,[[`path`,{d:`M15 3h6v6`,key:`1q9fwt`}],[`path`,{d:`M10 14 21 3`,key:`gplh6r`}],[`path`,{d:`M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6`,key:`a6xqqp`}]]),F=y(`FileText`,[[`path`,{d:`M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z`,key:`1rqfz7`}],[`path`,{d:`M14 2v4a2 2 0 0 0 2 2h4`,key:`tnqrlb`}],[`path`,{d:`M10 9H8`,key:`b1mrlr`}],[`path`,{d:`M16 13H8`,key:`t4e002`}],[`path`,{d:`M16 17H8`,key:`z1uh3a`}]]),ee=y(`FlaskConical`,[[`path`,{d:`M10 2v7.527a2 2 0 0 1-.211.896L4.72 20.55a1 1 0 0 0 .9 1.45h12.76a1 1 0 0 0 .9-1.45l-5.069-10.127A2 2 0 0 1 14 9.527V2`,key:`pzvekw`}],[`path`,{d:`M8.5 2h7`,key:`csnxdl`}],[`path`,{d:`M7 16h10`,key:`wp8him`}]]),I=y(`Globe`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20`,key:`13o1zl`}],[`path`,{d:`M2 12h20`,key:`9i4pu4`}]]),L=y(`HelpCircle`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3`,key:`1u773s`}],[`path`,{d:`M12 17h.01`,key:`p32p05`}]]),R=y(`History`,[[`path`,{d:`M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8`,key:`1357e3`}],[`path`,{d:`M3 3v5h5`,key:`1xhq8a`}],[`path`,{d:`M12 7v5l4 2`,key:`1fdv2h`}]]),te=y(`Home`,[[`path`,{d:`m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z`,key:`y5dka4`}],[`polyline`,{points:`9 22 9 12 15 12 15 22`,key:`e2us08`}]]),ne=y(`Info`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`M12 16v-4`,key:`1dtifu`}],[`path`,{d:`M12 8h.01`,key:`e9boi3`}]]),re=y(`KeyRound`,[[`path`,{d:`M2 18v3c0 .6.4 1 1 1h4v-3h3v-3h2l1.4-1.4a6.5 6.5 0 1 0-4-4Z`,key:`167ctg`}],[`circle`,{cx:`16.5`,cy:`7.5`,r:`.5`,fill:`currentColor`,key:`w0ekpg`}]]),z=y(`Key`,[[`circle`,{cx:`7.5`,cy:`15.5`,r:`5.5`,key:`yqb3hr`}],[`path`,{d:`m21 2-9.6 9.6`,key:`1j0ho8`}],[`path`,{d:`m15.5 7.5 3 3L22 7l-3-3`,key:`1rn1fs`}]]),ie=y(`LayoutGrid`,[[`rect`,{width:`7`,height:`7`,x:`3`,y:`3`,rx:`1`,key:`1g98yp`}],[`rect`,{width:`7`,height:`7`,x:`14`,y:`3`,rx:`1`,key:`6d4xhi`}],[`rect`,{width:`7`,height:`7`,x:`14`,y:`14`,rx:`1`,key:`nxv5o0`}],[`rect`,{width:`7`,height:`7`,x:`3`,y:`14`,rx:`1`,key:`1bb6yr`}]]),ae=y(`Loader2`,[[`path`,{d:`M21 12a9 9 0 1 1-6.219-8.56`,key:`13zald`}]]),oe=y(`Lock`,[[`rect`,{width:`18`,height:`11`,x:`3`,y:`11`,rx:`2`,ry:`2`,key:`1w4ew1`}],[`path`,{d:`M7 11V7a5 5 0 0 1 10 0v4`,key:`fwvmzm`}]]),se=y(`Menu`,[[`line`,{x1:`4`,x2:`20`,y1:`12`,y2:`12`,key:`1e0a9i`}],[`line`,{x1:`4`,x2:`20`,y1:`6`,y2:`6`,key:`1owob3`}],[`line`,{x1:`4`,x2:`20`,y1:`18`,y2:`18`,key:`yk5zj1`}]]),ce=y(`Package`,[[`path`,{d:`m7.5 4.27 9 5.15`,key:`1c824w`}],[`path`,{d:`M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z`,key:`hh9hay`}],[`path`,{d:`m3.3 7 8.7 5 8.7-5`,key:`g66t2b`}],[`path`,{d:`M12 22V12`,key:`d0xqtd`}]]),le=y(`Pencil`,[[`path`,{d:`M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z`,key:`5qss01`}],[`path`,{d:`m15 5 4 4`,key:`1mk7zo`}]]),ue=y(`Plug`,[[`path`,{d:`M12 22v-5`,key:`1ega77`}],[`path`,{d:`M9 8V2`,key:`14iosj`}],[`path`,{d:`M15 8V2`,key:`18g5xt`}],[`path`,{d:`M18 8v5a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V8Z`,key:`osxo6l`}]]),de=y(`Puzzle`,[[`path`,{d:`M19.439 7.85c-.049.322.059.648.289.878l1.568 1.568c.47.47.706 1.087.706 1.704s-.235 1.233-.706 1.704l-1.611 1.611a.98.98 0 0 1-.837.276c-.47-.07-.802-.48-.968-.925a2.501 2.501 0 1 0-3.214 3.214c.446.166.855.497.925.968a.979.979 0 0 1-.276.837l-1.61 1.61a2.404 2.404 0 0 1-1.705.707 2.402 2.402 0 0 1-1.704-.706l-1.568-1.568a1.026 1.026 0 0 0-.877-.29c-.493.074-.84.504-1.02.968a2.5 2.5 0 1 1-3.237-3.237c.464-.18.894-.527.967-1.02a1.026 1.026 0 0 0-.289-.877l-1.568-1.568A2.402 2.402 0 0 1 1.998 12c0-.617.236-1.234.706-1.704L4.23 8.77c.24-.24.581-.353.917-.303.515.077.877.528 1.073 1.01a2.5 2.5 0 1 0 3.259-3.259c-.482-.196-.933-.558-1.01-1.073-.05-.336.062-.676.303-.917l1.525-1.525A2.402 2.402 0 0 1 12 1.998c.617 0 1.234.236 1.704.706l1.568 1.568c.23.23.556.338.877.29.493-.074.84-.504 1.02-.968a2.5 2.5 0 1 1 3.237 3.237c-.464.18-.894.527-.967 1.02Z`,key:`i0oyt7`}]]),fe=y(`Rocket`,[[`path`,{d:`M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z`,key:`m3kijz`}],[`path`,{d:`m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z`,key:`1fmvmk`}],[`path`,{d:`M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0`,key:`1f8sc4`}],[`path`,{d:`M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5`,key:`qeys4`}]]),pe=y(`Search`,[[`circle`,{cx:`11`,cy:`11`,r:`8`,key:`4ej97u`}],[`path`,{d:`m21 21-4.3-4.3`,key:`1qie3q`}]]),me=y(`Send`,[[`path`,{d:`m22 2-7 20-4-9-9-4Z`,key:`1q3vgg`}],[`path`,{d:`M22 2 11 13`,key:`nzbqef`}]]),he=y(`Server`,[[`rect`,{width:`20`,height:`8`,x:`2`,y:`2`,rx:`2`,ry:`2`,key:`ngkwjq`}],[`rect`,{width:`20`,height:`8`,x:`2`,y:`14`,rx:`2`,ry:`2`,key:`iecqi9`}],[`line`,{x1:`6`,x2:`6.01`,y1:`6`,y2:`6`,key:`16zg32`}],[`line`,{x1:`6`,x2:`6.01`,y1:`18`,y2:`18`,key:`nzw8ys`}]]),ge=y(`ShoppingCart`,[[`circle`,{cx:`8`,cy:`21`,r:`1`,key:`jimo8o`}],[`circle`,{cx:`19`,cy:`21`,r:`1`,key:`13723u`}],[`path`,{d:`M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12`,key:`9zh506`}]]),_e=y(`Smartphone`,[[`rect`,{width:`14`,height:`20`,x:`5`,y:`2`,rx:`2`,ry:`2`,key:`1yt0o3`}],[`path`,{d:`M12 18h.01`,key:`mhygvu`}]]),ve=y(`Sparkles`,[[`path`,{d:`m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z`,key:`17u4zn`}],[`path`,{d:`M5 3v4`,key:`bklmnn`}],[`path`,{d:`M19 17v4`,key:`iiml17`}],[`path`,{d:`M3 5h4`,key:`nem4j1`}],[`path`,{d:`M17 19h4`,key:`lbex7p`}]]),ye=y(`Wrench`,[[`path`,{d:`M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z`,key:`cbrjhi`}]]),be=y(`XCircle`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`m15 9-6 6`,key:`1uzhvr`}],[`path`,{d:`m9 9 6 6`,key:`z0biqf`}]]),xe=y(`X`,[[`path`,{d:`M18 6 6 18`,key:`1bl5f8`}],[`path`,{d:`m6 6 12 12`,key:`d8bk6v`}]]),Se=y(`Zap`,[[`polygon`,{points:`13 2 3 14 12 14 11 22 21 10 12 10 13 2`,key:`45s27k`}]]),Ce=o((e=>{var t=u(),n=Symbol.for(`react.element`),r=Symbol.for(`react.fragment`),i=Object.prototype.hasOwnProperty,a=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,o={key:!0,ref:!0,__self:!0,__source:!0};function s(e,t,r){var s,c={},l=null,u=null;for(s in r!==void 0&&(l=``+r),t.key!==void 0&&(l=``+t.key),t.ref!==void 0&&(u=t.ref),t)i.call(t,s)&&!o.hasOwnProperty(s)&&(c[s]=t[s]);if(e&&e.defaultProps)for(s in t=e.defaultProps,t)c[s]===void 0&&(c[s]=t[s]);return{$$typeof:n,type:e,key:l,ref:u,props:c,_owner:a.current}}e.Fragment=r,e.jsx=s,e.jsxs=s})),we=o(((e,t)=>{t.exports=Ce()})),Te=h(),B=we(),Ee=[{code:`en`,name:`English`,flag:`🇺🇸`},{code:`ro`,name:`Română`,flag:`🇷🇴`},{code:`ru`,name:`Русский`,flag:`🇷🇺`}],De=({currentLanguage:e,onLanguageChange:t})=>{let[n,r]=(0,_.useState)(!1),i=(0,_.useRef)(null),a=Ee.find(t=>t.code===e)||Ee[0];return(0,_.useEffect)(()=>{let e=e=>{i.current&&!i.current.contains(e.target)&&r(!1)};return document.addEventListener(`mousedown`,e),()=>document.removeEventListener(`mousedown`,e)},[]),(0,B.jsxs)(`div`,{className:`relative`,ref:i,children:[(0,B.jsxs)(`button`,{onClick:()=>r(!n),className:`flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-4 py-2 text-sm font-medium text-paynet-gray-700 bg-white border border-paynet-gray-300 rounded-paynet hover:bg-paynet-gray-50 focus:outline-none focus:ring-2 focus:ring-paynet-primary focus:border-transparent transition-colors shadow-paynet`,children:[(0,B.jsx)(I,{className:`hidden sm:block w-4 h-4`}),(0,B.jsx)(`span`,{className:`text-lg`,children:a.flag}),(0,B.jsx)(`span`,{className:`hidden sm:inline`,children:a.name}),(0,B.jsx)(O,{className:`w-4 h-4 transition-transform ${n?`rotate-180`:``}`})]}),n&&(0,B.jsx)(`div`,{className:`absolute top-full right-0 mt-2 w-48 bg-white border border-paynet-gray-200 rounded-paynet shadow-paynet-lg z-50`,children:Ee.map(n=>(0,B.jsxs)(`button`,{onClick:()=>{t(n.code),r(!1)},className:`w-full flex items-center gap-3 px-4 py-3 text-sm text-left hover:bg-paynet-gray-50 transition-colors ${e===n.code?`bg-paynet-light text-paynet-primary font-medium border-l-4 border-paynet-primary`:`text-paynet-gray-700`} ${n===Ee[0]?`rounded-t-paynet`:``} ${n===Ee[Ee.length-1]?`rounded-b-paynet`:``}`,children:[(0,B.jsx)(`span`,{className:`text-lg`,children:n.flag}),(0,B.jsx)(`span`,{children:n.name}),e===n.code&&(0,B.jsx)(`span`,{className:`ml-auto text-paynet-primary`,children:`✓`})]},n.code))})]})},Oe=Object.assign({"../../content/en/common/01-notifications.md":`# Notifications (webhooks)

When a payment is paid, Paynet sends an HTTP \`POST\` with a JSON body to the callback URL you registered with Paynet. The same notification is used by all integration types.

**Only successful payments are notified.** \`EventType\` is always \`PAID\`. If a payment fails, Paynet does not send a notification; the customer is only redirected to your \`LinkUrlCancel\`. Treat an order as unpaid until you receive a verified \`PAID\` notification (or the status API shows it paid), and as abandoned after its \`ExpiryDate\`.

## Request

\`\`\`http
POST https://shop.example/paynet/notification
Content-Type: application/json; charset=utf-8
Hash: lq3+OCn0J/zSyNF5iAoShg==
\`\`\`

\`\`\`json
{
  "Eventid": 1000001,
  "EventType": "PAID",
  "Message": "Request processed successfully",
  "EventDate": "2026-11-09T12:00:00",
  "Payment": {
    "Id": 1234567,
    "ExternalId": 1762444800000,
    "SaleAreaCode": "onlidocumentation_md",
    "Customer": "37369XXX111",
    "StatusDate": "2026-11-09T12:00:00",
    "Amount": 1235,
    "PaidAmount": 1235,
    "Merchant": "265505",
    "CardMask": "411111******1111",
    "CardExpireMonth": "12",
    "CardExpireYear": "27",
    "CardIssuer": "TEST BANK",
    "CardLinkHash": null,
    "MoneyType": "CARD",
    "PayerName": "Ion",
    "PayerSurname": "Popescu",
    "PayerIDNP": null,
    "RRN": "000000000000"
  }
}
\`\`\`

The request has only two headers: \`Content-Type\` and \`Hash\`. There is no \`Authorization\` header — authenticity is proven by \`Hash\`.

## Fields

> **Important:** JSON keys are case-sensitive in most languages. The keys are \`Id\` and \`ExternalId\` (not \`ID\` / \`ExternalID\`).

| Field | Type | Description |
|---|---|---|
| \`Eventid\` | long | Notification ID. |
| \`EventType\` | string | Always \`PAID\`. |
| \`Message\` | string | Text status, e.g. \`Request processed successfully\`. |
| \`EventDate\` | string | When the notification was created, \`YYYY-MM-DDTHH:mm:ss\`, Chișinău local time. |
| \`Payment.Id\` | long | Paynet payment ID (\`paymentId\`). Use it as the idempotency key. |
| \`Payment.ExternalId\` | long | Your order number (\`Order\`). |
| \`Payment.SaleAreaCode\` | string | Sale area code. |
| \`Payment.Customer\` | string | The customer code you sent in the order (\`Customer.Code\`), usually masked, e.g. \`37369XXX111\` or \`name***@gmail.com\`. |
| \`Payment.StatusDate\` | string | When the payment reached this status (Chișinău local time). |
| \`Payment.Amount\` | long | Order amount in minor units, as you sent it. |
| \`Payment.PaidAmount\` | long | Amount actually paid by the customer, in minor units. See below. |
| \`Payment.Merchant\` | string | Your merchant code. |
| \`Payment.MoneyType\` | string | How the customer paid: \`CARD\`, \`APPLEPAY\`, \`GOOGLEPAY\`, \`MIA_QR\`, \`PAYNET\`, \`CASH_INVOICE\`. |
| \`Payment.CardMask\`, \`CardExpireMonth\`, \`CardExpireYear\`, \`CardIssuer\` | string | Card details. Filled for \`CARD\`, and also for \`APPLEPAY\` and \`GOOGLEPAY\` (the card behind the wallet); \`null\` for other payment methods. |
| \`Payment.CardLinkHash\` | string | Saved card token: sent when [card saving](#/guides/saved-cards) is enabled for your \`SaleAreaCode\` and the customer kept the checkbox; otherwise \`null\`. |
| \`Payment.PayerName\`, \`PayerSurname\`, \`PayerIDNP\` | string | Payer details; may be \`null\`. |
| \`Payment.RRN\` | string | Retrieval reference number. |
| \`Hash\` (HTTP header) | string | Signature of the notification. |

Ignore fields you do not know: new optional fields may be added.

The \`MoneyType\` values in notifications are not the same as in the order request (\`Card\`, \`All\`, …). Do not compare them directly.

### Amount and PaidAmount

\`PaidAmount\` must be equal to \`Amount\`.

They can differ **only** if your company has officially agreed a promotion or discount with Paynet (for example 10% off for Mastercard cards of a certain BIN). Paynet configures such a promotion on its side at your request; it cannot be enabled through the API.

> **Important:** if you have no such agreement and \`PaidAmount\` is not equal to \`Amount\`, do not fulfil the order automatically. Save the notification and contact Paynet.

Settlement: you receive \`PaidAmount\` minus the Paynet commission. Use this when you reconcile with the statement.

## Verify the signature

\`\`\`text
PreparedString = EventDate + Eventid + EventType + Payment.Amount + Payment.Customer +
                 Payment.ExternalId + Payment.Id + Payment.Merchant + Payment.StatusDate
ExpectedHash   = Base64( MD5( UTF8( PreparedString + NotificationSecretKey ) ) )
\`\`\`

- Take the values exactly as they appear in the JSON body. A missing or \`null\` value is an empty string.
- The order is fixed — exactly as in the line above. **Do not sort the names in code:** a plain sort puts \`EventType\` before \`Eventid\`, and the hash will not match.
- Use the **notification** secret key (it is different from the checkout key).
- Compare \`ExpectedHash\` with the \`Hash\` header. If they differ, reject the request (for example HTTP \`400\`) and do not change the order.

Worked example with expected output: [Signatures](#/guides/signatures).

### Node.js (Express)

\`\`\`javascript
import crypto from 'node:crypto';
import express from 'express';

const SECRET = process.env.PAYNET_NOTIFICATION_SECRET;
const s = (v) => (v === null || v === undefined ? '' : String(v));

function expectedHash(n) {
  const p = n.Payment || {};
  const prepared = s(n.EventDate) + s(n.Eventid) + s(n.EventType) + s(p.Amount) + s(p.Customer) +
    s(p.ExternalId) + s(p.Id) + s(p.Merchant) + s(p.StatusDate);
  return crypto.createHash('md5').update(prepared + SECRET, 'utf8').digest('base64');
}

const app = express();
app.post('/paynet/notification', express.json(), async (req, res) => {
  const received = req.get('Hash') || '';
  const expected = expectedHash(req.body);
  const ok = received.length === expected.length &&
    crypto.timingSafeEqual(Buffer.from(received), Buffer.from(expected));
  if (!ok) return res.status(400).send('Invalid hash');

  const p = req.body.Payment;
  // Process each Payment.Id only once (idempotency).
  // If PaidAmount !== Amount and you have no agreed promotion: do not fulfil, contact Paynet.
  // await markOrderPaidOnce(p.Id, p.ExternalId, p.Amount, p.PaidAmount);
  res.status(200).json({ ResultCode: 'SUCCESS' });
});
\`\`\`

### PHP

\`\`\`php
<?php
$secret = getenv('PAYNET_NOTIFICATION_SECRET');
$body   = file_get_contents('php://input');
$n      = json_decode($body, true);
$p      = $n['Payment'] ?? [];
$s      = fn($v) => $v === null ? '' : (string) $v;

$prepared = $s($n['EventDate'] ?? null) . $s($n['Eventid'] ?? null) . $s($n['EventType'] ?? null)
          . $s($p['Amount'] ?? null) . $s($p['Customer'] ?? null) . $s($p['ExternalId'] ?? null)
          . $s($p['Id'] ?? null) . $s($p['Merchant'] ?? null) . $s($p['StatusDate'] ?? null);
$expected = base64_encode(md5($prepared . $secret, true));

if (!hash_equals($expected, $_SERVER['HTTP_HASH'] ?? '')) {
    http_response_code(400);
    exit('Invalid hash');
}
// Process once per Payment.Id; check PaidAmount === Amount (unless a promotion is agreed), then:
http_response_code(200);
echo json_encode(['ResultCode' => 'SUCCESS']);
\`\`\`

> **Important:** build \`PreparedString\` from the values exactly as they appear in the JSON body. Do not reformat dates (keep \`2026-11-09T12:00:00\` as is) and do not convert numbers to another notation.

## What the signature protects, and confirming with the API

The \`Hash\` header protects only the fields that make up \`PreparedString\`:

| Signed (checked by \`Hash\`) | Not signed |
|---|---|
| \`EventDate\`, \`Eventid\`, \`EventType\`, \`Payment.Amount\`, \`Payment.Customer\`, \`Payment.ExternalId\`, \`Payment.Id\`, \`Payment.Merchant\`, \`Payment.StatusDate\` | \`Payment.PaidAmount\`, \`Payment.MoneyType\`, \`Payment.CardLinkHash\`, \`Payment.SaleAreaCode\`, card and payer data (\`CardMask\`, \`CardIssuer\`, \`PayerName\`…), \`Message\` |

A valid \`Hash\` confirms that order \`ExternalId\` is paid for \`Amount\`. It does **not** confirm the unsigned fields. Before you act on them — which amount to treat as received, whether to save a card — compare them with the authenticated API response \`GET /api/order/merchant/{Order}\`. That response is protected by your token and HTTPS.

Compare the values, do not just call the method:

| Check | Notification | API response |
|---|---|---|
| Payment | \`Payment.Id\` | \`paymentId\` |
| Status | \`EventType\` = \`PAID\` | \`status\` = \`4\` |
| Order amount | \`Payment.Amount\` (and your own order amount) | \`amount.amount\` |
| Paid amount | \`Payment.PaidAmount\` | \`amount.paidAmount\` |
| Customer | your order | \`customer.code\` |
| Saved card | \`Payment.CardLinkHash\` | \`cardLinkHash\`, if the API returns it |

If the values differ, do not fulfil the order automatically and do not save the card: send the order to manual review.

If the signature is valid but you cannot fulfil the order (order not found, amounts differ), still answer \`200\` and send it to review: otherwise Paynet keeps retrying the notification.

### Complete handler: Node.js

Verifies the signature, stores the notification once, answers \`200\`, then confirms the values with the API and fulfils the order or sends it to review. The logic of this sample is tested automatically on every documentation build.

\`\`\`javascript
// paynet-notifications.mjs — complete notification handler, no dependencies (Node.js 18+).
import crypto from 'node:crypto';

// The 9 signed fields, in this exact order. Do not sort.
const signedValues = (n) => {
  const p = n.Payment || {};
  return [n.EventDate, n.Eventid, n.EventType, p.Amount, p.Customer, p.ExternalId, p.Id, p.Merchant, p.StatusDate];
};

export function verifyHash(notification, hashHeader, secret) {
  const prepared = signedValues(notification).map((v) => (v === null || v === undefined ? '' : String(v))).join('');
  const expected = crypto.createHash('md5').update(prepared + secret, 'utf8').digest('base64');
  const received = String(hashHeader || '');
  return received.length === expected.length && crypto.timingSafeEqual(Buffer.from(received), Buffer.from(expected));
}

/**
 * deps.secret      notification secret key
 * deps.apiUrl      https://ecom-api.paynet.md (test: https://ecom-api-test.paynet.md)
 * deps.getToken()  returns a valid Bearer token (POST /auth, cached)
 * deps.fetch       fetch implementation (globalThis.fetch)
 * deps.db          your storage:
 *   saveNotificationOnce(paymentId, notification) -> true if new, false if already stored
 *   findOrder(order) -> { amount, customerCode, promotionAgreed } or null
 *   markPaid(order, paidAmount), saveCard(customerCode, cardLinkHash), sendToReview(order, problems)
 *
 * handle(rawBody, hashHeader) -> { status, processing }
 *   status: HTTP status to answer Paynet; processing: promise of the work done after answering.
 */
export function createPaynetHandler(deps) {
  const { db } = deps;

  async function confirmWithApi(n, order) {
    const p = n.Payment;
    const response = await deps.fetch(\`\${deps.apiUrl}/api/order/merchant/\${p.ExternalId}\`, {
      headers: { Authorization: \`Bearer \${await deps.getToken()}\` },
    });
    if (!response.ok) throw new Error(\`Status check failed: HTTP \${response.status}\`);
    const payment = await response.json();

    const problems = [];
    if (payment.paymentId !== p.Id) problems.push('paymentId');
    if (payment.status !== 4) problems.push('status');
    if (payment.amount?.amount !== p.Amount || p.Amount !== order.amount) problems.push('Amount');
    if (payment.amount?.paidAmount !== p.PaidAmount) problems.push('PaidAmount');
    if (payment.customer?.code !== order.customerCode) problems.push('customer');
    if (p.CardLinkHash && payment.cardLinkHash && payment.cardLinkHash !== p.CardLinkHash) problems.push('CardLinkHash');
    return problems;
  }

  async function process(n) {
    const p = n.Payment;
    if (n.EventType !== 'PAID') return db.sendToReview(p.ExternalId, ['EventType']);
    const order = await db.findOrder(p.ExternalId);
    if (!order) return db.sendToReview(p.ExternalId, ['unknown order']);

    const problems = await confirmWithApi(n, order);
    if (p.PaidAmount !== p.Amount && !order.promotionAgreed) problems.push('PaidAmount differs from Amount');
    if (problems.length) return db.sendToReview(p.ExternalId, problems);

    await db.markPaid(p.ExternalId, p.PaidAmount);
    if (p.CardLinkHash) await db.saveCard(order.customerCode, p.CardLinkHash);
  }

  return async function handle(rawBody, hashHeader) {
    let n;
    try {
      n = JSON.parse(rawBody);
    } catch {
      return { status: 400, processing: null };
    }
    if (!verifyHash(n, hashHeader, deps.secret)) return { status: 400, processing: null };

    const isNew = await db.saveNotificationOnce(n.Payment?.Id, n); // idempotency by Payment.Id
    if (!isNew) return { status: 200, processing: null }; // a retry: already stored
    // Answer 200 now; confirm and fulfil after the answer. If this work fails, the stored
    // notification stays unprocessed and a background job can retry it.
    return { status: 200, processing: process(n) };
  };
}
\`\`\`

Connecting it to Express (read the raw body, answer first, process after):

\`\`\`javascript
import express from 'express';
import { createPaynetHandler } from './paynet-notifications.mjs';

const handle = createPaynetHandler({
  secret: process.env.PAYNET_NOTIFICATION_SECRET,
  apiUrl: process.env.PAYNET_API_URL,
  getToken, // your cached POST /auth
  fetch: globalThis.fetch,
  db, // your storage
});

const app = express();
app.post('/paynet/notification', express.text({ type: '*/*' }), async (req, res) => {
  const { status, processing } = await handle(req.body, req.get('Hash'));
  res.status(status).json(status === 200 ? { ResultCode: 'SUCCESS' } : { error: 'Invalid notification' });
  processing?.catch((error) => console.error('Paynet notification processing failed', error));
});
\`\`\`

### Complete handler: PHP

\`\`\`php
<?php
// paynet-notification.php — complete notification handler (PHP 7.4+, ext-curl).
// $db must implement: saveNotificationOnce($paymentId, array $n): bool, findOrder($order): ?array
// (['amount' => int, 'customerCode' => string, 'promotionAgreed' => bool]), markPaid($order, $paidAmount),
// saveCard($customerCode, $cardLinkHash), sendToReview($order, array $problems).

function paynetVerifyHash(array $n, string $hashHeader, string $secret): bool {
    $p = $n['Payment'] ?? [];
    $s = fn($v) => $v === null ? '' : (string) $v;
    // The 9 signed fields, in this exact order. Do not sort.
    $prepared = $s($n['EventDate'] ?? null) . $s($n['Eventid'] ?? null) . $s($n['EventType'] ?? null)
              . $s($p['Amount'] ?? null) . $s($p['Customer'] ?? null) . $s($p['ExternalId'] ?? null)
              . $s($p['Id'] ?? null) . $s($p['Merchant'] ?? null) . $s($p['StatusDate'] ?? null);
    $expected = base64_encode(md5($prepared . $secret, true));
    return hash_equals($expected, $hashHeader);
}

function paynetConfirmWithApi(array $n, array $order, string $apiUrl, string $token): array {
    $p  = $n['Payment'];
    $ch = curl_init($apiUrl . '/api/order/merchant/' . $p['ExternalId']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code !== 200) throw new RuntimeException("Status check failed: HTTP $code");
    $pay = json_decode($body, true);

    $problems = [];
    if (($pay['paymentId'] ?? null) !== $p['Id']) $problems[] = 'paymentId';
    if (($pay['status'] ?? null) !== 4) $problems[] = 'status';
    if (($pay['amount']['amount'] ?? null) !== $p['Amount'] || $p['Amount'] !== $order['amount']) $problems[] = 'Amount';
    if (($pay['amount']['paidAmount'] ?? null) !== ($p['PaidAmount'] ?? null)) $problems[] = 'PaidAmount';
    if (($pay['customer']['code'] ?? null) !== $order['customerCode']) $problems[] = 'customer';
    if (!empty($p['CardLinkHash']) && !empty($pay['cardLinkHash']) && $pay['cardLinkHash'] !== $p['CardLinkHash']) $problems[] = 'CardLinkHash';
    return $problems;
}

function paynetProcess(array $n, $db, string $apiUrl, string $token): void {
    $p = $n['Payment'];
    if (($n['EventType'] ?? '') !== 'PAID') { $db->sendToReview($p['ExternalId'], ['EventType']); return; }
    $order = $db->findOrder($p['ExternalId']);
    if (!$order) { $db->sendToReview($p['ExternalId'], ['unknown order']); return; }

    $problems = paynetConfirmWithApi($n, $order, $apiUrl, $token);
    if (($p['PaidAmount'] ?? null) !== $p['Amount'] && empty($order['promotionAgreed'])) $problems[] = 'PaidAmount differs from Amount';
    if ($problems) { $db->sendToReview($p['ExternalId'], $problems); return; }

    $db->markPaid($p['ExternalId'], $p['PaidAmount']);
    if (!empty($p['CardLinkHash'])) $db->saveCard($order['customerCode'], $p['CardLinkHash']);
}

// --- Endpoint -------------------------------------------------------------
function paynetHandleRequest($db, callable $getToken): void {
    $raw = file_get_contents('php://input');
    $n   = json_decode($raw, true);
    if (!is_array($n) || !paynetVerifyHash($n, $_SERVER['HTTP_HASH'] ?? '', getenv('PAYNET_NOTIFICATION_SECRET'))) {
        http_response_code(400);
        exit('Invalid notification');
    }
    $isNew = $db->saveNotificationOnce($n['Payment']['Id'] ?? null, $n); // idempotency by Payment.Id

    // Answer 200 first.
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['ResultCode' => 'SUCCESS']);
    if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();

    if ($isNew) {
        try {
            paynetProcess($n, $db, getenv('PAYNET_API_URL'), $getToken());
        } catch (Throwable $e) {
            error_log('Paynet notification processing failed: ' . $e->getMessage()); // retry from storage later
        }
    }
}
\`\`\`

## Respond and retries

- Answer HTTP \`200\` **after** you have verified the hash and saved the result.
- Answer fast: store the notification, return \`200\`, and do heavy processing after the response.
- Any other response (or no response) is treated as a failure, and Paynet sends the notification again. After a \`200\` response, retries stop.
- Only the HTTP code counts; the response body does not matter. \`{ "ResultCode": "SUCCESS" }\` in the examples is optional.
- Schedule — **9 attempts**; the retries run for about 25 minutes after the first attempt, then sending stops:

| Attempt | When |
|---|---|
| 1 | after the card-issuing bank confirms the payment (depends on the bank: from a few seconds to several minutes) |
| 2–4 | after ~1 minute, then every ~35 seconds |
| 5–7 | after ~5 minutes, then every ~35 seconds |
| 8–9 | after ~15 minutes, then after ~35 seconds |

> **Important:** retries last only about 25 minutes after the first attempt. If your server was down longer, the notification will not come again. So check the status of unpaid orders through the API and reconcile daily.

- Because of retries the same notification can arrive more than once. Process each \`Payment.Id\` only once.
- If a notification did not arrive (for example, your server was down longer than all attempts), check the status with \`GET /api/order/{paymentId}\` or \`GET /api/order/merchant/{Order}\`. You can ask Paynet support to send it again.
- If your server is behind a firewall, allow incoming requests from Paynet's IP addresses: \`93.113.159.22\` — production, \`93.113.159.23\` — test environment.
- Antifraud will not cancel a payment you received \`PAID\` for: it acts before the payment is confirmed. A paid payment changes status only after your own [refund](#/guides/errors-and-statuses) (\`5\` or \`6\`).

## Notification simulator on this portal

Open **General → Notifications → Notification simulator**:

1. Enter your callback URL. It must be reachable from the internet and, **for the simulator only**, accept requests from the browser (CORS).
2. Check the notification secret key: the test key \`D9873689-E5F8-4272-A67F-0D8BA3F9BAA7\` is already filled in; you can replace it with your own.
3. Enter your merchant order number (\`Order\`) of a **paid** test payment and press **Get** — the portal loads the payment.
4. Press **Send notification** — the portal sends a signed \`PAID\` notification built from that payment to your URL and shows the \`PreparedString\` and \`Hash\` it used.

This is a simulation sent from your browser, not a real Paynet notification. For unpaid orders the simulator sends nothing, just like Paynet.

> **Important:** CORS is needed only for the simulator, because it posts from your browser. Real notifications are sent by the Paynet server, and CORS does not apply to them: do not enable CORS on your production endpoint for Paynet. A successful simulation checks your signature verification and processing, not delivery from Paynet (network access, firewall, TLS certificate). Confirm delivery with a real test payment.
`,"../../content/en/common/02-signatures.md":'# Signatures\n\nPaynet uses one hashing scheme everywhere:\n\n```text\nSignature = Base64( MD5( <string to sign> + SecretKey ) )\n```\n\n- MD5 over the **UTF-8** bytes of the string (also for Cyrillic and Romanian diacritics).\n- Base64 of the **raw 16-byte digest** (not of the 32-character hex string). The result is always 24 characters and ends with `==`.\n- Do not confuse it with the `signature` field in the `POST /api/order` response: that is an internal value of the payment link (32 characters, equal to the `s` parameter in `paymentLink`). Do not use it for verification.\n\nWhat changes is how the string to sign is built:\n\n| Where | String to sign | Secret key |\n|---|---|---|\n| Hosted checkout form (you → Paynet) | `RawData`: signed field values, sorted by field name, RFC 3986-encoded, concatenated | hosted checkout secret key |\n| Notifications (Paynet → you) | `PreparedString`: 9 notification values in fixed order | notification secret key |\n\nThe two secret keys are different on purpose. Paynet issues both to you.\n\n## Test vector 1: hosted checkout form\n\nSecret key (test): `F90D6485-9CCC-458B-96A3-8958AF9B4458`\n\nInput fields:\n\n```json\n{\n  "Order": 1762444800000,\n  "Currency": "498",\n  "Merchant": "265505",\n  "SaleAreaCode": "onlidocumentation_md",\n  "Amount": "1235",\n  "Description": "Test&Co SRL",\n  "CustomerCode": "5555",\n  "CustomerNameFirst": "First name",\n  "CustomerNameLast": "Last name",\n  "CustomerPhoneNumber": "060000000",\n  "CustomerEmail": "test@gmail.com",\n  "ExpiryDate": "2026-12-31T23:59:59",\n  "LinkUrlCancel": "https://test.oplta.md/cancel",\n  "LinkUrlSuccess": "https://test.oplta.md/ok",\n  "Lang": "ro",\n  "MoneyType": "Card"\n}\n```\n\nField order after sorting: `Amount, Currency, CustomerCode, CustomerEmail, CustomerNameFirst, CustomerNameLast, CustomerPhoneNumber, Description, ExpiryDate, Lang, LinkUrlCancel, LinkUrlSuccess, Merchant, MoneyType, Order, SaleAreaCode`.\n\nExpected `RawData`:\n\n```text\n12354985555test%40gmail.comFirst%20nameLast%20name060000000Test%26Co%20SRL2026-12-31T23%3A59%3A59rohttps%3A%2F%2Ftest.oplta.md%2Fcancelhttps%3A%2F%2Ftest.oplta.md%2Fok265505Card1762444800000onlidocumentation_md\n```\n\nExpected `Signature`:\n\n```text\ncxr/+yLYZp34aR0KXLkb2A==\n```\n\n## Test vector 2: notification\n\nNotification secret key (test): `D9873689-E5F8-4272-A67F-0D8BA3F9BAA7`\n\n```json\n{\n  "Eventid": 1000001,\n  "EventType": "PAID",\n  "EventDate": "2026-11-09T12:00:00",\n  "Payment": {\n    "Id": 1234567,\n    "ExternalId": 1762444800000,\n    "Merchant": "265505",\n    "Customer": "37369XXX111",\n    "StatusDate": "2026-11-09T12:00:00",\n    "Amount": 1235\n  }\n}\n```\n\n(Only the fields used in the signature are shown; the real notification has more, see [Notifications](#/guides/notifications).)\n\nExpected `PreparedString`:\n\n```text\n2026-11-09T12:00:001000001PAID123537369XXX111176244480000012345672655052026-11-09T12:00:00\n```\n\nExpected `Hash`:\n\n```text\nlq3+OCn0J/zSyNF5iAoShg==\n```\n\n## Test vector 3: special characters\n\nSame secret key as vector 1. The values contain `\'`, `&`, `!`, `(`, `)`, `*`, Cyrillic and Romanian letters. The test environment accepted this exact form (11.11.2026).\n\n```json\n{\n  "Order": 1762444800003,\n  "Currency": "498",\n  "Merchant": "265505",\n  "SaleAreaCode": "onlidocumentation_md",\n  "Amount": "1235",\n  "Description": "Mary\'s Cake & Co! (1)*",\n  "CustomerCode": "5555",\n  "CustomerNameFirst": "Мария",\n  "CustomerNameLast": "Țurcan",\n  "ExpiryDate": "2026-12-31T23:59:59",\n  "LinkUrlCancel": "https://test.oplta.md/cancel",\n  "LinkUrlSuccess": "https://test.oplta.md/ok",\n  "Lang": "ro",\n  "MoneyType": "Card"\n}\n```\n\nExpected `RawData`:\n\n```text\n12354985555%D0%9C%D0%B0%D1%80%D0%B8%D1%8F%C8%9AurcanMary%27s%20Cake%20%26%20Co%21%20%281%29%2A2026-12-31T23%3A59%3A59rohttps%3A%2F%2Ftest.oplta.md%2Fcancelhttps%3A%2F%2Ftest.oplta.md%2Fok265505Card1762444800003onlidocumentation_md\n```\n\nExpected `Signature`:\n\n```text\nfm47qWzVzqPQQ+huHgWVZw==\n```\n\n## Special characters\n\nResults of real form submissions to the test environment:\n\n| The value contains | Result |\n|---|---|\n| `" \' & < > # ; % + = ? / \\`, `’`, emoji, Cyrillic, Romanian letters | Works if every value is RFC 3986-encoded (table below). |\n| A line break (multi-line `Description`) | The signature fails. Replace line breaks with a space before signing. |\n| An HTML tag (`<b>`) or an HTML entity (`&#039;`) | Paynet rejects the form before checking the signature: the customer sees the Paynet home page instead of the payment page. Remove tags and turn entities into plain characters before signing. |\n\nEncoding function by language:\n\n| Language | Correct | Wrong (breaks on some characters) |\n|---|---|---|\n| PHP | `rawurlencode($v)` | `urlencode($v)`: space becomes `+`, `~` becomes `%7E` |\n| JavaScript / Node.js | `encodeURIComponent(v).replace(/[!\'()*]/g, (c) => \'%\' + c.charCodeAt(0).toString(16).toUpperCase())` | `encodeURIComponent(v)` alone: leaves `! \' ( ) *` |\n| Python | `urllib.parse.quote(v, safe="~")` | `quote(v)` (leaves `/`), `quote_plus(v)` (space becomes `+`) |\n| C# | `Uri.EscapeDataString(v)` (.NET Core / .NET 5+) | `HttpUtility.UrlEncode`, `WebUtility.UrlEncode`: space becomes `+` |\n| Java | `URLEncoder.encode(v, StandardCharsets.UTF_8).replace("+", "%20").replace("*", "%2A").replace("%7E", "~")` | `URLEncoder.encode` alone: space becomes `+`, `*` is left |\n\nRules:\n\n- Sign the original values: exactly what the browser will send. Do not sign HTML-escaped text (`&amp;`, `&#039;`).\n- Escape values for HTML only once, when you write them into the form (`&` → `&amp;`, `"` → `&quot;`). An unescaped `"` cuts the value off inside `value="…"`.\n- Do not change values after signing (trimming, replacing characters, shortening).\n- Serve the page in UTF-8 (`<meta charset="utf-8">`) and add `accept-charset="UTF-8"` to the form.\n- If your CMS gives you product names with HTML entities (`Mary&#039;s`), decode them (`Mary\'s`) before you build the form.\n\n## Check your implementation\n\nPython:\n\n```python\nimport base64, hashlib, urllib.parse\n\ndef md5_base64(text: str) -> str:\n    return base64.b64encode(hashlib.md5(text.encode("utf-8")).digest()).decode()\n\nSIGNED = ["Order", "Currency", "Merchant", "SaleAreaCode", "CustomerCode", "CustomerNameFirst",\n          "CustomerNameLast", "CustomerPhoneNumber", "CustomerEmail", "ExpiryDate", "Description",\n          "Amount", "LinkUrlCancel", "LinkUrlSuccess", "Lang", "MoneyType"]\n\ndef checkout_signature(fields: dict, secret: str) -> str:\n    names = sorted(n for n in SIGNED if fields.get(n) is not None)\n    raw = "".join(urllib.parse.quote(str(fields[n]), safe="~") for n in names)\n    return md5_base64(raw + secret)\n\ndef notification_hash(n: dict, secret: str) -> str:\n    s = lambda v: "" if v is None else str(v)\n    p = n.get("Payment", {})\n    prepared = (s(n.get("EventDate")) + s(n.get("Eventid")) + s(n.get("EventType")) + s(p.get("Amount"))\n                + s(p.get("Customer")) + s(p.get("ExternalId")) + s(p.get("Id")) + s(p.get("Merchant"))\n                + s(p.get("StatusDate")))\n    return md5_base64(prepared + secret)\n```\n\nC#:\n\n```csharp\nusing System.Security.Cryptography;\nusing System.Text;\n\nstatic string Md5Base64(string text) =>\n    Convert.ToBase64String(MD5.HashData(Encoding.UTF8.GetBytes(text)));\n\n// Hosted checkout form: Uri.EscapeDataString implements RFC 3986.\nstatic string CheckoutSignature(IDictionary<string, string?> fields, string secret)\n{\n    string[] signed = { "Order", "Currency", "Merchant", "SaleAreaCode", "CustomerCode", "CustomerNameFirst",\n        "CustomerNameLast", "CustomerPhoneNumber", "CustomerEmail", "ExpiryDate", "Description", "Amount",\n        "LinkUrlCancel", "LinkUrlSuccess", "Lang", "MoneyType" };\n    var raw = new StringBuilder();\n    foreach (var name in signed.Where(n => fields.TryGetValue(n, out var v) && v != null).OrderBy(n => n, StringComparer.Ordinal))\n        raw.Append(Uri.EscapeDataString(fields[name]!));\n    return Md5Base64(raw + secret);\n}\n```\n\n## Common mistakes\n\n| Symptom | Cause |\n|---|---|\n| Signature has 32 hex characters | You Base64-encoded the hex string or did not Base64 at all. Base64 the raw digest. |\n| Works for some orders, fails for others | Values with spaces, `&`, `@`, `:` or `/` are not RFC 3986-encoded, or `+` is used for spaces instead of `%20`. |\n| Notification hash never matches | Wrong secret key (checkout and notification keys are different), fields in the wrong order, or the code reads `Payment.ID` / `Payment.ExternalID` instead of `Payment.Id` / `Payment.ExternalId` (keys are case-sensitive). |\n| Hash differs only for Cyrillic/Romanian names | The string was not encoded as UTF-8 before hashing. |\n| Signature fails after you added a field | A signed field was added to the form but not to `RawData` (or the other way round). |\n| Fails only when a value contains `\'`, `!`, `(`, `)` or `*` | `encodeURIComponent` (or another function) that does not encode these five characters. See "Special characters" above. |\n| After the form is sent, the Paynet home page opens instead of the payment page | A value contains an HTML tag (`<b>`) or an HTML entity (`&#039;`). See "Special characters" above. |\n| Fails when `Description` has several lines | A line break in a value. Replace it with a space before signing. |\n',"../../content/en/common/03-errors-and-statuses.md":'# Errors and statuses\n\n## Cheat sheet: what to do on an error\n\nChecked on the test environment on 10.11.2026. Details on each format are in the sections below.\n\n| HTTP | What the response contains | When it happens | What to do | Retry the request? |\n|---|---|---|---|---|\n| `400` | `INVALID_PARAMETER`, `details` names the field | Invalid parameter value | Fix the field named in `details` | Only after fixing |\n| `400` | `errorInfo`, `errors` lists the fields | Unreadable JSON, missing required fields, wrong type (for example, letters instead of a number in `paymentId` in the URL) | Fix the request | Only after fixing |\n| `401` | `UNAUTHORIZED` (capitalised keys: `Status`, `Code`…) | No token, or it is invalid or expired | Get a new token from `/auth` | Yes, once with the new token |\n| `401` | `AUTHENTICATION_FAILED` | `/auth`: wrong username or password | Check the credentials (test and production ones differ) | No |\n| `404` | `NOT_FOUND_RECORD` | No payment with this ID; refund of an unpaid payment; search: no payments in the period (an empty result) | Check `paymentId` / `Order` and the payment status; for search, treat it as an empty result | No |\n| `404` | Empty body | Wrong address (path) | Check the URL and API address | No |\n| `405` | Empty body | Wrong HTTP method (for example, `GET` instead of `POST`) | Check the method | Only after fixing |\n| `415` | Empty body | No `Content-Type: application/json` header, or the body is not JSON (including `/auth`) | Add the header, send JSON | Only after fixing |\n| `500` | `TECHNICAL_ERROR` | `Order` repeated with different data or after payment; or a failure on Paynet\'s side | First check `GET /api/order/merchant/{Order}`. If it is a repeated `Order`, create an order with a new `Order` | Only after checking |\n| — | No response (timeout, network) | Connection problem | Look the order up by `Order`; if it does not exist, repeat **the same** request unchanged | Yes, with the same body |\n\n- No `403`, `429` or `503` responses were seen on the test environment. No rate limiting was observed: 100 parallel requests returned `200`. Paynet does not publish official limits, so do not send requests in a loop without a pause.\n- In `errorInfo`, `ppResponseCodeDescription` may say "We are sorry, this service is temporarily unavailable" even for an ordinary validation error. Rely on `errors`, not on this text, and do not show it to the customer.\n- If you get `401` for the token: get a new token and repeat the request **once**. If it is `401` again, check the credentials.\n\n## HTTP status codes\n\n| HTTP | `code` | Meaning | What to do |\n|---|---|---|---|\n| `200` | — | Success. | — |\n| `400` | `INVALID_PARAMETER` | One or more parameters are missing or invalid. `details` names the parameter. | Fix the request. Do not retry unchanged. |\n| `401` | `UNAUTHORIZED` | Bearer token is missing, invalid or expired. | Call `/auth` again and retry once. |\n| `404` | `NOT_FOUND_RECORD` | No payment/record for the given ID. | Check the ID (`paymentId` vs your `Order`). |\n| `500` | `TECHNICAL_ERROR` | Error on Paynet side, **or** a repeated `Order` that cannot be reused (see below). | Check with `GET /api/order/merchant/{Order}` whether the order exists; if it is a real technical error, retry later with backoff. |\n| `401` | `AUTHENTICATION_FAILED` | `/auth` with wrong username or password. | Check credentials. |\n\n## Error body\n\n```json\n{\n  "status": 400,\n  "message": "One or more entered parameters are incorrect.",\n  "code": "INVALID_PARAMETER",\n  "traceId": "9b9346f9-f83a-465d-ac8d-dc382c460c22",\n  "details": "The invalid parameter is: XXXX"\n}\n```\n\n| Field | Description |\n|---|---|\n| `status` | HTTP status. |\n| `message` | Human-readable message. |\n| `code` | Machine-readable error code (table above). |\n| `traceId` | Request ID. Send it to Paynet support when you report a problem. |\n| `details` | Extra information, e.g. the invalid parameter. |\n\n> **Note:** a `401` for a missing, invalid or expired token uses capitalised keys (`Status`, `Message`, `Code`, `TraceId`), while the `401` from `/auth` for a wrong password uses the usual ones (`status`, `message`…). Read error fields case-insensitively.\n\n### Invalid JSON or missing required fields\n\nIf the request body cannot be read (invalid JSON, wrong types, a required field missing), the API answers `400` in a different format, with the error inside `errorInfo`:\n\n```json\n{\n  "errorInfo": {\n    "title": "One or more validation errors occurred.",\n    "status": 400,\n    "ppResponseCodeEnum": "TECHNICAL_ERROR",\n    "ppResponseCode": 1,\n    "ppResponseCodeText": "TECHNICAL_ERROR",\n    "errors": {\n      "$": ["JSON deserialization for type \'…DeleteLinkedCardRequest\' was missing required properties including: \'cardLinkHash\', \'saleAreaCode\', \'customerCode\'."]\n    },\n    "traceId": "00-7c209d88f31e3e5cd2f7bd88ae2f23c2-ad167338e418068c-00"\n  }\n}\n```\n\n`errors` lists the problem fields. Handle both error formats: check for `errorInfo` first, then read `status` / `code` / `message`.\n\nRequest field names are not case-sensitive: `CardLinkHash` and `cardLinkHash` are both accepted (checked on the test API). Use the spelling from the examples.\n\n## Repeated order number (Order)\n\n| Situation | Result |\n|---|---|\n| New `Order` | A new payment is created. |\n| Same `Order`, **same data**, payment not paid yet | The same `paymentId` and `paymentLink` are returned. Safe to repeat, e.g. after a timeout. |\n| Same `Order`, **different data** (amount, products, …) | Server-to-server: HTTP `500`, `TECHNICAL_ERROR`. |\n| Same `Order`, payment already paid or being processed by the card issuer | Server-to-server: HTTP `500`, `TECHNICAL_ERROR`. Hosted checkout: the customer sees the Paynet page "Plata a fost respinsă" (this invoice is already paid or being processed). |\n\nError body in these cases:\n\n```json\n{\n  "status": 500,\n  "message": "One or more errors occurred.",\n  "code": "TECHNICAL_ERROR",\n  "traceId": "11de6054-87ef-484d-a368-7cfae0b452ff",\n  "details": "Please verify the transmitted data and try again, or contact support."\n}\n```\n\n**Rule:** one order in your shop = one `Order`. If the customer changes the cart, create a new order with a new `Order`.\n\n## Payment status\n\nThe payment object (`POST /api/order`, `GET /api/order/{id}`, `GET /api/order/merchant/{id}`, `GET /api/order/search`) has a numeric `status` and the dates `registered`, `paidDate`, `expiryDate`.\n\nA newly created order has `status` = `1` and `paidDate` = `null`.\n\n| `status` | Meaning | What to do |\n|---|---|---|\n| `1` | Registered: the order exists, no payment yet | Wait for payment. If the customer left the page, you can send them to the same `paymentLink` again (the one from the create response, see below). |\n| `3` | Pending: the customer pressed "Pay", the bank has not answered yet | Do not create the order again and do not cancel it. Check the status later. |\n| `4` | Paid | Fulfil the order. |\n| `5` | Not paid (declined by the bank, cancelled by antifraud) or fully refunded | Final. A new payment attempt needs an order with a new `Order`. |\n| `6` | Paid, then partially refunded | Final. The customer paid; part of the money was returned. |\n\n```\n1 ──► 3 ──► 4 ──► 5  (full refund / полный возврат / rambursare totală)\n      │      └──► 6  (partial refund / частичный возврат / rambursare parțială)\n      └──► 5  (declined, antifraud / отказ, антифрод / refuz, antifraudă)\n```\n\n- `5` and `6` are final: nothing changes after them. The value `2` is not used.\n- There is no separate "expired" status: if `ExpiryDate` has passed without payment, the order stays `1`, but it can no longer be paid.\n- Antifraud acts before the payment is confirmed. Once you have received a verified `PAID` notification, antifraud will not cancel that payment; status `5` on a paid order means a full refund only.\n- Treat a payment as paid when you received a verified `PAID` notification or `status` = `4`. `6` also means the customer paid (then part was refunded); `5` after a payment means it was refunded in full.\n- If the customer fails 3-D Secure, the payment gets status `5` and the customer returns to `LinkUrlCancel` — the same as a bank decline.\n- The reason for a decline (bank decline, antifraud, 3-D Secure) is not available through the API: status `5` only means this order is closed and a new attempt needs a new `Order`.\n\n### Failed payment and another attempt\n\nA failed payment does not produce a notification: the customer returns to `LinkUrlCancel`. Check the status with `GET /api/order/merchant/{Order}`:\n\n| `status` | What happened | How to let the customer pay again |\n|---|---|---|\n| `1` | The customer did not pay (for example, closed the page) | Send them to the same `paymentLink`. |\n| `3` | The payment is still being processed | Wait and check the status again. Do not create a new order. |\n| `5` | The bank declined the payment | The order is closed. Create a new order with a **new** `Order` and send the customer to the new `paymentLink`. |\n\n**Keep the `paymentLink` from the `POST /api/order` response.** Only that response has the full link (with the payment number and `?s=…`). In `GET /api/order/…` responses `paymentLink` is cut to `https://…/ecom/getecom` and cannot be opened. If you lost the link, send the same `POST /api/order` again with the **same body** (same `Order`, same data): you get the same payment and the same link.\n\n## Dates and formats\n\n| Where | Format | Example |\n|---|---|---|\n| `ExpiryDate` in requests | `YYYY-MM-DDTHH:mm:ss`, **Chișinău local time** | `2026-12-31T23:59:59` |\n| Dates in payment responses | `YYYY-MM-DD HH:mm:ss` | `2026-04-01 15:01:12` |\n| `eventDate` in the refund response | `DD.MM.YYYY HH:mm:ss` | `09.11.2026 18:17:54` |\n| Dates in notifications | `YYYY-MM-DDTHH:mm:ss`, Chișinău local time | `2026-11-09T12:00:00` |\n| `from` / `to` in `/api/order/search` | `YYYY-MM-DDTHH:mm:ss`, **Chișinău local time**, without `Z` (a `Z` or offset is ignored) | `2026-03-09T08:40:05` |\n| `dateStart` / `dateFinish` in statements | date | `2026-03-01` |\n| Amounts | integer, minor units | `1201` = 12.01 MDL |\n| Currency | ISO 4217 numeric | `498` = MDL |\n\nChișinău local time is the `Europe/Chisinau` time zone: UTC+2 in winter, UTC+3 in summer. If your server runs in UTC, convert before you build `ExpiryDate`, otherwise orders expire 2–3 hours earlier than intended.\n\n## Refunds\n\n`POST /api/order/refund`:\n\n```json\n{\n  "PaymentId": 328733,\n  "SaleAreaCode": "onlidocumentation_md",\n  "RefundType": "full",\n  "Amount": 400,\n  "Currency": 498,\n  "Reason": "Customer request"\n}\n```\n\n| Rule | Value |\n|---|---|\n| What can be refunded | Only a paid payment (`status` = `4`). |\n| How many times | **One** refund per payment: full (`full`) or partial (`partial`). A second refund of the same payment is not possible. |\n| Amount | `Amount` in minor units; at most the payment\'s `PaidAmount` (lower than the order amount when a promotion applied). For a full refund send `RefundType` `full` and `Amount` = `PaidAmount` (`amount.paidAmount` from `GET /api/order/merchant/{Order}`). |\n| Deadline | 180 days after payment. |\n| Payment methods | All except `CASH_INVOICE`. |\n| Result | Immediately in the `POST /api/order/refund` response: `200` = the refund is done. No callback notification is sent for refunds. |\n| Repeating the request | Not safe: a second refund returns `400`. After a timeout or network error, first check the status with `GET /api/order/merchant/{Order}`: `5` or `6` means the refund went through. |\n| Status afterwards | `5` after a full refund, `6` after a partial one. Both are final. |\n| Merchant balance | If there is no money on the merchant\'s Paynet account, the refund does not go through. |\n\n### Refund responses (checked on the test environment)\n\nThe request example above and the response below are the same test payment (paid 4.00 MDL, refunded in full).\n\n| Situation | Response |\n|---|---|\n| Refund done | `200`, body below |\n| Payment not paid | `404 NOT_FOUND_RECORD` |\n| Amount above the paid amount | `400 INVALID_PARAMETER`, `details`: "The invalid parameter is: RefundType". The field named in `details` is misleading: the cause is the amount |\n| Another refund of the same payment (for example, full after partial) | `400 INVALID_PARAMETER`, `details`: "The invalid parameter is: RefundType" |\n\n```json\n{\n  "paymentId": 328733,\n  "saleAreaCode": "onlidocumentation_md",\n  "customer": "464566161",\n  "eventDate": "09.11.2026 18:17:54",\n  "refundType": "full",\n  "currency": 498,\n  "amount": 400,\n  "merchant": "265505",\n  "cardMask": "411111******1111",\n  "cardLinkHash": null,\n  "moneyType": "CYBER_SOURCE"\n}\n```\n\n- `eventDate` in the refund response uses the format `DD.MM.YYYY HH:mm:ss`.\n- `moneyType` here is the processing code (for example `CYBER_SOURCE`), not the notification value (`CARD`…).\n- After a refund the payment\'s `paidDate` stays filled.\n\n## Contacting support\n\n- **If a Paynet manager is onboarding you:** usually a shared Telegram chat is created with a Paynet developer and your developer. There you get credentials and links and can ask integration questions. Ask your manager to create such a chat.\n- **If you have not talked to a manager yet:** write to [support@paynet.md](mailto:support@paynet.md).\n\nTo get a fast answer, send right away:\n\n| What | Example |\n|---|---|\n| `traceId` from the error response | `9b9346f9-f83a-465d-ac8d-dc382c460c22` |\n| Method and address | `POST https://ecom-api-test.paynet.md/api/order` |\n| Date and time of the request (Chisinau time) | `10.11.2026 12:05` |\n| `Order` and / or `paymentId` | `1762444800000`, `328731` |\n| Sale area and merchant | `onlidocumentation_md`, `265505` |\n| HTTP code and the full response body | `400`, `{ "errorInfo": … }` |\n| Test or production | test |\n\nNever send your password, secret keys or token.\n',"../../content/en/common/04-ai-assistants.md":'# Integrate with an AI assistant\n\nYou can hand this documentation to any AI coding assistant (Claude, ChatGPT, Gemini, Copilot, Cursor and others) and ask it to write the integration.\n\n## Files for AI\n\n| File | What it contains | When to use |\n|---|---|---|\n| [`llms-full.txt`](llms-full.txt) | The whole documentation in one plain-text file: all products, guides, API reference, signatures with test vectors, test data | Give this one file to the assistant. |\n| [`llms-ecom.txt`](llms-ecom.txt) | E-commerce only, plus the general topics it needs (notifications, signatures, errors) | When you integrate only e-commerce payments. |\n| [`llms.txt`](llms.txt) | Short index with links to every page | For assistants that browse links themselves. |\n| [`openapi.json`](openapi.json) | OpenAPI 3 specification of the server-to-server API | For code generators and typed clients. |\n| `docs/<page>.md`, `docs/ru/<page>.md`, `docs/ro/<page>.md` | Each guide as a separate Markdown file (English, Russian, Romanian) | When you need only one topic. |\n| `docs/api/<method>.md` | Each API method as a separate Markdown file | When you work on one endpoint. |\n\nEvery guide and API method page has a **Copy for AI** button. It copies the page as Markdown; its menu (the arrow next to it) also opens the page as Markdown or in ChatGPT, Claude or Gemini with a ready question.\n\n> **Note:** most assistants cannot read this portal by opening its address, because the pages are rendered with JavaScript. Give them `llms-full.txt` or `llms-ecom.txt` (upload the file or paste its link). The AI files are in English, the language models work with best; the assistant can answer you in any language.\n\n## Connect an assistant in your editor\n\nCoding assistants in the editor work best when the documentation is part of the project or added as a source:\n\n| Assistant | How to add the documentation |\n|---|---|\n| Cursor | Chat → `@Docs` → *Add new doc* → paste the `llms-full.txt` link. Then mention `@Docs` in your requests. |\n| VS Code (GitHub Copilot) | In the chat, use `#fetch` with the `llms-ecom.txt` link, or save the file into the project and attach it. |\n| Claude Code | Save `llms-ecom.txt` into the project (for example `docs/paynet.md`) and add to `CLAUDE.md`: *Paynet integration: follow docs/paynet.md*. |\n| Codex | Save `llms-ecom.txt` into the project and reference it in `AGENTS.md` the same way. |\n\nKeeping the file in the project also lets you see in code review which version of the documentation was used. Download it again when the documentation changes.\n\n## Prompt template\n\nCopy, fill in the brackets, and attach `llms-ecom.txt`:\n\n```text\nYou are integrating Paynet e-commerce payments into my project.\nUse ONLY the attached Paynet documentation as the source of truth.\n\nMy stack: [e.g. Node.js 20 + Express / PHP 8.2 + Laravel / Python 3.12 + Django]\nIntegration type: [official Paynet SDK (PHP / Node.js) | server-to-server API | hosted checkout form]\nWhat to build:\n1. Create a payment for a cart and redirect the customer to Paynet.\n2. A notification endpoint that verifies the Hash header and marks the order paid exactly once.\n3. A status check by paymentId used before fulfilment.\n\nRequirements:\n- If my stack is PHP or Node.js, use the official Paynet SDK from the documentation\n  (section "SDK for PHP and Node.js") instead of writing your own HTTP client.\n- Read credentials and secret keys from environment variables.\n- One shop order = one unique Order number; ExpiryDate in the future, in Europe/Chisinau time.\n- Amounts are integers in minor units (100 = 1.00 MDL).\n- Implement signatures exactly as documented and add unit tests that reproduce\n  the test vectors from the "Signatures" section.\n- Do not invent endpoints, fields or status values that are not in the documentation.\n  If something is missing, list it as an open question instead of guessing.\n```\n\n## Rules for the assistant\n\nThese rules are also included at the top of the AI files:\n\n1. Test API: `https://ecom-api-test.paynet.md`; production API: `https://ecom-api.paynet.md` (same paths: `/auth`, `/api/...`). Hosted checkout form: `https://test.paynet.md/ecom/checkout` (test), `https://paynet.md/ecom/checkout` (production).\n2. Authenticate with `POST /auth` (JSON), then send `Authorization: Bearer <token>`.\n3. One shop order = one `Order`. Repeating an `Order` with the same data returns the same payment; with different data, or after payment, it fails with `500 TECHNICAL_ERROR`.\n4. `ExpiryDate` is `YYYY-MM-DDTHH:mm:ss` in Chișinău local time (`Europe/Chisinau`) and must be in the future.\n5. Amounts are integers in minor units; `Currency` is `498` for MDL.\n6. Signatures are `Base64(MD5(UTF8(string + secretKey)))`, Base64 of the raw digest. The checkout secret key and the notification secret key are different.\n7. Notifications are sent only for paid payments (`EventType` = `PAID`). Keys are `Payment.Id` and `Payment.ExternalId` (case-sensitive). A failed payment only redirects the customer to `LinkUrlCancel`.\n8. `PaidAmount` must equal `Amount` unless the merchant has an agreed promotion with Paynet; otherwise do not fulfil automatically.\n9. Never trust the redirect to `LinkUrlSuccess`; confirm with a verified notification or the status API.\n10. Secrets never go to browser code or a mobile app.\n11. If the stack is PHP or Node.js, the assistant suggests the [official SDK](#/guides/sdk) instead of its own HTTP client.\n12. Payment search: `from`/`to` are Chișinău time; an empty period gives `404 NOT_FOUND_RECORD`.\n',"../../content/en/common/05-faq.md":`# FAQ

## Are test and production keys the same?

No. Production credentials and both secret keys (for the checkout form and for notifications) differ from the test ones. When going live, replace all values — see the [Go-live checklist](#/guides/go-live).

## How do I get production access?

It is sent to your company administrator's email. This takes from 5 minutes to several days depending on the features you connect.

## The customer returned to the success page, but there is no notification. Is the order paid?

Do not treat an order as paid only because the customer returned to \`LinkUrlSuccess\`. Wait for a verified \`PAID\` notification or check the status: \`GET /api/order/merchant/{Order}\`, \`status\` = \`4\` means paid. See [Payment status](#/guides/errors-and-statuses).

## The same notification arrived several times

That is normal: if your server did not answer \`200\`, Paynet sends the notification again. Process each \`Payment.Id\` once. See [Notifications](#/guides/notifications).

## A notification never arrived

Check the status with \`GET /api/order/merchant/{Order}\`. You can ask Paynet support to send the notification again.

## The bank declined the payment. Can the same order be paid again?

No: after a decline the order gets status \`5\` and is closed. Create a new order with a new \`Order\`. If the customer simply closed the page without paying, the order stays \`1\` and can be paid with the same \`paymentLink\`.

## A repeated \`POST /api/order\` with the same \`Order\` returned \`500\`

With the same \`Order\` and the same data Paynet returns the same payment. \`500 TECHNICAL_ERROR\` means the data differs, or the order is already paid or its payment is being processed. See [Repeated order number](#/guides/errors-and-statuses).

## Why is \`PaidAmount\` lower than \`Amount\`?

Normally they are equal. \`PaidAmount\` is lower only with a promotion officially agreed with Paynet (for example, a discount for cards of a certain bank). You receive \`PaidAmount\` minus the Paynet fee.

## Can I make a second refund of the same payment?

No. One refund per payment is possible: full or partial.

## Why does a refund fail?

Check that no more than 180 days have passed since payment; the payment method is not \`CASH_INVOICE\`; the payment has not been refunded yet; the amount is not above \`PaidAmount\`; there is money on the merchant's Paynet account. See [Refunds](#/guides/errors-and-statuses).

## Why does the order expire earlier than intended?

\`ExpiryDate\` is in Chișinău local time (\`Europe/Chisinau\`). If your server runs in UTC, convert the time, otherwise the order expires 2–3 hours early.

## The signature does not match

Check that the string is encoded in UTF-8; the right key is used (the checkout form and notifications have different keys); values are taken exactly as they appear in the JSON. Compare your code with the [test vectors](#/guides/signatures).

## Do I need CORS for notifications?

No. CORS is needed only by the notification simulator on this portal, because it posts from the browser. Real notifications are sent by the Paynet server.

## Why is \`CardLinkHash\` \`null\` in the notification?

Card saving is not enabled for your \`SaleAreaCode\`, the order had no \`Customer\`, or the customer unchecked "save card". See [Saved cards](#/guides/saved-cards).
`,"../../content/en/common/06-changelog.md":'# Changelog\n\n## Documentation v3.5.1 — 17.11.2026\n\n- **Portal build** (no changes to the API or the documentation texts): `npm run build:prod` now builds the complete portal for https://docs.paynet.md/api/ with all checks, on Windows, macOS and Linux (Node.js 22.12+). Libraries with known vulnerabilities removed or updated (Vite 8, js-yaml 4.3). The signature calculators on the portal compute MD5 without a third-party library; the results are the same (checked on the published test vectors).\n\n## Documentation v3.5 — 11.11.2026\n\n- **Example shop: step-by-step start for Windows, macOS and Linux** (found by running the example as a newcomer): checking Node.js, `tar -xf` instead of `unzip` (works on Windows 10/11), why an order stays `pending` and how to send the test notification, a troubleshooting table. The shop\'s Orders page and return page now show the ready command for sending the notification. See [Example shop](#/guides/example-shop).\n\n## Documentation v3.4 — 11.11.2026\n\n- **Special characters in the hosted checkout signature** (checked by real form submissions to the test environment): correct and wrong encoding functions for PHP, JavaScript, Python, C#, Java; line breaks break the signature; HTML tags and HTML entities make Paynet reject the form before the signature check. New test vector 3 with `\' & ! ( ) *`, Cyrillic and Romanian letters. See [Signatures](#/guides/signatures).\n- The "Previous portal version" link opens the previous documentation at https://docs.paynet.md/psp/.\n- `robots.txt` and `sitemap.xml` are published with the portal.\n\n## Documentation v3.3 — 10.11.2026\n\nClarifications found by a test in which a developer new to Paynet integrated using only this documentation.\n\n- **Products:** if you send `Products`, `LineNo`, `Name`, `UnitPrice`, `Quantity`, `Amount`, `TotalAmount` are required; `Code` and `Description` are optional (checked on the test environment). See [Server-to-server](#/guides/server-to-server).\n- **Payment link:** keep `paymentLink` from the create response — status responses return it shortened.\n- **Refunds:** full refund = `Amount` equal to `PaidAmount`; `200` = done; do not repeat a refund without checking the status first. The request and response examples now show the same payment. See [Errors and statuses](#/guides/errors-and-statuses).\n- Payment search dates in the formats table: Chișinău time, without `Z`.\n- Notifications: only the HTTP code `200` counts, the response body does not matter.\n- Getting started: where the merchant code is used.\n- `Customer.PhoneNumber`: optional, but without it the customer types the phone on the payment page. Examples now send it.\n- **Statuses:** `6` = paid, then partially refunded; `5` = not paid (declined, antifraud) or fully refunded.\n- **Notifications:** the first notification is sent after the card-issuing bank confirms the payment (timing depends on the bank); the retry intervals are unchanged.\n- **SDK notification example:** the notification is saved before the `200` answer, the order is fulfilled from the saved record.\n- `linkUrlSuccess` / `linkUrlCancel` in payment responses can be `null` (API reference, Node.js SDK types).\n- `Lang`: upper or lower case both work; an unknown value opens the page in English (checked on the test environment).\n- The example shop is now downloaded as an archive from this portal.\n\n## Documentation v3.2 — 10.11.2026\n\n- **Official SDKs for PHP and Node.js** (version 1.0.0, MIT license): authorization, orders, statuses, refunds with rule checks, saved cards, statements, notifications, hosted checkout form, errors. Checked on the test environment. See [SDK](#/guides/sdk).\n- **Mobile apps**: how an app takes payments through your server and the Paynet page. See [Mobile apps](#/guides/mobile-apps).\n- **Payment search:** `from`/`to` are Chișinău time; an empty period gives `404 NOT_FOUND_RECORD`. The Postman collection is fixed.\n- Product `Quantity` is in hundredths (`100` = 1 pc).\n\n## Documentation v3.1 — 10.11.2026\n\n- **New Postman collection** with TEST and PRODUCTION environments: the token is obtained automatically, every order is unique, data is passed between requests. Checked by a run on the test environment. See [Testing → Postman](#/guides/testing).\n- **Error cheat sheet** with a "retry the request?" column; `405`, `415` and `404` with an empty body added (checked on the test environment). See [Errors and statuses](#/guides/errors-and-statuses).\n- **Notification retry schedule:** 9 attempts within about 25 minutes. Paynet **IP addresses** for your firewall. See [Notifications](#/guides/notifications).\n- 3-D Secure and the decline reason in the statuses section; a "Contacting support" section.\n- Sidebar with icons; parameter tables are readable on phones.\n\n## Documentation v3 — 09.11.2026\n\n- **Example shop in Node.js** — a complete integration with no dependencies. Checked by an end-to-end test on the test environment: purchase, payment, notification, refund. See [Example shop](#/guides/example-shop).\n- **Mock responses for failure tests**: statuses `3`, `5`, `6`, refund errors, `401`, `errorInfo`, signed notifications. See [Testing](#/guides/testing).\n- **API specification checked against real responses** of the test environment: `/auth` with a wrong password returns `401` (not `500`); the token `401` format and the `errorInfo` format are described; `amount.paidAmount` is added; refund, search and statement response schemas are added.\n- **Saved cards checked on the test environment:** the same customer sees the card, another customer does not. See [Saved cards](#/guides/saved-cards).\n- **Complete notification handlers** in Node.js and PHP; the Node.js logic is tested on every build.\n\n## Documentation v2 — 09.11.2026\n\n- Multi-product portal: home page, site-wide search, "General" and "E-commerce" sections.\n- API rules confirmed by Paynet: payment statuses, failed payments, refunds, notification retries, saved cards, production access.\n- What the notification signature protects and how to confirm unsigned fields with the API.\n- FAQ, "Copy for AI" menu, AI files in three languages.\n- The description of the retired protocol from the old documentation removed.\n- This version is kept in the `documentation-v2` branch of the repository.\n\n## Documentation v1\n\nThe original portal. Available via the "Previous portal version" link at the bottom of the page.\n',"../../content/en/ecom/01-integration-options.md":`# E-commerce: integration options

Paynet e-commerce lets your online shop accept payments by card (including Apple Pay and Google Pay), Paynet wallet, MIA instant payments and cash invoice. There are three ways to integrate. All of them end on the same Paynet-hosted payment page, so you never collect card data yourself.

| | Server-to-server API | Hosted checkout (client-server) | Ready-made plugins |
|---|---|---|---|
| How the order reaches Paynet | your **backend** calls \`POST /api/order\` with a Bearer token | the customer's **browser** posts a signed HTML form to Paynet | the plugin does it for you |
| What protects the request | access token (\`/auth\`) | \`Signature\` = MD5 + Base64 with your secret key | plugin settings |
| What you get back | \`paymentId\` + \`paymentLink\` in JSON | the customer lands directly on the payment page | — |
| Status checks, refunds, statements | yes, same API | yes, via the server-to-server API (orders are found by your \`Order\`) | depends on plugin |
| Best for | custom shops and apps with a backend | simple sites, quick start without an API client | WordPress/WooCommerce, OpenCart, PrestaShop, Magento, CS-Cart, Shopify |

## How to choose

- **You have a backend and want full control** → [Server-to-server integration](#/guides/server-to-server). This is the most flexible option and gives you the \`paymentId\` immediately.
- **You only need a "Pay" button and do not want to call an API to create orders** → [Hosted checkout](#/guides/hosted-checkout). You still need a backend to compute the signature, because the secret key must never be in browser code.
- **You want less code** → ready-made [SDKs for PHP and Node.js](#/guides/sdk): authorization, refund rules, signatures and errors are already done.
- **You have a mobile app** → payments go through your server and the Paynet page, see [Mobile apps](#/guides/mobile-apps).
- **Your shop runs on a supported CMS** → download a plugin from [**Plugins**](#/page/plugins). Shopify is connected through Cybersource.

## What every integration needs

1. **A callback URL** for [notifications](#/guides/notifications). Paynet calls it when a payment is paid (only successful payments are notified). Send this URL to Paynet.
2. **Signature verification** of every notification, see [Signatures](#/guides/signatures).
3. **A status check** before you ship goods: \`GET /api/order/{paymentId}\` or \`GET /api/order/merchant/{order}\`.
4. **Unique order numbers** (\`Order\`) on your side: one shop order = one \`Order\`.
5. **Two secret keys** from Paynet: one for the hosted checkout signature, one for notifications.

## Common flow

\`\`\`text
Customer        Your shop (backend)                 Paynet
   |  checkout   |                                     |
   |-----------> | 1. create order (API or signed form)|
   |             |------------------------------------>|
   | 2. redirect to payment page                       |
   |-------------------------------------------------->|
   |              3. customer pays on Paynet page       |
   |<--------------------------------------------------|
   | 4. back to LinkUrlSuccess / LinkUrlCancel          |
   |             | 5. notification (POST, Hash header) |
   |             |<------------------------------------|
   |             | 6. verify Hash, check status, ship   |
\`\`\`

The redirect back to \`LinkUrlSuccess\` is only a user-interface step. **Do not mark an order as paid because the customer came back to the success page.** Rely on the notification and/or the status API.

If the payment fails, the customer is redirected to \`LinkUrlCancel\`. Paynet does not send a notification for failed payments.
`,"../../content/en/ecom/02-getting-started.md":'# Quick start\n\nThis page takes you from zero to a successful test payment in about 10 minutes, using the shared test account and the "Test API Request" panels on this portal. The customer pays on a Paynet-hosted payment page, so you never handle card data.\n\n## Environments\n\n| Item | Test | Production |\n|---|---|---|\n| API base URL | `https://ecom-api-test.paynet.md` | `https://ecom-api.paynet.md` |\n| Hosted checkout form URL | `https://test.paynet.md/ecom/checkout` | `https://paynet.md/ecom/checkout` |\n\nBoth environments use the same paths (`/auth`, `/api/...`).\n\n## Credentials\n\n| Item | Test (shared) | Production |\n|---|---|---|\n| API user (`username` / `password`) | `771064` / `sLgMnGWJ` | issued to your company by Paynet |\n| Merchant code (`Merchant`) | `265505` — not sent in `POST /api/order`; used in the hosted checkout form and to check notifications (`Payment.Merchant`) | issued by Paynet |\n| Sale area code (`SaleAreaCode`) | `onlidocumentation_md` | issued by Paynet (one per website/shop) |\n| Secret key for the hosted checkout signature | `F90D6485-9CCC-458B-96A3-8958AF9B4458` | issued by Paynet, keep it secret |\n| Secret key for notifications | `D9873689-E5F8-4272-A67F-0D8BA3F9BAA7` | issued by Paynet, keep it secret |\n| Test card | Visa `4111 1111 1111 1111`, expiry `12/27`, CVV `777` | real cards |\n\nPaynet gives you **two different secret keys**: one signs the hosted checkout form, the other signs notifications. Do not mix them up.\n\n> **Note:** the test credentials above are public on purpose and shared by everyone who tests on this portal. Never use them in production and never put production secrets in front-end code.\n\n## Your first test payment (server-to-server)\n\n### Step 1. Get an access token\n\nIn the sidebar open **E-commerce → API methods → Authentication and authorization** and press **Test API Request**. Leave the username and password as they are.\n\n```http\nPOST https://ecom-api-test.paynet.md/auth\nContent-Type: application/json\n\n{ "grantType": "password", "username": "771064", "password": "sLgMnGWJ" }\n```\n\nExpected result: HTTP `200` with an `access_token` (valid for about 4 hours, see `expires_in`). The portal remembers the token and adds it to the next requests as `Authorization: Bearer <token>`.\n\n### Step 2. Create an order\n\nOpen **E-commerce → API methods → Create an order** and press **Test API Request**.\n\nThe portal pre-fills a unique `Order` number and an `ExpiryDate` for tomorrow, so the sample works as is. If you edit the request yourself, remember:\n\n- one order = one new `Order` number;\n- `ExpiryDate` must be in the future, format `YYYY-MM-DDTHH:mm:ss`, Chișinău local time;\n- amounts are integers in minor units: `300` = 3.00 MDL.\n\nExpected result: HTTP `200` with `paymentId`, `status` `1` and a `paymentLink` like `https://test.paynet.md/ecom/getecom/317184?s=…`.\n\n### Step 3. Pay on the payment page\n\nOpen the `paymentLink` in your browser and pay with the test card `4111 1111 1111 1111`, `12/27`, CVV `777`. After payment you are redirected to `LinkUrlSuccess`.\n\n### Step 4. Check the payment status\n\nOpen **E-commerce → API methods → Get a payment info by merchant order id**, enter your `Order` number and run the request. You will see the payment details; `paidDate` is set for a paid payment.\n\n### Step 5. Try the notification (webhook)\n\nOpen **General → Notifications → Notification simulator**. Enter your callback URL, the notification secret key and your `Order` number, then press **Get** and **Send notification**. The portal sends a simulated, signed `PAID` notification to your URL so you can test your handler. See [Notifications](#/guides/notifications).\n\n## Next steps\n\n- Choose how to integrate: [Integration options](#/guides/integration-options).\n- Read the full flow: [Server-to-server integration](#/guides/server-to-server) or [Hosted checkout](#/guides/hosted-checkout).\n- Using an AI assistant to write the integration? Start with [Integrate with an AI assistant](#/guides/ai-assistants).\n',"../../content/en/ecom/03-server-to-server.md":'# Server-to-server integration\n\nIn this model your backend talks to the Paynet API directly. It is the recommended option for shops with their own backend.\n\n## Overview\n\n1. `POST /auth` → get an access token.\n2. `POST /api/order` → register the order, receive `paymentId` and `paymentLink`.\n3. Redirect the customer to `paymentLink`.\n4. Receive the [notification](#/guides/notifications) on your callback URL and verify its `Hash`.\n5. Confirm with `GET /api/order/{paymentId}` and fulfil the order.\n\nBase URL: `https://ecom-api-test.paynet.md` (test), `https://ecom-api.paynet.md` (production). All bodies are JSON (`Content-Type: application/json`).\n\n## 1. Authenticate\n\n```http\nPOST /auth\nContent-Type: application/json\n\n{ "grantType": "password", "username": "771064", "password": "sLgMnGWJ" }\n```\n\n```json\n{ "access_token": "Ccxl7QQiMEoakkrUoiUn8PIg…", "token_type": "bearer", "expires_in": 14399 }\n```\n\nSend the token in every other request: `Authorization: Bearer <access_token>`. `expires_in` is in seconds (about 4 hours). Cache the token and request a new one when it expires or when the API returns `401`.\n\nWrong credentials return an error with `code` `AUTHENTICATION_FAILED`.\n\n## 2. Create an order\n\n```http\nPOST /api/order\nAuthorization: Bearer <access_token>\nContent-Type: application/json\n```\n\n```json\n{\n  "Order": 1762444800000,\n  "SaleAreaCode": "onlidocumentation_md",\n  "LinkUrlSuccess": "https://shop.example/payment/success",\n  "LinkUrlCancel": "https://shop.example/payment/cancel",\n  "Customer": {\n    "Code": "464566161",\n    "NameFirst": "First Name",\n    "NameLast": "Last Name",\n    "email": "customer@example.com",\n    "PhoneNumber": "37360000000"\n  },\n  "Currency": 498,\n  "ExpiryDate": "2026-12-31T23:59:59",\n  "Services": [\n    {\n      "Name": "Demo eShop",\n      "Description": "Order #1762444800000",\n      "Amount": 300,\n      "Products": [\n        {\n          "LineNo": 1,\n          "Code": "SKU-1",\n          "Name": "Demo product",\n          "Description": "Demo product",\n          "UnitPrice": 100,\n          "Quantity": 300,\n          "Amount": 300,\n          "TotalAmount": 300\n        }\n      ]\n    }\n  ],\n  "MoneyType": "All",\n  "Lang": "EN"\n}\n```\n\n### Request fields\n\n| Field | Type | Required | Description |\n|---|---|---|---|\n| `Order` | integer (int64) | yes | Your order number. One shop order = one `Order` (see [repeated order number](#/guides/errors-and-statuses)). |\n| `SaleAreaCode` | string | yes | Your sale area (website) code issued by Paynet. |\n| `LinkUrlSuccess` | string | yes | Where the customer returns after a successful payment. |\n| `LinkUrlCancel` | string | yes | Where the customer returns after cancelling. |\n| `Currency` | integer | yes | ISO 4217 numeric code. `498` = MDL. |\n| `ExpiryDate` | string | yes | Payment deadline, `YYYY-MM-DDTHH:mm:ss`, Chișinău local time (`Europe/Chisinau`), must be in the future. |\n| `Services` | array | yes | At least one service, see below. |\n| `MoneyType` | string | yes | `All`, `Card`, `Paynet`, `MIA` or `CashInvoice` (see below). |\n| `Lang` | string | yes | Payment page language: `RO`, `RU` or `EN`. Upper or lower case both work (`EN` = `en`). Checked on the test environment: with an unknown value the page opens in English. |\n| `Customer` | object | no | Customer data. Required to [save a card](#/guides/saved-cards) or to pay with a saved card. |\n| `Customer.Code` | string | yes, if `Customer` is sent | Customer ID in your system. |\n| `Customer.NameFirst`, `NameLast`, `email`, `PhoneNumber` | string | no | Customer details. Note the lowercase `email`. If you do not send `PhoneNumber`, the customer has to type the phone on the payment page (block "Billing information"). Send the customer\'s details when you have them, so the customer does not have to enter them. |\n| `CardLinkHash` | string | no | Saved card token of this customer, received in a notification. Send it together with the same `Customer`. See [Saved cards](#/guides/saved-cards). |\n\n`Services[]`:\n\n| Field | Type | Required | Description |\n|---|---|---|---|\n| `Name` | string | yes | Service name. |\n| `Description` | string | yes | Service description. |\n| `Amount` | integer | yes | Service amount in minor units. |\n| `Products` | array | no | Optional. If you send products, six fields of each product are required (see below). |\n\n`Services[].Products[]` — required: `LineNo` (int), `Name` (string), `UnitPrice` (int), `Quantity` (int), `Amount` (int), `TotalAmount` (int). Optional: `Code` (string), `Description` (string). Checked on the test environment: without any of the six required fields the API answers `400`.\n\n**`Quantity` is in hundredths:** `100` = 1 pc, `300` = 3 pcs. In the example above `"Quantity": 300` means 3 pcs at `UnitPrice` 1.00 MDL.\n\n**Amounts** are integers in minor units (bani): `1201` = 12.01 MDL.\n\n**MoneyType** selects which payment methods the customer sees:\n\n| `MoneyType` | Customer sees |\n|---|---|\n| `All` | all methods enabled for your merchant |\n| `Card` | card (Visa/Mastercard), Apple Pay, Google Pay |\n| `Paynet` | Paynet wallet |\n| `MIA` | MIA instant payments |\n| `CashInvoice` | cash invoice |\n\nThere is no separate value for Apple Pay or Google Pay: they are shown with `Card` and with `All`. The notification tells you how the customer actually paid (`CARD`, `APPLEPAY`, `GOOGLEPAY`, `MIA_QR`, `PAYNET`, `CASH_INVOICE`).\n\n### Response\n\n```json\n{\n  "paymentId": 328731,\n  "paymentLink": "https://test.paynet.md/ecom/getecom/328731?s=8fa1bd0923368d3bb700fccacc263735",\n  "cardLinkHash": null,\n  "status": 1,\n  "order": 1762444800000,\n  "merchantCode": "265505",\n  "saleAreaCode": "onlidocumentation_md",\n  "amount": { "requestAmount": 300, "requestCurrency": 498, "amount": 300, "paidAmount": null },\n  "expiryDate": "2026-12-31 23:59:59",\n  "registered": "2026-11-09 18:16:41",\n  "paidDate": null,\n  "moneyType": "All"\n}\n```\n\n(Test environment response, shortened. After payment `status` = `4`, and `paidDate` and `amount.paidAmount` are filled. The full response also contains `customer`, `payer`, `services`, `cardLinkHash`, `signature`, `linkUrlSuccess`, `linkUrlCancel`.)\n\nStore `paymentId` together with your order. It is the key for status checks, refunds and notifications.\n\n**Repeating the request.** Sending the same `Order` again with the same data (while it is not paid) returns the same `paymentId` and `paymentLink`, so it is safe to retry after a timeout. The same `Order` with different data, or after payment, fails with `500 TECHNICAL_ERROR`. If the cart changes, use a new `Order`.\n\n"The same data" means literally the same request. Store the request body with the order and resend it unchanged: for example, a recomputed `ExpiryDate` already counts as different data.\n\n## 3. Redirect the customer\n\nSend the customer\'s browser to `paymentLink` (HTTP 302 or a link/button). Save this link with the order: only the `POST /api/order` response has the full link; `GET /api/order/…` responses return it shortened, without the payment number. After a successful payment the customer returns to `LinkUrlSuccess`; if the payment fails or is cancelled, to `LinkUrlCancel`.\n\n## 4. Handle the notification\n\nPaynet sends a signed `POST` to your callback URL when the payment is paid (`EventType` = `PAID`; failed payments are not notified). Verify the `Hash` header, check that `PaidAmount` equals `Amount`, and answer HTTP `200`. See [Notifications](#/guides/notifications).\n\n## 5. Check the status\n\n```http\nGET /api/order/{paymentId}\nGET /api/order/merchant/{Order}\nAuthorization: Bearer <access_token>\n```\n\nBoth return the same payment object. Use them before shipping goods and whenever a notification did not arrive. See [Errors and statuses](#/guides/errors-and-statuses).\n\n## Other operations\n\n| Operation | Request | Notes |\n|---|---|---|\n| Search payments | `GET /api/order/search?from=…&to=…` | Date-time **in Chișinău time** without `Z`, e.g. `2026-03-09T08:40:05`. The API ignores the UTC marker (`Z`): UTC times shift the period by 2–3 hours, and recent payments are missed. If there are no payments in the period, the API answers `404 NOT_FOUND_RECORD` — an empty result, not an error. |\n| Refund | `POST /api/order/refund` | Body: `PaymentId`, `SaleAreaCode`, `RefundType` (`full` or `partial`), `Amount`, `Currency`, `Reason`. |\n| Unlink a saved card | `POST /api/linked-cards/unlink` | Body: `CardLinkHash`, `SaleAreaCode`, `CustomerCode`. |\n| Statement | `GET /api/statement?dateStart=…&dateFinish=…` | Dates like `2026-03-01`. Optional `accountId`. |\n| Statement (Excel) | `GET /api/statement/download?dateStart=…&dateFinish=…` | Returns an `.xlsx` file. Period of at most 31 days. |\n\n## Example: Node.js (18+)\n\n```javascript\nconst BASE_URL = \'https://ecom-api-test.paynet.md\';\n\nasync function getToken() {\n  const res = await fetch(`${BASE_URL}/auth`, {\n    method: \'POST\',\n    headers: { \'Content-Type\': \'application/json\' },\n    body: JSON.stringify({ grantType: \'password\', username: process.env.PAYNET_USER, password: process.env.PAYNET_PASSWORD }),\n  });\n  if (!res.ok) throw new Error(`Auth failed: ${res.status} ${await res.text()}`);\n  return (await res.json()).access_token;\n}\n\nasync function createOrder(token, order) {\n  const res = await fetch(`${BASE_URL}/api/order`, {\n    method: \'POST\',\n    headers: { \'Content-Type\': \'application/json\', Authorization: `Bearer ${token}` },\n    body: JSON.stringify(order),\n  });\n  const body = await res.json();\n  if (!res.ok) throw new Error(`Create order failed: ${res.status} ${JSON.stringify(body)}`);\n  return body; // { paymentId, paymentLink, status, ... }\n}\n```\n\n## Example: PHP\n\n```php\n<?php\n$baseUrl = \'https://ecom-api-test.paynet.md\';\n\nfunction paynetRequest(string $method, string $url, ?array $body = null, ?string $token = null): array {\n    $headers = [\'Content-Type: application/json\', \'Accept: application/json\'];\n    if ($token) { $headers[] = \'Authorization: Bearer \' . $token; }\n    $ch = curl_init($url);\n    curl_setopt_array($ch, [\n        CURLOPT_CUSTOMREQUEST  => $method,\n        CURLOPT_RETURNTRANSFER => true,\n        CURLOPT_HTTPHEADER     => $headers,\n    ]);\n    if ($body !== null) { curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body)); }\n    $raw = curl_exec($ch);\n    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);\n    curl_close($ch);\n    $data = json_decode($raw, true);\n    if ($status !== 200) { throw new RuntimeException("Paynet error $status: $raw"); }\n    return $data;\n}\n\n$auth  = paynetRequest(\'POST\', "$baseUrl/auth", [\'grantType\' => \'password\', \'username\' => getenv(\'PAYNET_USER\'), \'password\' => getenv(\'PAYNET_PASSWORD\')]);\n$token = $auth[\'access_token\'];\n// $payment = paynetRequest(\'POST\', "$baseUrl/api/order", $order, $token);\n// header(\'Location: \' . $payment[\'paymentLink\']);\n```\n',"../../content/en/ecom/04-saved-cards.md":`# Saved cards

A customer can save their card during the first payment and next time choose it on the Paynet page without typing the card number again.

This works only with the [server-to-server integration](#/guides/server-to-server). Card saving is not available in the hosted checkout form.

> **Important:** this is not a charge without the customer. The customer always goes through the Paynet page and confirms the payment. Paynet may ask for the CVC or 3-D Secure — this depends on your shop's settings on the Paynet side.

## Enabling

Card saving is enabled for your \`SaleAreaCode\` on the Paynet side: contact your Paynet manager. It is enabled for the shared test sale area \`onlidocumentation_md\`: you can try the flow with the test credentials.

## What \`CardLinkHash\` is

- Paynet's internal identifier of a saved card. It is not the card number and not a Visa/Mastercard network token.
- It is bound to the \`SaleAreaCode\` (which belongs to one merchant) and to the customer's \`Customer.Code\`.
- It does not work in another sale area, even of the same merchant — unless Paynet has grouped those sale areas on its side.

## How it works

| Step | Who | What happens |
|---|---|---|
| 1 | You | Create an order with \`POST /api/order\` and send the \`Customer\` object. Without \`Customer\` the card is not saved. |
| 2 | Customer | Pays by card on the Paynet page. The "save card" checkbox is checked by default; the customer can uncheck it. |
| 3 | Paynet | Sends the \`PAID\` notification with \`Payment.CardLinkHash\`. If the customer unchecked the box, it is \`null\`. |
| 4 | You | Store \`CardLinkHash\` together with this customer (their \`Customer.Code\`). |
| 5 | You | On the next payment send \`CardLinkHash\` and the same \`Customer\` data in \`POST /api/order\`. |
| 6 | Customer | Sees the saved card on the Paynet page and confirms the payment. |

## First payment

A regular [create order](#/guides/server-to-server) request with the \`Customer\` object:

\`\`\`json
{
  "Order": 1762444800000,
  "SaleAreaCode": "onlidocumentation_md",
  "LinkUrlSuccess": "https://shop.example/payment/success",
  "LinkUrlCancel": "https://shop.example/payment/cancel",
  "Customer": {
    "Code": "464566161",
    "NameFirst": "First Name",
    "NameLast": "Last Name",
    "email": "customer@example.com",
    "PhoneNumber": "37360000000"
  },
  "Currency": 498,
  "ExpiryDate": "2026-12-31T23:59:59",
  "Services": [
    { "Name": "Demo eShop", "Description": "Order #1762444800000", "Amount": 300 }
  ],
  "MoneyType": "Card",
  "Lang": "EN"
}
\`\`\`

After payment the \`PAID\` notification carries the token:

\`\`\`json
{
  "Payment": {
    "Id": 1234567,
    "ExternalId": 1762444800000,
    "CardLinkHash": "1037153_b3f50103610e4fe9948ff8db553151f3"
  }
}
\`\`\`

(Fragment. The full format is in [Notifications](#/guides/notifications).)

## Next payment

A new order with a new \`Order\`, the same \`Customer\` and the saved \`CardLinkHash\`:

\`\`\`json
{
  "Order": 1762531200000,
  "SaleAreaCode": "onlidocumentation_md",
  "LinkUrlSuccess": "https://shop.example/payment/success",
  "LinkUrlCancel": "https://shop.example/payment/cancel",
  "Customer": {
    "Code": "464566161",
    "NameFirst": "First Name",
    "NameLast": "Last Name",
    "email": "customer@example.com",
    "PhoneNumber": "37360000000"
  },
  "CardLinkHash": "1037153_b3f50103610e4fe9948ff8db553151f3",
  "Currency": 498,
  "ExpiryDate": "2026-12-31T23:59:59",
  "Services": [
    { "Name": "Demo eShop", "Description": "Order #1762531200000", "Amount": 300 }
  ],
  "MoneyType": "Card",
  "Lang": "EN"
}
\`\`\`

The rest is as usual: send the customer to \`paymentLink\` and wait for the \`PAID\` notification.

## Checked on the test environment

| Situation | What happens |
|---|---|
| First payment with \`Customer\`, checkbox kept | \`CardLinkHash\` arrives in the notification and in the \`GET /api/order/merchant/{Order}\` response (\`cardLinkHash\` and \`customer.cardLinkHash\`) |
| Next payment: same \`Customer\` + \`CardLinkHash\` | The Paynet page shows the saved card (mask and expiry date). The customer can choose it, enter another card or delete the saved one |
| Another \`Customer.Code\` + the same \`CardLinkHash\` | The order is created (\`200\`), but the saved card is **not shown** — the customer enters a card again |
| Unknown \`CardLinkHash\` | The order is created (\`200\`), the payment page is the usual one |

The API does not reject an unsuitable token when the order is created: the protection works on the payment page. So keep each token strictly paired with the customer it was issued for.

## Rules

- \`CardLinkHash\` works only together with the \`Customer\` it was issued for. Send the pair unchanged.
- \`CardLinkHash\` is not covered by the notification signature. Before storing it, confirm the payment and the customer with the API — see [What the signature protects](#/guides/notifications).
- The token is valid as long as the card is. If the card expired or was reissued, the customer pays with the new card and you receive a new \`CardLinkHash\` — replace the old one.
- \`CardLinkHash\` in a notification may be \`null\` (the customer unchecked the box, or saving is not enabled). That is normal: just store nothing.
- Keep \`CardLinkHash\` on your server and never expose it in the browser.
- To delete a card (for example, at the customer's request), call \`POST /api/linked-cards/unlink\` with \`CardLinkHash\`, \`SaleAreaCode\` and \`CustomerCode\`.
`,"../../content/en/ecom/05-hosted-checkout.md":`# Hosted checkout (client-server)

In this model the customer's browser sends the order to Paynet as a signed HTML form (\`POST\`). You do not call an API to create the order, but you must compute a \`Signature\` with your secret key **on your server**.

| Environment | Form action URL |
|---|---|
| Test | \`https://test.paynet.md/ecom/checkout\` |
| Production | \`https://paynet.md/ecom/checkout\` |

## Flow

1. The customer clicks "Pay" in your shop.
2. Your server builds the form fields and computes \`Signature\` (see below).
3. Your page renders an auto-submitting form that posts the fields to the checkout URL.
4. The customer pays on the Paynet page and returns to \`LinkUrlSuccess\` (paid) or \`LinkUrlCancel\` (failed or cancelled).
5. Paynet sends a \`PAID\` [notification](#/guides/notifications) to your callback URL (failed payments are not notified).
6. Before you ship, confirm the payment with \`GET /api/order/merchant/{Order}\` (server-to-server API, Bearer token): orders created by the form are found by your \`Order\`.

## Form fields

| Field | Required | Signed | Description |
|---|---|---|---|
| \`Order\` | yes | yes | Your order number (integer). One shop order = one \`Order\`. |
| \`Currency\` | yes | yes | ISO 4217 numeric code, \`498\` = MDL. |
| \`Merchant\` | yes | yes | Your merchant code. |
| \`SaleAreaCode\` | yes | yes | Your sale area code. |
| \`Amount\` | yes | yes | Amount in minor units: \`1235\` = 12.35 MDL. |
| \`Description\` | yes | yes | Order description shown to the customer. |
| \`ExpiryDate\` | yes | yes | Payment deadline, \`YYYY-MM-DDTHH:mm:ss\`, Chișinău local time. |
| \`LinkUrlSuccess\` | yes | yes | Return URL after successful payment. |
| \`LinkUrlCancel\` | yes | yes | Return URL after cancellation. |
| \`Lang\` | yes | yes | Payment page language, e.g. \`ro\`, \`ru\`, \`en\`. |
| \`MoneyType\` | yes | yes | Payment methods shown: \`All\`, \`Card\` (card, Apple Pay, Google Pay), \`Paynet\`, \`MIA\`, \`CashInvoice\`. |
| \`CustomerCode\` | no | yes | Customer ID in your system. |
| \`CustomerNameFirst\` | no | yes | Customer first name. |
| \`CustomerNameLast\` | no | yes | Customer last name. |
| \`CustomerPhoneNumber\` | no | yes | Customer phone. |
| \`CustomerEmail\` | no | yes | Customer email. |
| \`ProductAmount\`, \`ProductBarcode\`, \`ProductCode\`, \`ProductDescription\`, \`ProductGroupId\`, \`ProductGroupName\`, \`ProductLineNo\`, \`ProductName\`, \`ProductUnitPrice\`, \`ProductQuantity\`, \`ProductUnitProduct\` | no | no | Optional product details. |
| \`Signature\` | yes | — | \`Base64(MD5(RawData + SecretKey))\` with the **hosted checkout** secret key, see below. |

## Signature

1. Take the **signed** fields from the table above that you actually send (skip fields you do not send).
2. Sort them by field name, A → Z.
3. Percent-encode each **value** with RFC 3986 (\`encodeURIComponent\` plus \`! ' ( ) *\`), using UTF-8 (also for Cyrillic and Romanian diacritics). Correct functions for PHP, JavaScript, Python, C#, Java and the rules for special characters: [Signatures](#/guides/signatures).
4. Concatenate the encoded values without separators → \`RawData\`.
5. \`Signature = Base64( MD5( RawData + SecretKey ) )\` — Base64 of the raw 16-byte MD5 digest, not of the hex string.

A complete worked example with expected output is on the [Signatures](#/guides/signatures) page. Use it as a unit test.

> **Important:** compute the signature on your server. The secret key must never appear in HTML or JavaScript sent to the browser.

## Example form

\`\`\`html
<form id="paynet" method="POST" action="https://test.paynet.md/ecom/checkout">
  <input type="hidden" name="Order" value="1762444800000">
  <input type="hidden" name="Currency" value="498">
  <input type="hidden" name="Merchant" value="265505">
  <input type="hidden" name="SaleAreaCode" value="onlidocumentation_md">
  <input type="hidden" name="Amount" value="1235">
  <input type="hidden" name="Description" value="Test&amp;Co SRL">
  <input type="hidden" name="CustomerCode" value="5555">
  <input type="hidden" name="CustomerNameFirst" value="First name">
  <input type="hidden" name="CustomerNameLast" value="Last name">
  <input type="hidden" name="CustomerPhoneNumber" value="060000000">
  <input type="hidden" name="CustomerEmail" value="test@gmail.com">
  <input type="hidden" name="ExpiryDate" value="2026-12-31T23:59:59">
  <input type="hidden" name="LinkUrlCancel" value="https://test.oplta.md/cancel">
  <input type="hidden" name="LinkUrlSuccess" value="https://test.oplta.md/ok">
  <input type="hidden" name="Lang" value="ro">
  <input type="hidden" name="MoneyType" value="Card">
  <input type="hidden" name="Signature" value="cxr/+yLYZp34aR0KXLkb2A==">
</form>
<script>document.getElementById('paynet').submit();<\/script>
\`\`\`

The \`Signature\` above is correct for these exact values and the test secret key. Values in HTML attributes must be HTML-escaped (\`&\` → \`&amp;\`); the browser sends the original value, which is what you sign. Do not put line breaks, HTML tags (\`<b>\`) or HTML entities (\`&#039;\`) in values: see [Signatures](#/guides/signatures).

## Example: Node.js signature

\`\`\`javascript
import crypto from 'node:crypto';

const SIGNED_FIELDS = ['Order', 'Currency', 'Merchant', 'SaleAreaCode', 'CustomerCode', 'CustomerNameFirst',
  'CustomerNameLast', 'CustomerPhoneNumber', 'CustomerEmail', 'ExpiryDate', 'Description', 'Amount',
  'LinkUrlCancel', 'LinkUrlSuccess', 'Lang', 'MoneyType'];

const encodeRfc3986 = (v) =>
  encodeURIComponent(v).replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());

export function checkoutSignature(fields, secretKey) {
  const rawData = SIGNED_FIELDS
    .filter((name) => fields[name] !== undefined && fields[name] !== null)
    .sort()
    .map((name) => encodeRfc3986(String(fields[name])))
    .join('');
  return crypto.createHash('md5').update(rawData + secretKey, 'utf8').digest('base64');
}
\`\`\`

## Example: PHP signature

\`\`\`php
<?php
function checkoutSignature(array $fields, string $secretKey): string {
    $signed = ['Order', 'Currency', 'Merchant', 'SaleAreaCode', 'CustomerCode', 'CustomerNameFirst',
        'CustomerNameLast', 'CustomerPhoneNumber', 'CustomerEmail', 'ExpiryDate', 'Description', 'Amount',
        'LinkUrlCancel', 'LinkUrlSuccess', 'Lang', 'MoneyType'];
    $present = array_values(array_filter($signed, fn($name) => isset($fields[$name])));
    sort($present, SORT_STRING);
    $rawData = '';
    foreach ($present as $name) {
        $rawData .= rawurlencode((string) $fields[$name]); // RFC 3986
    }
    return base64_encode(md5($rawData . $secretKey, true));
}
\`\`\`

## Testing on this portal

Open **E-commerce → Hosted checkout → Checkout form (try it)**. The portal fills a unique \`Order\` and a future \`ExpiryDate\`, generates the signature with the test key and opens the Paynet test page in a new tab.

If you post an \`Order\` that is already paid or being processed by the card issuer, the customer sees the Paynet page "Plata a fost respinsă" (this invoice is already paid or being processed).
`,"../../content/en/ecom/06-testing.md":'# Testing\n\n## Test environment\n\n| Item | Value |\n|---|---|\n| API base URL | `https://ecom-api-test.paynet.md` |\n| Hosted checkout form URL | `https://test.paynet.md/ecom/checkout` |\n| API username / password | `771064` / `sLgMnGWJ` |\n| Merchant code | `265505` |\n| Sale area code | `onlidocumentation_md` |\n| Secret key for the hosted checkout signature | `F90D6485-9CCC-458B-96A3-8958AF9B4458` |\n| Secret key for notifications | `D9873689-E5F8-4272-A67F-0D8BA3F9BAA7` |\n\nThese credentials are shared by everyone testing on this portal: other people\'s test payments are visible in searches and statements. Ask Paynet for your own test merchant if you need an isolated environment.\n\n## Test card\n\n| Card | Expiry | CVV | Result |\n|---|---|---|---|\n| Visa `4111 1111 1111 1111` | `12/27` | `777` | successful payment |\n\nTest cards can only reproduce a successful payment: there are no cards for declined or 3-D Secure payments. You still need to implement decline handling and test it with mocked API responses: `status` = `5` and the customer returning to `LinkUrlCancel` (see [Failed payment](#/guides/errors-and-statuses)). When a real payment fails, the customer is simply redirected to `LinkUrlCancel` and no notification is sent.\n\n## Rules that make tests fail\n\n- **Reused `Order`.** The same `Order` with different data, or an `Order` that is already paid, fails with `500 TECHNICAL_ERROR`. The portal generates a new `Order` for you (current time in milliseconds).\n- **`ExpiryDate` in the past.** Use a future date in Chișinău local time. The portal sets it to the end of tomorrow.\n- **Amounts in MDL instead of minor units.** `100` means 1.00 MDL.\n- **Expired token.** Tokens live about 4 hours; call `/auth` again after `401`.\n- **Products don\'t add up.** If you send `Products`, send all product fields and keep `Amount` values consistent with the service `Amount`.\n\n## Test scenarios\n\n| # | Scenario | How | Expected |\n|---|---|---|---|\n| 1 | Authenticate | `POST /auth` with test credentials | `200`, `access_token` |\n| 2 | Wrong password | `POST /auth` with a wrong password | `401`, `AUTHENTICATION_FAILED` |\n| 3 | Create order | `POST /api/order` | `200`, `paymentId`, `paymentLink`, `status` `1` |\n| 4 | Repeat the same request | send scenario 3 again unchanged | same `paymentId` and `paymentLink` |\n| 5 | Same `Order`, other amount | change `Amount`, keep `Order` | `500`, `TECHNICAL_ERROR` |\n| 6 | Invalid request | `POST /api/order` without `Services` | `400` with an `errorInfo` object (the missing field in `errors`) |\n| 7 | No token | `POST /api/order` without `Authorization` | `401`, `UNAUTHORIZED` |\n| 8 | Pay | open `paymentLink`, pay with the test card | redirect to `LinkUrlSuccess` |\n| 9 | Status | `GET /api/order/merchant/{Order}` | payment with `paidDate` set |\n| 10 | Unknown order | `GET /api/order/{id}` with a random ID | `404`, `NOT_FOUND_RECORD` |\n| 11 | Notification | **Notification simulator** → your URL | your handler verifies `Hash`, returns `200` |\n| 12 | Wrong hash | send a notification with a changed `Amount` | your handler rejects it |\n| 13 | Duplicate notification | send the same notification twice | your handler processes it once |\n| 14 | Hosted checkout | **Checkout form (try it)** | Paynet test payment page opens |\n| 15 | Refund | `POST /api/order/refund` for a paid payment | `200`; `status` becomes `5` (full) or `6` (partial) |\n| 16 | Refund above the paid amount | `RefundType` `partial`, `Amount` above `PaidAmount` | `400 INVALID_PARAMETER` |\n| 17 | Save a card (if enabled for your `SaleAreaCode`) | `POST /api/order` with `Customer`, pay keeping the "save card" checkbox | the `PAID` notification contains `CardLinkHash` |\n| 18 | Pay with a saved card (if enabled) | `POST /api/order` with `CardLinkHash` and the same `Customer` | the Paynet page shows the saved card |\n| 19 | Customer left without paying | open `paymentLink`, close the page, open the link again | `status` stays `1`, payment is still possible |\n\n## Mock responses for failure tests\n\nA bank decline, refund errors and damaged notifications cannot be reproduced with the test card. For automated tests of your integration use these ready responses — they are taken from real test-environment responses, and the notifications are signed with the test key. Full list: [mocks/index.json](mocks/index.json).\n\n| File | What it mocks | What your code must do |\n|---|---|---|\n| [payment-status-3.json](mocks/payment-status-3.json) | Payment still processing | Wait, do not create a new order |\n| [payment-status-5-declined.json](mocks/payment-status-5-declined.json) | Declined by the bank | Offer a new attempt with a new `Order` |\n| [payment-status-5-refunded.json](mocks/payment-status-5-refunded.json), [payment-status-6.json](mocks/payment-status-6.json) | Full and partial refund | Do not fulfil the order again |\n| [refund-400-amount-or-second.json](mocks/refund-400-amount-or-second.json), [refund-404-unpaid.json](mocks/refund-404-unpaid.json) | Refund errors | Show a clear error, do not retry automatically |\n| [order-500-repeated-order.json](mocks/order-500-repeated-order.json), [order-400-errorinfo.json](mocks/order-400-errorinfo.json) | Repeated `Order`, unreadable request | Handle both error formats |\n| [error-401-token.json](mocks/error-401-token.json) | Expired token | Get a new token and retry once |\n| [notification-paid.json](mocks/notification-paid.json) | Valid `PAID` notification | Answer `200`, fulfil once |\n| [notification-paid-wrong-hash.json](mocks/notification-paid-wrong-hash.json) | Wrong `Hash` | Answer `400`, change nothing |\n| [notification-paid-tampered-paidamount.json](mocks/notification-paid-tampered-paidamount.json) | Valid `Hash`, but the unsigned `PaidAmount` changed | The API confirmation must send the order to review |\n\n`payment-status-5-declined.json` is constructed: the `status` value is real, the other fields are those of an unpaid payment.\n\n## Testing from this portal\n\nThe "Test API Request" buttons call the test API directly from your browser. This works on the official portal domain. If you open a copy of the portal from another address, the browser may block the calls (CORS); use cURL or Postman instead. A ready-made Postman collection is described below.\n\n## Postman\n\nThe ready-made collection works right after import; nothing needs editing.\n\n1. Download the [collection](postman/paynet-ecom.postman_collection.json) and the [test environment](postman/paynet-test.postman_environment.json) (also in the sidebar under the "Postman collection" button).\n2. In Postman: **Import** → select both files → choose the **Paynet — TEST** environment at the top right.\n3. Run **1. Payments → Create order**. The token is obtained automatically; `Order` and `ExpiryDate` are new every time.\n4. The **Postman Console** shows `paymentLink` — open it and pay with the test card.\n5. Run **Get payment by Order**: `status` = `4` means paid. Then you can run **Refund**.\n\n| What the collection does by itself | How |\n|---|---|\n| Gets and refreshes the token | Before each request, if there is no token or it is about to expire |\n| Creates a unique order | `Order` = current time in ms, `ExpiryDate` = tomorrow, Chisinau time |\n| Passes data between requests | Saves `paymentId`, `paymentLink`, `lastOrder`, `cardLinkHash` |\n| Calculates periods | Search — last 24 hours in Chișinău time, statement — last 7 days |\n| Shows errors | Code, message, `details` and `traceId` in the Postman Console |\n\nThe **5. Error examples** folder triggers `401`, `400` and `404` on purpose, so you can see what they look like.\n\nFor production, import the [PRODUCTION environment](postman/paynet-production.postman_environment.json) and fill in **your own** `username`, `password`, `saleAreaCode`. Do not share this file once filled in.\n',"../../content/en/ecom/07-example-shop.md":'# Example shop (Node.js)\n\nA ready, minimal server-to-server integration: one Node.js 18+ server with no dependencies. Source code: [paynet-example-shop-node.zip](sdk/paynet-example-shop-node.zip).\n\n> **Important:** this example is checked by an end-to-end test on the Paynet test environment: a robot buys a product in the example, pays with the test card, sends the notification and makes a refund. So the example code is known to work.\n\n## Run\n\nThe example is a working online shop connected to the Paynet test environment. It runs on your computer; besides Node.js nothing has to be installed or configured.\n\n### Before you start: Node.js\n\nYou need **Node.js 18 or newer**. Open a command line:\n\n| System | How to open it |\n|---|---|\n| Windows | **Win+R** → type `cmd` → **Enter** |\n| macOS | **Terminal** app (Applications → Utilities) |\n| Linux | **Terminal** (usually **Ctrl+Alt+T**) |\n\nType the command and press **Enter**:\n\n```\nnode --version\n```\n\nIf a version number appears (for example `v22.11.0`), you are ready. If you get an error, install Node.js from https://nodejs.org (the **LTS** button), then close the command line and open it again.\n\n### Step 1. Download the archive and start the shop\n\nDownload [paynet-example-shop-node.zip](sdk/paynet-example-shop-node.zip). In the command line type these commands one by one, pressing **Enter** after each line:\n\n```\ncd Downloads\ntar -xf paynet-example-shop-node.zip\ncd node-shop\nnode server.mjs\n```\n\n| Command | What it does |\n|---|---|\n| `cd Downloads` | goes to the Downloads folder where the browser saved the archive |\n| `tar -xf …zip` | unpacks the archive (Windows 10/11, macOS); a `node-shop` folder appears |\n| `cd node-shop` | goes to the shop folder |\n| `node server.mjs` | starts the shop |\n\n**Linux:** instead of `tar -xf paynet-example-shop-node.zip` type `unzip paynet-example-shop-node.zip` (the standard Linux `tar` does not open `.zip`; if `unzip` is missing: `sudo apt install unzip`).\n\nThe line `Demo shop on http://localhost:3000 …` appears. **Do not close this window**: the shop runs while it is open. To stop the shop press **Ctrl+C**.\n\n> The archive was not saved to Downloads? Instead of `cd Downloads` type `cd ` with a space (on Windows `cd /d ` with a space) and drag **the folder that contains the archive** from your file manager into the command-line window — its path is inserted automatically. Drag a folder, not the `.zip` archive itself. On Linux with a non-English interface the folder may have a localised name.\n\n### Step 2. Pay a test order\n\nOpen http://localhost:3000 in your browser, click **Buy** and pay with the test card: number `4111 1111 1111 1111`, expiry `12/27`, CVV `777`. After the payment you return to the shop.\n\n### Step 3. Send the payment notification\n\nOpen http://localhost:3000/orders. The order is **`pending`**, and that is expected: the shop marks an order as paid **only after the Paynet notification**, the same way your real shop must work. Paynet sends notifications to your merchant\'s callback URL, and they cannot reach `localhost`. So while developing you send the notification yourself: the script checks the payment with the API, builds the notification and signs it the same way Paynet does.\n\nOpen a **second** command line and type, with the number of your order from the **Order** column:\n\n```\ncd Downloads/node-shop\nnode tools/send-test-notification.mjs <Order>\n```\n\nFor example: `node tools/send-test-notification.mjs 1794411831126`. The shop page shows the ready command for each `pending` order.\n\n### Step 4. Check the result\n\nRefresh http://localhost:3000/orders: the order is now **`paid`**, and next to it there is a refund button — try a refund.\n\n### If something does not work\n\n| Message | Cause and fix |\n|---|---|\n| `\'node\' is not recognized…` / `command not found: node` | Node.js is not installed, or the command line was opened before installing it. Install Node.js and open the command line again |\n| `The system cannot find the path specified` / `No such file or directory` after `cd Downloads` | The archive is in another folder. Use the tip under Step 1 |\n| `The directory name is invalid` | You dragged the `.zip` archive instead of a folder. Drag the folder that contains the archive |\n| `tar: This does not look like a tar archive` | You are on Linux: use `unzip paynet-example-shop-node.zip` instead of `tar -xf` |\n| `Cannot find module …server.mjs` | The command line is not in the `node-shop` folder. Repeat Step 1 |\n| `EADDRINUSE … 3000` | The shop is already running in another window. Close that window (or press **Ctrl+C** in it) and start again |\n| `Payment is not paid (status 1)` | The payment of this order was not completed. Create a new order and finish the payment |\n| The order stays `pending` | The notification was not sent. Do Step 3 |\n\n## What is inside\n\n| File | What it does |\n|---|---|\n| `server.mjs` | Shop: product, create order, redirect to payment, return pages, notification endpoint, refunds |\n| `paynet-client.mjs` | API client: token caching, create order with a safe retry, payment lookup, refund |\n| `paynet-notifications.mjs` | Notification handler — the same code as in [Notifications](#/guides/notifications) |\n| `store.mjs` | JSON-file storage — replace with your database |\n| `tools/send-test-notification.mjs` | Sends a signed `PAID` notification to your endpoint |\n\n## Rules the example demonstrates\n\n| Step | How the example does it | Rule |\n|---|---|---|\n| Create order | Unique `Order`; the request body is stored before calling Paynet | Retry only with the same body ([Repeated order number](#/guides/errors-and-statuses)) |\n| Payment deadline | `ExpiryDate` = now + 1 day in Chișinău time | `Europe/Chisinau` |\n| Customer returns | The page checks `status` with the API instead of trusting the redirect | The redirect to `LinkUrlSuccess` is not proof of payment |\n| `status` = `1` | "Continue to payment" with the same link | The customer did not pay |\n| `status` = `3` | The page waits and refreshes | The bank is still answering; do not create a new order |\n| `status` = `5` | "Try again" creates a new order with a new `Order` | The order is closed after a decline |\n| Notification | Signature, once per `Payment.Id`, `200` first, then API confirmation | [What the signature protects](#/guides/notifications) |\n| Refund | Only for `status` = `4`, at most `PaidAmount`, once | [Refunds](#/guides/errors-and-statuses) |\n| Saved card | `CardLinkHash` from a confirmed notification is stored for the customer | [Saved cards](#/guides/saved-cards) |\n\n## Going live\n\nSet the environment variables to production values — they differ from the test ones — and keep them out of the code:\n\n| Variable | Value |\n|---|---|\n| `PAYNET_API_URL` | `https://ecom-api.paynet.md` |\n| `PAYNET_USERNAME`, `PAYNET_PASSWORD` | production API credentials |\n| `PAYNET_SALE_AREA` | your sale area code |\n| `PAYNET_NOTIFICATION_SECRET` | production notification key |\n| `PUBLIC_URL` | your shop address (for `LinkUrlSuccess` / `LinkUrlCancel`) |\n\nReplace `store.mjs` with your database and go through the [go-live checklist](#/guides/go-live).\n',"../../content/en/ecom/08-go-live.md":`# Go-live checklist

## Before you switch to production

**Credentials and configuration**

- [ ] You received from Paynet: production API user, merchant code, sale area code and **two** secret keys (hosted checkout signature and notifications). Production access is sent to your company administrator's email; it takes from 5 minutes to several days depending on the features you connect.
- [ ] All test values are replaced with production ones: **production keys and credentials differ from the test ones**.
- [ ] Your code uses the production URLs: API \`https://ecom-api.paynet.md\`, hosted checkout form \`https://paynet.md/ecom/checkout\`.
- [ ] Secrets are stored in server configuration (environment variables, vault), not in code or front-end.
- [ ] Your callback URL (HTTPS) is registered with Paynet.
- [ ] \`LinkUrlSuccess\` and \`LinkUrlCancel\` point to production pages.

**Payments**

- [ ] Every shop order gets its own unique \`Order\` number, also after restarts and in parallel requests.
- [ ] \`ExpiryDate\` is computed in Chișinău local time (\`Europe/Chisinau\`), for example now + 1 day, not hard-coded.
- [ ] Amounts are sent in minor units and match the cart total.
- [ ] Hosted checkout: the signature is computed on the server and passes the [test vectors](#/guides/signatures).

**Notifications**

- [ ] The handler verifies the \`Hash\` header with the notification secret key.
- [ ] The handler reads \`Payment.Id\` and \`Payment.ExternalId\` (exact spelling).
- [ ] The handler is idempotent (one \`Payment.Id\` = one fulfilment).
- [ ] The handler checks that \`PaidAmount\` equals \`Amount\` (unless you have an agreed promotion with Paynet).
- [ ] The handler answers \`200\` only after the order is saved.
- [ ] A fallback job checks unpaid orders with \`GET /api/order/{paymentId}\` if no notification arrived. Failed payments are not notified.

**Operations**

- [ ] The token is cached and refreshed on \`401\`.
- [ ] Errors are logged with \`traceId\`.
- [ ] You do not mark orders as paid just because the customer returned to \`LinkUrlSuccess\`.
- [ ] Refund and statement flows are tested if you use them.

## After launch

- Make one real low-value payment and refund it.
- Reconcile the first day's payments with the statement (\`GET /api/statement\`): you receive \`PaidAmount\` minus the Paynet commission.
`,"../../content/en/ecom/09-sdk.md":`# SDK for PHP and Node.js

Official Paynet libraries for your shop's server side. They take care of authorization, API rules, signatures and error handling, so you write only your shop logic. No third-party dependencies.

| | PHP | Node.js |
|---|---|---|
| Version | 1.0.0 | 1.0.0 |
| Requirements | PHP 7.4+, \`curl\` and \`json\` extensions | Node.js 18+ |
| Download | [paynet-ecom-sdk-php-1.0.0.zip](sdk/paynet-ecom-sdk-php-1.0.0.zip) | [paynet-ecom-sdk-node-1.0.0.zip](sdk/paynet-ecom-sdk-node-1.0.0.zip) |
| License | MIT | MIT |

> **Important:** the SDK runs on your server only. Never send the username, password or secret keys to a browser or a mobile app. For apps, see [Mobile apps](#/guides/mobile-apps).

## What the SDK does for you

| Task | Without the SDK | With the SDK |
|---|---|---|
| Access token | Get it from \`/auth\`, store it, refresh it | Obtained automatically, refreshed on \`401\` |
| Creating an order | Store the request body, repeat it unchanged after a network failure | Repeated automatically after a network failure, with the same body |
| Refund | Check yourself: is it paid, is the amount not too big, was there a refund already | Rules are checked **before** calling the API — a clear error instead of an API rejection |
| Notifications | Build the string from 9 fields, MD5 + Base64, confirm unsigned fields | \`parseNotification\` + \`confirmNotification\` |
| Hosted checkout form | RFC 3986, field sorting, signature | \`buildCheckoutForm\` returns ready HTML |
| Errors | Three body formats and different key case | One error: kind, code, \`traceId\`, hint |
| Time | \`ExpiryDate\`, search and statements use Chișinău time | Dates are converted automatically |

## Install

Unpack the archive into your project — you get a \`paynet-ecom-sdk\` folder.

PHP:

\`\`\`php
require __DIR__ . '/paynet-ecom-sdk/autoload.php';
\`\`\`

Node.js:

\`\`\`javascript
import { PaynetClient } from './paynet-ecom-sdk/src/index.js';
\`\`\`

To check that everything is in place: \`php paynet-ecom-sdk/tests/run.php\` or \`node --test paynet-ecom-sdk/test/unit.test.js\`.

## Connect

PHP:

\`\`\`php
use Paynet\\Ecom\\PaynetClient;

$paynet = new PaynetClient([
    'username' => getenv('PAYNET_USERNAME'),
    'password' => getenv('PAYNET_PASSWORD'),
    'environment' => 'test', // 'production' — with production credentials
]);
\`\`\`

Node.js:

\`\`\`javascript
import { PaynetClient } from './paynet-ecom-sdk/src/index.js';

export const paynet = new PaynetClient({
  username: process.env.PAYNET_USERNAME,
  password: process.env.PAYNET_PASSWORD,
  environment: 'test', // 'production' — with production credentials
});
\`\`\`

In Node.js, save this code as \`paynet.js\`: the examples below import the client from it. Test credentials are on the [Testing](#/guides/testing) page. Production credentials are different.

## Create an order and send the customer to pay

Store the request body with your order: to repeat the request, send it unchanged — Paynet returns the same payment.

PHP:

\`\`\`php
use Paynet\\Ecom\\Time;

$order = [
    'Order' => 1762444800000, // your shop's order number
    'SaleAreaCode' => 'onlidocumentation_md',
    'LinkUrlSuccess' => 'https://shop.example/payment/success',
    'LinkUrlCancel' => 'https://shop.example/payment/cancel',
    'Customer' => ['Code' => 'customer-42', 'NameFirst' => 'Ion', 'NameLast' => 'Popescu', 'email' => 'ion@example.com', 'PhoneNumber' => '37360000000'],
    'ExpiryDate' => Time::expiryInHours(24), // in 24 hours, Chișinău time
    'Currency' => 498,
    'Services' => [['Name' => 'My shop', 'Description' => 'Order #1762444800000', 'Amount' => 300]], // 300 = 3.00 MDL
    'MoneyType' => 'All',
    'Lang' => 'ro',
];
$created = $paynet->createOrder($order);
header('Location: ' . $created['paymentLink']);
\`\`\`

Node.js:

\`\`\`javascript
import { expiryInHours } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

const order = {
  Order: 1762444800000, // your shop's order number
  SaleAreaCode: 'onlidocumentation_md',
  LinkUrlSuccess: 'https://shop.example/payment/success',
  LinkUrlCancel: 'https://shop.example/payment/cancel',
  Customer: { Code: 'customer-42', NameFirst: 'Ion', NameLast: 'Popescu', email: 'ion@example.com', PhoneNumber: '37360000000' },
  ExpiryDate: expiryInHours(24), // in 24 hours, Chișinău time
  Currency: 498,
  Services: [{ Name: 'My shop', Description: 'Order #1762444800000', Amount: 300 }], // 300 = 3.00 MDL
  MoneyType: 'All',
  Lang: 'ro',
};
const { paymentId, paymentLink } = await paynet.createOrder(order);
// redirect the customer to paymentLink
\`\`\`

## Check the payment

Before shipping, check the status through the API: a customer returning to \`LinkUrlSuccess\` does not by itself mean the payment is done.

PHP:

\`\`\`php
use Paynet\\Ecom\\PaymentStatus;

$payment = $paynet->getPaymentByOrder(1762444800000);
if ($payment['status'] === PaymentStatus::PAID) {
    // the order is paid — you can fulfil it
}
\`\`\`

Node.js:

\`\`\`javascript
import { PaymentStatus } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

const payment = await paynet.getPaymentByOrder(1762444800000);
if (payment.status === PaymentStatus.PAID) {
  // the order is paid — you can fulfil it
}
\`\`\`

Statuses: \`1\` — not paid, \`3\` — processing (wait, up to about a day), \`4\` — paid, \`6\` — paid, then partially refunded, \`5\` — not paid or fully refunded; \`5\` and \`6\` are final. \`isPaid\` is \`true\` only for \`4\`. More: [Statuses and errors](#/guides/errors-and-statuses).

## Receive a notification

Order of steps: check the signature → **save the notification** → answer \`200\` → confirm the payment through the API and fulfil the order from the saved record. Save before answering: after a \`200\` Paynet does not send the notification again, so an unsaved notification would be lost if your code fails later. The paid amount (\`PaidAmount\`) and some other fields are not signed, which is why the API check is needed.

PHP:

\`\`\`php
use Paynet\\Ecom\\Notification;
use Paynet\\Ecom\\PaynetException;

try {
    $notification = Notification::parse(file_get_contents('php://input'), $_SERVER['HTTP_HASH'] ?? null, getenv('PAYNET_NOTIFICATION_KEY'));
} catch (PaynetException $e) {
    http_response_code(400);
    exit;
}
// 1. Save the notification (your function, e.g. a database insert). A retry has the same Payment.Id: return false if it is already saved.
$isNew = saveNotification($notification);

// 2. Answer 200 only after it is saved.
http_response_code(200);
// Send the answer now and continue (PHP-FPM). Without FPM the answer is sent when the script ends.
if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
}
if (!$isNew) {
    exit;
}

// 3. After the answer: confirm through the API, then fulfil the order from the saved record.
// If this step fails, the saved record stays unprocessed: process it again later (for example, a scheduled job).
$check = Notification::confirm($paynet, $notification, ['amount' => 300, 'customerCode' => 'customer-42']);
if ($check['ok']) {
    // fulfil the order and mark the saved record as processed
} else {
    // send to manual review: $check['problems']
}
\`\`\`

Node.js:

\`\`\`javascript
import { parseNotification, confirmNotification } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

// rawBody — the request body as a string, unchanged; hash — the Hash header
export async function handlePaynetNotification(rawBody, hash, res) {
  let notification;
  try {
    notification = parseNotification(rawBody, hash, process.env.PAYNET_NOTIFICATION_KEY);
  } catch {
    res.writeHead(400).end();
    return;
  }
  // 1. Save the notification (your function, e.g. a database insert). A retry has the same Payment.Id: return false if it is already saved.
  const isNew = await saveNotification(notification);

  // 2. Answer 200 only after it is saved.
  res.writeHead(200).end();
  if (!isNew) return;

  // 3. After the answer: confirm through the API, then fulfil the order from the saved record.
  // If this step fails, the saved record stays unprocessed: process it again later (for example, a scheduled job).
  const check = await confirmNotification(paynet, notification, { amount: 300, customerCode: 'customer-42' });
  if (check.ok) {
    // fulfil the order and mark the saved record as processed
  } else {
    // send to manual review: check.problems
  }
}
\`\`\`

Use the **notification key**, not the checkout form key. More: [Notifications](#/guides/notifications).

## Make a refund

In production a payment can have **one** refund (full or partial), within 180 days, at most the paid amount, not for \`CASH_INVOICE\`. The SDK checks these rules before calling the API. The type (\`full\` / \`partial\`) is chosen from the amount.

PHP:

\`\`\`php
$refund = $paynet->refund((int) $created['paymentId'], 'onlidocumentation_md', 300, null, 'Customer request');
\`\`\`

Node.js:

\`\`\`javascript
import { paynet } from './paynet.js';

const refund = await paynet.refund({ paymentId: 328731, saleAreaCode: 'onlidocumentation_md', amount: 300, reason: 'Customer request' });
\`\`\`

The result comes in the response; there is no refund notification.

## Hosted checkout form

The signature is computed on the server; only the ready form goes to the browser. Use the **checkout form key**.

PHP:

\`\`\`php
use Paynet\\Ecom\\Checkout;

$form = Checkout::buildForm([
    'Order' => 1762444800000,
    'Merchant' => '265505',
    'SaleAreaCode' => 'onlidocumentation_md',
    'Amount' => 300,
    'Description' => 'Order #1762444800000',
    'LinkUrlSuccess' => 'https://shop.example/payment/success',
    'LinkUrlCancel' => 'https://shop.example/payment/cancel',
    'Lang' => 'ro',
    'MoneyType' => 'All',
], getenv('PAYNET_CHECKOUT_KEY'), 'test');
echo $form['html'];
\`\`\`

Node.js:

\`\`\`javascript
import { buildCheckoutForm } from './paynet-ecom-sdk/src/index.js';

const form = buildCheckoutForm({
  secretKey: process.env.PAYNET_CHECKOUT_KEY,
  environment: 'test',
  fields: {
    Order: 1762444800000,
    Merchant: '265505',
    SaleAreaCode: 'onlidocumentation_md',
    Amount: 300,
    Description: 'Order #1762444800000',
    LinkUrlSuccess: 'https://shop.example/payment/success',
    LinkUrlCancel: 'https://shop.example/payment/cancel',
    Lang: 'ro',
    MoneyType: 'All',
  },
});
// send form.html to the browser
\`\`\`

\`Currency\` defaults to \`498\`, \`ExpiryDate\` to 24 hours from now in Chișinău time.

## Errors

Every API error or rule violation is a \`PaynetException\` (PHP) or \`PaynetError\` (Node.js) with: kind (\`kind\`), HTTP code, Paynet code, \`traceId\`, a hint (\`hint\`) and whether repeating can help (\`retryable\`).

| Kind (\`kind\`) | When | What to do |
|---|---|---|
| \`validation\` | \`400\`: invalid or missing fields | Fix the request using \`details\` |
| \`authentication\` | \`/auth\`: wrong username or password | Check the credentials (test and production differ) |
| \`unauthorized\` | \`401\` even after refreshing the token | Check the credentials |
| \`not_found\` | \`404 NOT_FOUND_RECORD\`: no payment; refund of an unpaid payment | Check \`paymentId\` / \`Order\` |
| \`server\` | \`500 TECHNICAL_ERROR\` | Look the order up by \`Order\`; a repeated \`Order\` with other data needs a new \`Order\` |
| \`network\` | No response (timeout, network) | Look the order up by \`Order\`, repeat the same request |
| \`rule\` | The SDK did not call the API: a rule is broken (for example, a second refund) | Read the message — no request was sent |
| \`wrong_address\`, \`method_not_allowed\`, \`unsupported_media_type\` | \`404\` with an empty body, \`405\`, \`415\` | A client setup error — should not happen when using the SDK |

PHP:

\`\`\`php
use Paynet\\Ecom\\PaynetException;

try {
    $paynet->refund(328731, 'onlidocumentation_md', 300);
} catch (PaynetException $e) {
    error_log($e->kind . ' ' . $e->errorCode . ' traceId=' . $e->traceId . ' — ' . $e->hint);
}
\`\`\`

Node.js:

\`\`\`javascript
import { PaynetError } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

try {
  await paynet.refund({ paymentId: 328731, saleAreaCode: 'onlidocumentation_md', amount: 300 });
} catch (error) {
  if (error instanceof PaynetError) console.error(error.kind, error.code, \`traceId=\${error.traceId}\`, error.hint);
  else throw error;
}
\`\`\`

Send the \`traceId\` when you contact support.

## SDK methods

| What | PHP | Node.js | API method |
|---|---|---|---|
| Create an order | \`createOrder($order)\` | \`createOrder(order)\` | \`POST /api/order\` |
| Payment by \`paymentId\` | \`getPayment($id)\` | \`getPayment(id)\` | \`GET /api/order/{id}\` |
| Payment by your order number | \`getPaymentByOrder($order)\` | \`getPaymentByOrder(order)\` | \`GET /api/order/merchant/{id}\` |
| Is the order paid | \`isPaid($order)\` | \`isPaid(order)\` | \`GET /api/order/merchant/{id}\` |
| Search a period | \`searchPayments($from, $to)\` | \`searchPayments({ from, to })\` | \`GET /api/order/search\` |
| Refund | \`refund($paymentId, $saleArea, $amount, …)\` | \`refund({ paymentId, saleAreaCode, amount, … })\` | \`POST /api/order/refund\` |
| Delete a saved card | \`unlinkCard($hash, $saleArea, $customer)\` | \`unlinkCard({ cardLinkHash, saleAreaCode, customerCode })\` | \`POST /api/linked-cards/unlink\` |
| Statement | \`getStatement($start, $finish)\` | \`getStatement({ dateStart, dateFinish })\` | \`GET /api/statement\` |
| Statement \`.xlsx\` | \`downloadStatement($start, $finish)\` | \`downloadStatement({ dateStart, dateFinish })\` | \`GET /api/statement/download\` |
| Verify a notification | \`Notification::parse(…)\`, \`Notification::confirm(…)\` | \`parseNotification(…)\`, \`confirmNotification(…)\` | — |
| Hosted checkout form | \`Checkout::buildForm(…)\` | \`buildCheckoutForm(…)\` | — |

Search: dates are converted to Chișinău time; an empty period returns an empty list (the API answers \`404\` in that case).

## How the SDKs are checked

- **Unit tests** (included in the archive): signatures against the test vectors from [Signatures](#/guides/signatures), all error formats, token refresh, refund rules, Chișinău time. They run on every publication of the portal.
- **Check on the test environment** (merchant 265505): each SDK creates its own order, repeats the request, and after a test card payment checks status \`4\`, search, a partial refund, refusal of a second refund, deleting the saved card, statements and errors. Result on 10.11.2026: PHP — 20 of 20, Node.js — 20 of 20.

## Support

SDK questions go the same way as API questions: in the Telegram chat with a Paynet developer (through your manager) or to [support@paynet.md](mailto:support@paynet.md). Send the \`traceId\` from the error. More: [Contacting support](#/guides/errors-and-statuses).
`,"../../content/en/ecom/10-mobile-apps.md":`# Mobile apps

A separate mobile SDK is not needed. A mobile app takes payments through **your server** and the **Paynet payment page**. Other payment providers with a hosted payment page work the same way.

> **Important:** never store the API username and password, secret keys or the token in the app. Anyone can download and take an app apart — the keys would be found, and someone could create orders, make refunds and forge notifications on behalf of your shop. Everything that needs keys is done by the server only.

## How it works

| Step | Where | What happens |
|---|---|---|
| 1 | App | The customer taps "Pay". The app sends the order to **your server** |
| 2 | Your server | Creates the order in Paynet ([SDK](#/guides/sdk) or [API](#/guides/server-to-server)) and returns \`paymentLink\` to the app |
| 3 | App | Opens \`paymentLink\` in the **system browser view**. The customer pays on the Paynet page |
| 4 | Paynet → your server | [Notification](#/guides/notifications) \`PAID\`. The server checks the signature and the payment |
| 5 | Paynet → app | After payment the page returns the customer to \`LinkUrlSuccess\` (or \`LinkUrlCancel\`) |
| 6 | App → your server | The app asks **your server** whether the order is paid. Decide only by the server's answer |

## Server: create an order for the app

A Node.js example with the [SDK](#/guides/sdk). The app calls \`POST /mobile/orders/{id}/pay\` and gets the payment link; \`GET /mobile/orders/{id}/status\` tells whether the order is paid.

\`\`\`javascript
import http from 'node:http';
import { PaymentStatus } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

// In a real shop the order comes from your database by id: the amount comes from the order, not from the app's request.
// expiryDate is stored when the order is created (for example, expiryInHours(1)), so that tapping
// "Pay" again sends exactly the same request to Paynet.
const findOrder = async (id) => ({ order: Number(id), amount: 300, customerCode: 'customer-42', customerPhone: '37360000000', expiryDate: '2026-11-10T19:00:00' });

http.createServer(async (req, res) => {
  const match = req.url.match(/^\\/mobile\\/orders\\/(\\d+)\\/(pay|status)$/);
  if (!match) return res.writeHead(404).end();
  const order = await findOrder(match[1]);

  if (match[2] === 'pay' && req.method === 'POST') {
    const { paymentLink } = await paynet.createOrder({
      Order: order.order,
      SaleAreaCode: 'onlidocumentation_md',
      LinkUrlSuccess: \`https://shop.example/app/payment/success?order=\${order.order}\`,
      LinkUrlCancel: \`https://shop.example/app/payment/cancel?order=\${order.order}\`,
      Customer: { Code: order.customerCode, PhoneNumber: order.customerPhone },
      ExpiryDate: order.expiryDate,
      Currency: 498,
      Services: [{ Name: 'My shop', Description: \`Order #\${order.order}\`, Amount: order.amount }],
      MoneyType: 'All',
      Lang: 'ro',
    });
    return res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ paymentLink }));
  }

  const payment = await paynet.getPaymentByOrder(order.order);
  res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ paid: payment.status === PaymentStatus.PAID, status: payment.status }));
}).listen(3000);
\`\`\`

Authorize the app's requests to your server the same way as the app's other requests. Tapping "Pay" again for the same order must send **the same** request to Paynet — then Paynet returns the same payment.

## iOS: open the payment page

Use \`SFSafariViewController\` — the system Safari view inside your app.

\`\`\`swift
import SafariServices
import UIKit

func openPayment(_ paymentLink: String, from viewController: UIViewController) {
    guard let url = URL(string: paymentLink) else { return }
    let safari = SFSafariViewController(url: url)
    viewController.present(safari, animated: true)
}
\`\`\`

## Android: open the payment page

Use Chrome Custom Tabs (the \`androidx.browser\` library).

\`\`\`kotlin
import android.content.Context
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent

fun openPayment(context: Context, paymentLink: String) {
    CustomTabsIntent.Builder().build().launchUrl(context, Uri.parse(paymentLink))
}
\`\`\`

## Returning to the app after payment

Set \`LinkUrlSuccess\` and \`LinkUrlCancel\` to addresses of your website linked to the app: **Universal Links** (iOS) and **App Links** (Android). After payment the app opens, or your website if the app is not installed.

After returning, the app **does not treat the order as paid** just because the customer came back: it asks your server for the status (step 6). If the customer closed the payment view before finishing, the app also asks the server for the status.

## Recommendations

- **Do not use a WebView** for the payment page. In the system browser view the customer sees the Paynet page address, and Apple Pay and Google Pay may not work in an embedded WebView.
- **Take the amount from the order on the server**, not from the app's request.
- **Do not fulfil the order before the server confirms it**: a \`PAID\` notification with a verified signature, or \`status\` = \`4\` through the API.
- **Test on real devices** before going live: card payment, Apple Pay (iPhone), Google Pay (Android), returning to the app, cancelling the payment.

## Checklist before going live

- [ ] The app contains no Paynet username, password, keys or token.
- [ ] The server creates the order; the amount comes from the order on the server.
- [ ] The payment page opens in \`SFSafariViewController\` / Chrome Custom Tabs, not in a WebView.
- [ ] After payment and after cancelling, the customer returns to the app.
- [ ] The app gets the order status from the server, and the server from the notification or the API.
- [ ] Tapping "Pay" again does not create a second payment for the same order.
`,"../../content/ro/common/01-notifications.md":`# Notificări (webhooks)

Când o plată este achitată, Paynet trimite un \`POST\` HTTP cu corp JSON la URL-ul de callback înregistrat la Paynet. Notificarea este aceeași pentru toate tipurile de integrare.

**Se notifică doar plățile reușite.** \`EventType\` este mereu \`PAID\`. Dacă plata eșuează, Paynet nu trimite notificare — clientul este doar redirecționat la \`LinkUrlCancel\`. Considerați comanda neplătită până primiți o notificare \`PAID\` verificată (sau API-ul de status arată plata), iar după \`ExpiryDate\` — abandonată.

## Cererea

\`\`\`http
POST https://shop.example/paynet/notification
Content-Type: application/json; charset=utf-8
Hash: lq3+OCn0J/zSyNF5iAoShg==
\`\`\`

\`\`\`json
{
  "Eventid": 1000001,
  "EventType": "PAID",
  "Message": "Request processed successfully",
  "EventDate": "2026-11-09T12:00:00",
  "Payment": {
    "Id": 1234567,
    "ExternalId": 1762444800000,
    "SaleAreaCode": "onlidocumentation_md",
    "Customer": "37369XXX111",
    "StatusDate": "2026-11-09T12:00:00",
    "Amount": 1235,
    "PaidAmount": 1235,
    "Merchant": "265505",
    "CardMask": "411111******1111",
    "CardExpireMonth": "12",
    "CardExpireYear": "27",
    "CardIssuer": "TEST BANK",
    "CardLinkHash": null,
    "MoneyType": "CARD",
    "PayerName": "Ion",
    "PayerSurname": "Popescu",
    "PayerIDNP": null,
    "RRN": "000000000000"
  }
}
\`\`\`

Cererea are doar două antete: \`Content-Type\` și \`Hash\`. Nu există antet \`Authorization\` — autenticitatea este confirmată de \`Hash\`.

## Câmpuri

> **Important:** în majoritatea limbajelor cheile JSON țin cont de majuscule. Cheile sunt \`Id\` și \`ExternalId\` (nu \`ID\` / \`ExternalID\`).

| Câmp | Tip | Descriere |
|---|---|---|
| \`Eventid\` | long | ID-ul notificării. |
| \`EventType\` | string | Mereu \`PAID\`. |
| \`Message\` | string | Status text, de ex. \`Request processed successfully\`. |
| \`EventDate\` | string | Când a fost creată notificarea, \`YYYY-MM-DDTHH:mm:ss\`, ora locală Chișinău. |
| \`Payment.Id\` | long | ID-ul plății Paynet (\`paymentId\`). Folosiți-l drept cheie de idempotență. |
| \`Payment.ExternalId\` | long | Numărul comenzii dvs. (\`Order\`). |
| \`Payment.SaleAreaCode\` | string | Codul zonei de vânzare. |
| \`Payment.Customer\` | string | Codul clientului transmis în comandă (\`Customer.Code\`), de obicei mascat, de exemplu \`37369XXX111\` sau \`name***@gmail.com\`. |
| \`Payment.StatusDate\` | string | Când plata a ajuns în acest status (ora locală Chișinău). |
| \`Payment.Amount\` | long | Suma comenzii în unități minime, așa cum ați trimis-o. |
| \`Payment.PaidAmount\` | long | Suma plătită efectiv de client, în unități minime. Vezi mai jos. |
| \`Payment.Merchant\` | string | Codul dvs. de comerciant. |
| \`Payment.MoneyType\` | string | Cum a plătit clientul: \`CARD\`, \`APPLEPAY\`, \`GOOGLEPAY\`, \`MIA_QR\`, \`PAYNET\`, \`CASH_INVOICE\`. |
| \`Payment.CardMask\`, \`CardExpireMonth\`, \`CardExpireYear\`, \`CardIssuer\` | string | Datele cardului. Completate pentru \`CARD\`, precum și pentru \`APPLEPAY\` și \`GOOGLEPAY\` (cardul din portofel); \`null\` pentru alte metode de plată. |
| \`Payment.CardLinkHash\` | string | Tokenul cardului salvat: vine dacă pentru \`SaleAreaCode\` este activată [salvarea cardurilor](#/guides/saved-cards) și clientul a păstrat bifa; altfel \`null\`. |
| \`Payment.PayerName\`, \`PayerSurname\`, \`PayerIDNP\` | string | Datele plătitorului; pot fi \`null\`. |
| \`Payment.RRN\` | string | Retrieval reference number. |
| \`Hash\` (antet HTTP) | string | Semnătura notificării. |

Ignorați câmpurile necunoscute: pot apărea câmpuri opționale noi.

Valorile \`MoneyType\` din notificare nu coincid cu cele din cererea de creare a comenzii (\`Card\`, \`All\`, …). Nu le comparați direct.

### Amount și PaidAmount

\`PaidAmount\` trebuie să fie egal cu \`Amount\`.

Pot diferi **doar** dacă compania dvs. a convenit oficial cu Paynet o promoție sau o reducere (de ex. 10% la plata cu un card Mastercard cu un anumit BIN). Paynet configurează promoția pe partea sa, la cererea dvs.; nu se poate activa prin API.

> **Important:** dacă nu aveți o astfel de promoție convenită, iar \`PaidAmount\` diferă de \`Amount\`, nu onorați comanda automat. Salvați notificarea și contactați Paynet.

Decontare: primiți \`PaidAmount\` minus comisionul Paynet. Țineți cont de asta la reconcilierea cu extrasul.

## Verificarea semnăturii

\`\`\`text
PreparedString = EventDate + Eventid + EventType + Payment.Amount + Payment.Customer +
                 Payment.ExternalId + Payment.Id + Payment.Merchant + Payment.StatusDate
ExpectedHash   = Base64( MD5( UTF8( PreparedString + NotificationSecretKey ) ) )
\`\`\`

- Folosiți valorile exact așa cum apar în corpul JSON. O valoare lipsă sau \`null\` este un șir gol.
- Ordinea este fixă — exact ca în rândul de mai sus. **Nu sortați numele în cod:** o sortare obișnuită pune \`EventType\` înainte de \`Eventid\`, iar hash-ul nu se va potrivi.
- Folosiți cheia secretă pentru **notificări** (diferă de cheia pentru checkout).
- Comparați \`ExpectedHash\` cu antetul \`Hash\`. Dacă diferă, respingeți cererea (de ex. HTTP \`400\`) și nu modificați comanda.

Exemplu complet cu rezultatul așteptat: [Semnături](#/guides/signatures).

### Node.js (Express)

\`\`\`javascript
import crypto from 'node:crypto';
import express from 'express';

const SECRET = process.env.PAYNET_NOTIFICATION_SECRET;
const s = (v) => (v === null || v === undefined ? '' : String(v));

function expectedHash(n) {
  const p = n.Payment || {};
  const prepared = s(n.EventDate) + s(n.Eventid) + s(n.EventType) + s(p.Amount) + s(p.Customer) +
    s(p.ExternalId) + s(p.Id) + s(p.Merchant) + s(p.StatusDate);
  return crypto.createHash('md5').update(prepared + SECRET, 'utf8').digest('base64');
}

const app = express();
app.post('/paynet/notification', express.json(), async (req, res) => {
  const received = req.get('Hash') || '';
  const expected = expectedHash(req.body);
  const ok = received.length === expected.length &&
    crypto.timingSafeEqual(Buffer.from(received), Buffer.from(expected));
  if (!ok) return res.status(400).send('Invalid hash');

  const p = req.body.Payment;
  // Process each Payment.Id only once (idempotency).
  // If PaidAmount !== Amount and you have no agreed promotion: do not fulfil, contact Paynet.
  // await markOrderPaidOnce(p.Id, p.ExternalId, p.Amount, p.PaidAmount);
  res.status(200).json({ ResultCode: 'SUCCESS' });
});
\`\`\`

### PHP

\`\`\`php
<?php
$secret = getenv('PAYNET_NOTIFICATION_SECRET');
$body   = file_get_contents('php://input');
$n      = json_decode($body, true);
$p      = $n['Payment'] ?? [];
$s      = fn($v) => $v === null ? '' : (string) $v;

$prepared = $s($n['EventDate'] ?? null) . $s($n['Eventid'] ?? null) . $s($n['EventType'] ?? null)
          . $s($p['Amount'] ?? null) . $s($p['Customer'] ?? null) . $s($p['ExternalId'] ?? null)
          . $s($p['Id'] ?? null) . $s($p['Merchant'] ?? null) . $s($p['StatusDate'] ?? null);
$expected = base64_encode(md5($prepared . $secret, true));

if (!hash_equals($expected, $_SERVER['HTTP_HASH'] ?? '')) {
    http_response_code(400);
    exit('Invalid hash');
}
// Process once per Payment.Id; check PaidAmount === Amount (unless a promotion is agreed), then:
http_response_code(200);
echo json_encode(['ResultCode' => 'SUCCESS']);
\`\`\`

> **Important:** construiți \`PreparedString\` din valorile exact așa cum apar în corpul JSON. Nu reformatați datele (păstrați \`2026-11-09T12:00:00\` ca atare) și nu schimbați notația numerelor.

## Ce protejează semnătura și confirmarea prin API

Antetul \`Hash\` protejează doar câmpurile care intră în \`PreparedString\`:

| Semnate (verificate prin \`Hash\`) | Nesemnate |
|---|---|
| \`EventDate\`, \`Eventid\`, \`EventType\`, \`Payment.Amount\`, \`Payment.Customer\`, \`Payment.ExternalId\`, \`Payment.Id\`, \`Payment.Merchant\`, \`Payment.StatusDate\` | \`Payment.PaidAmount\`, \`Payment.MoneyType\`, \`Payment.CardLinkHash\`, \`Payment.SaleAreaCode\`, datele cardului și ale plătitorului (\`CardMask\`, \`CardIssuer\`, \`PayerName\`…), \`Message\` |

Un \`Hash\` valid confirmă că comanda \`ExternalId\` este plătită cu suma \`Amount\`. El **nu** confirmă câmpurile nesemnate. Înainte de a decide pe baza lor — ce sumă considerați primită, dacă salvați cardul — comparați-le cu răspunsul API-ului autentificat \`GET /api/order/merchant/{Order}\`. Acest răspuns este protejat de tokenul dvs. și de HTTPS.

Comparați valorile, nu doar apelați metoda:

| Ce verificați | Notificarea | Răspunsul API |
|---|---|---|
| Plata | \`Payment.Id\` | \`paymentId\` |
| Statusul | \`EventType\` = \`PAID\` | \`status\` = \`4\` |
| Suma comenzii | \`Payment.Amount\` (și suma comenzii dvs.) | \`amount.amount\` |
| Suma plătită | \`Payment.PaidAmount\` | \`amount.paidAmount\` |
| Clientul | comanda dvs. | \`customer.code\` |
| Cardul salvat | \`Payment.CardLinkHash\` | \`cardLinkHash\`, dacă API-ul îl returnează |

Dacă valorile diferă, nu onorați comanda automat și nu salvați cardul: trimiteți comanda la verificare manuală.

Dacă semnătura este validă, dar comanda nu poate fi onorată (comandă negăsită, sume diferite), răspundeți totuși \`200\` și trimiteți-o la verificare: altfel Paynet va repeta notificarea.

### Handler complet: Node.js

Verifică semnătura, salvează notificarea o singură dată, răspunde \`200\`, apoi confirmă valorile prin API și onorează comanda sau o trimite la verificare. Logica acestui exemplu este testată automat la fiecare build al documentației.

\`\`\`javascript
// paynet-notifications.mjs — complete notification handler, no dependencies (Node.js 18+).
import crypto from 'node:crypto';

// The 9 signed fields, in this exact order. Do not sort.
const signedValues = (n) => {
  const p = n.Payment || {};
  return [n.EventDate, n.Eventid, n.EventType, p.Amount, p.Customer, p.ExternalId, p.Id, p.Merchant, p.StatusDate];
};

export function verifyHash(notification, hashHeader, secret) {
  const prepared = signedValues(notification).map((v) => (v === null || v === undefined ? '' : String(v))).join('');
  const expected = crypto.createHash('md5').update(prepared + secret, 'utf8').digest('base64');
  const received = String(hashHeader || '');
  return received.length === expected.length && crypto.timingSafeEqual(Buffer.from(received), Buffer.from(expected));
}

/**
 * deps.secret      notification secret key
 * deps.apiUrl      https://ecom-api.paynet.md (test: https://ecom-api-test.paynet.md)
 * deps.getToken()  returns a valid Bearer token (POST /auth, cached)
 * deps.fetch       fetch implementation (globalThis.fetch)
 * deps.db          your storage:
 *   saveNotificationOnce(paymentId, notification) -> true if new, false if already stored
 *   findOrder(order) -> { amount, customerCode, promotionAgreed } or null
 *   markPaid(order, paidAmount), saveCard(customerCode, cardLinkHash), sendToReview(order, problems)
 *
 * handle(rawBody, hashHeader) -> { status, processing }
 *   status: HTTP status to answer Paynet; processing: promise of the work done after answering.
 */
export function createPaynetHandler(deps) {
  const { db } = deps;

  async function confirmWithApi(n, order) {
    const p = n.Payment;
    const response = await deps.fetch(\`\${deps.apiUrl}/api/order/merchant/\${p.ExternalId}\`, {
      headers: { Authorization: \`Bearer \${await deps.getToken()}\` },
    });
    if (!response.ok) throw new Error(\`Status check failed: HTTP \${response.status}\`);
    const payment = await response.json();

    const problems = [];
    if (payment.paymentId !== p.Id) problems.push('paymentId');
    if (payment.status !== 4) problems.push('status');
    if (payment.amount?.amount !== p.Amount || p.Amount !== order.amount) problems.push('Amount');
    if (payment.amount?.paidAmount !== p.PaidAmount) problems.push('PaidAmount');
    if (payment.customer?.code !== order.customerCode) problems.push('customer');
    if (p.CardLinkHash && payment.cardLinkHash && payment.cardLinkHash !== p.CardLinkHash) problems.push('CardLinkHash');
    return problems;
  }

  async function process(n) {
    const p = n.Payment;
    if (n.EventType !== 'PAID') return db.sendToReview(p.ExternalId, ['EventType']);
    const order = await db.findOrder(p.ExternalId);
    if (!order) return db.sendToReview(p.ExternalId, ['unknown order']);

    const problems = await confirmWithApi(n, order);
    if (p.PaidAmount !== p.Amount && !order.promotionAgreed) problems.push('PaidAmount differs from Amount');
    if (problems.length) return db.sendToReview(p.ExternalId, problems);

    await db.markPaid(p.ExternalId, p.PaidAmount);
    if (p.CardLinkHash) await db.saveCard(order.customerCode, p.CardLinkHash);
  }

  return async function handle(rawBody, hashHeader) {
    let n;
    try {
      n = JSON.parse(rawBody);
    } catch {
      return { status: 400, processing: null };
    }
    if (!verifyHash(n, hashHeader, deps.secret)) return { status: 400, processing: null };

    const isNew = await db.saveNotificationOnce(n.Payment?.Id, n); // idempotency by Payment.Id
    if (!isNew) return { status: 200, processing: null }; // a retry: already stored
    // Answer 200 now; confirm and fulfil after the answer. If this work fails, the stored
    // notification stays unprocessed and a background job can retry it.
    return { status: 200, processing: process(n) };
  };
}
\`\`\`

Connecting it to Express (read the raw body, answer first, process after):

\`\`\`javascript
import express from 'express';
import { createPaynetHandler } from './paynet-notifications.mjs';

const handle = createPaynetHandler({
  secret: process.env.PAYNET_NOTIFICATION_SECRET,
  apiUrl: process.env.PAYNET_API_URL,
  getToken, // your cached POST /auth
  fetch: globalThis.fetch,
  db, // your storage
});

const app = express();
app.post('/paynet/notification', express.text({ type: '*/*' }), async (req, res) => {
  const { status, processing } = await handle(req.body, req.get('Hash'));
  res.status(status).json(status === 200 ? { ResultCode: 'SUCCESS' } : { error: 'Invalid notification' });
  processing?.catch((error) => console.error('Paynet notification processing failed', error));
});
\`\`\`

### Handler complet: PHP

\`\`\`php
<?php
// paynet-notification.php — complete notification handler (PHP 7.4+, ext-curl).
// $db must implement: saveNotificationOnce($paymentId, array $n): bool, findOrder($order): ?array
// (['amount' => int, 'customerCode' => string, 'promotionAgreed' => bool]), markPaid($order, $paidAmount),
// saveCard($customerCode, $cardLinkHash), sendToReview($order, array $problems).

function paynetVerifyHash(array $n, string $hashHeader, string $secret): bool {
    $p = $n['Payment'] ?? [];
    $s = fn($v) => $v === null ? '' : (string) $v;
    // The 9 signed fields, in this exact order. Do not sort.
    $prepared = $s($n['EventDate'] ?? null) . $s($n['Eventid'] ?? null) . $s($n['EventType'] ?? null)
              . $s($p['Amount'] ?? null) . $s($p['Customer'] ?? null) . $s($p['ExternalId'] ?? null)
              . $s($p['Id'] ?? null) . $s($p['Merchant'] ?? null) . $s($p['StatusDate'] ?? null);
    $expected = base64_encode(md5($prepared . $secret, true));
    return hash_equals($expected, $hashHeader);
}

function paynetConfirmWithApi(array $n, array $order, string $apiUrl, string $token): array {
    $p  = $n['Payment'];
    $ch = curl_init($apiUrl . '/api/order/merchant/' . $p['ExternalId']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code !== 200) throw new RuntimeException("Status check failed: HTTP $code");
    $pay = json_decode($body, true);

    $problems = [];
    if (($pay['paymentId'] ?? null) !== $p['Id']) $problems[] = 'paymentId';
    if (($pay['status'] ?? null) !== 4) $problems[] = 'status';
    if (($pay['amount']['amount'] ?? null) !== $p['Amount'] || $p['Amount'] !== $order['amount']) $problems[] = 'Amount';
    if (($pay['amount']['paidAmount'] ?? null) !== ($p['PaidAmount'] ?? null)) $problems[] = 'PaidAmount';
    if (($pay['customer']['code'] ?? null) !== $order['customerCode']) $problems[] = 'customer';
    if (!empty($p['CardLinkHash']) && !empty($pay['cardLinkHash']) && $pay['cardLinkHash'] !== $p['CardLinkHash']) $problems[] = 'CardLinkHash';
    return $problems;
}

function paynetProcess(array $n, $db, string $apiUrl, string $token): void {
    $p = $n['Payment'];
    if (($n['EventType'] ?? '') !== 'PAID') { $db->sendToReview($p['ExternalId'], ['EventType']); return; }
    $order = $db->findOrder($p['ExternalId']);
    if (!$order) { $db->sendToReview($p['ExternalId'], ['unknown order']); return; }

    $problems = paynetConfirmWithApi($n, $order, $apiUrl, $token);
    if (($p['PaidAmount'] ?? null) !== $p['Amount'] && empty($order['promotionAgreed'])) $problems[] = 'PaidAmount differs from Amount';
    if ($problems) { $db->sendToReview($p['ExternalId'], $problems); return; }

    $db->markPaid($p['ExternalId'], $p['PaidAmount']);
    if (!empty($p['CardLinkHash'])) $db->saveCard($order['customerCode'], $p['CardLinkHash']);
}

// --- Endpoint -------------------------------------------------------------
function paynetHandleRequest($db, callable $getToken): void {
    $raw = file_get_contents('php://input');
    $n   = json_decode($raw, true);
    if (!is_array($n) || !paynetVerifyHash($n, $_SERVER['HTTP_HASH'] ?? '', getenv('PAYNET_NOTIFICATION_SECRET'))) {
        http_response_code(400);
        exit('Invalid notification');
    }
    $isNew = $db->saveNotificationOnce($n['Payment']['Id'] ?? null, $n); // idempotency by Payment.Id

    // Answer 200 first.
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['ResultCode' => 'SUCCESS']);
    if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();

    if ($isNew) {
        try {
            paynetProcess($n, $db, getenv('PAYNET_API_URL'), $getToken());
        } catch (Throwable $e) {
            error_log('Paynet notification processing failed: ' . $e->getMessage()); // retry from storage later
        }
    }
}
\`\`\`

## Răspuns și reîncercări

- Răspundeți HTTP \`200\` **după** ce ați verificat hash-ul și ați salvat rezultatul.
- Răspundeți repede: salvați notificarea, returnați \`200\`, iar procesarea grea faceți-o după răspuns.
- Orice alt răspuns (sau lipsa răspunsului) este considerat eșec, iar Paynet trimite notificarea din nou. După un răspuns \`200\`, reîncercările se opresc.
- Contează doar codul HTTP; corpul răspunsului nu contează. \`{ "ResultCode": "SUCCESS" }\` din exemple este opțional.
- Programul — **9 încercări**; reîncercările durează circa 25 de minute după prima încercare, apoi trimiterea se oprește:

| Încercarea | Când |
|---|---|
| 1 | după ce banca emitentă confirmă plata (depinde de bancă: de la câteva secunde la câteva minute) |
| 2–4 | după ~1 minut, apoi la fiecare ~35 de secunde |
| 5–7 | după ~5 minute, apoi la fiecare ~35 de secunde |
| 8–9 | după ~15 minute, apoi după ~35 de secunde |

> **Important:** reîncercările durează doar circa 25 de minute după prima încercare. Dacă serverul dvs. a fost indisponibil mai mult, notificarea nu va mai veni. De aceea verificați statusul comenzilor neplătite prin API și faceți reconcilierea zilnic.

- Din cauza reîncercărilor aceeași notificare poate sosi de mai multe ori. Procesați fiecare \`Payment.Id\` o singură dată.
- Dacă notificarea nu a sosit (de exemplu, serverul a fost indisponibil mai mult decât toate încercările), verificați statusul cu \`GET /api/order/{paymentId}\` sau \`GET /api/order/merchant/{Order}\`. Retrimiterea o puteți cere la suportul Paynet.
- Dacă serverul dvs. este protejat de firewall, permiteți cererile de intrare de la adresele IP Paynet: \`93.113.159.22\` — producție, \`93.113.159.23\` — mediul de test.
- Antifrauda nu va anula o plată pentru care ați primit \`PAID\`: ea acționează înainte de confirmarea plății. O plată achitată își schimbă statusul doar după [rambursarea](#/guides/errors-and-statuses) dvs. (\`5\` sau \`6\`).

## Simulatorul de notificări pe acest portal

Deschideți **General → Notificări → Simulator notificări**:

1. Introduceți URL-ul dvs. de callback. Trebuie să fie accesibil din internet și, **doar pentru simulator**, să accepte cereri din browser (CORS).
2. Verificați cheia secretă pentru notificări: cheia de test \`D9873689-E5F8-4272-A67F-0D8BA3F9BAA7\` este deja completată; o puteți înlocui cu propria cheie.
3. Introduceți numărul comenzii comerciantului (\`Order\`) al unei plăți de test **achitate** și apăsați **Get** — portalul încarcă plata.
4. Apăsați **Send notification** — portalul trimite la URL-ul dvs. o notificare \`PAID\` semnată, construită din această plată, și afișează \`PreparedString\` și \`Hash\` folosite.

Este o simulare trimisă din browserul dvs., nu o notificare reală Paynet. Pentru comenzile neplătite simulatorul nu trimite nimic — la fel ca Paynet.

> **Important:** CORS este necesar doar simulatorului, deoarece trimite cererea din browser. Notificările reale sunt trimise de serverul Paynet și CORS nu se aplică: nu activați CORS pe endpoint-ul de producție pentru Paynet. O simulare reușită verifică validarea semnăturii și procesarea, nu livrarea de la Paynet (acces din rețea, firewall, certificat TLS). Confirmați livrarea cu o plată de test reală.
`,"../../content/ro/common/02-signatures.md":'# Semnături\n\nPaynet folosește peste tot aceeași schemă de hash:\n\n```text\nSignature = Base64( MD5( <string to sign> + SecretKey ) )\n```\n\n- MD5 se calculează pe octeții **UTF-8** ai șirului (inclusiv pentru chirilice și diacritice românești).\n- Base64 se aplică pe **digestul brut de 16 octeți** (nu pe șirul hex de 32 de caractere). Rezultatul are mereu 24 de caractere și se termină cu `==`.\n- Nu o confundați cu câmpul `signature` din răspunsul `POST /api/order`: aceasta este o valoare internă a linkului de plată (32 de caractere, egală cu parametrul `s` din `paymentLink`). Nu o folosiți pentru verificări.\n\nDiferă doar modul în care se construiește șirul de semnat:\n\n| Unde | Șirul de semnat | Cheia secretă |\n|---|---|---|\n| Formularul hosted checkout (dvs. → Paynet) | `RawData`: valorile câmpurilor semnate, sortate după numele câmpului, codificate RFC 3986, concatenate | cheia hosted checkout |\n| Notificări (Paynet → dvs.) | `PreparedString`: 9 valori ale notificării în ordine fixă | cheia pentru notificări |\n\nCele două chei secrete diferă intenționat. Paynet vi le emite pe amândouă.\n\n## Vector de test 1: formularul hosted checkout\n\nCheia secretă (test): `F90D6485-9CCC-458B-96A3-8958AF9B4458`\n\nCâmpuri de intrare:\n\n```json\n{\n  "Order": 1762444800000,\n  "Currency": "498",\n  "Merchant": "265505",\n  "SaleAreaCode": "onlidocumentation_md",\n  "Amount": "1235",\n  "Description": "Test&Co SRL",\n  "CustomerCode": "5555",\n  "CustomerNameFirst": "First name",\n  "CustomerNameLast": "Last name",\n  "CustomerPhoneNumber": "060000000",\n  "CustomerEmail": "test@gmail.com",\n  "ExpiryDate": "2026-12-31T23:59:59",\n  "LinkUrlCancel": "https://test.oplta.md/cancel",\n  "LinkUrlSuccess": "https://test.oplta.md/ok",\n  "Lang": "ro",\n  "MoneyType": "Card"\n}\n```\n\nOrdinea câmpurilor după sortare: `Amount, Currency, CustomerCode, CustomerEmail, CustomerNameFirst, CustomerNameLast, CustomerPhoneNumber, Description, ExpiryDate, Lang, LinkUrlCancel, LinkUrlSuccess, Merchant, MoneyType, Order, SaleAreaCode`.\n\n`RawData` așteptat:\n\n```text\n12354985555test%40gmail.comFirst%20nameLast%20name060000000Test%26Co%20SRL2026-12-31T23%3A59%3A59rohttps%3A%2F%2Ftest.oplta.md%2Fcancelhttps%3A%2F%2Ftest.oplta.md%2Fok265505Card1762444800000onlidocumentation_md\n```\n\n`Signature` așteptată:\n\n```text\ncxr/+yLYZp34aR0KXLkb2A==\n```\n\n## Vector de test 2: notificare\n\nCheia secretă pentru notificări (test): `D9873689-E5F8-4272-A67F-0D8BA3F9BAA7`\n\n```json\n{\n  "Eventid": 1000001,\n  "EventType": "PAID",\n  "EventDate": "2026-11-09T12:00:00",\n  "Payment": {\n    "Id": 1234567,\n    "ExternalId": 1762444800000,\n    "Merchant": "265505",\n    "Customer": "37369XXX111",\n    "StatusDate": "2026-11-09T12:00:00",\n    "Amount": 1235\n  }\n}\n```\n\n(Sunt afișate doar câmpurile folosite în semnătură; notificarea reală are mai multe, vezi [Notificări](#/guides/notifications).)\n\n`PreparedString` așteptat:\n\n```text\n2026-11-09T12:00:001000001PAID123537369XXX111176244480000012345672655052026-11-09T12:00:00\n```\n\n`Hash` așteptat:\n\n```text\nlq3+OCn0J/zSyNF5iAoShg==\n```\n\n## Vector de test 3: caractere speciale\n\nAceeași cheie secretă ca la vectorul 1. Valorile conțin `\'`, `&`, `!`, `(`, `)`, `*`, litere chirilice și românești. Mediul de test a acceptat exact acest formular (11.11.2026).\n\n```json\n{\n  "Order": 1762444800003,\n  "Currency": "498",\n  "Merchant": "265505",\n  "SaleAreaCode": "onlidocumentation_md",\n  "Amount": "1235",\n  "Description": "Mary\'s Cake & Co! (1)*",\n  "CustomerCode": "5555",\n  "CustomerNameFirst": "Мария",\n  "CustomerNameLast": "Țurcan",\n  "ExpiryDate": "2026-12-31T23:59:59",\n  "LinkUrlCancel": "https://test.oplta.md/cancel",\n  "LinkUrlSuccess": "https://test.oplta.md/ok",\n  "Lang": "ro",\n  "MoneyType": "Card"\n}\n```\n\n`RawData` așteptat:\n\n```text\n12354985555%D0%9C%D0%B0%D1%80%D0%B8%D1%8F%C8%9AurcanMary%27s%20Cake%20%26%20Co%21%20%281%29%2A2026-12-31T23%3A59%3A59rohttps%3A%2F%2Ftest.oplta.md%2Fcancelhttps%3A%2F%2Ftest.oplta.md%2Fok265505Card1762444800003onlidocumentation_md\n```\n\n`Signature` așteptată:\n\n```text\nfm47qWzVzqPQQ+huHgWVZw==\n```\n\n## Caractere speciale\n\nRezultatele trimiterilor reale ale formularului în mediul de test:\n\n| Valoarea conține | Rezultat |\n|---|---|\n| `" \' & < > # ; % + = ? / \\`, `’`, emoji, chirilice, litere românești | Funcționează dacă fiecare valoare este codificată RFC 3986 (tabelul de mai jos). |\n| Un rând nou (`Description` pe mai multe rânduri) | Semnătura nu trece. Înlocuiți rândurile noi cu un spațiu înainte de semnare. |\n| Un tag HTML (`<b>`) sau o entitate HTML (`&#039;`) | Paynet respinge formularul înainte de verificarea semnăturii: clientul vede pagina principală Paynet în locul paginii de plată. Eliminați tagurile și transformați entitățile în caractere obișnuite înainte de semnare. |\n\nFuncția de codificare pe limbaje:\n\n| Limbaj | Corect | Greșit (nu merge pentru unele caractere) |\n|---|---|---|\n| PHP | `rawurlencode($v)` | `urlencode($v)`: spațiul devine `+`, `~` devine `%7E` |\n| JavaScript / Node.js | `encodeURIComponent(v).replace(/[!\'()*]/g, (c) => \'%\' + c.charCodeAt(0).toString(16).toUpperCase())` | doar `encodeURIComponent(v)`: lasă necodificate `! \' ( ) *` |\n| Python | `urllib.parse.quote(v, safe="~")` | `quote(v)` (lasă `/`), `quote_plus(v)` (spațiul devine `+`) |\n| C# | `Uri.EscapeDataString(v)` (.NET Core / .NET 5+) | `HttpUtility.UrlEncode`, `WebUtility.UrlEncode`: spațiul devine `+` |\n| Java | `URLEncoder.encode(v, StandardCharsets.UTF_8).replace("+", "%20").replace("*", "%2A").replace("%7E", "~")` | doar `URLEncoder.encode`: spațiul devine `+`, `*` rămâne necodificat |\n\nReguli:\n\n- Semnați valorile originale — exact ce va trimite browserul. Nu semnați textul escapat pentru HTML (`&amp;`, `&#039;`).\n- Escapați valorile pentru HTML o singură dată, când le scrieți în formular (`&` → `&amp;`, `"` → `&quot;`). Un `"` neescapat taie valoarea în `value="…"`.\n- Nu modificați valorile după semnare (eliminarea spațiilor, înlocuirea caracterelor, scurtarea).\n- Serviți pagina în UTF-8 (`<meta charset="utf-8">`) și adăugați `accept-charset="UTF-8"` la formular.\n- Dacă CMS-ul vă dă denumiri de produse cu entități HTML (`Mary&#039;s`), decodificați-le (`Mary\'s`) înainte de a construi formularul.\n\n## Verificați implementarea\n\nPython:\n\n```python\nimport base64, hashlib, urllib.parse\n\ndef md5_base64(text: str) -> str:\n    return base64.b64encode(hashlib.md5(text.encode("utf-8")).digest()).decode()\n\nSIGNED = ["Order", "Currency", "Merchant", "SaleAreaCode", "CustomerCode", "CustomerNameFirst",\n          "CustomerNameLast", "CustomerPhoneNumber", "CustomerEmail", "ExpiryDate", "Description",\n          "Amount", "LinkUrlCancel", "LinkUrlSuccess", "Lang", "MoneyType"]\n\ndef checkout_signature(fields: dict, secret: str) -> str:\n    names = sorted(n for n in SIGNED if fields.get(n) is not None)\n    raw = "".join(urllib.parse.quote(str(fields[n]), safe="~") for n in names)\n    return md5_base64(raw + secret)\n\ndef notification_hash(n: dict, secret: str) -> str:\n    s = lambda v: "" if v is None else str(v)\n    p = n.get("Payment", {})\n    prepared = (s(n.get("EventDate")) + s(n.get("Eventid")) + s(n.get("EventType")) + s(p.get("Amount"))\n                + s(p.get("Customer")) + s(p.get("ExternalId")) + s(p.get("Id")) + s(p.get("Merchant"))\n                + s(p.get("StatusDate")))\n    return md5_base64(prepared + secret)\n```\n\nC#:\n\n```csharp\nusing System.Security.Cryptography;\nusing System.Text;\n\nstatic string Md5Base64(string text) =>\n    Convert.ToBase64String(MD5.HashData(Encoding.UTF8.GetBytes(text)));\n\n// Hosted checkout form: Uri.EscapeDataString implements RFC 3986.\nstatic string CheckoutSignature(IDictionary<string, string?> fields, string secret)\n{\n    string[] signed = { "Order", "Currency", "Merchant", "SaleAreaCode", "CustomerCode", "CustomerNameFirst",\n        "CustomerNameLast", "CustomerPhoneNumber", "CustomerEmail", "ExpiryDate", "Description", "Amount",\n        "LinkUrlCancel", "LinkUrlSuccess", "Lang", "MoneyType" };\n    var raw = new StringBuilder();\n    foreach (var name in signed.Where(n => fields.TryGetValue(n, out var v) && v != null).OrderBy(n => n, StringComparer.Ordinal))\n        raw.Append(Uri.EscapeDataString(fields[name]!));\n    return Md5Base64(raw + secret);\n}\n```\n\n## Greșeli frecvente\n\n| Simptom | Cauză |\n|---|---|\n| Semnătura are 32 de caractere hex | Ați codificat Base64 șirul hex sau nu ați aplicat Base64 deloc. Codificați digestul brut. |\n| Funcționează pentru unele comenzi, pentru altele nu | Valorile cu spații, `&`, `@`, `:` sau `/` nu sunt codificate RFC 3986, sau spațiul este codificat ca `+` în loc de `%20`. |\n| Hash-ul notificării nu se potrivește niciodată | Cheie secretă greșită (cheile pentru checkout și notificări diferă), câmpuri în ordine greșită sau codul citește `Payment.ID` / `Payment.ExternalID` în loc de `Payment.Id` / `Payment.ExternalId` (cheile țin cont de majuscule). |\n| Hash-ul diferă doar pentru nume cu chirilice/diacritice | Șirul nu a fost codificat în UTF-8 înainte de hash. |\n| Semnătura nu mai trece după adăugarea unui câmp | Un câmp semnat a fost adăugat în formular, dar nu în `RawData` (sau invers). |\n| Nu merge doar când valoarea conține `\'`, `!`, `(`, `)` sau `*` | `encodeURIComponent` (sau altă funcție) nu codifică aceste cinci caractere. Vezi „Caractere speciale” mai sus. |\n| După trimiterea formularului se deschide pagina principală Paynet în locul paginii de plată | Valoarea conține un tag HTML (`<b>`) sau o entitate HTML (`&#039;`). Vezi „Caractere speciale” mai sus. |\n| Nu merge când `Description` are mai multe rânduri | Un rând nou în valoare. Înlocuiți-l cu un spațiu înainte de semnare. |\n',"../../content/ro/common/03-errors-and-statuses.md":'# Erori și statusuri\n\n## Fișă rapidă: ce faceți la o eroare\n\nVerificat în mediul de test pe 10.11.2026. Detalii despre fiecare format — în secțiunile de mai jos.\n\n| HTTP | Ce conține răspunsul | Când apare | Ce faceți | Repetați cererea? |\n|---|---|---|---|---|\n| `400` | `INVALID_PARAMETER`, `details` numește câmpul | Valoare invalidă a unui parametru | Corectați câmpul din `details` | Doar după corectare |\n| `400` | `errorInfo`, `errors` listează câmpurile | JSON ilizibil, lipsesc câmpuri obligatorii, tip greșit (de exemplu, litere în loc de număr în `paymentId` din adresă) | Corectați cererea | Doar după corectare |\n| `401` | `UNAUTHORIZED` (chei cu majusculă: `Status`, `Code`…) | Token lipsă, invalid sau expirat | Obțineți un token nou prin `/auth` | Da, o dată cu tokenul nou |\n| `401` | `AUTHENTICATION_FAILED` | `/auth`: utilizator sau parolă greșite | Verificați datele de acces (pentru test și producție sunt diferite) | Nu |\n| `404` | `NOT_FOUND_RECORD` | Nu există plata cu acest ID; rambursarea unei plăți neachitate; căutare: nu există plăți în perioadă (rezultat gol) | Verificați `paymentId` / `Order` și statusul plății; la căutare — considerați rezultatul gol | Nu |\n| `404` | Corp gol | Adresă (cale) greșită | Verificați URL-ul și adresa API | Nu |\n| `405` | Corp gol | Metodă HTTP greșită (de exemplu, `GET` în loc de `POST`) | Verificați metoda | Doar după corectare |\n| `415` | Corp gol | Lipsește antetul `Content-Type: application/json` sau corpul nu este JSON (inclusiv la `/auth`) | Adăugați antetul, trimiteți JSON | Doar după corectare |\n| `500` | `TECHNICAL_ERROR` | `Order` repetat cu alte date sau după plată; ori o defecțiune la Paynet | Verificați întâi `GET /api/order/merchant/{Order}`. Dacă este un `Order` repetat, creați o comandă cu un `Order` nou | Doar după verificare |\n| — | Niciun răspuns (timeout, rețea) | Problemă de conexiune | Căutați comanda după `Order`; dacă nu există, repetați **aceeași** cerere fără modificări | Da, cu același corp |\n\n- În mediul de test nu au apărut răspunsuri `403`, `429` sau `503`. Nu s-a observat limitarea frecvenței: 100 de cereri paralele au primit `200`. Paynet nu publică limite oficiale, așa că nu trimiteți cereri în buclă fără pauză.\n- În `errorInfo`, câmpul `ppResponseCodeDescription` poate conține „We are sorry, this service is temporarily unavailable” chiar și la o eroare obișnuită de validare. Bazați-vă pe `errors`, nu pe acest text, și nu-l afișați clientului.\n- Dacă primiți `401` pentru token: obțineți un token nou și repetați cererea **o singură dată**. Dacă din nou `401` — verificați datele de acces.\n\n## Coduri HTTP\n\n| HTTP | `code` | Semnificație | Ce faceți |\n|---|---|---|---|\n| `200` | — | Succes. | — |\n| `400` | `INVALID_PARAMETER` | Unul sau mai mulți parametri lipsesc sau sunt invalizi. `details` numește parametrul. | Corectați cererea. Nu o repetați nemodificată. |\n| `401` | `UNAUTHORIZED` | Tokenul Bearer lipsește, este invalid sau a expirat. | Apelați din nou `/auth` și repetați o singură dată. |\n| `404` | `NOT_FOUND_RECORD` | Nu există plată/înregistrare cu acest ID. | Verificați ID-ul (`paymentId` sau `Order`-ul dvs.). |\n| `500` | `TECHNICAL_ERROR` | Eroare pe partea Paynet **sau** un `Order` repetat care nu poate fi refolosit (vezi mai jos). | Verificați cu `GET /api/order/merchant/{Order}` dacă comanda există; dacă este o eroare tehnică reală, reîncercați mai târziu, cu pauză. |\n| `401` | `AUTHENTICATION_FAILED` | `/auth` cu utilizator sau parolă greșite. | Verificați datele de autentificare. |\n\n## Corpul erorii\n\n```json\n{\n  "status": 400,\n  "message": "One or more entered parameters are incorrect.",\n  "code": "INVALID_PARAMETER",\n  "traceId": "9b9346f9-f83a-465d-ac8d-dc382c460c22",\n  "details": "The invalid parameter is: XXXX"\n}\n```\n\n| Câmp | Descriere |\n|---|---|\n| `status` | Statusul HTTP. |\n| `message` | Mesaj pentru oameni. |\n| `code` | Codul erorii, citibil de mașină (tabelul de mai sus). |\n| `traceId` | ID-ul cererii. Trimiteți-l suportului Paynet când raportați o problemă. |\n| `details` | Informații suplimentare, de ex. parametrul invalid. |\n\n> **Notă:** un `401` pentru token lipsă, invalid sau expirat folosește chei cu majusculă (`Status`, `Message`, `Code`, `TraceId`), iar `401` de la `/auth` pentru parolă greșită folosește cheile obișnuite (`status`, `message`…). Citiți câmpurile erorii fără a ține cont de majuscule.\n\n### JSON invalid sau câmpuri obligatorii lipsă\n\nDacă corpul cererii nu poate fi citit (JSON invalid, tipuri greșite, lipsește un câmp obligatoriu), API-ul răspunde `400` într-un alt format, cu eroarea în `errorInfo`:\n\n```json\n{\n  "errorInfo": {\n    "title": "One or more validation errors occurred.",\n    "status": 400,\n    "ppResponseCodeEnum": "TECHNICAL_ERROR",\n    "ppResponseCode": 1,\n    "ppResponseCodeText": "TECHNICAL_ERROR",\n    "errors": {\n      "$": ["JSON deserialization for type \'…DeleteLinkedCardRequest\' was missing required properties including: \'cardLinkHash\', \'saleAreaCode\', \'customerCode\'."]\n    },\n    "traceId": "00-7c209d88f31e3e5cd2f7bd88ae2f23c2-ad167338e418068c-00"\n  }\n}\n```\n\n`errors` enumeră câmpurile cu probleme. Tratați ambele formate de eroare: verificați întâi `errorInfo`, apoi citiți `status` / `code` / `message`.\n\nNumele câmpurilor din cerere nu țin cont de majuscule: sunt acceptate și `CardLinkHash`, și `cardLinkHash` (verificat pe API-ul de test). Folosiți scrierea din exemple.\n\n## Număr de comandă repetat (Order)\n\n| Situație | Rezultat |\n|---|---|\n| `Order` nou | Se creează o plată nouă. |\n| Același `Order`, **aceleași date**, plata încă neachitată | Se returnează același `paymentId` și `paymentLink`. Repetarea este sigură, de ex. după un timeout. |\n| Același `Order`, **date diferite** (sumă, produse, …) | Server-to-server: HTTP `500`, `TECHNICAL_ERROR`. |\n| Același `Order`, plata deja achitată sau în procesare la banca emitentă | Server-to-server: HTTP `500`, `TECHNICAL_ERROR`. Hosted checkout: clientul vede pagina Paynet „Plata a fost respinsă” (factura este deja plătită sau în curs de procesare). |\n\nCorpul erorii în aceste cazuri:\n\n```json\n{\n  "status": 500,\n  "message": "One or more errors occurred.",\n  "code": "TECHNICAL_ERROR",\n  "traceId": "11de6054-87ef-484d-a368-7cfae0b452ff",\n  "details": "Please verify the transmitted data and try again, or contact support."\n}\n```\n\n**Regulă:** o comandă în magazin = un `Order`. Dacă clientul modifică coșul, creați o comandă nouă cu un `Order` nou.\n\n## Statusul plății\n\nObiectul plății (`POST /api/order`, `GET /api/order/{id}`, `GET /api/order/merchant/{id}`, `GET /api/order/search`) are un `status` numeric și datele `registered`, `paidDate`, `expiryDate`.\n\nO comandă nou creată are `status` = `1` și `paidDate` = `null`.\n\n| `status` | Semnificație | Ce faceți |\n|---|---|---|\n| `1` | Înregistrată: comanda există, încă nu e plătită | Așteptați plata. Dacă clientul a părăsit pagina, îl puteți trimite din nou la același `paymentLink` (cel din răspunsul la crearea comenzii, vezi mai jos). |\n| `3` | În procesare: clientul a apăsat „Plătește”, banca încă nu a răspuns | Nu creați comanda din nou și nu o anulați. Verificați statusul mai târziu. |\n| `4` | Achitată | Onorați comanda. |\n| `5` | Neachitată (refuzată de bancă, anulată de antifraudă) sau rambursată integral | Final. O nouă încercare de plată necesită o comandă cu un `Order` nou. |\n| `6` | Achitată, apoi rambursată parțial | Final. Clientul a plătit; o parte din bani i-a fost returnată. |\n\n```\n1 ──► 3 ──► 4 ──► 5  (full refund / полный возврат / rambursare totală)\n      │      └──► 6  (partial refund / частичный возврат / rambursare parțială)\n      └──► 5  (declined, antifraud / отказ, антифрод / refuz, antifraudă)\n```\n\n- `5` și `6` sunt finale: după ele nu se mai schimbă nimic. Valoarea `2` nu se folosește.\n- Nu există un status separat „expirată”: dacă `ExpiryDate` a trecut fără plată, comanda rămâne `1`, dar nu mai poate fi plătită.\n- Antifrauda acționează înainte de confirmarea plății. După ce ați primit o notificare `PAID` verificată, antifrauda nu va anula acea plată; statusul `5` la o comandă plătită înseamnă doar rambursare integrală.\n- Considerați plata achitată când ați primit o notificare `PAID` verificată sau `status` = `4`. `6` înseamnă tot că clientul a plătit (apoi o parte a fost rambursată); `5` după plată înseamnă rambursare integrală.\n- Dacă clientul nu trece 3-D Secure, plata primește statusul `5`, iar clientul revine la `LinkUrlCancel` — la fel ca la refuzul băncii.\n- Motivul refuzului (refuzul băncii, antifraudă, 3-D Secure) nu poate fi aflat prin API: statusul `5` înseamnă doar că această comandă este închisă și pentru o nouă încercare este nevoie de un `Order` nou.\n\n### Plată eșuată și o nouă încercare\n\nO plată eșuată nu generează notificare: clientul revine la `LinkUrlCancel`. Verificați statusul cu `GET /api/order/merchant/{Order}`:\n\n| `status` | Ce s-a întâmplat | Cum îi permiteți clientului să plătească din nou |\n|---|---|---|\n| `1` | Clientul nu a plătit (de exemplu, a închis pagina) | Trimiteți-l la același `paymentLink`. |\n| `3` | Plata este încă în procesare | Așteptați și verificați statusul din nou. Nu creați o comandă nouă. |\n| `5` | Banca a refuzat plata | Comanda este închisă. Creați o comandă nouă cu un `Order` **nou** și trimiteți clientul la noul `paymentLink`. |\n\n**Păstrați `paymentLink` din răspunsul la `POST /api/order`.** Doar acest răspuns conține linkul complet (cu numărul plății și `?s=…`). În răspunsurile `GET /api/order/…` câmpul `paymentLink` este trunchiat la `https://…/ecom/getecom` și nu poate fi deschis. Dacă ați pierdut linkul, trimiteți din nou `POST /api/order` cu **același corp** (același `Order`, aceleași date): primiți aceeași plată și același link.\n\n## Date și formate\n\n| Unde | Format | Exemplu |\n|---|---|---|\n| `ExpiryDate` în cereri | `YYYY-MM-DDTHH:mm:ss`, **ora locală Chișinău** | `2026-12-31T23:59:59` |\n| Datele în răspunsurile despre plată | `YYYY-MM-DD HH:mm:ss` | `2026-04-01 15:01:12` |\n| `eventDate` în răspunsul la rambursare | `DD.MM.YYYY HH:mm:ss` | `09.11.2026 18:17:54` |\n| Datele în notificări | `YYYY-MM-DDTHH:mm:ss`, ora locală Chișinău | `2026-11-09T12:00:00` |\n| `from` / `to` în `/api/order/search` | `YYYY-MM-DDTHH:mm:ss`, **ora locală Chișinău**, fără `Z` (`Z` sau decalajul sunt ignorate) | `2026-03-09T08:40:05` |\n| `dateStart` / `dateFinish` în extrase | dată | `2026-03-01` |\n| Sume | întreg, unități minime | `1201` = 12,01 MDL |\n| Monedă | numeric ISO 4217 | `498` = MDL |\n\nOra locală Chișinău este fusul orar `Europe/Chisinau`: UTC+2 iarna, UTC+3 vara. Dacă serverul rulează în UTC, convertiți ora înainte de a construi `ExpiryDate`, altfel comenzile expiră cu 2–3 ore mai devreme decât intenționat.\n\n## Rambursări\n\n`POST /api/order/refund`:\n\n```json\n{\n  "PaymentId": 328733,\n  "SaleAreaCode": "onlidocumentation_md",\n  "RefundType": "full",\n  "Amount": 400,\n  "Currency": 498,\n  "Reason": "Customer request"\n}\n```\n\n| Regulă | Valoare |\n|---|---|\n| Ce se poate rambursa | Doar o plată achitată (`status` = `4`). |\n| De câte ori | **O singură** rambursare per plată: integrală (`full`) sau parțială (`partial`). A doua rambursare a aceleiași plăți nu este posibilă. |\n| Suma | `Amount` în unități minime; maximum `PaidAmount` al plății (mai mic decât suma comenzii când s-a aplicat o promoție). Pentru rambursarea integrală trimiteți `RefundType` `full` și `Amount` = `PaidAmount` (`amount.paidAmount` din `GET /api/order/merchant/{Order}`). |\n| Termen | 180 de zile după plată. |\n| Metode de plată | Toate, cu excepția `CASH_INVOICE`. |\n| Rezultat | Imediat în răspunsul `POST /api/order/refund`: `200` = rambursarea este efectuată. Pentru rambursări nu se trimite notificare pe callback. |\n| Repetarea cererii | Nu este sigură: a doua rambursare returnează `400`. După un timeout sau o eroare de rețea verificați mai întâi statusul cu `GET /api/order/merchant/{Order}`: `5` sau `6` înseamnă că rambursarea a trecut. |\n| Statusul după | `5` după rambursarea integrală, `6` după cea parțială. Ambele sunt finale. |\n| Soldul comerciantului | Dacă în contul comerciantului din Paynet nu sunt bani, rambursarea nu trece. |\n\n### Răspunsuri la rambursare (verificat în mediul de test)\n\nExemplul de cerere de mai sus și răspunsul de mai jos sunt aceeași plată de test (plătit 4,00 MDL, rambursat integral).\n\n| Situație | Răspuns |\n|---|---|\n| Rambursare efectuată | `200`, corpul mai jos |\n| Plata nu este achitată | `404 NOT_FOUND_RECORD` |\n| Suma depășește suma plătită | `400 INVALID_PARAMETER`, `details`: „The invalid parameter is: RefundType”. Câmpul din `details` este indicat greșit: cauza este suma |\n| O nouă rambursare a aceleiași plăți (de exemplu, integrală după parțială) | `400 INVALID_PARAMETER`, `details`: „The invalid parameter is: RefundType” |\n\n```json\n{\n  "paymentId": 328733,\n  "saleAreaCode": "onlidocumentation_md",\n  "customer": "464566161",\n  "eventDate": "09.11.2026 18:17:54",\n  "refundType": "full",\n  "currency": 498,\n  "amount": 400,\n  "merchant": "265505",\n  "cardMask": "411111******1111",\n  "cardLinkHash": null,\n  "moneyType": "CYBER_SOURCE"\n}\n```\n\n- `eventDate` în răspunsul la rambursare are formatul `DD.MM.YYYY HH:mm:ss`.\n- `moneyType` aici este codul de procesare (de exemplu `CYBER_SOURCE`), nu valoarea din notificare (`CARD`…).\n- După rambursare `paidDate` al plății rămâne completat.\n\n## Contactarea suportului\n\n- **Dacă vă conectează un manager Paynet:** de obicei se creează un chat comun în Telegram cu un dezvoltator Paynet și dezvoltatorul dvs. Acolo primiți datele de acces și linkurile și puteți pune întrebări despre integrare. Rugați managerul să creeze un astfel de chat.\n- **Dacă încă nu ați discutat cu un manager:** scrieți la [support@paynet.md](mailto:support@paynet.md).\n\nPentru un răspuns rapid, trimiteți imediat:\n\n| Ce | Exemplu |\n|---|---|\n| `traceId` din răspunsul cu eroare | `9b9346f9-f83a-465d-ac8d-dc382c460c22` |\n| Metoda și adresa | `POST https://ecom-api-test.paynet.md/api/order` |\n| Data și ora cererii (ora Chișinăului) | `10.11.2026 12:05` |\n| `Order` și / sau `paymentId` | `1762444800000`, `328731` |\n| Zona de vânzare și comerciantul | `onlidocumentation_md`, `265505` |\n| Codul HTTP și corpul complet al răspunsului | `400`, `{ "errorInfo": … }` |\n| Test sau producție | test |\n\nNu trimiteți niciodată parola, cheile secrete sau tokenul.\n',"../../content/ro/common/04-ai-assistants.md":'# Integrare cu un asistent AI\n\nPuteți da această documentație oricărui asistent AI de programare (Claude, ChatGPT, Gemini, Copilot, Cursor și alții) și să-i cereți să scrie integrarea.\n\n## Fișiere pentru AI\n\n| Fișier | Ce conține | Când îl folosiți |\n|---|---|---|\n| [`llms-full.txt`](llms-full.txt) | Toată documentația într-un singur fișier text: toate produsele, ghidurile, referința API, semnăturile cu vectori de test, datele de test | Dați asistentului acest singur fișier. |\n| [`llms-ecom.txt`](llms-ecom.txt) | Doar E-commerce și subiectele generale de care are nevoie (notificări, semnături, erori) | Când integrați doar plățile e-commerce. |\n| [`llms.txt`](llms.txt) | Cuprins scurt cu linkuri către toate paginile | Pentru asistenții care navighează singuri prin linkuri. |\n| [`openapi.json`](openapi.json) | Specificația OpenAPI 3 a API-ului server-to-server | Pentru generatoare de cod și clienți tipizați. |\n| `docs/<page>.md`, `docs/ru/<page>.md`, `docs/ro/<page>.md` | Fiecare ghid ca fișier Markdown separat (engleză, rusă, română) | Când aveți nevoie de un singur subiect. |\n| `docs/api/<method>.md` | Fiecare metodă API ca fișier Markdown separat | Când lucrați cu o singură metodă. |\n\nFiecare pagină de ghid și de metodă API are un buton **Copiază pentru AI**. El copiază pagina în Markdown; meniul lui (săgeata de lângă) deschide pagina și ca Markdown sau în ChatGPT, Claude și Gemini cu o întrebare pregătită.\n\n> **Notă:** majoritatea asistenților nu pot citi portalul deschizând adresa lui, deoarece paginile sunt generate cu JavaScript. Dați-le `llms-full.txt` sau `llms-ecom.txt` (încărcați fișierul sau lipiți linkul). Fișierele pentru AI sunt în engleză, limba cu care modelele lucrează cel mai bine; vă pot răspunde în orice limbă.\n\n## Conectarea asistentului în editorul de cod\n\nAsistenții din editor lucrează cel mai bine când documentația se află în proiect sau este adăugată ca sursă:\n\n| Asistent | Cum adăugați documentația |\n|---|---|\n| Cursor | Chat → `@Docs` → *Add new doc* → lipiți linkul către `llms-full.txt`. Apoi menționați `@Docs` în cereri. |\n| VS Code (GitHub Copilot) | În chat folosiți `#fetch` cu linkul către `llms-ecom.txt` sau salvați fișierul în proiect și atașați-l. |\n| Claude Code | Salvați `llms-ecom.txt` în proiect (de exemplu `docs/paynet.md`) și adăugați în `CLAUDE.md`: *Integrare Paynet: urmează docs/paynet.md*. |\n| Codex | Salvați `llms-ecom.txt` în proiect și indicați-l la fel în `AGENTS.md`. |\n\nFișierul din proiect arată și la code review după ce versiune a documentației s-a făcut integrarea. Descărcați-l din nou când documentația se schimbă.\n\n## Șablon de cerere\n\nCopiați, completați parantezele și atașați `llms-ecom.txt`:\n\n```text\nYou are integrating Paynet e-commerce payments into my project.\nUse ONLY the attached Paynet documentation as the source of truth.\n\nMy stack: [e.g. Node.js 20 + Express / PHP 8.2 + Laravel / Python 3.12 + Django]\nIntegration type: [official Paynet SDK (PHP / Node.js) | server-to-server API | hosted checkout form]\nWhat to build:\n1. Create a payment for a cart and redirect the customer to Paynet.\n2. A notification endpoint that verifies the Hash header and marks the order paid exactly once.\n3. A status check by paymentId used before fulfilment.\n\nRequirements:\n- If my stack is PHP or Node.js, use the official Paynet SDK from the documentation\n  (section "SDK for PHP and Node.js") instead of writing your own HTTP client.\n- Read credentials and secret keys from environment variables.\n- One shop order = one unique Order number; ExpiryDate in the future, in Europe/Chisinau time.\n- Amounts are integers in minor units (100 = 1.00 MDL).\n- Implement signatures exactly as documented and add unit tests that reproduce\n  the test vectors from the "Signatures" section.\n- Do not invent endpoints, fields or status values that are not in the documentation.\n  If something is missing, list it as an open question instead of guessing.\n- Answer me in Romanian.\n```\n\n## Reguli pentru asistent\n\nAceste reguli sunt incluse și la începutul fișierelor pentru AI:\n\n1. API de test: `https://ecom-api-test.paynet.md`; API de producție: `https://ecom-api.paynet.md` (aceleași căi: `/auth`, `/api/...`). Formularul hosted checkout: `https://test.paynet.md/ecom/checkout` (test), `https://paynet.md/ecom/checkout` (producție).\n2. Autentificare cu `POST /auth` (JSON), apoi antetul `Authorization: Bearer <token>`.\n3. O comandă din magazin = un `Order`. Repetarea unui `Order` cu aceleași date returnează aceeași plată; cu date diferite sau după plată — eroare `500 TECHNICAL_ERROR`.\n4. `ExpiryDate` este `YYYY-MM-DDTHH:mm:ss` în ora locală Chișinău (`Europe/Chisinau`) și trebuie să fie în viitor.\n5. Sumele sunt numere întregi în unități minime; `Currency` este `498` pentru MDL.\n6. Semnături: `Base64(MD5(UTF8(șir + secretKey)))`, Base64 din digestul brut. Cheia pentru checkout și cea pentru notificări diferă.\n7. Notificările se trimit doar pentru plățile achitate (`EventType` = `PAID`). Cheile sunt `Payment.Id` și `Payment.ExternalId` (țin cont de majuscule). La o plată eșuată clientul este doar redirecționat la `LinkUrlCancel`.\n8. `PaidAmount` trebuie să fie egal cu `Amount`, cu excepția unei promoții convenite cu Paynet; altfel nu onorați comanda automat.\n9. Nu vă bazați pe revenirea la `LinkUrlSuccess`; confirmați cu o notificare verificată sau cu API-ul de status.\n10. Secretele nu ajung niciodată în codul browserului sau într-o aplicație mobilă.\n11. Dacă stack-ul este PHP sau Node.js, asistentul propune [SDK-ul oficial](#/guides/sdk) în locul propriului client HTTP.\n12. Căutarea plăților: `from`/`to` sunt în ora Chișinăului; o perioadă goală dă `404 NOT_FOUND_RECORD`.\n',"../../content/ro/common/05-faq.md":"# Întrebări frecvente\n\n## Cheile de test și de producție sunt aceleași?\n\nNu. Accesele de producție și ambele chei secrete (pentru formularul checkout și pentru notificări) diferă de cele de test. La trecerea în producție înlocuiți toate valorile — vezi [Lista de verificare pentru lansare](#/guides/go-live).\n\n## Cum obțin accesele de producție?\n\nSunt trimise pe emailul administratorului companiei dvs. Durează de la 5 minute la câteva zile, în funcție de funcțiile conectate.\n\n## Clientul a revenit pe pagina de succes, dar notificarea nu a venit. Comanda e plătită?\n\nNu considerați comanda plătită doar pentru că clientul a revenit la `LinkUrlSuccess`. Așteptați o notificare `PAID` verificată sau verificați statusul: `GET /api/order/merchant/{Order}`, `status` = `4` înseamnă achitată. Vezi [Statusul plății](#/guides/errors-and-statuses).\n\n## Aceeași notificare a venit de mai multe ori\n\nEste normal: dacă serverul dvs. nu a răspuns `200`, Paynet trimite notificarea din nou. Procesați fiecare `Payment.Id` o singură dată. Vezi [Notificări](#/guides/notifications).\n\n## Notificarea nu a mai venit\n\nVerificați statusul cu `GET /api/order/merchant/{Order}`. Retrimiterea notificării o puteți cere la suportul Paynet.\n\n## Banca a refuzat plata. Se poate plăti aceeași comandă din nou?\n\nNu: după refuz comanda primește statusul `5` și se închide. Creați o comandă nouă cu un `Order` nou. Dacă clientul doar a închis pagina fără să plătească, comanda rămâne `1` și poate fi plătită cu același `paymentLink`.\n\n## Un `POST /api/order` repetat cu același `Order` a returnat `500`\n\nCu același `Order` și aceleași date Paynet returnează aceeași plată. `500 TECHNICAL_ERROR` înseamnă că datele diferă sau comanda este deja plătită ori plata ei este în procesare. Vezi [Număr de comandă repetat](#/guides/errors-and-statuses).\n\n## De ce `PaidAmount` este mai mic decât `Amount`?\n\nDe obicei sunt egale. `PaidAmount` este mai mic doar la o promoție convenită oficial cu Paynet (de exemplu, reducere pentru cardurile unei anumite bănci). Primiți `PaidAmount` minus comisionul Paynet.\n\n## Pot face a doua rambursare pentru aceeași plată?\n\nNu. Pentru o plată este posibilă o singură rambursare: integrală sau parțială.\n\n## De ce nu trece rambursarea?\n\nVerificați: nu au trecut mai mult de 180 de zile de la plată; metoda de plată nu este `CASH_INVOICE`; plata nu a fost încă rambursată; suma nu depășește `PaidAmount`; în contul comerciantului din Paynet sunt bani. Vezi [Rambursări](#/guides/errors-and-statuses).\n\n## De ce comanda expiră mai devreme decât am planificat?\n\n`ExpiryDate` este în ora locală a Chișinăului (`Europe/Chisinau`). Dacă serverul dvs. lucrează în UTC, convertiți ora, altfel comanda expiră cu 2–3 ore mai devreme.\n\n## Semnătura nu se potrivește\n\nVerificați: șirul este codificat UTF-8; se folosește cheia corectă (formularul checkout și notificările au chei diferite); valorile sunt luate exact cum apar în JSON. Comparați codul cu [vectorii de test](#/guides/signatures).\n\n## Trebuie activat CORS pentru notificări?\n\nNu. CORS este necesar doar simulatorului de notificări de pe acest portal, deoarece trimite cererea din browser. Notificările reale sunt trimise de serverul Paynet.\n\n## De ce `CardLinkHash` este `null` în notificare?\n\nSalvarea cardurilor nu este activată pentru `SaleAreaCode` dvs., comanda nu a avut `Customer` sau clientul a debifat „salvează cardul”. Vezi [Salvarea cardurilor](#/guides/saved-cards).\n","../../content/ro/common/06-changelog.md":"# Jurnalul modificărilor\n\n## Documentația v3.5.1 — 17.11.2026\n\n- **Construirea portalului** (API-ul și textele documentației nu s-au schimbat): `npm run build:prod` construiește acum întregul portal pentru https://docs.paynet.md/api/ cu toate verificările, în Windows, macOS și Linux (Node.js 22.12+). Bibliotecile cu vulnerabilități cunoscute au fost eliminate sau actualizate (Vite 8, js-yaml 4.3). Calculatoarele de semnătură din portal calculează MD5 fără o bibliotecă terță; rezultatul este același (verificat pe vectorii de test publicați).\n\n## Documentația v3.5 — 11.11.2026\n\n- **Exemplu de magazin: pornire pas cu pas pentru Windows, macOS și Linux** (găsit la rularea exemplului „ca un începător”): verificarea Node.js, `tar -xf` în loc de `unzip` (funcționează în Windows 10/11), de ce comanda rămâne `pending` și cum se trimite notificarea de test, tabel de depanare. Pagina comenzilor și pagina de revenire din magazin afișează acum comanda gata de folosit pentru trimiterea notificării. Vezi [Exemplu de magazin](#/guides/example-shop).\n\n## Documentația v3.4 — 11.11.2026\n\n- **Caractere speciale în semnătura hosted checkout** (verificat prin trimiteri reale ale formularului în mediul de test): funcții de codificare corecte și greșite pentru PHP, JavaScript, Python, C#, Java; rândul nou strică semnătura; tagurile și entitățile HTML fac ca Paynet să respingă formularul înainte de verificarea semnăturii. Vector de test 3 nou cu `' & ! ( ) *`, litere chirilice și românești. Vezi [Semnături](#/guides/signatures).\n- Linkul „Previous portal version” deschide documentația anterioară https://docs.paynet.md/psp/.\n- Împreună cu portalul se publică `robots.txt` și `sitemap.xml`.\n\n## Documentația v3.3 — 10.11.2026\n\nClarificări în urma unui test în care un dezvoltator nou în Paynet a făcut integrarea folosind doar această documentație.\n\n- **Produse:** dacă trimiteți `Products`, sunt obligatorii `LineNo`, `Name`, `UnitPrice`, `Quantity`, `Amount`, `TotalAmount`; `Code` și `Description` sunt opționale (verificat în mediul de test). Vezi [Server-to-server](#/guides/server-to-server).\n- **Linkul de plată:** păstrați `paymentLink` din răspunsul la crearea comenzii — în răspunsurile de status este scurtat.\n- **Rambursări:** rambursare integrală = `Amount` egal cu `PaidAmount`; `200` = efectuată; nu repetați rambursarea fără a verifica statusul. Exemplele de cerere și răspuns arată acum aceeași plată. Vezi [Erori și statusuri](#/guides/errors-and-statuses).\n- Datele căutării plăților în tabelul de formate: ora Chișinău, fără `Z`.\n- Notificări: contează doar codul HTTP `200`, corpul răspunsului nu contează.\n- Getting started: unde se folosește codul comerciantului.\n- `Customer.PhoneNumber`: opțional, dar fără el clientul introduce telefonul pe pagina de plată. Exemplele îl trimit acum.\n- **Statusuri:** `6` — achitat, apoi rambursat parțial; `5` — neachitat (refuz bancar, antifraudă) sau rambursat integral.\n- **Notificări:** prima notificare se trimite după ce banca emitentă confirmă plata (timpul depinde de bancă); intervalele reîncercărilor nu s-au schimbat.\n- **Exemplul de notificări din SDK:** notificarea se salvează înainte de răspunsul `200`, comanda se onorează din înregistrarea salvată.\n- `linkUrlSuccess` / `linkUrlCancel` în răspunsurile despre plată pot fi `null` (referința API, tipurile Node.js SDK).\n- `Lang`: majusculele nu contează; la o valoare necunoscută pagina se deschide în engleză (verificat în mediul de test).\n- Exemplul de magazin se descarcă acum ca arhivă de pe acest portal.\n\n## Documentația v3.2 — 10.11.2026\n\n- **SDK-uri oficiale pentru PHP și Node.js** (versiunea 1.0.0, licență MIT): autorizare, comenzi, statusuri, rambursări cu verificarea regulilor, carduri salvate, extrase, notificări, formularul hosted checkout, erori. Verificate în mediul de test. Vezi [SDK](#/guides/sdk).\n- **Aplicații mobile**: cum acceptă o aplicație plăți prin serverul dvs. și pagina Paynet. Vezi [Aplicații mobile](#/guides/mobile-apps).\n- **Căutarea plăților:** `from`/`to` sunt în ora Chișinăului; o perioadă goală dă `404 NOT_FOUND_RECORD`. Colecția Postman a fost corectată.\n- `Quantity` produsului este în sutimi (`100` = 1 buc.).\n\n## Documentația v3.1 — 10.11.2026\n\n- **Colecție Postman nouă** cu mediile TEST și PRODUCTION: tokenul se obține automat, fiecare comandă este unică, datele se transmit între cereri. Verificată printr-o rulare în mediul de test. Vezi [Testare → Postman](#/guides/testing).\n- **Fișă rapidă pentru erori** cu coloana „repetați cererea?”; au fost adăugate `405`, `415` și `404` cu corp gol (verificat în mediul de test). Vezi [Erori și statusuri](#/guides/errors-and-statuses).\n- **Programul reîncercărilor notificărilor:** 9 încercări în circa 25 de minute. **Adresele IP** Paynet pentru firewall. Vezi [Notificări](#/guides/notifications).\n- 3-D Secure și motivul refuzului în secțiunea de statusuri; secțiunea „Contactarea suportului”.\n- Meniu lateral cu pictograme; tabelele de parametri se citesc pe telefon.\n\n## Documentația v3 — 09.11.2026\n\n- **Exemplu de magazin în Node.js** — o integrare completă fără dependențe. Verificat de un test end-to-end în mediul de test: cumpărare, plată, notificare, rambursare. Vezi [Exemplu de magazin](#/guides/example-shop).\n- **Răspunsuri simulate pentru testele de eșec**: statusurile `3`, `5`, `6`, erori de rambursare, `401`, `errorInfo`, notificări semnate. Vezi [Testare](#/guides/testing).\n- **Specificația API verificată cu răspunsuri reale** ale mediului de test: `/auth` cu parolă greșită returnează `401` (nu `500`); sunt descrise formatul `401` pentru token și formatul `errorInfo`; a fost adăugat `amount.paidAmount`; au fost adăugate schemele răspunsurilor pentru rambursare, căutare și extras.\n- **Salvarea cardurilor verificată în mediul de test:** același client vede cardul, alt client nu. Vezi [Salvarea cardurilor](#/guides/saved-cards).\n- **Handlere complete de notificări** în Node.js și PHP; logica Node.js este testată la fiecare build.\n\n## Documentația v2 — 09.11.2026\n\n- Portal pentru mai multe produse: pagina principală, căutare pe tot site-ul, secțiunile „General” și „E-commerce”.\n- Reguli API confirmate de Paynet: statusurile plății, plăți eșuate, rambursări, reîncercări ale notificărilor, salvarea cardurilor, accese de producție.\n- Ce protejează semnătura notificării și cum confirmați câmpurile nesemnate prin API.\n- Întrebări frecvente, meniul „Copiază pentru AI”, fișiere pentru AI în trei limbi.\n- Descrierea protocolului învechit din documentația veche a fost eliminată.\n- Această versiune este păstrată în ramura `documentation-v2` a depozitului.\n\n## Documentația v1\n\nPortalul original. Disponibil prin linkul „Versiunea anterioară a portalului” din josul paginii.\n","../../content/ro/ecom/01-integration-options.md":`# E-commerce: opțiuni de integrare

Paynet e-commerce permite magazinului online să accepte plăți cu cardul (inclusiv Apple Pay și Google Pay), portofelul Paynet, plăți instant MIA și factură cu plată în numerar. Există trei moduri de integrare. Toate se termină pe aceeași pagină de plată Paynet, deci nu colectați niciodată singuri datele cardurilor.

| | API server-to-server | Hosted checkout (client-server) | Pluginuri gata făcute |
|---|---|---|---|
| Cum ajunge comanda la Paynet | **backend-ul** dvs. apelează \`POST /api/order\` cu token Bearer | **browserul** clientului trimite la Paynet un formular HTML semnat | pluginul o face pentru dvs. |
| Ce protejează cererea | token de acces (\`/auth\`) | \`Signature\` = MD5 + Base64 cu cheia dvs. secretă | setările pluginului |
| Ce primiți | \`paymentId\` + \`paymentLink\` în JSON | clientul ajunge direct pe pagina de plată | — |
| Statusuri, rambursări, extrase | da, același API | da, prin API-ul server-to-server (comenzile se găsesc după \`Order\`-ul dvs.) | depinde de plugin |
| Potrivit pentru | magazine și aplicații proprii cu backend | site-uri simple, start rapid fără client API | WordPress/WooCommerce, OpenCart, PrestaShop, Magento, CS-Cart, Shopify |

## Cum alegeți

- **Aveți backend și doriți control deplin** → [Server-to-server](#/guides/server-to-server). Cea mai flexibilă opțiune, primiți \`paymentId\` imediat.
- **Aveți nevoie doar de un buton „Plătește” fără apel API pentru crearea comenzii** → [Hosted checkout](#/guides/hosted-checkout). Backend-ul este totuși necesar pentru calculul semnăturii: cheia secretă nu trebuie să ajungă în codul browserului.
- **Vreți mai puțin cod** → [SDK-uri pentru PHP și Node.js](#/guides/sdk) gata făcute: autorizarea, regulile de rambursare, semnăturile și erorile sunt deja implementate.
- **Aveți o aplicație mobilă** → plățile trec prin serverul dvs. și pagina Paynet, vedeți [Aplicații mobile](#/guides/mobile-apps).
- **Magazinul rulează pe un CMS suportat** → descărcați un plugin din [**Pluginuri**](#/page/plugins). Shopify se conectează prin Cybersource.

## Ce necesită orice integrare

1. **Un URL de callback** pentru [notificări](#/guides/notifications). Paynet îl apelează când plata este achitată (se notifică doar plățile reușite). Comunicați acest URL către Paynet.
2. **Verificarea semnăturii** fiecărei notificări, vezi [Semnături](#/guides/signatures).
3. **Verificarea statusului** înainte de livrare: \`GET /api/order/{paymentId}\` sau \`GET /api/order/merchant/{order}\`.
4. **Numere de comandă unice** (\`Order\`) pe partea dvs.: o comandă din magazin = un \`Order\`.
5. **Două chei secrete** de la Paynet: una pentru semnătura hosted checkout, alta pentru notificări.

## Fluxul general

\`\`\`text
Client          Magazinul dvs. (backend)            Paynet
   |  checkout   |                                     |
   |-----------> | 1. creare comandă (API sau formular)|
   |             |------------------------------------>|
   | 2. redirecționare la pagina de plată              |
   |-------------------------------------------------->|
   |              3. clientul plătește pe pagina Paynet |
   |<--------------------------------------------------|
   | 4. revenire la LinkUrlSuccess / LinkUrlCancel      |
   |             | 5. notificare (POST, antet Hash)    |
   |             |<------------------------------------|
   |             | 6. verificare Hash și status, livrare|
\`\`\`

Revenirea clientului la \`LinkUrlSuccess\` este doar un pas de interfață. **Nu marcați comanda ca plătită doar pentru că clientul a revenit pe pagina de succes.** Bazați-vă pe notificare și/sau pe API-ul de status.

Dacă plata eșuează, clientul este redirecționat la \`LinkUrlCancel\`. Paynet nu trimite notificări pentru plățile eșuate.
`,"../../content/ro/ecom/02-getting-started.md":'# Primii pași\n\nAceastă pagină vă duce de la zero la o plată de test reușită în aproximativ 10 minute, folosind contul de test comun și panourile „Test API Request” ale portalului. Clientul plătește pe pagina de plată Paynet, deci nu lucrați cu datele cardurilor.\n\n## Medii\n\n| Element | Test | Producție |\n|---|---|---|\n| URL de bază API | `https://ecom-api-test.paynet.md` | `https://ecom-api.paynet.md` |\n| URL-ul formularului hosted checkout | `https://test.paynet.md/ecom/checkout` | `https://paynet.md/ecom/checkout` |\n\nAmbele medii folosesc aceleași căi (`/auth`, `/api/...`).\n\n## Date de acces\n\n| Element | Test (comun) | Producție |\n|---|---|---|\n| Utilizator API (`username` / `password`) | `771064` / `sLgMnGWJ` | emis companiei dvs. de Paynet |\n| Codul comerciantului (`Merchant`) | `265505` — nu se trimite în `POST /api/order`; se folosește în formularul Hosted Checkout și la verificarea notificărilor (`Payment.Merchant`) | emis de Paynet |\n| Codul zonei de vânzare (`SaleAreaCode`) | `onlidocumentation_md` | emis de Paynet (unul per site/magazin) |\n| Cheia secretă pentru semnătura hosted checkout | `F90D6485-9CCC-458B-96A3-8958AF9B4458` | emisă de Paynet, păstrați-o secretă |\n| Cheia secretă pentru notificări | `D9873689-E5F8-4272-A67F-0D8BA3F9BAA7` | emisă de Paynet, păstrați-o secretă |\n| Card de test | Visa `4111 1111 1111 1111`, expirare `12/27`, CVV `777` | carduri reale |\n\nPaynet vă emite **două chei secrete diferite**: una semnează formularul hosted checkout, cealaltă — notificările. Nu le confundați.\n\n> **Notă:** datele de test de mai sus sunt publice intenționat și comune pentru toți cei care testează pe portal. Nu le folosiți niciodată în producție și nu puneți niciodată secretele de producție în codul front-end.\n\n## Prima plată de test (server-to-server)\n\n### Pasul 1. Obțineți tokenul de acces\n\nÎn meniul lateral deschideți **E-commerce → Metode API → Autentificare și autorizare** și apăsați **Test API Request**. Nu modificați utilizatorul și parola.\n\n```http\nPOST https://ecom-api-test.paynet.md/auth\nContent-Type: application/json\n\n{ "grantType": "password", "username": "771064", "password": "sLgMnGWJ" }\n```\n\nRezultat așteptat: HTTP `200` cu `access_token` (valabil aproximativ 4 ore, vezi `expires_in`). Portalul reține tokenul și îl adaugă la următoarele cereri ca `Authorization: Bearer <token>`.\n\n### Pasul 2. Creați comanda\n\nDeschideți **E-commerce → Metode API → Creați o plată** și apăsați **Test API Request**.\n\nPortalul completează automat un număr `Order` unic și `ExpiryDate` pentru mâine, deci exemplul funcționează fără modificări. Dacă editați cererea manual, rețineți:\n\n- o comandă = un număr `Order` nou;\n- `ExpiryDate` trebuie să fie în viitor, format `YYYY-MM-DDTHH:mm:ss`, ora locală Chișinău;\n- sumele sunt numere întregi în unități minime: `300` = 3,00 MDL.\n\nRezultat așteptat: HTTP `200` cu `paymentId`, `status` `1` și un `paymentLink` de forma `https://test.paynet.md/ecom/getecom/317184?s=…`.\n\n### Pasul 3. Plătiți pe pagina de plată\n\nDeschideți `paymentLink` în browser și plătiți cu cardul de test `4111 1111 1111 1111`, `12/27`, CVV `777`. După plată reveniți la `LinkUrlSuccess`.\n\n### Pasul 4. Verificați statusul plății\n\nDeschideți **E-commerce → Metode API → Obține informații despre plată după numărul comenzii comerciantului**, introduceți numărul `Order` și executați cererea. Veți vedea detaliile plății; la o plată achitată `paidDate` este completat.\n\n### Pasul 5. Testați notificarea (webhook)\n\nDeschideți **General → Notificări → Simulator notificări**. Introduceți URL-ul dvs. de callback, cheia secretă pentru notificări și numărul `Order`, apoi apăsați **Get** și **Send notification**. Portalul trimite la URL-ul dvs. o notificare `PAID` simulată și semnată, ca să vă testați handler-ul. Detalii: [Notificări](#/guides/notifications).\n\n## Pașii următori\n\n- Alegeți modul de integrare: [Opțiuni de integrare](#/guides/integration-options).\n- Citiți fluxul complet: [Server-to-server](#/guides/server-to-server) sau [Hosted checkout](#/guides/hosted-checkout).\n- Scrieți integrarea cu ajutorul AI? Începeți cu [Integrare cu un asistent AI](#/guides/ai-assistants).\n',"../../content/ro/ecom/03-server-to-server.md":'# Integrare server-to-server\n\nÎn acest model backend-ul dvs. comunică direct cu API-ul Paynet. Este opțiunea recomandată pentru magazinele cu backend propriu.\n\n## Prezentare generală\n\n1. `POST /auth` → obțineți tokenul de acces.\n2. `POST /api/order` → înregistrați comanda, primiți `paymentId` și `paymentLink`.\n3. Redirecționați clientul la `paymentLink`.\n4. Primiți [notificarea](#/guides/notifications) la URL-ul de callback și verificați `Hash`.\n5. Confirmați cu `GET /api/order/{paymentId}` și onorați comanda.\n\nURL de bază: `https://ecom-api-test.paynet.md` (test), `https://ecom-api.paynet.md` (producție). Toate corpurile cererilor sunt JSON (`Content-Type: application/json`).\n\n## 1. Autentificare\n\n```http\nPOST /auth\nContent-Type: application/json\n\n{ "grantType": "password", "username": "771064", "password": "sLgMnGWJ" }\n```\n\n```json\n{ "access_token": "Ccxl7QQiMEoakkrUoiUn8PIg…", "token_type": "bearer", "expires_in": 14399 }\n```\n\nTrimiteți tokenul în toate celelalte cereri: `Authorization: Bearer <access_token>`. `expires_in` este în secunde (aproximativ 4 ore). Păstrați tokenul în cache și cereți unul nou când expiră sau când API-ul returnează `401`.\n\nDatele de autentificare greșite returnează o eroare cu `code` `AUTHENTICATION_FAILED`.\n\n## 2. Crearea comenzii\n\n```http\nPOST /api/order\nAuthorization: Bearer <access_token>\nContent-Type: application/json\n```\n\n```json\n{\n  "Order": 1762444800000,\n  "SaleAreaCode": "onlidocumentation_md",\n  "LinkUrlSuccess": "https://shop.example/payment/success",\n  "LinkUrlCancel": "https://shop.example/payment/cancel",\n  "Customer": {\n    "Code": "464566161",\n    "NameFirst": "First Name",\n    "NameLast": "Last Name",\n    "email": "customer@example.com",\n    "PhoneNumber": "37360000000"\n  },\n  "Currency": 498,\n  "ExpiryDate": "2026-12-31T23:59:59",\n  "Services": [\n    {\n      "Name": "Demo eShop",\n      "Description": "Order #1762444800000",\n      "Amount": 300,\n      "Products": [\n        {\n          "LineNo": 1,\n          "Code": "SKU-1",\n          "Name": "Demo product",\n          "Description": "Demo product",\n          "UnitPrice": 100,\n          "Quantity": 300,\n          "Amount": 300,\n          "TotalAmount": 300\n        }\n      ]\n    }\n  ],\n  "MoneyType": "All",\n  "Lang": "EN"\n}\n```\n\n### Câmpurile cererii\n\n| Câmp | Tip | Obligatoriu | Descriere |\n|---|---|---|---|\n| `Order` | integer (int64) | da | Numărul comenzii la dvs. O comandă din magazin = un `Order` (vezi [număr de comandă repetat](#/guides/errors-and-statuses)). |\n| `SaleAreaCode` | string | da | Codul zonei de vânzare (site-ului) emis de Paynet. |\n| `LinkUrlSuccess` | string | da | Unde revine clientul după plata reușită. |\n| `LinkUrlCancel` | string | da | Unde revine clientul după anulare. |\n| `Currency` | integer | da | Cod numeric ISO 4217. `498` = MDL. |\n| `ExpiryDate` | string | da | Termenul de plată, `YYYY-MM-DDTHH:mm:ss`, ora locală Chișinău (`Europe/Chisinau`), în viitor. |\n| `Services` | array | da | Cel puțin un serviciu, vezi mai jos. |\n| `MoneyType` | string | da | `All`, `Card`, `Paynet`, `MIA` sau `CashInvoice` (vezi mai jos). |\n| `Lang` | string | da | Limba paginii de plată: `RO`, `RU` sau `EN`. Majusculele nu contează (`EN` = `en`). Verificat în mediul de test: la o valoare necunoscută pagina se deschide în engleză. |\n| `Customer` | object | nu | Datele clientului. Obligatoriu pentru a [salva cardul](#/guides/saved-cards) sau a plăti cu un card salvat. |\n| `Customer.Code` | string | da, dacă se trimite `Customer` | ID-ul clientului în sistemul dvs. |\n| `Customer.NameFirst`, `NameLast`, `email`, `PhoneNumber` | string | nu | Datele clientului. Atenție: `email` cu literă mică. Dacă nu trimiteți `PhoneNumber`, clientul trebuie să introducă telefonul pe pagina de plată (blocul „Billing information”). Trimiteți datele clientului dacă le aveți, ca acesta să nu le introducă singur. |\n| `CardLinkHash` | string | nu | Tokenul cardului salvat al acestui client, primit într-o notificare. Trimiteți-l împreună cu același `Customer`. Vezi [Salvarea cardurilor](#/guides/saved-cards). |\n\n`Services[]`:\n\n| Câmp | Tip | Obligatoriu | Descriere |\n|---|---|---|---|\n| `Name` | string | da | Denumirea serviciului. |\n| `Description` | string | da | Descrierea serviciului. |\n| `Amount` | integer | da | Suma serviciului în unități minime. |\n| `Products` | array | nu | Opțional. Dacă trimiteți produse, la fiecare produs sunt obligatorii șase câmpuri (vezi mai jos). |\n\n`Services[].Products[]` — obligatorii: `LineNo` (int), `Name` (string), `UnitPrice` (int), `Quantity` (int), `Amount` (int), `TotalAmount` (int). Opționale: `Code` (string), `Description` (string). Verificat în mediul de test: fără oricare dintre cele șase câmpuri obligatorii API-ul răspunde `400`.\n\n**`Quantity` este în sutimi:** `100` = 1 buc., `300` = 3 buc. În exemplul de mai sus `"Quantity": 300` înseamnă 3 buc. la `UnitPrice` 1,00 MDL.\n\n**Sumele** sunt numere întregi în unități minime (bani): `1201` = 12,01 MDL.\n\n**MoneyType** stabilește ce metode de plată vede clientul:\n\n| `MoneyType` | Clientul vede |\n|---|---|\n| `All` | toate metodele activate pentru comerciant |\n| `Card` | card (Visa/Mastercard), Apple Pay, Google Pay |\n| `Paynet` | portofel Paynet |\n| `MIA` | plăți instant MIA |\n| `CashInvoice` | factură cu plată în numerar |\n\nNu există o valoare separată pentru Apple Pay și Google Pay: apar atât cu `Card`, cât și cu `All`. Cum a plătit clientul efectiv vă spune notificarea (`CARD`, `APPLEPAY`, `GOOGLEPAY`, `MIA_QR`, `PAYNET`, `CASH_INVOICE`).\n\n### Răspuns\n\n```json\n{\n  "paymentId": 328731,\n  "paymentLink": "https://test.paynet.md/ecom/getecom/328731?s=8fa1bd0923368d3bb700fccacc263735",\n  "cardLinkHash": null,\n  "status": 1,\n  "order": 1762444800000,\n  "merchantCode": "265505",\n  "saleAreaCode": "onlidocumentation_md",\n  "amount": { "requestAmount": 300, "requestCurrency": 498, "amount": 300, "paidAmount": null },\n  "expiryDate": "2026-12-31 23:59:59",\n  "registered": "2026-11-09 18:16:41",\n  "paidDate": null,\n  "moneyType": "All"\n}\n```\n\n(Răspuns din mediul de test, prescurtat. După plată `status` = `4`, iar `paidDate` și `amount.paidAmount` sunt completate. Răspunsul complet conține și `customer`, `payer`, `services`, `cardLinkHash`, `signature`, `linkUrlSuccess`, `linkUrlCancel`.)\n\nSalvați `paymentId` împreună cu comanda: este cheia pentru verificarea statusului, rambursări și notificări.\n\n**Repetarea cererii.** Dacă trimiteți din nou același `Order` cu aceleași date (cât timp nu este plătit), primiți același `paymentId` și `paymentLink` — repetarea după un timeout este sigură. Același `Order` cu date diferite sau după plată dă `500 TECHNICAL_ERROR`. Dacă s-a schimbat coșul, folosiți un `Order` nou.\n\n„Aceleași date” înseamnă literal aceeași cerere. Salvați corpul cererii împreună cu comanda și retrimiteți-l neschimbat: de exemplu, un `ExpiryDate` recalculat înseamnă deja date diferite.\n\n## 3. Redirecționați clientul\n\nTrimiteți browserul clientului la `paymentLink` (HTTP 302 sau link/buton). Salvați acest link împreună cu comanda: linkul complet există doar în răspunsul la `POST /api/order`; în răspunsurile `GET /api/order/…` este scurtat, fără numărul plății. După plata reușită clientul revine la `LinkUrlSuccess`; dacă plata eșuează sau este anulată — la `LinkUrlCancel`.\n\n## 4. Procesați notificarea\n\nCând plata este achitată, Paynet trimite un `POST` semnat la URL-ul dvs. de callback (`EventType` = `PAID`; plățile eșuate nu se notifică). Verificați antetul `Hash`, comparați `PaidAmount` cu `Amount` și răspundeți HTTP `200`. Vezi [Notificări](#/guides/notifications).\n\n## 5. Verificați statusul\n\n```http\nGET /api/order/{paymentId}\nGET /api/order/merchant/{Order}\nAuthorization: Bearer <access_token>\n```\n\nAmbele returnează același obiect de plată. Folosiți-le înainte de livrare și dacă notificarea nu a sosit. Vezi [Erori și statusuri](#/guides/errors-and-statuses).\n\n## Alte operațiuni\n\n| Operațiune | Cerere | Note |\n|---|---|---|\n| Căutare plăți | `GET /api/order/search?from=…&to=…` | Dată-oră **în ora Chișinăului**, fără `Z`, de ex. `2026-03-09T08:40:05`. API-ul ignoră marcajul UTC (`Z`): ora UTC deplasează perioada cu 2–3 ore, iar plățile recente nu apar în rezultat. Dacă în perioadă nu există plăți, API-ul răspunde `404 NOT_FOUND_RECORD` — un rezultat gol, nu o eroare. |\n| Rambursare | `POST /api/order/refund` | Corp: `PaymentId`, `SaleAreaCode`, `RefundType` (`full` sau `partial`), `Amount`, `Currency`, `Reason`. |\n| Deconectarea unui card salvat | `POST /api/linked-cards/unlink` | Corp: `CardLinkHash`, `SaleAreaCode`, `CustomerCode`. |\n| Extras | `GET /api/statement?dateStart=…&dateFinish=…` | Date de forma `2026-03-01`. `accountId` opțional. |\n| Extras (Excel) | `GET /api/statement/download?dateStart=…&dateFinish=…` | Returnează un fișier `.xlsx`. Perioadă de cel mult 31 de zile. |\n\n## Exemplu: Node.js (18+)\n\n```javascript\nconst BASE_URL = \'https://ecom-api-test.paynet.md\';\n\nasync function getToken() {\n  const res = await fetch(`${BASE_URL}/auth`, {\n    method: \'POST\',\n    headers: { \'Content-Type\': \'application/json\' },\n    body: JSON.stringify({ grantType: \'password\', username: process.env.PAYNET_USER, password: process.env.PAYNET_PASSWORD }),\n  });\n  if (!res.ok) throw new Error(`Auth failed: ${res.status} ${await res.text()}`);\n  return (await res.json()).access_token;\n}\n\nasync function createOrder(token, order) {\n  const res = await fetch(`${BASE_URL}/api/order`, {\n    method: \'POST\',\n    headers: { \'Content-Type\': \'application/json\', Authorization: `Bearer ${token}` },\n    body: JSON.stringify(order),\n  });\n  const body = await res.json();\n  if (!res.ok) throw new Error(`Create order failed: ${res.status} ${JSON.stringify(body)}`);\n  return body; // { paymentId, paymentLink, status, ... }\n}\n```\n\n## Exemplu: PHP\n\n```php\n<?php\n$baseUrl = \'https://ecom-api-test.paynet.md\';\n\nfunction paynetRequest(string $method, string $url, ?array $body = null, ?string $token = null): array {\n    $headers = [\'Content-Type: application/json\', \'Accept: application/json\'];\n    if ($token) { $headers[] = \'Authorization: Bearer \' . $token; }\n    $ch = curl_init($url);\n    curl_setopt_array($ch, [\n        CURLOPT_CUSTOMREQUEST  => $method,\n        CURLOPT_RETURNTRANSFER => true,\n        CURLOPT_HTTPHEADER     => $headers,\n    ]);\n    if ($body !== null) { curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body)); }\n    $raw = curl_exec($ch);\n    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);\n    curl_close($ch);\n    $data = json_decode($raw, true);\n    if ($status !== 200) { throw new RuntimeException("Paynet error $status: $raw"); }\n    return $data;\n}\n\n$auth  = paynetRequest(\'POST\', "$baseUrl/auth", [\'grantType\' => \'password\', \'username\' => getenv(\'PAYNET_USER\'), \'password\' => getenv(\'PAYNET_PASSWORD\')]);\n$token = $auth[\'access_token\'];\n// $payment = paynetRequest(\'POST\', "$baseUrl/api/order", $order, $token);\n// header(\'Location: \' . $payment[\'paymentLink\']);\n```\n',"../../content/ro/ecom/04-saved-cards.md":`# Salvarea cardurilor

Clientul își poate salva cardul la prima plată, iar data viitoare îl poate alege pe pagina Paynet fără să introducă din nou numărul cardului.

Funcționează doar la [integrarea server-to-server](#/guides/server-to-server). În formularul hosted checkout salvarea cardurilor nu este disponibilă.

> **Important:** aceasta nu este o debitare fără participarea clientului. Clientul trece întotdeauna prin pagina Paynet și confirmă plata. Paynet poate cere CVC sau 3-D Secure — depinde de setările magazinului dvs. pe partea Paynet.

## Activare

Salvarea cardurilor se activează pentru \`SaleAreaCode\` dvs. pe partea Paynet: contactați managerul dvs. Paynet. Pentru zona de vânzare de test comună \`onlidocumentation_md\` ea este activată: puteți încerca scenariul cu accesele de test.

## Ce este \`CardLinkHash\`

- Identificatorul intern Paynet al unui card salvat. Nu este numărul cardului și nici un token de rețea Visa/Mastercard.
- Este legat de \`SaleAreaCode\` (care aparține unui singur comerciant) și de \`Customer.Code\` al clientului.
- Nu funcționează în altă zonă de vânzare, chiar a aceluiași comerciant — cu excepția cazului în care Paynet a grupat acele zone pe partea sa.

## Cum funcționează

| Pas | Cine | Ce se întâmplă |
|---|---|---|
| 1 | Dvs. | Creați comanda cu \`POST /api/order\` și trimiteți obiectul \`Customer\`. Fără \`Customer\` cardul nu se salvează. |
| 2 | Clientul | Plătește cu cardul pe pagina Paynet. Bifa „salvează cardul” este activă implicit; clientul o poate debifa. |
| 3 | Paynet | Trimite notificarea \`PAID\` cu \`Payment.CardLinkHash\`. Dacă clientul a debifat, valoarea este \`null\`. |
| 4 | Dvs. | Salvați \`CardLinkHash\` împreună cu acest client (\`Customer.Code\`). |
| 5 | Dvs. | La următoarea plată trimiteți în \`POST /api/order\` câmpul \`CardLinkHash\` și aceleași date \`Customer\`. |
| 6 | Clientul | Vede cardul salvat pe pagina Paynet și confirmă plata. |

## Prima plată

O cerere obișnuită de [creare a comenzii](#/guides/server-to-server) cu obiectul \`Customer\`:

\`\`\`json
{
  "Order": 1762444800000,
  "SaleAreaCode": "onlidocumentation_md",
  "LinkUrlSuccess": "https://shop.example/payment/success",
  "LinkUrlCancel": "https://shop.example/payment/cancel",
  "Customer": {
    "Code": "464566161",
    "NameFirst": "First Name",
    "NameLast": "Last Name",
    "email": "customer@example.com",
    "PhoneNumber": "37360000000"
  },
  "Currency": 498,
  "ExpiryDate": "2026-12-31T23:59:59",
  "Services": [
    { "Name": "Demo eShop", "Description": "Order #1762444800000", "Amount": 300 }
  ],
  "MoneyType": "Card",
  "Lang": "RO"
}
\`\`\`

După plată notificarea \`PAID\` conține tokenul:

\`\`\`json
{
  "Payment": {
    "Id": 1234567,
    "ExternalId": 1762444800000,
    "CardLinkHash": "1037153_b3f50103610e4fe9948ff8db553151f3"
  }
}
\`\`\`

(Fragment. Formatul complet este în [Notificări](#/guides/notifications).)

## Plata următoare

O comandă nouă cu un \`Order\` nou, același \`Customer\` și \`CardLinkHash\` salvat:

\`\`\`json
{
  "Order": 1762531200000,
  "SaleAreaCode": "onlidocumentation_md",
  "LinkUrlSuccess": "https://shop.example/payment/success",
  "LinkUrlCancel": "https://shop.example/payment/cancel",
  "Customer": {
    "Code": "464566161",
    "NameFirst": "First Name",
    "NameLast": "Last Name",
    "email": "customer@example.com",
    "PhoneNumber": "37360000000"
  },
  "CardLinkHash": "1037153_b3f50103610e4fe9948ff8db553151f3",
  "Currency": 498,
  "ExpiryDate": "2026-12-31T23:59:59",
  "Services": [
    { "Name": "Demo eShop", "Description": "Order #1762531200000", "Amount": 300 }
  ],
  "MoneyType": "Card",
  "Lang": "RO"
}
\`\`\`

Restul este ca de obicei: trimiteți clientul la \`paymentLink\` și așteptați notificarea \`PAID\`.

## Ce s-a verificat în mediul de test

| Situație | Ce se întâmplă |
|---|---|
| Prima plată cu \`Customer\`, bifa păstrată | \`CardLinkHash\` vine în notificare și în răspunsul \`GET /api/order/merchant/{Order}\` (\`cardLinkHash\` și \`customer.cardLinkHash\`) |
| Plata următoare: același \`Customer\` + \`CardLinkHash\` | Pagina Paynet afișează cardul salvat (masca și data expirării). Clientul îl poate alege, poate introduce alt card sau poate șterge cardul salvat |
| Alt \`Customer.Code\` + același \`CardLinkHash\` | Comanda se creează (\`200\`), dar cardul salvat **nu se afișează** — clientul introduce cardul din nou |
| \`CardLinkHash\` inexistent | Comanda se creează (\`200\`), pagina de plată este cea obișnuită |

API-ul nu respinge un token nepotrivit la crearea comenzii: protecția funcționează pe pagina de plată. De aceea păstrați fiecare token strict în pereche cu clientul pentru care a fost emis.

## Reguli

- \`CardLinkHash\` funcționează doar împreună cu \`Customer\` pentru care a fost emis. Trimiteți perechea neschimbată.
- \`CardLinkHash\` nu este acoperit de semnătura notificării. Înainte de a-l salva, confirmați plata și clientul prin API — vezi [Ce protejează semnătura](#/guides/notifications).
- Tokenul este valabil cât timp este valabil cardul. Dacă cardul a expirat sau a fost reemis, clientul plătește cu cardul nou și primiți un \`CardLinkHash\` nou — înlocuiți-l pe cel vechi.
- \`CardLinkHash\` în notificare poate fi \`null\` (clientul a debifat sau salvarea nu este activată). Este normal: nu salvați nimic.
- Păstrați \`CardLinkHash\` pe server și nu-l expuneți în browser.
- Pentru a șterge un card (de exemplu, la cererea clientului), apelați \`POST /api/linked-cards/unlink\` cu \`CardLinkHash\`, \`SaleAreaCode\` și \`CustomerCode\`.
`,"../../content/ro/ecom/05-hosted-checkout.md":`# Hosted checkout (client-server)

În acest model browserul clientului trimite comanda la Paynet ca formular HTML semnat (\`POST\`). Nu apelați un API pentru crearea comenzii, dar trebuie să calculați \`Signature\` cu cheia dvs. secretă **pe server**.

| Mediu | URL-ul formularului (action) |
|---|---|
| Test | \`https://test.paynet.md/ecom/checkout\` |
| Producție | \`https://paynet.md/ecom/checkout\` |

## Fluxul

1. Clientul apasă „Plătește” în magazinul dvs.
2. Serverul dvs. construiește câmpurile formularului și calculează \`Signature\` (vezi mai jos).
3. Pagina dvs. afișează un formular care se trimite automat la URL-ul de checkout.
4. Clientul plătește pe pagina Paynet și revine la \`LinkUrlSuccess\` (achitat) sau \`LinkUrlCancel\` (eșuat sau anulat).
5. Paynet trimite o [notificare](#/guides/notifications) \`PAID\` la URL-ul dvs. de callback (plățile eșuate nu se notifică).
6. Înainte de livrare confirmați plata cu \`GET /api/order/merchant/{Order}\` (API server-to-server, token Bearer): comenzile create prin formular se găsesc după \`Order\`-ul dvs.

## Câmpurile formularului

| Câmp | Obligatoriu | Semnat | Descriere |
|---|---|---|---|
| \`Order\` | da | da | Numărul comenzii la dvs. (număr întreg). O comandă din magazin = un \`Order\`. |
| \`Currency\` | da | da | Cod numeric ISO 4217, \`498\` = MDL. |
| \`Merchant\` | da | da | Codul dvs. de comerciant. |
| \`SaleAreaCode\` | da | da | Codul zonei dvs. de vânzare. |
| \`Amount\` | da | da | Suma în unități minime: \`1235\` = 12,35 MDL. |
| \`Description\` | da | da | Descrierea comenzii afișată clientului. |
| \`ExpiryDate\` | da | da | Termenul de plată, \`YYYY-MM-DDTHH:mm:ss\`, ora locală Chișinău. |
| \`LinkUrlSuccess\` | da | da | URL de revenire după plata reușită. |
| \`LinkUrlCancel\` | da | da | URL de revenire după anulare. |
| \`Lang\` | da | da | Limba paginii de plată, de ex. \`ro\`, \`ru\`, \`en\`. |
| \`MoneyType\` | da | da | Metodele de plată afișate: \`All\`, \`Card\` (card, Apple Pay, Google Pay), \`Paynet\`, \`MIA\`, \`CashInvoice\`. |
| \`CustomerCode\` | nu | da | ID-ul clientului în sistemul dvs. |
| \`CustomerNameFirst\` | nu | da | Prenumele clientului. |
| \`CustomerNameLast\` | nu | da | Numele clientului. |
| \`CustomerPhoneNumber\` | nu | da | Telefonul clientului. |
| \`CustomerEmail\` | nu | da | Emailul clientului. |
| \`ProductAmount\`, \`ProductBarcode\`, \`ProductCode\`, \`ProductDescription\`, \`ProductGroupId\`, \`ProductGroupName\`, \`ProductLineNo\`, \`ProductName\`, \`ProductUnitPrice\`, \`ProductQuantity\`, \`ProductUnitProduct\` | nu | nu | Date opționale despre produs. |
| \`Signature\` | da | — | \`Base64(MD5(RawData + SecretKey))\` cu cheia secretă **hosted checkout**, vezi mai jos. |

## Semnătura

1. Luați câmpurile **semnate** din tabelul de mai sus pe care le trimiteți efectiv (omiteți câmpurile pe care nu le trimiteți).
2. Sortați-le după numele câmpului, A → Z.
3. Codificați fiecare **valoare** conform RFC 3986 (\`encodeURIComponent\` plus \`! ' ( ) *\`), în UTF-8 (inclusiv chirilice și diacritice românești). Funcțiile corecte pentru PHP, JavaScript, Python, C#, Java și regulile pentru caractere speciale: [Semnături](#/guides/signatures).
4. Concatenați valorile codificate fără separatori → \`RawData\`.
5. \`Signature = Base64( MD5( RawData + SecretKey ) )\` — Base64 din digestul MD5 brut de 16 octeți, nu din șirul hex.

Un exemplu complet cu rezultatul așteptat se află pe pagina [Semnături](#/guides/signatures). Folosiți-l ca test unitar.

> **Important:** calculați semnătura pe server. Cheia secretă nu trebuie să apară niciodată în HTML sau JavaScript trimis browserului.

## Exemplu de formular

\`\`\`html
<form id="paynet" method="POST" action="https://test.paynet.md/ecom/checkout">
  <input type="hidden" name="Order" value="1762444800000">
  <input type="hidden" name="Currency" value="498">
  <input type="hidden" name="Merchant" value="265505">
  <input type="hidden" name="SaleAreaCode" value="onlidocumentation_md">
  <input type="hidden" name="Amount" value="1235">
  <input type="hidden" name="Description" value="Test&amp;Co SRL">
  <input type="hidden" name="CustomerCode" value="5555">
  <input type="hidden" name="CustomerNameFirst" value="First name">
  <input type="hidden" name="CustomerNameLast" value="Last name">
  <input type="hidden" name="CustomerPhoneNumber" value="060000000">
  <input type="hidden" name="CustomerEmail" value="test@gmail.com">
  <input type="hidden" name="ExpiryDate" value="2026-12-31T23:59:59">
  <input type="hidden" name="LinkUrlCancel" value="https://test.oplta.md/cancel">
  <input type="hidden" name="LinkUrlSuccess" value="https://test.oplta.md/ok">
  <input type="hidden" name="Lang" value="ro">
  <input type="hidden" name="MoneyType" value="Card">
  <input type="hidden" name="Signature" value="cxr/+yLYZp34aR0KXLkb2A==">
</form>
<script>document.getElementById('paynet').submit();<\/script>
\`\`\`

\`Signature\` de mai sus este corectă exact pentru aceste valori și cheia de test. Valorile din atributele HTML trebuie escapate (\`&\` → \`&amp;\`); browserul trimite valoarea originală, iar aceasta se semnează. Nu folosiți în valori rânduri noi, taguri HTML (\`<b>\`) sau entități HTML (\`&#039;\`): vezi [Semnături](#/guides/signatures).

## Exemplu: semnătura în Node.js

\`\`\`javascript
import crypto from 'node:crypto';

const SIGNED_FIELDS = ['Order', 'Currency', 'Merchant', 'SaleAreaCode', 'CustomerCode', 'CustomerNameFirst',
  'CustomerNameLast', 'CustomerPhoneNumber', 'CustomerEmail', 'ExpiryDate', 'Description', 'Amount',
  'LinkUrlCancel', 'LinkUrlSuccess', 'Lang', 'MoneyType'];

const encodeRfc3986 = (v) =>
  encodeURIComponent(v).replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());

export function checkoutSignature(fields, secretKey) {
  const rawData = SIGNED_FIELDS
    .filter((name) => fields[name] !== undefined && fields[name] !== null)
    .sort()
    .map((name) => encodeRfc3986(String(fields[name])))
    .join('');
  return crypto.createHash('md5').update(rawData + secretKey, 'utf8').digest('base64');
}
\`\`\`

## Exemplu: semnătura în PHP

\`\`\`php
<?php
function checkoutSignature(array $fields, string $secretKey): string {
    $signed = ['Order', 'Currency', 'Merchant', 'SaleAreaCode', 'CustomerCode', 'CustomerNameFirst',
        'CustomerNameLast', 'CustomerPhoneNumber', 'CustomerEmail', 'ExpiryDate', 'Description', 'Amount',
        'LinkUrlCancel', 'LinkUrlSuccess', 'Lang', 'MoneyType'];
    $present = array_values(array_filter($signed, fn($name) => isset($fields[$name])));
    sort($present, SORT_STRING);
    $rawData = '';
    foreach ($present as $name) {
        $rawData .= rawurlencode((string) $fields[$name]); // RFC 3986
    }
    return base64_encode(md5($rawData . $secretKey, true));
}
\`\`\`

## Testare pe acest portal

Deschideți **E-commerce → Hosted checkout → Formular checkout (încercați)**. Portalul completează un \`Order\` unic și un \`ExpiryDate\` în viitor, generează semnătura cu cheia de test și deschide pagina de test Paynet într-un tab nou.

Dacă trimiteți un \`Order\` deja achitat sau în procesare la banca emitentă, clientul vede pagina Paynet „Plata a fost respinsă” (factura este deja plătită sau în curs de procesare).
`,"../../content/ro/ecom/06-testing.md":"# Testare\n\n## Mediul de test\n\n| Element | Valoare |\n|---|---|\n| URL de bază API | `https://ecom-api-test.paynet.md` |\n| URL-ul formularului hosted checkout | `https://test.paynet.md/ecom/checkout` |\n| Utilizator / parolă API | `771064` / `sLgMnGWJ` |\n| Codul comerciantului | `265505` |\n| Codul zonei de vânzare | `onlidocumentation_md` |\n| Cheia secretă pentru semnătura hosted checkout | `F90D6485-9CCC-458B-96A3-8958AF9B4458` |\n| Cheia secretă pentru notificări | `D9873689-E5F8-4272-A67F-0D8BA3F9BAA7` |\n\nAceste date sunt comune pentru toți cei care testează pe portal: plățile de test ale altora apar în căutări și extrase. Dacă aveți nevoie de un mediu izolat, cereți de la Paynet un comerciant de test propriu.\n\n## Card de test\n\n| Card | Expirare | CVV | Rezultat |\n|---|---|---|---|\n| Visa `4111 1111 1111 1111` | `12/27` | `777` | plată reușită |\n\nCardurile de test pot reproduce doar o plată reușită: nu există carduri pentru plăți refuzate sau 3-D Secure. Tratarea refuzului trebuie totuși implementată și testată cu răspunsuri API simulate: `status` = `5` și revenirea clientului la `LinkUrlCancel` (vezi [Plată eșuată](#/guides/errors-and-statuses)). Când o plată reală eșuează, clientul este doar redirecționat la `LinkUrlCancel` și nu se trimite notificare.\n\n## Ce face testele să eșueze\n\n- **`Order` reutilizat.** Același `Order` cu date diferite sau un `Order` deja achitat dă `500 TECHNICAL_ERROR`. Portalul generează automat un `Order` nou (ora curentă în milisecunde).\n- **`ExpiryDate` în trecut.** Folosiți o dată viitoare în ora locală Chișinău. Portalul pune sfârșitul zilei de mâine.\n- **Sume în MDL în loc de unități minime.** `100` înseamnă 1,00 MDL.\n- **Token expirat.** Tokenul este valabil aproximativ 4 ore; după `401` apelați din nou `/auth`.\n- **Produsele nu se potrivesc.** Dacă trimiteți `Products`, trimiteți toate câmpurile produsului și păstrați valorile `Amount` coerente cu `Amount` al serviciului.\n\n## Scenarii de test\n\n| # | Scenariu | Cum | Rezultat așteptat |\n|---|---|---|---|\n| 1 | Autentificare | `POST /auth` cu datele de test | `200`, `access_token` |\n| 2 | Parolă greșită | `POST /auth` cu parolă greșită | `401`, `AUTHENTICATION_FAILED` |\n| 3 | Creare comandă | `POST /api/order` | `200`, `paymentId`, `paymentLink`, `status` `1` |\n| 4 | Repetarea aceleiași cereri | trimiteți scenariul 3 din nou, nemodificat | același `paymentId` și `paymentLink` |\n| 5 | Același `Order`, altă sumă | modificați `Amount`, păstrați `Order` | `500`, `TECHNICAL_ERROR` |\n| 6 | Cerere invalidă | `POST /api/order` fără `Services` | `400` cu obiectul `errorInfo` (câmpul lipsă în `errors`) |\n| 7 | Fără token | `POST /api/order` fără `Authorization` | `401`, `UNAUTHORIZED` |\n| 8 | Plată | deschideți `paymentLink`, plătiți cu cardul de test | revenire la `LinkUrlSuccess` |\n| 9 | Status | `GET /api/order/merchant/{Order}` | plată cu `paidDate` completat |\n| 10 | Comandă necunoscută | `GET /api/order/{id}` cu un ID aleator | `404`, `NOT_FOUND_RECORD` |\n| 11 | Notificare | **Simulator notificări** → URL-ul dvs. | handler-ul verifică `Hash` și returnează `200` |\n| 12 | Hash greșit | trimiteți o notificare cu `Amount` modificat | handler-ul o respinge |\n| 13 | Notificare duplicată | trimiteți aceeași notificare de două ori | handler-ul o procesează o singură dată |\n| 14 | Hosted checkout | **Formular checkout (încercați)** | se deschide pagina de plată de test Paynet |\n| 15 | Rambursare | `POST /api/order/refund` pentru o plată achitată | `200`; `status` devine `5` (integrală) sau `6` (parțială) |\n| 16 | Rambursare peste suma plătită | `RefundType` `partial`, `Amount` mai mare decât `PaidAmount` | `400 INVALID_PARAMETER` |\n| 17 | Salvarea cardului (dacă este activată pentru `SaleAreaCode`) | `POST /api/order` cu `Customer`, plătiți păstrând bifa „salvează cardul” | notificarea `PAID` conține `CardLinkHash` |\n| 18 | Plata cu card salvat (dacă este activată) | `POST /api/order` cu `CardLinkHash` și același `Customer` | pagina Paynet afișează cardul salvat |\n| 19 | Clientul a plecat fără să plătească | deschideți `paymentLink`, închideți pagina, deschideți linkul din nou | `status` rămâne `1`, plata e încă posibilă |\n\n## Răspunsuri simulate pentru testele de eșec\n\nRefuzul băncii, erorile de rambursare și notificările deteriorate nu pot fi reproduse cu cardul de test. Pentru testele automate ale integrării folosiți aceste răspunsuri gata — sunt luate din răspunsuri reale ale mediului de test, iar notificările sunt semnate cu cheia de test. Lista completă: [mocks/index.json](mocks/index.json).\n\n| Fișier | Ce simulează | Ce trebuie să facă codul dvs. |\n|---|---|---|\n| [payment-status-3.json](mocks/payment-status-3.json) | Plata este încă în procesare | Așteptați, nu creați o comandă nouă |\n| [payment-status-5-declined.json](mocks/payment-status-5-declined.json) | Refuzată de bancă | Oferiți o nouă încercare cu un `Order` nou |\n| [payment-status-5-refunded.json](mocks/payment-status-5-refunded.json), [payment-status-6.json](mocks/payment-status-6.json) | Rambursare integrală și parțială | Nu onorați comanda din nou |\n| [refund-400-amount-or-second.json](mocks/refund-400-amount-or-second.json), [refund-404-unpaid.json](mocks/refund-404-unpaid.json) | Erori de rambursare | Afișați o eroare clară, nu repetați automat |\n| [order-500-repeated-order.json](mocks/order-500-repeated-order.json), [order-400-errorinfo.json](mocks/order-400-errorinfo.json) | `Order` repetat, cerere ilizibilă | Tratați ambele formate de eroare |\n| [error-401-token.json](mocks/error-401-token.json) | Token expirat | Obțineți un token nou și repetați o dată |\n| [notification-paid.json](mocks/notification-paid.json) | Notificare `PAID` validă | Răspundeți `200`, onorați o singură dată |\n| [notification-paid-wrong-hash.json](mocks/notification-paid-wrong-hash.json) | `Hash` greșit | Răspundeți `400`, nu schimbați nimic |\n| [notification-paid-tampered-paidamount.json](mocks/notification-paid-tampered-paidamount.json) | `Hash` valid, dar `PaidAmount` nesemnat modificat | Confirmarea prin API trebuie să trimită comanda la verificare |\n\n`payment-status-5-declined.json` este construit: valoarea `status` este reală, celelalte câmpuri sunt ca la o plată neachitată.\n\n## Testare de pe acest portal\n\nButoanele „Test API Request” apelează API-ul de test direct din browserul dvs. Funcționează pe domeniul oficial al portalului. Dacă deschideți o copie a portalului de la altă adresă, browserul poate bloca apelurile (CORS) — folosiți atunci cURL sau Postman. O colecție Postman gata de utilizare este descrisă mai jos.\n\n## Postman\n\nColecția gata făcută funcționează imediat după import, nu trebuie modificat nimic.\n\n1. Descărcați [colecția](postman/paynet-ecom.postman_collection.json) și [mediul de test](postman/paynet-test.postman_environment.json) (le găsiți și în meniul lateral, sub butonul „Postman collection”).\n2. În Postman: **Import** → selectați ambele fișiere → în dreapta sus alegeți mediul **Paynet — TEST**.\n3. Rulați **1. Payments → Create order**. Tokenul se obține automat; `Order` și `ExpiryDate` sunt noi de fiecare dată.\n4. În **Postman Console** apare `paymentLink` — deschideți-l și plătiți cu cardul de test.\n5. Rulați **Get payment by Order**: `status` = `4` înseamnă achitat. Apoi puteți rula **Refund**.\n\n| Ce face colecția singură | Cum |\n|---|---|\n| Obține și reînnoiește tokenul | Înainte de fiecare cerere, dacă tokenul lipsește sau expiră curând |\n| Creează o comandă unică | `Order` = ora curentă în ms, `ExpiryDate` = mâine, ora Chișinăului |\n| Transmite datele între cereri | Salvează `paymentId`, `paymentLink`, `lastOrder`, `cardLinkHash` |\n| Calculează perioadele | Căutare — ultimele 24 de ore în ora Chișinăului, extras — ultimele 7 zile |\n| Afișează erorile | Codul, mesajul, `details` și `traceId` în Postman Console |\n\nDosarul **5. Error examples** provoacă intenționat erorile `401`, `400` și `404`, ca să vedeți cum arată.\n\nPentru producție, importați [mediul PRODUCTION](postman/paynet-production.postman_environment.json) și completați **propriile** `username`, `password`, `saleAreaCode`. Nu distribuiți acest fișier după completare.\n","../../content/ro/ecom/07-example-shop.md":"# Exemplu de magazin (Node.js)\n\nO integrare server-to-server minimă și gata de folosit: un server Node.js 18+ fără dependențe. Cod sursă: [paynet-example-shop-node.zip](sdk/paynet-example-shop-node.zip).\n\n> **Important:** acest exemplu este verificat de un test end-to-end în mediul de test Paynet: un robot cumpără un produs în exemplu, plătește cu cardul de test, trimite notificarea și face o rambursare. Deci codul exemplului funcționează.\n\n## Pornire\n\nExemplul este un magazin online funcțional, conectat la mediul de test Paynet. Rulează pe calculatorul dvs.; în afară de Node.js nu trebuie instalat sau configurat nimic.\n\n### Înainte de început: Node.js\n\nAveți nevoie de **Node.js 18 sau mai nou**. Deschideți linia de comandă:\n\n| Sistem | Cum se deschide |\n|---|---|\n| Windows | **Win+R** → tastați `cmd` → **Enter** |\n| macOS | aplicația **Terminal** (Aplicații → Utilitare) |\n| Linux | **Terminal** (de obicei **Ctrl+Alt+T**) |\n\nTastați comanda și apăsați **Enter**:\n\n```\nnode --version\n```\n\nDacă apare un număr de versiune (de exemplu `v22.11.0`), totul e gata. Dacă apare o eroare, instalați Node.js de pe https://nodejs.org (butonul **LTS**), apoi închideți și redeschideți linia de comandă.\n\n### Pasul 1. Descărcați arhiva și porniți magazinul\n\nDescărcați [paynet-example-shop-node.zip](sdk/paynet-example-shop-node.zip). În linia de comandă tastați comenzile pe rând, apăsând **Enter** după fiecare rând:\n\n```\ncd Downloads\ntar -xf paynet-example-shop-node.zip\ncd node-shop\nnode server.mjs\n```\n\n| Comandă | Ce face |\n|---|---|\n| `cd Downloads` | trece în folderul Descărcări, unde browserul a salvat arhiva |\n| `tar -xf …zip` | dezarhivează arhiva (Windows 10/11, macOS); apare folderul `node-shop` |\n| `cd node-shop` | trece în folderul magazinului |\n| `node server.mjs` | pornește magazinul |\n\n**Linux:** în loc de `tar -xf paynet-example-shop-node.zip` tastați `unzip paynet-example-shop-node.zip` (`tar` standard din Linux nu deschide `.zip`; dacă `unzip` lipsește: `sudo apt install unzip`).\n\nApare rândul `Demo shop on http://localhost:3000 …`. **Nu închideți această fereastră**: magazinul funcționează cât timp ea este deschisă. Oprirea magazinului — **Ctrl+C**.\n\n> Arhiva nu s-a salvat în Descărcări? În loc de `cd Downloads` tastați `cd ` cu un spațiu (în Windows — `cd /d ` cu un spațiu) și trageți cu mouse-ul în fereastra liniei de comandă **folderul în care se află arhiva**: calea se inserează automat. Trageți folderul, nu arhiva `.zip`. În Linux cu interfață în altă limbă folderul poate avea un nume tradus.\n\n### Pasul 2. Plătiți o comandă de test\n\nDeschideți în browser http://localhost:3000, apăsați **Buy** și plătiți cu cardul de test: numărul `4111 1111 1111 1111`, valabil până la `12/27`, CVV `777`. După plată reveniți în magazin.\n\n### Pasul 3. Trimiteți notificarea de plată\n\nDeschideți http://localhost:3000/orders. Comanda este **`pending`**, și este normal: magazinul marchează comanda ca plătită **doar după notificarea Paynet** — la fel trebuie să funcționeze și magazinul dvs. real. Paynet trimite notificările la URL-ul de callback al comerciantului dvs., iar ele nu ajung la `localhost`. De aceea, în timpul dezvoltării trimiteți notificarea singuri: scriptul verifică plata prin API, construiește notificarea și o semnează la fel ca Paynet.\n\nDeschideți **a doua** linie de comandă și tastați, cu numărul comenzii dvs. din coloana **Order**:\n\n```\ncd Downloads/node-shop\nnode tools/send-test-notification.mjs <Order>\n```\n\nDe exemplu: `node tools/send-test-notification.mjs 1794411831126`. Pagina comenzilor din magazin afișează comanda gata de copiat pentru fiecare comandă `pending`.\n\n### Pasul 4. Verificați rezultatul\n\nReîmprospătați http://localhost:3000/orders: comanda este acum **`paid`**, iar alături este butonul de rambursare — încercați o rambursare.\n\n### Dacă ceva nu merge\n\n| Mesaj | Cauză și soluție |\n|---|---|\n| `'node' is not recognized…` / `command not found: node` | Node.js nu este instalat sau linia de comandă a fost deschisă înainte de instalare. Instalați Node.js și redeschideți linia de comandă |\n| `The system cannot find the path specified` / `No such file or directory` după `cd Downloads` | Arhiva este în alt folder. Folosiți sfatul de sub pasul 1 |\n| `The directory name is invalid` | Ați tras arhiva `.zip`, nu un folder. Trageți folderul în care se află arhiva |\n| `tar: This does not look like a tar archive` | Sunteți pe Linux: folosiți `unzip paynet-example-shop-node.zip` în loc de `tar -xf` |\n| `Cannot find module …server.mjs` | Linia de comandă nu este în folderul `node-shop`. Repetați pasul 1 |\n| `EADDRINUSE … 3000` | Magazinul rulează deja în altă fereastră. Închideți-o (sau apăsați **Ctrl+C** în ea) și porniți din nou |\n| `Payment is not paid (status 1)` | Plata comenzii nu a fost finalizată. Creați o comandă nouă și finalizați plata |\n| Comanda rămâne `pending` | Notificarea nu a fost trimisă. Faceți pasul 3 |\n\n## Ce conține\n\n| Fișier | Ce face |\n|---|---|\n| `server.mjs` | Magazin: produs, creare comandă, redirecționare la plată, pagini de revenire, primirea notificărilor, rambursări |\n| `paynet-client.mjs` | Client API: cache pentru token, creare comandă cu repetare sigură, căutare plată, rambursare |\n| `paynet-notifications.mjs` | Handler de notificări — același cod ca în [Notificări](#/guides/notifications) |\n| `store.mjs` | Stocare în fișier JSON — înlocuiți-o cu baza dvs. de date |\n| `tools/send-test-notification.mjs` | Trimite o notificare `PAID` semnată la adresa dvs. |\n\n## Ce reguli arată exemplul\n\n| Pas | Cum face exemplul | Regulă |\n|---|---|---|\n| Creare comandă | `Order` unic; corpul cererii se salvează înainte de apelul Paynet | Repetare doar cu același corp ([Număr de comandă repetat](#/guides/errors-and-statuses)) |\n| Termen de plată | `ExpiryDate` = acum + 1 zi, ora Chișinăului | `Europe/Chisinau` |\n| Revenirea clientului | Pagina verifică `status` prin API, nu se bazează pe redirecționare | Revenirea la `LinkUrlSuccess` nu dovedește plata |\n| `status` = `1` | „Continuă plata” cu același link | Clientul nu a plătit |\n| `status` = `3` | Pagina așteaptă și se reîmprospătează | Banca încă răspunde; nu creați o comandă nouă |\n| `status` = `5` | „Încearcă din nou” creează o comandă nouă cu un `Order` nou | Comanda este închisă după refuz |\n| Notificare | Semnătură, o dată per `Payment.Id`, întâi `200`, apoi confirmare prin API | [Ce protejează semnătura](#/guides/notifications) |\n| Rambursare | Doar la `status` = `4`, cel mult `PaidAmount`, o singură dată | [Rambursări](#/guides/errors-and-statuses) |\n| Card salvat | `CardLinkHash` dintr-o notificare confirmată se salvează pentru client | [Salvarea cardurilor](#/guides/saved-cards) |\n\n## Trecerea în producție\n\nSetați variabilele de mediu cu valorile de producție — ele diferă de cele de test — și nu le păstrați în cod:\n\n| Variabilă | Valoare |\n|---|---|\n| `PAYNET_API_URL` | `https://ecom-api.paynet.md` |\n| `PAYNET_USERNAME`, `PAYNET_PASSWORD` | accesele API de producție |\n| `PAYNET_SALE_AREA` | codul zonei dvs. de vânzare |\n| `PAYNET_NOTIFICATION_SECRET` | cheia de notificări de producție |\n| `PUBLIC_URL` | adresa magazinului dvs. (pentru `LinkUrlSuccess` / `LinkUrlCancel`) |\n\nÎnlocuiți `store.mjs` cu baza dvs. de date și parcurgeți [lista de verificare pentru lansare](#/guides/go-live).\n","../../content/ro/ecom/08-go-live.md":`# Lista de verificare pentru lansare

## Înainte de trecerea în producție

**Acces și configurare**

- [ ] Ați primit de la Paynet: utilizatorul API de producție, codul comerciantului, codul zonei de vânzare și **două** chei secrete (pentru semnătura hosted checkout și pentru notificări). Accesele de producție sunt trimise pe emailul administratorului companiei dvs.; durează de la 5 minute la câteva zile, în funcție de funcțiile conectate.
- [ ] Toate valorile de test sunt înlocuite cu cele de producție: **cheile și accesele de producție diferă de cele de test**.
- [ ] Codul folosește adresele de producție: API \`https://ecom-api.paynet.md\`, formularul hosted checkout \`https://paynet.md/ecom/checkout\`.
- [ ] Secretele sunt păstrate în configurația serverului (variabile de mediu, vault), nu în cod sau în front-end.
- [ ] URL-ul dvs. de callback (HTTPS) este înregistrat la Paynet.
- [ ] \`LinkUrlSuccess\` și \`LinkUrlCancel\` indică paginile de producție.

**Plăți**

- [ ] Fiecare comandă din magazin primește propriul număr \`Order\` unic, inclusiv după reporniri și la cereri paralele.
- [ ] \`ExpiryDate\` este calculat în ora locală Chișinău (\`Europe/Chisinau\`), de ex. acum + 1 zi, nu fixat în cod.
- [ ] Sumele sunt trimise în unități minime și corespund totalului coșului.
- [ ] Hosted checkout: semnătura este calculată pe server și trece [vectorii de test](#/guides/signatures).

**Notificări**

- [ ] Handler-ul verifică antetul \`Hash\` cu cheia pentru notificări.
- [ ] Handler-ul citește \`Payment.Id\` și \`Payment.ExternalId\` (exact cu această scriere).
- [ ] Handler-ul este idempotent (un \`Payment.Id\` = o singură onorare a comenzii).
- [ ] Handler-ul verifică că \`PaidAmount\` este egal cu \`Amount\` (dacă nu aveți o promoție convenită cu Paynet).
- [ ] Handler-ul răspunde \`200\` doar după ce comanda este salvată.
- [ ] Un job de rezervă verifică comenzile neplătite cu \`GET /api/order/{paymentId}\` dacă notificarea nu a sosit. Plățile eșuate nu se notifică.

**Operare**

- [ ] Tokenul este păstrat în cache și reînnoit la \`401\`.
- [ ] Erorile sunt înregistrate împreună cu \`traceId\`.
- [ ] Comanda nu este marcată plătită doar pentru că clientul a revenit la \`LinkUrlSuccess\`.
- [ ] Rambursările și extrasele sunt testate, dacă le folosiți.

## După lansare

- Faceți o plată reală de valoare mică și rambursați-o.
- Reconciliați plățile din prima zi cu extrasul (\`GET /api/statement\`): primiți \`PaidAmount\` minus comisionul Paynet.
`,"../../content/ro/ecom/09-sdk.md":`# SDK pentru PHP și Node.js

Biblioteci oficiale Paynet pentru partea de server a magazinului. Ele se ocupă de autorizare, regulile API, semnături și tratarea erorilor, iar dvs. scrieți doar logica magazinului. Fără dependențe externe.

| | PHP | Node.js |
|---|---|---|
| Versiune | 1.0.0 | 1.0.0 |
| Cerințe | PHP 7.4+, extensiile \`curl\` și \`json\` | Node.js 18+ |
| Descărcare | [paynet-ecom-sdk-php-1.0.0.zip](sdk/paynet-ecom-sdk-php-1.0.0.zip) | [paynet-ecom-sdk-node-1.0.0.zip](sdk/paynet-ecom-sdk-node-1.0.0.zip) |
| Licență | MIT | MIT |

> **Important:** SDK-ul rulează doar pe server. Nu trimiteți niciodată utilizatorul, parola sau cheile secrete în browser sau într-o aplicație mobilă. Pentru aplicații, vedeți [Aplicații mobile](#/guides/mobile-apps).

## Ce face SDK-ul în locul dvs.

| Sarcină | Fără SDK | Cu SDK |
|---|---|---|
| Token de acces | Obținut prin \`/auth\`, păstrat, reînnoit | Se obține automat, se reînnoiește la \`401\` |
| Crearea comenzii | Păstrați corpul cererii, repetați-l neschimbat după o eroare de rețea | Repetat automat după o eroare de rețea, cu același corp |
| Rambursare | Verificați singur: este achitată, suma nu e prea mare, nu a existat deja o rambursare | Regulile se verifică **înainte** de apelul API — o eroare clară în loc de refuzul API |
| Notificări | Construiți șirul din 9 câmpuri, MD5 + Base64, verificați câmpurile nesemnate | \`parseNotification\` + \`confirmNotification\` |
| Formularul hosted checkout | RFC 3986, sortarea câmpurilor, semnătura | \`buildCheckoutForm\` returnează HTML gata |
| Erori | Trei formate de corp și majuscule diferite în chei | O singură eroare: tip, cod, \`traceId\`, indicație |
| Ora | \`ExpiryDate\`, căutarea și extrasele folosesc ora Chișinăului | Datele se convertesc automat |

## Instalare

Dezarhivați arhiva în proiect — obțineți dosarul \`paynet-ecom-sdk\`.

PHP:

\`\`\`php
require __DIR__ . '/paynet-ecom-sdk/autoload.php';
\`\`\`

Node.js:

\`\`\`javascript
import { PaynetClient } from './paynet-ecom-sdk/src/index.js';
\`\`\`

Pentru a verifica: \`php paynet-ecom-sdk/tests/run.php\` sau \`node --test paynet-ecom-sdk/test/unit.test.js\`.

## Conectare

PHP:

\`\`\`php
use Paynet\\Ecom\\PaynetClient;

$paynet = new PaynetClient([
    'username' => getenv('PAYNET_USERNAME'),
    'password' => getenv('PAYNET_PASSWORD'),
    'environment' => 'test', // 'production' — cu datele de acces de producție
]);
\`\`\`

Node.js:

\`\`\`javascript
import { PaynetClient } from './paynet-ecom-sdk/src/index.js';

export const paynet = new PaynetClient({
  username: process.env.PAYNET_USERNAME,
  password: process.env.PAYNET_PASSWORD,
  environment: 'test', // 'production' — cu datele de acces de producție
});
\`\`\`

În Node.js, salvați acest cod în fișierul \`paynet.js\`: exemplele de mai jos importă clientul de acolo. Datele de acces de test sunt pe pagina [Testare](#/guides/testing). Cele de producție sunt diferite.

## Creați comanda și trimiteți clientul la plată

Păstrați corpul cererii împreună cu comanda: pentru a repeta cererea, trimiteți-o neschimbată — Paynet returnează aceeași plată.

PHP:

\`\`\`php
use Paynet\\Ecom\\Time;

$order = [
    'Order' => 1762444800000, // numărul comenzii în magazinul dvs.
    'SaleAreaCode' => 'onlidocumentation_md',
    'LinkUrlSuccess' => 'https://shop.example/payment/success',
    'LinkUrlCancel' => 'https://shop.example/payment/cancel',
    'Customer' => ['Code' => 'customer-42', 'NameFirst' => 'Ion', 'NameLast' => 'Popescu', 'email' => 'ion@example.com', 'PhoneNumber' => '37360000000'],
    'ExpiryDate' => Time::expiryInHours(24), // peste 24 de ore, ora Chișinăului
    'Currency' => 498,
    'Services' => [['Name' => 'My shop', 'Description' => 'Order #1762444800000', 'Amount' => 300]], // 300 = 3.00 MDL
    'MoneyType' => 'All',
    'Lang' => 'ro',
];
$created = $paynet->createOrder($order);
header('Location: ' . $created['paymentLink']);
\`\`\`

Node.js:

\`\`\`javascript
import { expiryInHours } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

const order = {
  Order: 1762444800000, // numărul comenzii în magazinul dvs.
  SaleAreaCode: 'onlidocumentation_md',
  LinkUrlSuccess: 'https://shop.example/payment/success',
  LinkUrlCancel: 'https://shop.example/payment/cancel',
  Customer: { Code: 'customer-42', NameFirst: 'Ion', NameLast: 'Popescu', email: 'ion@example.com', PhoneNumber: '37360000000' },
  ExpiryDate: expiryInHours(24), // peste 24 de ore, ora Chișinăului
  Currency: 498,
  Services: [{ Name: 'My shop', Description: 'Order #1762444800000', Amount: 300 }], // 300 = 3.00 MDL
  MoneyType: 'All',
  Lang: 'ro',
};
const { paymentId, paymentLink } = await paynet.createOrder(order);
// redirecționați clientul la paymentLink
\`\`\`

## Verificați plata

Înainte de livrare, verificați statusul prin API: revenirea clientului la \`LinkUrlSuccess\` nu înseamnă singură că plata s-a efectuat.

PHP:

\`\`\`php
use Paynet\\Ecom\\PaymentStatus;

$payment = $paynet->getPaymentByOrder(1762444800000);
if ($payment['status'] === PaymentStatus::PAID) {
    // comanda este achitată — o puteți executa
}
\`\`\`

Node.js:

\`\`\`javascript
import { PaymentStatus } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

const payment = await paynet.getPaymentByOrder(1762444800000);
if (payment.status === PaymentStatus.PAID) {
  // comanda este achitată — o puteți executa
}
\`\`\`

Statusuri: \`1\` — neachitat, \`3\` — în procesare (așteptați, până la circa o zi), \`4\` — achitat, \`6\` — achitat, apoi rambursat parțial, \`5\` — neachitat sau rambursat integral; \`5\` și \`6\` sunt finale. \`isPaid\` returnează \`true\` doar pentru \`4\`. Mai mult: [Statusuri și erori](#/guides/errors-and-statuses).

## Primiți notificarea

Ordinea pașilor: verificați semnătura → **salvați notificarea** → răspundeți \`200\` → confirmați plata prin API și onorați comanda din înregistrarea salvată. Salvați înainte de răspuns: după \`200\` Paynet nu mai trimite notificarea, iar o notificare nesalvată se pierde dacă codul dvs. cade ulterior. Suma achitată (\`PaidAmount\`) și alte câteva câmpuri nu sunt semnate — de aceea este necesară verificarea prin API.

PHP:

\`\`\`php
use Paynet\\Ecom\\Notification;
use Paynet\\Ecom\\PaynetException;

try {
    $notification = Notification::parse(file_get_contents('php://input'), $_SERVER['HTTP_HASH'] ?? null, getenv('PAYNET_NOTIFICATION_KEY'));
} catch (PaynetException $e) {
    http_response_code(400);
    exit;
}
// 1. Salvați notificarea (funcția dvs., de exemplu o înregistrare în baza de date). O reîncercare vine cu același Payment.Id: returnați false dacă este deja salvată.
$isNew = saveNotification($notification);

// 2. Răspundeți 200 doar după salvare.
http_response_code(200);
// Trimiteți răspunsul acum și continuați (PHP-FPM). Fără FPM răspunsul pleacă la sfârșitul scriptului.
if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
}
if (!$isNew) {
    exit;
}

// 3. După răspuns: confirmați prin API, apoi onorați comanda din înregistrarea salvată.
// Dacă acest pas eșuează, înregistrarea rămâne neprocesată: procesați-o din nou mai târziu (de exemplu, o sarcină programată).
$check = Notification::confirm($paynet, $notification, ['amount' => 300, 'customerCode' => 'customer-42']);
if ($check['ok']) {
    // executați comanda și marcați înregistrarea salvată ca procesată
} else {
    // trimiteți la verificare manuală: $check['problems']
}
\`\`\`

Node.js:

\`\`\`javascript
import { parseNotification, confirmNotification } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

// rawBody — corpul cererii ca șir, neschimbat; hash — antetul Hash
export async function handlePaynetNotification(rawBody, hash, res) {
  let notification;
  try {
    notification = parseNotification(rawBody, hash, process.env.PAYNET_NOTIFICATION_KEY);
  } catch {
    res.writeHead(400).end();
    return;
  }
  // 1. Salvați notificarea (funcția dvs., de exemplu o înregistrare în baza de date). O reîncercare vine cu același Payment.Id: returnați false dacă este deja salvată.
  const isNew = await saveNotification(notification);

  // 2. Răspundeți 200 doar după salvare.
  res.writeHead(200).end();
  if (!isNew) return;

  // 3. După răspuns: confirmați prin API, apoi onorați comanda din înregistrarea salvată.
  // Dacă acest pas eșuează, înregistrarea rămâne neprocesată: procesați-o din nou mai târziu (de exemplu, o sarcină programată).
  const check = await confirmNotification(paynet, notification, { amount: 300, customerCode: 'customer-42' });
  if (check.ok) {
    // executați comanda și marcați înregistrarea salvată ca procesată
  } else {
    // trimiteți la verificare manuală: check.problems
  }
}
\`\`\`

Folosiți **cheia pentru notificări**, nu cheia formularului checkout. Mai mult: [Notificări](#/guides/notifications).

## Efectuați o rambursare

În producție o plată poate avea **o singură** rambursare (totală sau parțială), în 180 de zile, cel mult suma achitată, nu pentru \`CASH_INVOICE\`. SDK-ul verifică aceste reguli înainte de apelul API. Tipul (\`full\` / \`partial\`) se alege după sumă.

PHP:

\`\`\`php
$refund = $paynet->refund((int) $created['paymentId'], 'onlidocumentation_md', 300, null, 'Customer request');
\`\`\`

Node.js:

\`\`\`javascript
import { paynet } from './paynet.js';

const refund = await paynet.refund({ paymentId: 328731, saleAreaCode: 'onlidocumentation_md', amount: 300, reason: 'Customer request' });
\`\`\`

Rezultatul vine în răspuns; nu există notificare despre rambursare.

## Formularul hosted checkout

Semnătura se calculează pe server; în browser ajunge doar formularul gata. Folosiți **cheia formularului checkout**.

PHP:

\`\`\`php
use Paynet\\Ecom\\Checkout;

$form = Checkout::buildForm([
    'Order' => 1762444800000,
    'Merchant' => '265505',
    'SaleAreaCode' => 'onlidocumentation_md',
    'Amount' => 300,
    'Description' => 'Order #1762444800000',
    'LinkUrlSuccess' => 'https://shop.example/payment/success',
    'LinkUrlCancel' => 'https://shop.example/payment/cancel',
    'Lang' => 'ro',
    'MoneyType' => 'All',
], getenv('PAYNET_CHECKOUT_KEY'), 'test');
echo $form['html'];
\`\`\`

Node.js:

\`\`\`javascript
import { buildCheckoutForm } from './paynet-ecom-sdk/src/index.js';

const form = buildCheckoutForm({
  secretKey: process.env.PAYNET_CHECKOUT_KEY,
  environment: 'test',
  fields: {
    Order: 1762444800000,
    Merchant: '265505',
    SaleAreaCode: 'onlidocumentation_md',
    Amount: 300,
    Description: 'Order #1762444800000',
    LinkUrlSuccess: 'https://shop.example/payment/success',
    LinkUrlCancel: 'https://shop.example/payment/cancel',
    Lang: 'ro',
    MoneyType: 'All',
  },
});
// trimiteți form.html în browser
\`\`\`

\`Currency\` implicit \`498\`, \`ExpiryDate\` — peste 24 de ore, ora Chișinăului.

## Erori

Orice eroare API sau încălcare a unei reguli este un \`PaynetException\` (PHP) sau \`PaynetError\` (Node.js) cu: tip (\`kind\`), cod HTTP, cod Paynet, \`traceId\`, indicație (\`hint\`) și dacă repetarea poate ajuta (\`retryable\`).

| Tip (\`kind\`) | Când | Ce faceți |
|---|---|---|
| \`validation\` | \`400\`: câmpuri invalide sau lipsă | Corectați cererea după \`details\` |
| \`authentication\` | \`/auth\`: utilizator sau parolă greșite | Verificați datele de acces (test și producție diferă) |
| \`unauthorized\` | \`401\` chiar după reînnoirea tokenului | Verificați datele de acces |
| \`not_found\` | \`404 NOT_FOUND_RECORD\`: plata nu există; rambursarea unei plăți neachitate | Verificați \`paymentId\` / \`Order\` |
| \`server\` | \`500 TECHNICAL_ERROR\` | Căutați comanda după \`Order\`; un \`Order\` repetat cu alte date necesită un \`Order\` nou |
| \`network\` | Niciun răspuns (timeout, rețea) | Căutați comanda după \`Order\`, repetați aceeași cerere |
| \`rule\` | SDK-ul nu a apelat API-ul: o regulă este încălcată (de exemplu, a doua rambursare) | Citiți mesajul — cererea nu a fost trimisă |
| \`wrong_address\`, \`method_not_allowed\`, \`unsupported_media_type\` | \`404\` cu corp gol, \`405\`, \`415\` | Eroare de configurare a clientului — nu ar trebui să apară cu SDK-ul |

PHP:

\`\`\`php
use Paynet\\Ecom\\PaynetException;

try {
    $paynet->refund(328731, 'onlidocumentation_md', 300);
} catch (PaynetException $e) {
    error_log($e->kind . ' ' . $e->errorCode . ' traceId=' . $e->traceId . ' — ' . $e->hint);
}
\`\`\`

Node.js:

\`\`\`javascript
import { PaynetError } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

try {
  await paynet.refund({ paymentId: 328731, saleAreaCode: 'onlidocumentation_md', amount: 300 });
} catch (error) {
  if (error instanceof PaynetError) console.error(error.kind, error.code, \`traceId=\${error.traceId}\`, error.hint);
  else throw error;
}
\`\`\`

Trimiteți \`traceId\` când contactați suportul.

## Metodele SDK

| Ce | PHP | Node.js | Metoda API |
|---|---|---|---|
| Creare comandă | \`createOrder($order)\` | \`createOrder(order)\` | \`POST /api/order\` |
| Plata după \`paymentId\` | \`getPayment($id)\` | \`getPayment(id)\` | \`GET /api/order/{id}\` |
| Plata după numărul comenzii | \`getPaymentByOrder($order)\` | \`getPaymentByOrder(order)\` | \`GET /api/order/merchant/{id}\` |
| Este comanda achitată | \`isPaid($order)\` | \`isPaid(order)\` | \`GET /api/order/merchant/{id}\` |
| Căutare într-o perioadă | \`searchPayments($from, $to)\` | \`searchPayments({ from, to })\` | \`GET /api/order/search\` |
| Rambursare | \`refund($paymentId, $saleArea, $amount, …)\` | \`refund({ paymentId, saleAreaCode, amount, … })\` | \`POST /api/order/refund\` |
| Ștergerea cardului salvat | \`unlinkCard($hash, $saleArea, $customer)\` | \`unlinkCard({ cardLinkHash, saleAreaCode, customerCode })\` | \`POST /api/linked-cards/unlink\` |
| Extras | \`getStatement($start, $finish)\` | \`getStatement({ dateStart, dateFinish })\` | \`GET /api/statement\` |
| Extras \`.xlsx\` | \`downloadStatement($start, $finish)\` | \`downloadStatement({ dateStart, dateFinish })\` | \`GET /api/statement/download\` |
| Verificarea notificării | \`Notification::parse(…)\`, \`Notification::confirm(…)\` | \`parseNotification(…)\`, \`confirmNotification(…)\` | — |
| Formular hosted checkout | \`Checkout::buildForm(…)\` | \`buildCheckoutForm(…)\` | — |

Căutare: datele se convertesc în ora Chișinăului; o perioadă goală returnează o listă goală (API-ul răspunde \`404\` în acest caz).

## Cum sunt verificate SDK-urile

- **Teste unitare** (incluse în arhivă): semnături pe vectorii de test de pe pagina [Semnături](#/guides/signatures), toate formatele de erori, reînnoirea tokenului, regulile de rambursare, ora Chișinăului. Rulează la fiecare publicare a portalului.
- **Verificare în mediul de test** (comerciantul 265505): fiecare SDK creează propria comandă, repetă cererea, iar după plata cu cardul de test verifică statusul \`4\`, căutarea, o rambursare parțială, refuzul celei de-a doua rambursări, ștergerea cardului salvat, extrasele și erorile. Rezultat 10.11.2026: PHP — 20 din 20, Node.js — 20 din 20.

## Suport

Întrebările despre SDK — ca și cele despre API: în chatul Telegram cu dezvoltatorul Paynet (prin managerul dvs.) sau la [support@paynet.md](mailto:support@paynet.md). Trimiteți \`traceId\` din eroare. Mai mult: [Contactarea suportului](#/guides/errors-and-statuses).
`,"../../content/ro/ecom/10-mobile-apps.md":`# Aplicații mobile

Nu este nevoie de un SDK mobil separat. Aplicația mobilă acceptă plăți prin **serverul dvs.** și **pagina de plată Paynet**. La fel funcționează și alți furnizori cu pagină de plată proprie.

> **Important:** nu păstrați niciodată în aplicație utilizatorul și parola API, cheile secrete sau tokenul. Oricine poate descărca și dezasambla aplicația — cheile ar fi găsite, iar cineva ar putea crea comenzi, face rambursări și falsifica notificări în numele magazinului. Tot ce necesită chei face doar serverul.

## Cum funcționează

| Pas | Unde | Ce se întâmplă |
|---|---|---|
| 1 | Aplicație | Clientul apasă „Plătește”. Aplicația trimite comanda la **serverul dvs.** |
| 2 | Serverul dvs. | Creează comanda în Paynet ([SDK](#/guides/sdk) sau [API](#/guides/server-to-server)) și returnează aplicației \`paymentLink\` |
| 3 | Aplicație | Deschide \`paymentLink\` în **fereastra de sistem a browserului**. Clientul plătește pe pagina Paynet |
| 4 | Paynet → serverul dvs. | [Notificare](#/guides/notifications) \`PAID\`. Serverul verifică semnătura și plata |
| 5 | Paynet → aplicație | După plată pagina îl întoarce pe client la \`LinkUrlSuccess\` (sau \`LinkUrlCancel\`) |
| 6 | Aplicație → serverul dvs. | Aplicația întreabă **serverul dvs.** dacă comanda este achitată. Decizia — doar după răspunsul serverului |

## Server: crearea comenzii pentru aplicație

Exemplu Node.js cu [SDK](#/guides/sdk). Aplicația apelează \`POST /mobile/orders/{id}/pay\` și primește linkul de plată; \`GET /mobile/orders/{id}/status\` arată dacă comanda este achitată.

\`\`\`javascript
import http from 'node:http';
import { PaymentStatus } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

// Într-un magazin real comanda se ia din baza de date după id: suma — din comandă, nu din cererea aplicației.
// expiryDate se salvează la crearea comenzii (de exemplu, expiryInHours(1)), astfel încât o nouă apăsare
// pe „Plătește” să trimită în Paynet exact aceeași cerere.
const findOrder = async (id) => ({ order: Number(id), amount: 300, customerCode: 'customer-42', customerPhone: '37360000000', expiryDate: '2026-11-10T19:00:00' });

http.createServer(async (req, res) => {
  const match = req.url.match(/^\\/mobile\\/orders\\/(\\d+)\\/(pay|status)$/);
  if (!match) return res.writeHead(404).end();
  const order = await findOrder(match[1]);

  if (match[2] === 'pay' && req.method === 'POST') {
    const { paymentLink } = await paynet.createOrder({
      Order: order.order,
      SaleAreaCode: 'onlidocumentation_md',
      LinkUrlSuccess: \`https://shop.example/app/payment/success?order=\${order.order}\`,
      LinkUrlCancel: \`https://shop.example/app/payment/cancel?order=\${order.order}\`,
      Customer: { Code: order.customerCode, PhoneNumber: order.customerPhone },
      ExpiryDate: order.expiryDate,
      Currency: 498,
      Services: [{ Name: 'My shop', Description: \`Order #\${order.order}\`, Amount: order.amount }],
      MoneyType: 'All',
      Lang: 'ro',
    });
    return res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ paymentLink }));
  }

  const payment = await paynet.getPaymentByOrder(order.order);
  res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ paid: payment.status === PaymentStatus.PAID, status: payment.status }));
}).listen(3000);
\`\`\`

Autorizați cererile aplicației către serverul dvs. la fel ca celelalte cereri ale aplicației. O nouă apăsare pe „Plătește” pentru aceeași comandă trebuie să trimită în Paynet **aceeași** cerere — atunci Paynet returnează aceeași plată.

## iOS: deschiderea paginii de plată

Folosiți \`SFSafariViewController\` — fereastra de sistem Safari în interiorul aplicației.

\`\`\`swift
import SafariServices
import UIKit

func openPayment(_ paymentLink: String, from viewController: UIViewController) {
    guard let url = URL(string: paymentLink) else { return }
    let safari = SFSafariViewController(url: url)
    viewController.present(safari, animated: true)
}
\`\`\`

## Android: deschiderea paginii de plată

Folosiți Chrome Custom Tabs (biblioteca \`androidx.browser\`).

\`\`\`kotlin
import android.content.Context
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent

fun openPayment(context: Context, paymentLink: String) {
    CustomTabsIntent.Builder().build().launchUrl(context, Uri.parse(paymentLink))
}
\`\`\`

## Revenirea în aplicație după plată

Setați în \`LinkUrlSuccess\` și \`LinkUrlCancel\` adrese ale site-ului dvs. legate de aplicație: **Universal Links** (iOS) și **App Links** (Android). După plată se deschide aplicația, iar dacă nu este instalată — site-ul dvs.

După revenire, aplicația **nu consideră comanda achitată** doar pentru că clientul s-a întors: întreabă serverul dvs. despre status (pasul 6). Dacă clientul a închis fereastra de plată înainte de final, aplicația întreabă și ea serverul.

## Recomandări

- **Nu folosiți WebView** pentru pagina de plată. În fereastra de sistem a browserului clientul vede adresa paginii Paynet, iar Apple Pay și Google Pay pot să nu funcționeze într-un WebView încorporat.
- **Luați suma din comanda de pe server**, nu din cererea aplicației.
- **Nu executați comanda înainte de confirmarea serverului**: notificare \`PAID\` cu semnătură verificată sau \`status\` = \`4\` prin API.
- **Testați pe dispozitive reale** înainte de lansare: plata cu cardul, Apple Pay (iPhone), Google Pay (Android), revenirea în aplicație, anularea plății.

## Ce verificați înainte de lansare

- [ ] Aplicația nu conține utilizatorul, parola, cheile sau tokenul Paynet.
- [ ] Comanda o creează serverul; suma se ia din comanda de pe server.
- [ ] Pagina de plată se deschide în \`SFSafariViewController\` / Chrome Custom Tabs, nu în WebView.
- [ ] După plată și după anulare clientul revine în aplicație.
- [ ] Aplicația află statusul comenzii de la server, iar serverul — din notificare sau prin API.
- [ ] O nouă apăsare pe „Plătește” nu creează a doua plată pentru aceeași comandă.
`,"../../content/ru/common/01-notifications.md":`# Уведомления (webhooks)

Когда платёж оплачен, Paynet отправляет HTTP \`POST\` с JSON-телом на callback URL, который вы зарегистрировали в Paynet. Уведомление одинаковое для всех типов интеграции.

**Уведомления приходят только об успешных платежах.** \`EventType\` всегда \`PAID\`. Если оплата не прошла, Paynet уведомление не отправляет — покупатель просто перенаправляется на ваш \`LinkUrlCancel\`. Считайте заказ неоплаченным, пока не получили проверенное уведомление \`PAID\` (или API статуса не показал оплату), и брошенным после его \`ExpiryDate\`.

## Запрос

\`\`\`http
POST https://shop.example/paynet/notification
Content-Type: application/json; charset=utf-8
Hash: lq3+OCn0J/zSyNF5iAoShg==
\`\`\`

\`\`\`json
{
  "Eventid": 1000001,
  "EventType": "PAID",
  "Message": "Request processed successfully",
  "EventDate": "2026-11-09T12:00:00",
  "Payment": {
    "Id": 1234567,
    "ExternalId": 1762444800000,
    "SaleAreaCode": "onlidocumentation_md",
    "Customer": "37369XXX111",
    "StatusDate": "2026-11-09T12:00:00",
    "Amount": 1235,
    "PaidAmount": 1235,
    "Merchant": "265505",
    "CardMask": "411111******1111",
    "CardExpireMonth": "12",
    "CardExpireYear": "27",
    "CardIssuer": "TEST BANK",
    "CardLinkHash": null,
    "MoneyType": "CARD",
    "PayerName": "Ion",
    "PayerSurname": "Popescu",
    "PayerIDNP": null,
    "RRN": "000000000000"
  }
}
\`\`\`

У запроса только два заголовка: \`Content-Type\` и \`Hash\`. Заголовка \`Authorization\` нет — подлинность подтверждает \`Hash\`.

## Поля

> **Важно:** в большинстве языков ключи JSON чувствительны к регистру. Ключи называются \`Id\` и \`ExternalId\` (не \`ID\` / \`ExternalID\`).

| Поле | Тип | Описание |
|---|---|---|
| \`Eventid\` | long | ID уведомления. |
| \`EventType\` | string | Всегда \`PAID\`. |
| \`Message\` | string | Текстовый статус, например \`Request processed successfully\`. |
| \`EventDate\` | string | Когда создано уведомление, \`YYYY-MM-DDTHH:mm:ss\`, местное время Кишинёва. |
| \`Payment.Id\` | long | ID платежа Paynet (\`paymentId\`). Используйте как ключ идемпотентности. |
| \`Payment.ExternalId\` | long | Ваш номер заказа (\`Order\`). |
| \`Payment.SaleAreaCode\` | string | Код торговой зоны. |
| \`Payment.Customer\` | string | Код покупателя, который вы передали в заказе (\`Customer.Code\`), обычно замаскирован, например \`37369XXX111\` или \`name***@gmail.com\`. |
| \`Payment.StatusDate\` | string | Когда платёж перешёл в этот статус (местное время Кишинёва). |
| \`Payment.Amount\` | long | Сумма заказа в минимальных единицах, как вы её передали. |
| \`Payment.PaidAmount\` | long | Фактически оплаченная покупателем сумма, в минимальных единицах. См. ниже. |
| \`Payment.Merchant\` | string | Ваш код мерчанта. |
| \`Payment.MoneyType\` | string | Чем заплатил покупатель: \`CARD\`, \`APPLEPAY\`, \`GOOGLEPAY\`, \`MIA_QR\`, \`PAYNET\`, \`CASH_INVOICE\`. |
| \`Payment.CardMask\`, \`CardExpireMonth\`, \`CardExpireYear\`, \`CardIssuer\` | string | Данные карты. Заполнены для \`CARD\`, а также для \`APPLEPAY\` и \`GOOGLEPAY\` (карта внутри кошелька); \`null\` для других способов оплаты. |
| \`Payment.CardLinkHash\` | string | Токен сохранённой карты: приходит, если для вашего \`SaleAreaCode\` включено [сохранение карт](#/guides/saved-cards) и покупатель не снял галочку; иначе \`null\`. |
| \`Payment.PayerName\`, \`PayerSurname\`, \`PayerIDNP\` | string | Данные плательщика; могут быть \`null\`. |
| \`Payment.RRN\` | string | Retrieval reference number. |
| \`Hash\` (HTTP-заголовок) | string | Подпись уведомления. |

Неизвестные поля игнорируйте: могут добавиться новые необязательные поля.

Значения \`MoneyType\` в уведомлении не совпадают со значениями в запросе на создание заказа (\`Card\`, \`All\`, …). Не сравнивайте их напрямую.

### Amount и PaidAmount

\`PaidAmount\` должен совпадать с \`Amount\`.

Они могут различаться **только** если ваша компания официально согласовала с Paynet акцию или скидку (например, 10% при оплате картой Mastercard определённого BIN). Такую акцию Paynet настраивает на своей стороне по вашему запросу, через API её включить нельзя.

> **Важно:** если у вас нет такой согласованной акции, а \`PaidAmount\` не равен \`Amount\`, не выполняйте заказ автоматически. Сохраните уведомление и свяжитесь с Paynet.

Расчёты: вы получаете \`PaidAmount\` за вычетом комиссии Paynet. Учитывайте это при сверке с выпиской.

## Проверка подписи

\`\`\`text
PreparedString = EventDate + Eventid + EventType + Payment.Amount + Payment.Customer +
                 Payment.ExternalId + Payment.Id + Payment.Merchant + Payment.StatusDate
ExpectedHash   = Base64( MD5( UTF8( PreparedString + NotificationSecretKey ) ) )
\`\`\`

- Берите значения ровно так, как они записаны в JSON. Отсутствующее значение или \`null\` — пустая строка.
- Порядок фиксированный — ровно как в строке выше. **Не сортируйте имена программно:** обычная сортировка ставит \`EventType\` перед \`Eventid\`, и хэш не совпадёт.
- Используйте секретный ключ **уведомлений** (он отличается от ключа checkout).
- Сравните \`ExpectedHash\` с заголовком \`Hash\`. Если не совпадает — отклоните запрос (например, HTTP \`400\`) и не меняйте заказ.

Разобранный пример с ожидаемым результатом: [Подписи](#/guides/signatures).

### Node.js (Express)

\`\`\`javascript
import crypto from 'node:crypto';
import express from 'express';

const SECRET = process.env.PAYNET_NOTIFICATION_SECRET;
const s = (v) => (v === null || v === undefined ? '' : String(v));

function expectedHash(n) {
  const p = n.Payment || {};
  const prepared = s(n.EventDate) + s(n.Eventid) + s(n.EventType) + s(p.Amount) + s(p.Customer) +
    s(p.ExternalId) + s(p.Id) + s(p.Merchant) + s(p.StatusDate);
  return crypto.createHash('md5').update(prepared + SECRET, 'utf8').digest('base64');
}

const app = express();
app.post('/paynet/notification', express.json(), async (req, res) => {
  const received = req.get('Hash') || '';
  const expected = expectedHash(req.body);
  const ok = received.length === expected.length &&
    crypto.timingSafeEqual(Buffer.from(received), Buffer.from(expected));
  if (!ok) return res.status(400).send('Invalid hash');

  const p = req.body.Payment;
  // Process each Payment.Id only once (idempotency).
  // If PaidAmount !== Amount and you have no agreed promotion: do not fulfil, contact Paynet.
  // await markOrderPaidOnce(p.Id, p.ExternalId, p.Amount, p.PaidAmount);
  res.status(200).json({ ResultCode: 'SUCCESS' });
});
\`\`\`

### PHP

\`\`\`php
<?php
$secret = getenv('PAYNET_NOTIFICATION_SECRET');
$body   = file_get_contents('php://input');
$n      = json_decode($body, true);
$p      = $n['Payment'] ?? [];
$s      = fn($v) => $v === null ? '' : (string) $v;

$prepared = $s($n['EventDate'] ?? null) . $s($n['Eventid'] ?? null) . $s($n['EventType'] ?? null)
          . $s($p['Amount'] ?? null) . $s($p['Customer'] ?? null) . $s($p['ExternalId'] ?? null)
          . $s($p['Id'] ?? null) . $s($p['Merchant'] ?? null) . $s($p['StatusDate'] ?? null);
$expected = base64_encode(md5($prepared . $secret, true));

if (!hash_equals($expected, $_SERVER['HTTP_HASH'] ?? '')) {
    http_response_code(400);
    exit('Invalid hash');
}
// Process once per Payment.Id; check PaidAmount === Amount (unless a promotion is agreed), then:
http_response_code(200);
echo json_encode(['ResultCode' => 'SUCCESS']);
\`\`\`

> **Важно:** собирайте \`PreparedString\` из значений ровно в том виде, в каком они записаны в JSON. Не переформатируйте даты (оставляйте \`2026-11-09T12:00:00\` как есть) и не меняйте запись чисел.

## Что защищает подпись и сверка через API

Заголовок \`Hash\` защищает только поля, которые входят в \`PreparedString\`:

| Подписаны (проверяются через \`Hash\`) | Не подписаны |
|---|---|
| \`EventDate\`, \`Eventid\`, \`EventType\`, \`Payment.Amount\`, \`Payment.Customer\`, \`Payment.ExternalId\`, \`Payment.Id\`, \`Payment.Merchant\`, \`Payment.StatusDate\` | \`Payment.PaidAmount\`, \`Payment.MoneyType\`, \`Payment.CardLinkHash\`, \`Payment.SaleAreaCode\`, данные карты и плательщика (\`CardMask\`, \`CardIssuer\`, \`PayerName\`…), \`Message\` |

Верный \`Hash\` подтверждает, что заказ \`ExternalId\` оплачен на сумму \`Amount\`. Он **не** подтверждает неподписанные поля. Прежде чем принимать по ним решения — какую сумму считать полученной, сохранять ли карту — сверьте их с ответом авторизованного API \`GET /api/order/merchant/{Order}\`. Этот ответ защищён вашим токеном и HTTPS.

Сравнивайте значения, а не просто вызывайте метод:

| Что сверить | Уведомление | Ответ API |
|---|---|---|
| Платёж | \`Payment.Id\` | \`paymentId\` |
| Статус | \`EventType\` = \`PAID\` | \`status\` = \`4\` |
| Сумма заказа | \`Payment.Amount\` (и ваша сумма заказа) | \`amount.amount\` |
| Оплаченная сумма | \`Payment.PaidAmount\` | \`amount.paidAmount\` |
| Покупатель | ваш заказ | \`customer.code\` |
| Сохранённая карта | \`Payment.CardLinkHash\` | \`cardLinkHash\`, если API его вернул |

Если значения различаются, не выполняйте заказ автоматически и не сохраняйте карту: отправьте заказ на ручную проверку.

Если подпись верна, но заказ выполнить нельзя (заказ не найден, суммы не совпадают), всё равно ответьте \`200\` и отправьте заказ на проверку: иначе Paynet продолжит повторять уведомление.

### Полный обработчик: Node.js

Проверяет подпись, сохраняет уведомление один раз, отвечает \`200\`, затем сверяет значения через API и выполняет заказ или отправляет его на проверку. Логика этого примера проверяется автоматически при каждой сборке документации.

\`\`\`javascript
// paynet-notifications.mjs — complete notification handler, no dependencies (Node.js 18+).
import crypto from 'node:crypto';

// The 9 signed fields, in this exact order. Do not sort.
const signedValues = (n) => {
  const p = n.Payment || {};
  return [n.EventDate, n.Eventid, n.EventType, p.Amount, p.Customer, p.ExternalId, p.Id, p.Merchant, p.StatusDate];
};

export function verifyHash(notification, hashHeader, secret) {
  const prepared = signedValues(notification).map((v) => (v === null || v === undefined ? '' : String(v))).join('');
  const expected = crypto.createHash('md5').update(prepared + secret, 'utf8').digest('base64');
  const received = String(hashHeader || '');
  return received.length === expected.length && crypto.timingSafeEqual(Buffer.from(received), Buffer.from(expected));
}

/**
 * deps.secret      notification secret key
 * deps.apiUrl      https://ecom-api.paynet.md (test: https://ecom-api-test.paynet.md)
 * deps.getToken()  returns a valid Bearer token (POST /auth, cached)
 * deps.fetch       fetch implementation (globalThis.fetch)
 * deps.db          your storage:
 *   saveNotificationOnce(paymentId, notification) -> true if new, false if already stored
 *   findOrder(order) -> { amount, customerCode, promotionAgreed } or null
 *   markPaid(order, paidAmount), saveCard(customerCode, cardLinkHash), sendToReview(order, problems)
 *
 * handle(rawBody, hashHeader) -> { status, processing }
 *   status: HTTP status to answer Paynet; processing: promise of the work done after answering.
 */
export function createPaynetHandler(deps) {
  const { db } = deps;

  async function confirmWithApi(n, order) {
    const p = n.Payment;
    const response = await deps.fetch(\`\${deps.apiUrl}/api/order/merchant/\${p.ExternalId}\`, {
      headers: { Authorization: \`Bearer \${await deps.getToken()}\` },
    });
    if (!response.ok) throw new Error(\`Status check failed: HTTP \${response.status}\`);
    const payment = await response.json();

    const problems = [];
    if (payment.paymentId !== p.Id) problems.push('paymentId');
    if (payment.status !== 4) problems.push('status');
    if (payment.amount?.amount !== p.Amount || p.Amount !== order.amount) problems.push('Amount');
    if (payment.amount?.paidAmount !== p.PaidAmount) problems.push('PaidAmount');
    if (payment.customer?.code !== order.customerCode) problems.push('customer');
    if (p.CardLinkHash && payment.cardLinkHash && payment.cardLinkHash !== p.CardLinkHash) problems.push('CardLinkHash');
    return problems;
  }

  async function process(n) {
    const p = n.Payment;
    if (n.EventType !== 'PAID') return db.sendToReview(p.ExternalId, ['EventType']);
    const order = await db.findOrder(p.ExternalId);
    if (!order) return db.sendToReview(p.ExternalId, ['unknown order']);

    const problems = await confirmWithApi(n, order);
    if (p.PaidAmount !== p.Amount && !order.promotionAgreed) problems.push('PaidAmount differs from Amount');
    if (problems.length) return db.sendToReview(p.ExternalId, problems);

    await db.markPaid(p.ExternalId, p.PaidAmount);
    if (p.CardLinkHash) await db.saveCard(order.customerCode, p.CardLinkHash);
  }

  return async function handle(rawBody, hashHeader) {
    let n;
    try {
      n = JSON.parse(rawBody);
    } catch {
      return { status: 400, processing: null };
    }
    if (!verifyHash(n, hashHeader, deps.secret)) return { status: 400, processing: null };

    const isNew = await db.saveNotificationOnce(n.Payment?.Id, n); // idempotency by Payment.Id
    if (!isNew) return { status: 200, processing: null }; // a retry: already stored
    // Answer 200 now; confirm and fulfil after the answer. If this work fails, the stored
    // notification stays unprocessed and a background job can retry it.
    return { status: 200, processing: process(n) };
  };
}
\`\`\`

Connecting it to Express (read the raw body, answer first, process after):

\`\`\`javascript
import express from 'express';
import { createPaynetHandler } from './paynet-notifications.mjs';

const handle = createPaynetHandler({
  secret: process.env.PAYNET_NOTIFICATION_SECRET,
  apiUrl: process.env.PAYNET_API_URL,
  getToken, // your cached POST /auth
  fetch: globalThis.fetch,
  db, // your storage
});

const app = express();
app.post('/paynet/notification', express.text({ type: '*/*' }), async (req, res) => {
  const { status, processing } = await handle(req.body, req.get('Hash'));
  res.status(status).json(status === 200 ? { ResultCode: 'SUCCESS' } : { error: 'Invalid notification' });
  processing?.catch((error) => console.error('Paynet notification processing failed', error));
});
\`\`\`

### Полный обработчик: PHP

\`\`\`php
<?php
// paynet-notification.php — complete notification handler (PHP 7.4+, ext-curl).
// $db must implement: saveNotificationOnce($paymentId, array $n): bool, findOrder($order): ?array
// (['amount' => int, 'customerCode' => string, 'promotionAgreed' => bool]), markPaid($order, $paidAmount),
// saveCard($customerCode, $cardLinkHash), sendToReview($order, array $problems).

function paynetVerifyHash(array $n, string $hashHeader, string $secret): bool {
    $p = $n['Payment'] ?? [];
    $s = fn($v) => $v === null ? '' : (string) $v;
    // The 9 signed fields, in this exact order. Do not sort.
    $prepared = $s($n['EventDate'] ?? null) . $s($n['Eventid'] ?? null) . $s($n['EventType'] ?? null)
              . $s($p['Amount'] ?? null) . $s($p['Customer'] ?? null) . $s($p['ExternalId'] ?? null)
              . $s($p['Id'] ?? null) . $s($p['Merchant'] ?? null) . $s($p['StatusDate'] ?? null);
    $expected = base64_encode(md5($prepared . $secret, true));
    return hash_equals($expected, $hashHeader);
}

function paynetConfirmWithApi(array $n, array $order, string $apiUrl, string $token): array {
    $p  = $n['Payment'];
    $ch = curl_init($apiUrl . '/api/order/merchant/' . $p['ExternalId']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code !== 200) throw new RuntimeException("Status check failed: HTTP $code");
    $pay = json_decode($body, true);

    $problems = [];
    if (($pay['paymentId'] ?? null) !== $p['Id']) $problems[] = 'paymentId';
    if (($pay['status'] ?? null) !== 4) $problems[] = 'status';
    if (($pay['amount']['amount'] ?? null) !== $p['Amount'] || $p['Amount'] !== $order['amount']) $problems[] = 'Amount';
    if (($pay['amount']['paidAmount'] ?? null) !== ($p['PaidAmount'] ?? null)) $problems[] = 'PaidAmount';
    if (($pay['customer']['code'] ?? null) !== $order['customerCode']) $problems[] = 'customer';
    if (!empty($p['CardLinkHash']) && !empty($pay['cardLinkHash']) && $pay['cardLinkHash'] !== $p['CardLinkHash']) $problems[] = 'CardLinkHash';
    return $problems;
}

function paynetProcess(array $n, $db, string $apiUrl, string $token): void {
    $p = $n['Payment'];
    if (($n['EventType'] ?? '') !== 'PAID') { $db->sendToReview($p['ExternalId'], ['EventType']); return; }
    $order = $db->findOrder($p['ExternalId']);
    if (!$order) { $db->sendToReview($p['ExternalId'], ['unknown order']); return; }

    $problems = paynetConfirmWithApi($n, $order, $apiUrl, $token);
    if (($p['PaidAmount'] ?? null) !== $p['Amount'] && empty($order['promotionAgreed'])) $problems[] = 'PaidAmount differs from Amount';
    if ($problems) { $db->sendToReview($p['ExternalId'], $problems); return; }

    $db->markPaid($p['ExternalId'], $p['PaidAmount']);
    if (!empty($p['CardLinkHash'])) $db->saveCard($order['customerCode'], $p['CardLinkHash']);
}

// --- Endpoint -------------------------------------------------------------
function paynetHandleRequest($db, callable $getToken): void {
    $raw = file_get_contents('php://input');
    $n   = json_decode($raw, true);
    if (!is_array($n) || !paynetVerifyHash($n, $_SERVER['HTTP_HASH'] ?? '', getenv('PAYNET_NOTIFICATION_SECRET'))) {
        http_response_code(400);
        exit('Invalid notification');
    }
    $isNew = $db->saveNotificationOnce($n['Payment']['Id'] ?? null, $n); // idempotency by Payment.Id

    // Answer 200 first.
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['ResultCode' => 'SUCCESS']);
    if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();

    if ($isNew) {
        try {
            paynetProcess($n, $db, getenv('PAYNET_API_URL'), $getToken());
        } catch (Throwable $e) {
            error_log('Paynet notification processing failed: ' . $e->getMessage()); // retry from storage later
        }
    }
}
\`\`\`

## Ответ и повторы

- Отвечайте HTTP \`200\` **после** того, как проверили хэш и сохранили результат.
- Отвечайте быстро: сохраните уведомление, верните \`200\`, а тяжёлую обработку выполняйте после ответа.
- Любой другой ответ (или отсутствие ответа) считается ошибкой, и Paynet отправляет уведомление повторно. После ответа \`200\` повторы прекращаются.
- Важен только HTTP-код; тело ответа значения не имеет. \`{ "ResultCode": "SUCCESS" }\` в примерах необязательно.
- Расписание — **9 попыток**; повторы идут примерно 25 минут после первой попытки, затем отправка прекращается:

| Попытка | Когда |
|---|---|
| 1 | после того как банк-эмитент подтвердил оплату (зависит от банка: от нескольких секунд до нескольких минут) |
| 2–4 | через ~1 минуту, затем каждые ~35 секунд |
| 5–7 | через ~5 минут, затем каждые ~35 секунд |
| 8–9 | через ~15 минут, затем через ~35 секунд |

> **Важно:** повторы идут всего около 25 минут после первой попытки. Если ваш сервер был недоступен дольше, уведомление больше не придёт. Поэтому проверяйте статус неоплаченных заказов через API и делайте ежедневную сверку.

- Из-за повторов одно и то же уведомление может прийти несколько раз. Обрабатывайте каждый \`Payment.Id\` один раз.
- Если уведомление не пришло (например, сервер был недоступен дольше всех попыток), проверьте статус через \`GET /api/order/{paymentId}\` или \`GET /api/order/merchant/{Order}\`. Повторную отправку можно запросить в поддержке Paynet.
- Если ваш сервер закрыт файрволом, разрешите входящие запросы с IP-адресов Paynet: \`93.113.159.22\` — продакшн, \`93.113.159.23\` — тестовая среда.
- Оплату, по которой пришло \`PAID\`, антифрод уже не отменит: он срабатывает до подтверждения оплаты. Статус оплаченного платежа меняется только после вашего [возврата](#/guides/errors-and-statuses) (\`5\` или \`6\`).

## Симулятор уведомлений на портале

Откройте **Общее → Уведомления → Симулятор уведомлений**:

1. Введите ваш callback URL. Он должен быть доступен из интернета и, **только для симулятора**, принимать запросы из браузера (CORS).
2. Проверьте секретный ключ уведомлений: тестовый ключ \`D9873689-E5F8-4272-A67F-0D8BA3F9BAA7\` уже подставлен, свой ключ можно вписать вместо него.
3. Введите номер заказа мерчанта (\`Order\`) **оплаченного** тестового платежа и нажмите **Get** — портал загрузит платёж.
4. Нажмите **Send notification** — портал отправит на ваш URL подписанное уведомление \`PAID\` по этому платежу и покажет использованные \`PreparedString\` и \`Hash\`.

Это симуляция из вашего браузера, а не настоящее уведомление Paynet. Для неоплаченных заказов симулятор ничего не отправляет — так же, как Paynet.

> **Важно:** CORS нужен только симулятору, потому что он отправляет запрос из браузера. Настоящие уведомления отправляет сервер Paynet, и CORS на них не влияет: не включайте CORS на боевом endpoint ради Paynet. Успешная симуляция проверяет вашу проверку подписи и обработку, но не доставку от Paynet (доступ из сети, firewall, TLS-сертификат). Доставку подтвердите настоящим тестовым платежом.
`,"../../content/ru/common/02-signatures.md":'# Подписи\n\nPaynet везде использует одну схему хэширования:\n\n```text\nSignature = Base64( MD5( <string to sign> + SecretKey ) )\n```\n\n- MD5 считается по байтам строки в **UTF-8** (в том числе для кириллицы и румынской диакритики).\n- Base64 берётся от **«сырого» 16-байтового дайджеста** (не от 32-символьной hex-строки). Результат всегда 24 символа и заканчивается на `==`.\n- Не путайте с полем `signature` в ответе `POST /api/order`: это служебное значение ссылки на оплату (32 символа, совпадает с параметром `s` в `paymentLink`). Для проверок его не используйте.\n\nОтличается только то, как собирается подписываемая строка:\n\n| Где | Подписываемая строка | Секретный ключ |\n|---|---|---|\n| Форма hosted checkout (вы → Paynet) | `RawData`: значения подписываемых полей, отсортированные по имени поля, закодированные RFC 3986, склеенные | ключ hosted checkout |\n| Уведомления (Paynet → вы) | `PreparedString`: 9 значений уведомления в фиксированном порядке | ключ уведомлений |\n\nДва секретных ключа разные намеренно. Paynet выдаёт вам оба.\n\n## Тестовый вектор 1: форма hosted checkout\n\nСекретный ключ (тест): `F90D6485-9CCC-458B-96A3-8958AF9B4458`\n\nВходные поля:\n\n```json\n{\n  "Order": 1762444800000,\n  "Currency": "498",\n  "Merchant": "265505",\n  "SaleAreaCode": "onlidocumentation_md",\n  "Amount": "1235",\n  "Description": "Test&Co SRL",\n  "CustomerCode": "5555",\n  "CustomerNameFirst": "First name",\n  "CustomerNameLast": "Last name",\n  "CustomerPhoneNumber": "060000000",\n  "CustomerEmail": "test@gmail.com",\n  "ExpiryDate": "2026-12-31T23:59:59",\n  "LinkUrlCancel": "https://test.oplta.md/cancel",\n  "LinkUrlSuccess": "https://test.oplta.md/ok",\n  "Lang": "ro",\n  "MoneyType": "Card"\n}\n```\n\nПорядок полей после сортировки: `Amount, Currency, CustomerCode, CustomerEmail, CustomerNameFirst, CustomerNameLast, CustomerPhoneNumber, Description, ExpiryDate, Lang, LinkUrlCancel, LinkUrlSuccess, Merchant, MoneyType, Order, SaleAreaCode`.\n\nОжидаемый `RawData`:\n\n```text\n12354985555test%40gmail.comFirst%20nameLast%20name060000000Test%26Co%20SRL2026-12-31T23%3A59%3A59rohttps%3A%2F%2Ftest.oplta.md%2Fcancelhttps%3A%2F%2Ftest.oplta.md%2Fok265505Card1762444800000onlidocumentation_md\n```\n\nОжидаемая `Signature`:\n\n```text\ncxr/+yLYZp34aR0KXLkb2A==\n```\n\n## Тестовый вектор 2: уведомление\n\nСекретный ключ уведомлений (тест): `D9873689-E5F8-4272-A67F-0D8BA3F9BAA7`\n\n```json\n{\n  "Eventid": 1000001,\n  "EventType": "PAID",\n  "EventDate": "2026-11-09T12:00:00",\n  "Payment": {\n    "Id": 1234567,\n    "ExternalId": 1762444800000,\n    "Merchant": "265505",\n    "Customer": "37369XXX111",\n    "StatusDate": "2026-11-09T12:00:00",\n    "Amount": 1235\n  }\n}\n```\n\n(Показаны только поля, участвующие в подписи; в настоящем уведомлении их больше, см. [Уведомления](#/guides/notifications).)\n\nОжидаемый `PreparedString`:\n\n```text\n2026-11-09T12:00:001000001PAID123537369XXX111176244480000012345672655052026-11-09T12:00:00\n```\n\nОжидаемый `Hash`:\n\n```text\nlq3+OCn0J/zSyNF5iAoShg==\n```\n\n## Тестовый вектор 3: спецсимволы\n\nТот же секретный ключ, что в векторе 1. В значениях есть `\'`, `&`, `!`, `(`, `)`, `*`, кириллица и румынские буквы. Тестовая среда приняла именно эту форму (11.11.2026).\n\n```json\n{\n  "Order": 1762444800003,\n  "Currency": "498",\n  "Merchant": "265505",\n  "SaleAreaCode": "onlidocumentation_md",\n  "Amount": "1235",\n  "Description": "Mary\'s Cake & Co! (1)*",\n  "CustomerCode": "5555",\n  "CustomerNameFirst": "Мария",\n  "CustomerNameLast": "Țurcan",\n  "ExpiryDate": "2026-12-31T23:59:59",\n  "LinkUrlCancel": "https://test.oplta.md/cancel",\n  "LinkUrlSuccess": "https://test.oplta.md/ok",\n  "Lang": "ro",\n  "MoneyType": "Card"\n}\n```\n\nОжидаемый `RawData`:\n\n```text\n12354985555%D0%9C%D0%B0%D1%80%D0%B8%D1%8F%C8%9AurcanMary%27s%20Cake%20%26%20Co%21%20%281%29%2A2026-12-31T23%3A59%3A59rohttps%3A%2F%2Ftest.oplta.md%2Fcancelhttps%3A%2F%2Ftest.oplta.md%2Fok265505Card1762444800003onlidocumentation_md\n```\n\nОжидаемая `Signature`:\n\n```text\nfm47qWzVzqPQQ+huHgWVZw==\n```\n\n## Спецсимволы\n\nРезультаты реальных отправок формы в тестовую среду:\n\n| В значении есть | Результат |\n|---|---|\n| `" \' & < > # ; % + = ? / \\`, `’`, эмодзи, кириллица, румынские буквы | Работает, если каждое значение закодировано по RFC 3986 (таблица ниже). |\n| Перенос строки (многострочный `Description`) | Подпись не сходится. Замените переносы строк пробелом до подписи. |\n| HTML-тег (`<b>`) или HTML-сущность (`&#039;`) | Paynet отклоняет форму ещё до проверки подписи: покупатель видит главную страницу Paynet вместо платёжной. Уберите теги и замените сущности обычными символами до подписи. |\n\nФункция кодирования по языкам:\n\n| Язык | Правильно | Неправильно (ломается на части символов) |\n|---|---|---|\n| PHP | `rawurlencode($v)` | `urlencode($v)`: пробел становится `+`, `~` — `%7E` |\n| JavaScript / Node.js | `encodeURIComponent(v).replace(/[!\'()*]/g, (c) => \'%\' + c.charCodeAt(0).toString(16).toUpperCase())` | один `encodeURIComponent(v)`: не кодирует `! \' ( ) *` |\n| Python | `urllib.parse.quote(v, safe="~")` | `quote(v)` (не кодирует `/`), `quote_plus(v)` (пробел становится `+`) |\n| C# | `Uri.EscapeDataString(v)` (.NET Core / .NET 5+) | `HttpUtility.UrlEncode`, `WebUtility.UrlEncode`: пробел становится `+` |\n| Java | `URLEncoder.encode(v, StandardCharsets.UTF_8).replace("+", "%20").replace("*", "%2A").replace("%7E", "~")` | один `URLEncoder.encode`: пробел становится `+`, `*` не кодируется |\n\nПравила:\n\n- Подписывайте исходные значения — ровно то, что отправит браузер. Не подписывайте текст, экранированный для HTML (`&amp;`, `&#039;`).\n- Экранируйте значения для HTML один раз — когда пишете их в форму (`&` → `&amp;`, `"` → `&quot;`). Неэкранированная `"` обрезает значение внутри `value="…"`.\n- Не меняйте значения после подписи (обрезка пробелов, замена символов, сокращение).\n- Отдавайте страницу в UTF-8 (`<meta charset="utf-8">`) и добавьте в форму `accept-charset="UTF-8"`.\n- Если CMS отдаёт названия товаров с HTML-сущностями (`Mary&#039;s`), раскодируйте их (`Mary\'s`) до сборки формы.\n\n## Проверьте свою реализацию\n\nPython:\n\n```python\nimport base64, hashlib, urllib.parse\n\ndef md5_base64(text: str) -> str:\n    return base64.b64encode(hashlib.md5(text.encode("utf-8")).digest()).decode()\n\nSIGNED = ["Order", "Currency", "Merchant", "SaleAreaCode", "CustomerCode", "CustomerNameFirst",\n          "CustomerNameLast", "CustomerPhoneNumber", "CustomerEmail", "ExpiryDate", "Description",\n          "Amount", "LinkUrlCancel", "LinkUrlSuccess", "Lang", "MoneyType"]\n\ndef checkout_signature(fields: dict, secret: str) -> str:\n    names = sorted(n for n in SIGNED if fields.get(n) is not None)\n    raw = "".join(urllib.parse.quote(str(fields[n]), safe="~") for n in names)\n    return md5_base64(raw + secret)\n\ndef notification_hash(n: dict, secret: str) -> str:\n    s = lambda v: "" if v is None else str(v)\n    p = n.get("Payment", {})\n    prepared = (s(n.get("EventDate")) + s(n.get("Eventid")) + s(n.get("EventType")) + s(p.get("Amount"))\n                + s(p.get("Customer")) + s(p.get("ExternalId")) + s(p.get("Id")) + s(p.get("Merchant"))\n                + s(p.get("StatusDate")))\n    return md5_base64(prepared + secret)\n```\n\nC#:\n\n```csharp\nusing System.Security.Cryptography;\nusing System.Text;\n\nstatic string Md5Base64(string text) =>\n    Convert.ToBase64String(MD5.HashData(Encoding.UTF8.GetBytes(text)));\n\n// Hosted checkout form: Uri.EscapeDataString implements RFC 3986.\nstatic string CheckoutSignature(IDictionary<string, string?> fields, string secret)\n{\n    string[] signed = { "Order", "Currency", "Merchant", "SaleAreaCode", "CustomerCode", "CustomerNameFirst",\n        "CustomerNameLast", "CustomerPhoneNumber", "CustomerEmail", "ExpiryDate", "Description", "Amount",\n        "LinkUrlCancel", "LinkUrlSuccess", "Lang", "MoneyType" };\n    var raw = new StringBuilder();\n    foreach (var name in signed.Where(n => fields.TryGetValue(n, out var v) && v != null).OrderBy(n => n, StringComparer.Ordinal))\n        raw.Append(Uri.EscapeDataString(fields[name]!));\n    return Md5Base64(raw + secret);\n}\n```\n\n## Частые ошибки\n\n| Симптом | Причина |\n|---|---|\n| Подпись из 32 hex-символов | Вы закодировали в Base64 hex-строку или не закодировали вовсе. Кодируйте «сырой» дайджест. |\n| Работает для одних заказов и не работает для других | Значения с пробелами, `&`, `@`, `:` или `/` не закодированы по RFC 3986, или пробел закодирован как `+` вместо `%20`. |\n| Хэш уведомления никогда не совпадает | Не тот секретный ключ (ключи checkout и уведомлений разные), поля в неправильном порядке, или код читает `Payment.ID` / `Payment.ExternalID` вместо `Payment.Id` / `Payment.ExternalId` (ключи чувствительны к регистру). |\n| Хэш отличается только для имён на кириллице/румынском | Строка не была закодирована в UTF-8 перед хэшированием. |\n| Подпись перестала сходиться после добавления поля | Подписываемое поле добавили в форму, но не в `RawData` (или наоборот). |\n| Не работает, только когда в значении есть `\'`, `!`, `(`, `)` или `*` | `encodeURIComponent` (или другая функция) не кодирует эти пять символов. См. «Спецсимволы» выше. |\n| После отправки формы открывается главная страница Paynet вместо платёжной | В значении есть HTML-тег (`<b>`) или HTML-сущность (`&#039;`). См. «Спецсимволы» выше. |\n| Не работает, когда в `Description` несколько строк | Перенос строки в значении. Замените его пробелом до подписи. |\n',"../../content/ru/common/03-errors-and-statuses.md":'# Ошибки и статусы\n\n## Шпаргалка: что делать при ошибке\n\nПроверено на тестовой среде 10.11.2026. Подробности о каждом формате — в разделах ниже.\n\n| HTTP | Что в ответе | Когда бывает | Что делать | Повторять запрос? |\n|---|---|---|---|---|\n| `400` | `INVALID_PARAMETER`, в `details` — имя поля | Неверное значение параметра | Исправить поле из `details` | Только после исправления |\n| `400` | `errorInfo`, в `errors` — список полей | Нечитаемый JSON, нет обязательных полей, неверный тип (например, буквы вместо числа в `paymentId` в адресе) | Исправить запрос | Только после исправления |\n| `401` | `UNAUTHORIZED` (ключи с большой буквы: `Status`, `Code`…) | Нет токена, он неверный или истёк | Получить новый токен через `/auth` | Да, один раз с новым токеном |\n| `401` | `AUTHENTICATION_FAILED` | `/auth`: неверный логин или пароль | Проверить данные доступа (у теста и продакшна они разные) | Нет |\n| `404` | `NOT_FOUND_RECORD` | Нет платежа с таким ID; возврат неоплаченного платежа; поиск: за период нет платежей (это пустой результат) | Проверить `paymentId` / `Order` и статус платежа; для поиска — считать результат пустым | Нет |\n| `404` | Пустое тело | Неверный адрес (путь) | Проверить URL и адрес API | Нет |\n| `405` | Пустое тело | Неверный HTTP-метод (например, `GET` вместо `POST`) | Проверить метод | Только после исправления |\n| `415` | Пустое тело | Нет заголовка `Content-Type: application/json` или формат не JSON (в том числе у `/auth`) | Добавить заголовок, отправлять JSON | Только после исправления |\n| `500` | `TECHNICAL_ERROR` | Повтор `Order` с другими данными или после оплаты; либо сбой на стороне Paynet | Сначала проверить `GET /api/order/merchant/{Order}`. Если это повтор `Order` — создать заказ с новым `Order` | Только после проверки |\n| — | Нет ответа (таймаут, сеть) | Проблема связи | Проверить заказ по `Order`; если его нет — повторить **тот же** запрос без изменений | Да, с тем же телом |\n\n- Ответов `403`, `429` и `503` на тестовой среде не было. Ограничение частоты не наблюдалось: 100 параллельных запросов прошли с `200`. Официальных лимитов Paynet не публикует, поэтому не отправляйте запросы в цикле без паузы.\n- В `errorInfo` поле `ppResponseCodeDescription` может содержать «We are sorry, this service is temporarily unavailable» даже при обычной ошибке валидации. Ориентируйтесь на `errors`, а не на этот текст, и не показывайте его покупателю.\n- Если пришёл `401` по токену: получите новый токен и повторите запрос **один** раз. Если снова `401` — проверьте данные доступа.\n\n## HTTP-коды\n\n| HTTP | `code` | Значение | Что делать |\n|---|---|---|---|\n| `200` | — | Успех. | — |\n| `400` | `INVALID_PARAMETER` | Один или несколько параметров отсутствуют или неверны. `details` называет параметр. | Исправьте запрос. Не повторяйте без изменений. |\n| `401` | `UNAUTHORIZED` | Bearer-токен отсутствует, неверен или истёк. | Снова вызовите `/auth` и повторите запрос один раз. |\n| `404` | `NOT_FOUND_RECORD` | Нет платежа/записи с таким ID. | Проверьте ID (`paymentId` или ваш `Order`). |\n| `500` | `TECHNICAL_ERROR` | Ошибка на стороне Paynet **или** повтор `Order`, который нельзя использовать снова (см. ниже). | Проверьте через `GET /api/order/merchant/{Order}`, существует ли заказ; если это настоящая техническая ошибка — повторите позже с паузой. |\n| `401` | `AUTHENTICATION_FAILED` | `/auth` с неверным логином или паролем. | Проверьте учётные данные. |\n\n## Тело ошибки\n\n```json\n{\n  "status": 400,\n  "message": "One or more entered parameters are incorrect.",\n  "code": "INVALID_PARAMETER",\n  "traceId": "9b9346f9-f83a-465d-ac8d-dc382c460c22",\n  "details": "The invalid parameter is: XXXX"\n}\n```\n\n| Поле | Описание |\n|---|---|\n| `status` | HTTP-статус. |\n| `message` | Сообщение для человека. |\n| `code` | Машиночитаемый код ошибки (таблица выше). |\n| `traceId` | ID запроса. Передайте его в поддержку Paynet, когда сообщаете о проблеме. |\n| `details` | Дополнительная информация, например неверный параметр. |\n\n> **Примечание:** ответ `401` на отсутствующий, неверный или просроченный токен использует ключи с большой буквы (`Status`, `Message`, `Code`, `TraceId`), а `401` от `/auth` на неверный пароль — обычные (`status`, `message`…). Читайте поля ошибки без учёта регистра.\n\n### Неверный JSON или нет обязательных полей\n\nЕсли тело запроса нельзя прочитать (неверный JSON, неверные типы, нет обязательного поля), API отвечает `400` в другом формате — ошибка внутри `errorInfo`:\n\n```json\n{\n  "errorInfo": {\n    "title": "One or more validation errors occurred.",\n    "status": 400,\n    "ppResponseCodeEnum": "TECHNICAL_ERROR",\n    "ppResponseCode": 1,\n    "ppResponseCodeText": "TECHNICAL_ERROR",\n    "errors": {\n      "$": ["JSON deserialization for type \'…DeleteLinkedCardRequest\' was missing required properties including: \'cardLinkHash\', \'saleAreaCode\', \'customerCode\'."]\n    },\n    "traceId": "00-7c209d88f31e3e5cd2f7bd88ae2f23c2-ad167338e418068c-00"\n  }\n}\n```\n\n`errors` перечисляет проблемные поля. Обрабатывайте оба формата ошибок: сначала проверьте наличие `errorInfo`, затем читайте `status` / `code` / `message`.\n\nНазвания полей в запросе не чувствительны к регистру: принимаются и `CardLinkHash`, и `cardLinkHash` (проверено на тестовом API). Используйте написание из примеров.\n\n## Повтор номера заказа (Order)\n\n| Ситуация | Результат |\n|---|---|\n| Новый `Order` | Создаётся новый платёж. |\n| Тот же `Order`, **те же данные**, платёж ещё не оплачен | Возвращаются тот же `paymentId` и `paymentLink`. Повтор безопасен, например после таймаута. |\n| Тот же `Order`, **другие данные** (сумма, товары, …) | Server-to-server: HTTP `500`, `TECHNICAL_ERROR`. |\n| Тот же `Order`, платёж уже оплачен или в обработке у банка-эмитента | Server-to-server: HTTP `500`, `TECHNICAL_ERROR`. Hosted checkout: покупатель видит страницу Paynet «Plata a fost respinsă» (счёт уже оплачен или в обработке). |\n\nТело ошибки в этих случаях:\n\n```json\n{\n  "status": 500,\n  "message": "One or more errors occurred.",\n  "code": "TECHNICAL_ERROR",\n  "traceId": "11de6054-87ef-484d-a368-7cfae0b452ff",\n  "details": "Please verify the transmitted data and try again, or contact support."\n}\n```\n\n**Правило:** один заказ в магазине = один `Order`. Если покупатель изменил корзину, создайте новый заказ с новым `Order`.\n\n## Статус платежа\n\nОбъект платежа (`POST /api/order`, `GET /api/order/{id}`, `GET /api/order/merchant/{id}`, `GET /api/order/search`) содержит числовой `status` и даты `registered`, `paidDate`, `expiryDate`.\n\nУ только что созданного заказа `status` = `1`, а `paidDate` = `null`.\n\n| `status` | Значение | Что делать |\n|---|---|---|\n| `1` | Зарегистрирован: заказ создан, оплаты не было | Ждать оплаты. Если покупатель ушёл со страницы, его можно снова отправить по той же `paymentLink` (из ответа на создание заказа, см. ниже). |\n| `3` | В обработке: покупатель нажал «Оплатить», ждём ответа банка | Не создавать заказ заново и не отменять его. Проверить статус позже. |\n| `4` | Оплачен | Выполнить заказ. |\n| `5` | Не оплачен (банк отклонил оплату, отмена антифродом) или возвращён полностью | Окончательный. Для новой попытки оплаты нужен заказ с новым `Order`. |\n| `6` | Оплачен, затем частично возвращён | Окончательный. Покупатель заплатил, часть денег ему вернули. |\n\n```\n1 ──► 3 ──► 4 ──► 5  (full refund / полный возврат / rambursare totală)\n      │      └──► 6  (partial refund / частичный возврат / rambursare parțială)\n      └──► 5  (declined, antifraud / отказ, антифрод / refuz, antifraudă)\n```\n\n- `5` и `6` — окончательные статусы, после них ничего не меняется. Значение `2` не используется.\n- Отдельного статуса «истёк» нет: если `ExpiryDate` прошёл, а оплаты не было, заказ остаётся в статусе `1`, но оплатить его уже нельзя.\n- Антифрод срабатывает до подтверждения оплаты. Если вы получили проверенное уведомление `PAID`, антифрод этот платёж уже не отменит; статус `5` у оплаченного заказа означает только полный возврат.\n- Считайте платёж оплаченным, если получили проверенное уведомление `PAID` или `status` = `4`. `6` тоже означает, что покупатель заплатил (затем часть вернули); `5` после оплаты — возврат полностью.\n- Если покупатель не прошёл 3-D Secure, платёж получает статус `5`, а покупатель возвращается на `LinkUrlCancel` — как при отказе банка.\n- Причину отказа (отказ банка, антифрод, 3-D Secure) через API узнать нельзя: статус `5` означает только, что этот заказ закрыт и для новой попытки нужен новый `Order`.\n\n### Неуспешная оплата и повторная попытка\n\nНеуспешная оплата не порождает уведомление: покупатель возвращается на `LinkUrlCancel`. Проверьте статус через `GET /api/order/merchant/{Order}`:\n\n| `status` | Что произошло | Как дать покупателю оплатить ещё раз |\n|---|---|---|\n| `1` | Покупатель не оплачивал (например, закрыл страницу) | Отправьте его по той же `paymentLink`. |\n| `3` | Оплата ещё обрабатывается | Подождите и проверьте статус снова. Не создавайте новый заказ. |\n| `5` | Банк отклонил оплату | Заказ закрыт. Создайте новый заказ с **новым** `Order` и отправьте покупателя по новой `paymentLink`. |\n\n**Сохраняйте `paymentLink` из ответа на `POST /api/order`.** Полная ссылка (с номером платежа и `?s=…`) есть только в этом ответе. В ответах `GET /api/order/…` поле `paymentLink` обрезано до `https://…/ecom/getecom`, по нему оплатить нельзя. Если ссылка потеряна, отправьте `POST /api/order` ещё раз с **тем же телом** (тот же `Order`, те же данные): вернётся тот же платёж и та же ссылка.\n\n## Даты и форматы\n\n| Где | Формат | Пример |\n|---|---|---|\n| `ExpiryDate` в запросах | `YYYY-MM-DDTHH:mm:ss`, **местное время Кишинёва** | `2026-12-31T23:59:59` |\n| Даты в ответах о платеже | `YYYY-MM-DD HH:mm:ss` | `2026-04-01 15:01:12` |\n| `eventDate` в ответе на возврат | `DD.MM.YYYY HH:mm:ss` | `09.11.2026 18:17:54` |\n| Даты в уведомлениях | `YYYY-MM-DDTHH:mm:ss`, местное время Кишинёва | `2026-11-09T12:00:00` |\n| `from` / `to` в `/api/order/search` | `YYYY-MM-DDTHH:mm:ss`, **местное время Кишинёва**, без `Z` (`Z` и смещение игнорируются) | `2026-03-09T08:40:05` |\n| `dateStart` / `dateFinish` в выписках | дата | `2026-03-01` |\n| Суммы | целое, минимальные единицы | `1201` = 12,01 MDL |\n| Валюта | числовой ISO 4217 | `498` = MDL |\n\nМестное время Кишинёва — часовой пояс `Europe/Chisinau`: UTC+2 зимой, UTC+3 летом. Если сервер работает в UTC, переводите время перед формированием `ExpiryDate`, иначе заказы будут истекать на 2–3 часа раньше задуманного.\n\n## Возвраты\n\n`POST /api/order/refund`:\n\n```json\n{\n  "PaymentId": 328733,\n  "SaleAreaCode": "onlidocumentation_md",\n  "RefundType": "full",\n  "Amount": 400,\n  "Currency": 498,\n  "Reason": "Customer request"\n}\n```\n\n| Правило | Значение |\n|---|---|\n| Что можно вернуть | Только оплаченный платёж (`status` = `4`). |\n| Сколько раз | **Один** возврат на платёж: полный (`full`) или частичный (`partial`). Второй возврат по тому же платежу невозможен. |\n| Сумма | `Amount` в минимальных единицах; максимум — `PaidAmount` платежа (при акции он меньше суммы заказа). Для полного возврата передайте `RefundType` `full` и `Amount` = `PaidAmount` (`amount.paidAmount` из `GET /api/order/merchant/{Order}`). |\n| Срок | 180 дней после оплаты. |\n| Способы оплаты | Все, кроме `CASH_INVOICE`. |\n| Результат | Сразу в ответе `POST /api/order/refund`: `200` = возврат выполнен. Уведомление на callback о возврате не отправляется. |\n| Повтор запроса | Небезопасен: второй возврат вернёт `400`. После тайм-аута или ошибки сети сначала проверьте статус через `GET /api/order/merchant/{Order}`: `5` или `6` — возврат прошёл. |\n| Статус после | `5` после полного, `6` после частичного. Оба окончательные. |\n| Баланс мерчанта | Если на счёте мерчанта в Paynet нет денег, возврат не пройдёт. |\n\n### Ответы на возврат (проверено на тестовой среде)\n\nПример запроса выше и ответ ниже — один и тот же тестовый платёж (оплачено 4,00 MDL, возвращено полностью).\n\n| Ситуация | Ответ |\n|---|---|\n| Возврат выполнен | `200`, тело ниже |\n| Платёж не оплачен | `404 NOT_FOUND_RECORD` |\n| Сумма больше оплаченной | `400 INVALID_PARAMETER`, `details`: «The invalid parameter is: RefundType». Поле в `details` указано неточно: причина в сумме |\n| Повторный возврат по тому же платежу (например, полный после частичного) | `400 INVALID_PARAMETER`, `details`: «The invalid parameter is: RefundType» |\n\n```json\n{\n  "paymentId": 328733,\n  "saleAreaCode": "onlidocumentation_md",\n  "customer": "464566161",\n  "eventDate": "09.11.2026 18:17:54",\n  "refundType": "full",\n  "currency": 498,\n  "amount": 400,\n  "merchant": "265505",\n  "cardMask": "411111******1111",\n  "cardLinkHash": null,\n  "moneyType": "CYBER_SOURCE"\n}\n```\n\n- `eventDate` в ответе на возврат имеет формат `DD.MM.YYYY HH:mm:ss`.\n- `moneyType` здесь — код процессинга (например, `CYBER_SOURCE`), а не значение из уведомления (`CARD`…).\n- После возврата `paidDate` платежа остаётся заполненным.\n\n## Обращение в поддержку\n\n- **Если вас подключает менеджер Paynet:** обычно создаётся общий чат в Telegram с разработчиком Paynet и вашим разработчиком. Там вы получите доступы и ссылки и сможете задавать вопросы по интеграции. Попросите менеджера создать такой чат.\n- **Если вы ещё не общались с менеджером:** напишите на [support@paynet.md](mailto:support@paynet.md).\n\nЧтобы на вопрос ответили быстро, сразу пришлите:\n\n| Что | Пример |\n|---|---|\n| `traceId` из ответа с ошибкой | `9b9346f9-f83a-465d-ac8d-dc382c460c22` |\n| Метод и адрес | `POST https://ecom-api-test.paynet.md/api/order` |\n| Дата и время запроса (по Кишинёву) | `10.11.2026 12:05` |\n| `Order` и / или `paymentId` | `1762444800000`, `328731` |\n| Торговая зона и мерчант | `onlidocumentation_md`, `265505` |\n| HTTP-код и тело ответа целиком | `400`, `{ "errorInfo": … }` |\n| Тест или продакшн | тест |\n\nНикогда не присылайте пароль, секретные ключи и токен.\n',"../../content/ru/common/04-ai-assistants.md":'# Интеграция с помощью ИИ\n\nЭту документацию можно передать любому ИИ-ассистенту для программирования (Claude, ChatGPT, Gemini, Copilot, Cursor и другим) и попросить написать интеграцию.\n\n## Файлы для ИИ\n\n| Файл | Что внутри | Когда использовать |\n|---|---|---|\n| [`llms-full.txt`](llms-full.txt) | Вся документация одним текстовым файлом: все продукты, руководства, справочник API, подписи с тестовыми векторами, тестовые данные | Дайте ассистенту этот один файл. |\n| [`llms-ecom.txt`](llms-ecom.txt) | Только E-commerce и нужные ему общие темы (уведомления, подписи, ошибки) | Если интегрируете только приём платежей e-commerce. |\n| [`llms.txt`](llms.txt) | Короткое оглавление со ссылками на все страницы | Для ассистентов, которые сами ходят по ссылкам. |\n| [`openapi.json`](openapi.json) | Спецификация OpenAPI 3 для server-to-server API | Для генераторов кода и типизированных клиентов. |\n| `docs/<page>.md`, `docs/ru/<page>.md`, `docs/ro/<page>.md` | Каждое руководство отдельным файлом Markdown (английский, русский, румынский) | Когда нужна только одна тема. |\n| `docs/api/<method>.md` | Каждый API-метод отдельным файлом Markdown | Когда работаете с одним методом. |\n\nНа каждой странице руководства и API-метода есть кнопка **Копировать для ИИ**. Она копирует страницу в Markdown; её меню (стрелка рядом) также открывает страницу как Markdown или в ChatGPT, Claude и Gemini с готовым вопросом.\n\n> **Примечание:** большинство ассистентов не могут прочитать портал по ссылке, потому что страницы рисуются JavaScript. Давайте им `llms-full.txt` или `llms-ecom.txt` (загрузите файл или вставьте ссылку). Файлы для ИИ написаны на английском: модели лучше всего работают с ним, а отвечать вам могут на любом языке.\n\n## Подключение ассистента в редакторе кода\n\nАссистенты в редакторе работают лучше всего, когда документация лежит в проекте или добавлена как источник:\n\n| Ассистент | Как добавить документацию |\n|---|---|\n| Cursor | Чат → `@Docs` → *Add new doc* → вставьте ссылку на `llms-full.txt`. Затем упоминайте `@Docs` в запросах. |\n| VS Code (GitHub Copilot) | В чате используйте `#fetch` со ссылкой на `llms-ecom.txt` или сохраните файл в проект и прикрепите его. |\n| Claude Code | Сохраните `llms-ecom.txt` в проект (например, `docs/paynet.md`) и добавьте в `CLAUDE.md`: *Интеграция Paynet: следуй docs/paynet.md*. |\n| Codex | Сохраните `llms-ecom.txt` в проект и так же укажите его в `AGENTS.md`. |\n\nФайл в проекте также показывает при ревью кода, по какой версии документации сделана интеграция. Скачайте его заново, когда документация изменится.\n\n## Шаблон запроса\n\nСкопируйте, заполните скобки и приложите `llms-ecom.txt`:\n\n```text\nYou are integrating Paynet e-commerce payments into my project.\nUse ONLY the attached Paynet documentation as the source of truth.\n\nMy stack: [e.g. Node.js 20 + Express / PHP 8.2 + Laravel / Python 3.12 + Django]\nIntegration type: [official Paynet SDK (PHP / Node.js) | server-to-server API | hosted checkout form]\nWhat to build:\n1. Create a payment for a cart and redirect the customer to Paynet.\n2. A notification endpoint that verifies the Hash header and marks the order paid exactly once.\n3. A status check by paymentId used before fulfilment.\n\nRequirements:\n- If my stack is PHP or Node.js, use the official Paynet SDK from the documentation\n  (section "SDK for PHP and Node.js") instead of writing your own HTTP client.\n- Read credentials and secret keys from environment variables.\n- One shop order = one unique Order number; ExpiryDate in the future, in Europe/Chisinau time.\n- Amounts are integers in minor units (100 = 1.00 MDL).\n- Implement signatures exactly as documented and add unit tests that reproduce\n  the test vectors from the "Signatures" section.\n- Do not invent endpoints, fields or status values that are not in the documentation.\n  If something is missing, list it as an open question instead of guessing.\n- Answer me in Russian.\n```\n\n## Правила для ассистента\n\nЭти правила также включены в начало файлов для ИИ:\n\n1. Тестовый API: `https://ecom-api-test.paynet.md`; боевой API: `https://ecom-api.paynet.md` (пути те же: `/auth`, `/api/...`). Форма hosted checkout: `https://test.paynet.md/ecom/checkout` (тест), `https://paynet.md/ecom/checkout` (прод).\n2. Аутентификация через `POST /auth` (JSON), затем заголовок `Authorization: Bearer <token>`.\n3. Один заказ магазина = один `Order`. Повтор `Order` с теми же данными возвращает тот же платёж; с другими данными или после оплаты — ошибка `500 TECHNICAL_ERROR`.\n4. `ExpiryDate` — `YYYY-MM-DDTHH:mm:ss` по местному времени Кишинёва (`Europe/Chisinau`), в будущем.\n5. Суммы — целые числа в минимальных единицах; `Currency` — `498` для MDL.\n6. Подписи: `Base64(MD5(UTF8(строка + secretKey)))`, Base64 от «сырого» дайджеста. Ключ checkout и ключ уведомлений — разные.\n7. Уведомления приходят только об оплаченных платежах (`EventType` = `PAID`). Ключи — `Payment.Id` и `Payment.ExternalId` (с учётом регистра). При неуспешной оплате покупатель только перенаправляется на `LinkUrlCancel`.\n8. `PaidAmount` должен равняться `Amount`, если у мерчанта нет согласованной с Paynet акции; иначе не выполнять заказ автоматически.\n9. Не доверяйте возврату на `LinkUrlSuccess`; подтверждайте проверенным уведомлением или API статуса.\n10. Секреты никогда не попадают в код браузера и мобильного приложения.\n11. Если стек — PHP или Node.js, ассистент предлагает [официальный SDK](#/guides/sdk) вместо собственного HTTP-клиента.\n12. Поиск платежей: `from`/`to` — по времени Кишинёва; пустой период — `404 NOT_FOUND_RECORD`.\n',"../../content/ru/common/05-faq.md":"# Частые вопросы\n\n## Тестовые и боевые ключи одинаковые?\n\nНет. Боевые доступы и оба секретных ключа (для формы checkout и для уведомлений) отличаются от тестовых. При переходе в бой замените все значения — см. [Чек-лист запуска](#/guides/go-live).\n\n## Как получить боевые доступы?\n\nИх присылают на почту администратора вашей компании. Это занимает от 5 минут до нескольких дней в зависимости от подключаемых функций.\n\n## Покупатель вернулся на страницу успеха, но уведомления нет. Заказ оплачен?\n\nНе считайте заказ оплаченным только по возврату на `LinkUrlSuccess`. Дождитесь проверенного уведомления `PAID` или проверьте статус: `GET /api/order/merchant/{Order}`, `status` = `4` — оплачен. См. [Статус платежа](#/guides/errors-and-statuses).\n\n## Одно и то же уведомление пришло несколько раз\n\nЭто нормально: если ваш сервер не ответил `200`, Paynet повторяет уведомление. Обрабатывайте каждый `Payment.Id` один раз. См. [Уведомления](#/guides/notifications).\n\n## Уведомление так и не пришло\n\nПроверьте статус через `GET /api/order/merchant/{Order}`. Повторную отправку уведомления можно запросить в поддержке Paynet.\n\n## Банк отклонил оплату. Можно оплатить тот же заказ ещё раз?\n\nНет: после отказа заказ получает статус `5` и закрывается. Создайте новый заказ с новым `Order`. Если же покупатель просто закрыл страницу, не оплачивая, заказ остаётся `1` и его можно оплатить по той же `paymentLink`.\n\n## Повторный `POST /api/order` с тем же `Order` вернул `500`\n\nС тем же `Order` и теми же данными Paynet вернёт тот же платёж. Ошибка `500 TECHNICAL_ERROR` означает, что данные отличаются, либо заказ уже оплачен или оплата обрабатывается. См. [Повтор номера заказа](#/guides/errors-and-statuses).\n\n## Почему `PaidAmount` меньше `Amount`?\n\nОбычно они равны. Меньше `PaidAmount` бывает только при акции, официально согласованной с Paynet (например, скидка для карт определённого банка). Вы получаете `PaidAmount` за вычетом комиссии Paynet.\n\n## Можно сделать второй возврат по тому же платежу?\n\nНет. По одному платежу возможен один возврат: полный или частичный.\n\n## Почему не проходит возврат?\n\nПроверьте: прошло не больше 180 дней после оплаты; способ оплаты — не `CASH_INVOICE`; по платежу ещё не было возврата; сумма не больше `PaidAmount`; на счёте мерчанта в Paynet есть деньги. См. [Возвраты](#/guides/errors-and-statuses).\n\n## Почему заказ истекает раньше, чем задумано?\n\n`ExpiryDate` задаётся по местному времени Кишинёва (`Europe/Chisinau`). Если ваш сервер работает в UTC, переведите время, иначе заказ истечёт на 2–3 часа раньше.\n\n## Не сходится подпись\n\nПроверьте: строка кодируется в UTF-8; используется правильный ключ (для формы checkout и для уведомлений ключи разные); значения берутся ровно в том виде, как в JSON. Сверьте свой код с [тестовыми векторами](#/guides/signatures).\n\n## Нужно ли включать CORS для уведомлений?\n\nНет. CORS нужен только симулятору уведомлений на этом портале, потому что он отправляет запрос из браузера. Настоящие уведомления отправляет сервер Paynet.\n\n## Почему в уведомлении `CardLinkHash` = `null`?\n\nСохранение карт не включено для вашего `SaleAreaCode`, в заказе не было `Customer`, либо покупатель снял галочку «сохранить карту». См. [Сохранение карт](#/guides/saved-cards).\n","../../content/ru/common/06-changelog.md":"# Журнал изменений\n\n## Документация v3.5.1 — 17.11.2026\n\n- **Сборка портала** (API и тексты документации не менялись): `npm run build:prod` теперь собирает весь портал для https://docs.paynet.md/api/ со всеми проверками — в Windows, macOS и Linux (Node.js 22.12+). Библиотеки с известными уязвимостями удалены или обновлены (Vite 8, js-yaml 4.3). Калькуляторы подписи на портале считают MD5 без сторонней библиотеки; результат тот же (проверено на опубликованных тестовых векторах).\n\n## Документация v3.5 — 11.11.2026\n\n- **Пример магазина: пошаговый запуск для Windows, macOS и Linux** (найдено при запуске примера «как новичок»): проверка Node.js, `tar -xf` вместо `unzip` (работает в Windows 10/11), почему заказ остаётся `pending` и как отправить тестовое уведомление, таблица «Если что-то не получилось». Страница заказов и страница возврата в магазине теперь показывают готовую команду для отправки уведомления. См. [Пример магазина](#/guides/example-shop).\n\n## Документация v3.4 — 11.11.2026\n\n- **Спецсимволы в подписи hosted checkout** (проверено реальными отправками формы в тестовую среду): правильные и неправильные функции кодирования для PHP, JavaScript, Python, C#, Java; перенос строки ломает подпись; HTML-теги и HTML-сущности приводят к тому, что Paynet отклоняет форму до проверки подписи. Новый тестовый вектор 3 с `' & ! ( ) *`, кириллицей и румынскими буквами. См. [Подписи](#/guides/signatures).\n- Ссылка «Previous portal version» ведёт на предыдущую документацию https://docs.paynet.md/psp/.\n- Вместе с порталом публикуются `robots.txt` и `sitemap.xml`.\n\n## Документация v3.3 — 10.11.2026\n\nУточнения по итогам теста, в котором разработчик, не знакомый с Paynet, сделал интеграцию только по этой документации.\n\n- **Товары:** если передаёте `Products`, обязательны `LineNo`, `Name`, `UnitPrice`, `Quantity`, `Amount`, `TotalAmount`; `Code` и `Description` — необязательны (проверено на тестовой среде). См. [Server-to-server](#/guides/server-to-server).\n- **Ссылка на оплату:** сохраняйте `paymentLink` из ответа на создание заказа — в ответах о статусе она сокращена.\n- **Возвраты:** полный возврат — `Amount` равен `PaidAmount`; `200` = выполнен; не повторяйте возврат, не проверив статус. Примеры запроса и ответа теперь об одном платеже. См. [Ошибки и статусы](#/guides/errors-and-statuses).\n- Даты поиска платежей в таблице форматов: время Кишинёва, без `Z`.\n- Уведомления: важен только HTTP-код `200`, тело ответа значения не имеет.\n- Getting started: где используется код мерчанта.\n- `Customer.PhoneNumber`: необязателен, но без него покупатель вводит телефон на платёжной странице. Примеры теперь его передают.\n- **Статусы:** `6` — оплачен, затем частично возвращён; `5` — не оплачен (отказ банка, антифрод) или возвращён полностью.\n- **Уведомления:** первое уведомление отправляется после подтверждения оплаты банком-эмитентом (время зависит от банка); интервалы повторов не изменились.\n- **Пример уведомлений в SDK:** уведомление сохраняется до ответа `200`, заказ выполняется по сохранённой записи.\n- `linkUrlSuccess` / `linkUrlCancel` в ответах о платеже могут быть `null` (справочник API, типы Node.js SDK).\n- `Lang`: регистр не важен; при неизвестном значении страница открывается на английском (проверено на тестовой среде).\n- Пример магазина теперь скачивается архивом с этого портала.\n\n## Документация v3.2 — 10.11.2026\n\n- **Официальные SDK для PHP и Node.js** (версия 1.0.0, лицензия MIT): авторизация, заказы, статусы, возвраты с проверкой правил, сохранённые карты, выписки, уведомления, форма hosted checkout, ошибки. Проверены на тестовой среде. См. [SDK](#/guides/sdk).\n- **Мобильные приложения**: как принимать оплату в приложении через ваш сервер и страницу Paynet. См. [Мобильные приложения](#/guides/mobile-apps).\n- **Поиск платежей:** `from`/`to` — время Кишинёва; пустой период — `404 NOT_FOUND_RECORD`. Исправлена коллекция Postman.\n- `Quantity` товара — в сотых долях (`100` = 1 шт.).\n\n## Документация v3.1 — 10.11.2026\n\n- **Новая коллекция Postman** с окружениями TEST и PRODUCTION: токен получается сам, каждый заказ уникальный, данные передаются между запросами. Проверяется прогоном на тестовой среде. См. [Тестирование → Postman](#/guides/testing).\n- **Шпаргалка по ошибкам** с колонкой «повторять запрос?»; добавлены `405`, `415` и `404` с пустым телом (проверено на тестовой среде). См. [Ошибки и статусы](#/guides/errors-and-statuses).\n- **Расписание повторов уведомлений:** 9 попыток примерно за 25 минут. **IP-адреса** Paynet для файрвола. См. [Уведомления](#/guides/notifications).\n- 3-D Secure и причина отказа в разделе статусов; раздел «Обращение в поддержку».\n- Боковое меню с иконками; таблицы параметров читаются на телефоне.\n\n## Документация v3 — 09.11.2026\n\n- **Пример магазина на Node.js** — полная интеграция без внешних библиотек. Проверяется сквозным тестом на тестовой среде: покупка, оплата, уведомление, возврат. См. [Пример магазина](#/guides/example-shop).\n- **Имитированные ответы для тестов отказов**: статусы `3`, `5`, `6`, ошибки возврата, `401`, `errorInfo`, подписанные уведомления. См. [Тестирование](#/guides/testing).\n- **Спецификация API сверена с реальными ответами** тестовой среды: `/auth` с неверным паролем возвращает `401` (а не `500`); описаны формат `401` по токену и формат `errorInfo`; добавлено поле `amount.paidAmount`; добавлены схемы ответов возврата, поиска и выписки.\n- **Сохранение карт проверено на тестовой среде:** тому же покупателю карта показывается, чужому — нет. См. [Сохранение карт](#/guides/saved-cards).\n- **Полные обработчики уведомлений** на Node.js и PHP; логика Node.js-версии проверяется при каждой сборке.\n\n## Документация v2 — 09.11.2026\n\n- Портал для нескольких продуктов: главная страница, поиск по всему сайту, разделы «Общее» и «E-commerce».\n- Правила API, подтверждённые Paynet: статусы платежа, неуспешная оплата, возвраты, повторы уведомлений, сохранение карт, боевые доступы.\n- Что защищает подпись уведомления и как сверять неподписанные поля через API.\n- Частые вопросы, меню «Копировать для ИИ», файлы для ИИ на трёх языках.\n- Убрано описание устаревшего протокола из старой документации.\n- Версия сохранена в ветке `documentation-v2` репозитория.\n\n## Документация v1\n\nИсходный портал. Доступен по ссылке «Предыдущая версия портала» внизу страницы.\n","../../content/ru/ecom/01-integration-options.md":`# E-commerce: варианты интеграции

Paynet e-commerce позволяет интернет-магазину принимать оплату картой (включая Apple Pay и Google Pay), кошельком Paynet, мгновенными платежами MIA и наличными по счёту. Интегрироваться можно тремя способами. Все они заканчиваются на одной и той же платёжной странице Paynet, поэтому вы сами никогда не собираете данные карт.

| | Server-to-server API | Hosted checkout (client-server) | Готовые плагины |
|---|---|---|---|
| Как заказ попадает в Paynet | ваш **бэкенд** вызывает \`POST /api/order\` с Bearer-токеном | **браузер** покупателя отправляет в Paynet подписанную HTML-форму | плагин делает это сам |
| Чем защищён запрос | токен доступа (\`/auth\`) | \`Signature\` = MD5 + Base64 с вашим секретным ключом | настройки плагина |
| Что вы получаете | \`paymentId\` + \`paymentLink\` в JSON | покупатель сразу попадает на платёжную страницу | — |
| Статусы, возвраты, выписки | да, тот же API | да, через server-to-server API (заказы ищутся по вашему \`Order\`) | зависит от плагина |
| Подходит для | собственных магазинов и приложений с бэкендом | простых сайтов, быстрого старта без API-клиента | WordPress/WooCommerce, OpenCart, PrestaShop, Magento, CS-Cart, Shopify |

## Как выбрать

- **У вас есть бэкенд и нужен полный контроль** → [Server-to-server](#/guides/server-to-server). Самый гибкий вариант, \`paymentId\` вы получаете сразу.
- **Нужна только кнопка «Оплатить» без вызова API для создания заказа** → [Hosted checkout](#/guides/hosted-checkout). Бэкенд всё равно нужен для расчёта подписи: секретный ключ не должен попадать в код браузера.
- **Хотите меньше кода** → готовые [SDK для PHP и Node.js](#/guides/sdk): авторизация, правила возврата, подписи и ошибки уже реализованы.
- **У вас мобильное приложение** → оплата через ваш сервер и страницу Paynet, см. [Мобильные приложения](#/guides/mobile-apps).
- **Магазин работает на поддерживаемой CMS** → скачайте плагин в разделе [**Плагины**](#/page/plugins). Shopify подключается через Cybersource.

## Что нужно любой интеграции

1. **Callback URL** для [уведомлений](#/guides/notifications). Paynet вызывает его, когда платёж оплачен (уведомления приходят только об успешных платежах). Сообщите этот URL в Paynet.
2. **Проверка подписи** каждого уведомления, см. [Подписи](#/guides/signatures).
3. **Проверка статуса** перед отгрузкой: \`GET /api/order/{paymentId}\` или \`GET /api/order/merchant/{order}\`.
4. **Уникальные номера заказов** (\`Order\`) на вашей стороне: один заказ магазина = один \`Order\`.
5. **Два секретных ключа** от Paynet: один для подписи hosted checkout, другой для уведомлений.

## Общая схема

\`\`\`text
Покупатель      Ваш магазин (бэкенд)                Paynet
   | оформление |                                     |
   |----------->| 1. создать заказ (API или форма)    |
   |            |------------------------------------>|
   | 2. переход на платёжную страницу                  |
   |-------------------------------------------------->|
   |              3. оплата на странице Paynet          |
   |<--------------------------------------------------|
   | 4. возврат на LinkUrlSuccess / LinkUrlCancel       |
   |            | 5. уведомление (POST, заголовок Hash)|
   |            |<------------------------------------|
   |            | 6. проверить Hash и статус, отгрузить |
\`\`\`

Возврат покупателя на \`LinkUrlSuccess\` — это только шаг интерфейса. **Не считайте заказ оплаченным только потому, что покупатель вернулся на страницу успеха.** Опирайтесь на уведомление и/или API статуса.

Если оплата не прошла, покупатель перенаправляется на \`LinkUrlCancel\`. О неуспешных платежах Paynet уведомления не отправляет.
`,"../../content/ru/ecom/02-getting-started.md":'# Быстрый старт\n\nЭта страница проведёт вас от нуля до успешного тестового платежа примерно за 10 минут, используя общий тестовый аккаунт и панели «Test API Request» портала. Покупатель платит на платёжной странице Paynet, поэтому вы не работаете с данными карт.\n\n## Окружения\n\n| Что | Тест | Продакшн |\n|---|---|---|\n| Базовый URL API | `https://ecom-api-test.paynet.md` | `https://ecom-api.paynet.md` |\n| URL формы hosted checkout | `https://test.paynet.md/ecom/checkout` | `https://paynet.md/ecom/checkout` |\n\nВ обоих окружениях пути одинаковые (`/auth`, `/api/...`).\n\n## Учётные данные\n\n| Что | Тест (общий) | Продакшн |\n|---|---|---|\n| Пользователь API (`username` / `password`) | `771064` / `sLgMnGWJ` | выдаёт Paynet вашей компании |\n| Код мерчанта (`Merchant`) | `265505` — в `POST /api/order` не передаётся; нужен для формы Hosted Checkout и проверки уведомлений (`Payment.Merchant`) | выдаёт Paynet |\n| Код торговой зоны (`SaleAreaCode`) | `onlidocumentation_md` | выдаёт Paynet (по одному на сайт/магазин) |\n| Секретный ключ для подписи hosted checkout | `F90D6485-9CCC-458B-96A3-8958AF9B4458` | выдаёт Paynet, храните в секрете |\n| Секретный ключ для уведомлений | `D9873689-E5F8-4272-A67F-0D8BA3F9BAA7` | выдаёт Paynet, храните в секрете |\n| Тестовая карта | Visa `4111 1111 1111 1111`, срок `12/27`, CVV `777` | реальные карты |\n\nPaynet выдаёт **два разных секретных ключа**: один подписывает форму hosted checkout, другой — уведомления. Не путайте их.\n\n> **Примечание:** тестовые данные выше публичны намеренно и общие для всех, кто тестирует на портале. Никогда не используйте их в продакшне и никогда не кладите боевые секреты в код фронтенда.\n\n## Первый тестовый платёж (server-to-server)\n\n### Шаг 1. Получите токен доступа\n\nВ боковом меню откройте **E-commerce → Методы API → Аутентификация и авторизация** и нажмите **Test API Request**. Логин и пароль не меняйте.\n\n```http\nPOST https://ecom-api-test.paynet.md/auth\nContent-Type: application/json\n\n{ "grantType": "password", "username": "771064", "password": "sLgMnGWJ" }\n```\n\nОжидаемый результат: HTTP `200` и `access_token` (действует около 4 часов, см. `expires_in`). Портал запоминает токен и сам добавляет его в следующие запросы как `Authorization: Bearer <token>`.\n\n### Шаг 2. Создайте заказ\n\nОткройте **E-commerce → Методы API → Создание операции** и нажмите **Test API Request**.\n\nПортал сам подставляет уникальный номер `Order` и `ExpiryDate` на завтра, поэтому пример работает без правок. Если меняете запрос вручную, помните:\n\n- один заказ = один новый номер `Order`;\n- `ExpiryDate` должна быть в будущем, формат `YYYY-MM-DDTHH:mm:ss`, местное время Кишинёва;\n- суммы — целые числа в минимальных единицах: `300` = 3,00 MDL.\n\nОжидаемый результат: HTTP `200`, `paymentId`, `status` `1` и `paymentLink` вида `https://test.paynet.md/ecom/getecom/317184?s=…`.\n\n### Шаг 3. Оплатите на платёжной странице\n\nОткройте `paymentLink` в браузере и оплатите тестовой картой `4111 1111 1111 1111`, `12/27`, CVV `777`. После оплаты вы вернётесь на `LinkUrlSuccess`.\n\n### Шаг 4. Проверьте статус платежа\n\nОткройте **E-commerce → Методы API → Получить операцию по номеру заказа мерчанта**, введите ваш номер `Order` и выполните запрос. Вы увидите данные платежа; у оплаченного платежа заполнен `paidDate`.\n\n### Шаг 5. Проверьте уведомление (webhook)\n\nОткройте **Общее → Уведомления → Симулятор уведомлений**. Введите ваш callback URL, секретный ключ уведомлений и номер `Order`, затем нажмите **Get** и **Send notification**. Портал отправит на ваш URL смоделированное подписанное уведомление `PAID`, чтобы вы проверили свой обработчик. Подробнее: [Уведомления](#/guides/notifications).\n\n## Что дальше\n\n- Выберите способ интеграции: [Варианты интеграции](#/guides/integration-options).\n- Изучите полный сценарий: [Server-to-server](#/guides/server-to-server) или [Hosted checkout](#/guides/hosted-checkout).\n- Пишете интеграцию с помощью ИИ? Начните с раздела [Интеграция с помощью ИИ](#/guides/ai-assistants).\n',"../../content/ru/ecom/03-server-to-server.md":'# Server-to-server интеграция\n\nВ этой модели ваш бэкенд напрямую работает с API Paynet. Это рекомендуемый вариант для магазинов с собственным бэкендом.\n\n## Обзор\n\n1. `POST /auth` → получить токен доступа.\n2. `POST /api/order` → зарегистрировать заказ, получить `paymentId` и `paymentLink`.\n3. Перенаправить покупателя на `paymentLink`.\n4. Принять [уведомление](#/guides/notifications) на callback URL и проверить его `Hash`.\n5. Подтвердить через `GET /api/order/{paymentId}` и выполнить заказ.\n\nБазовый URL: `https://ecom-api-test.paynet.md` (тест), `https://ecom-api.paynet.md` (прод). Все тела запросов — JSON (`Content-Type: application/json`).\n\n## 1. Аутентификация\n\n```http\nPOST /auth\nContent-Type: application/json\n\n{ "grantType": "password", "username": "771064", "password": "sLgMnGWJ" }\n```\n\n```json\n{ "access_token": "Ccxl7QQiMEoakkrUoiUn8PIg…", "token_type": "bearer", "expires_in": 14399 }\n```\n\nПередавайте токен во всех остальных запросах: `Authorization: Bearer <access_token>`. `expires_in` указан в секундах (около 4 часов). Кэшируйте токен и запрашивайте новый, когда он истёк или API вернул `401`.\n\nНеверные учётные данные возвращают ошибку с `code` `AUTHENTICATION_FAILED`.\n\n## 2. Создание заказа\n\n```http\nPOST /api/order\nAuthorization: Bearer <access_token>\nContent-Type: application/json\n```\n\n```json\n{\n  "Order": 1762444800000,\n  "SaleAreaCode": "onlidocumentation_md",\n  "LinkUrlSuccess": "https://shop.example/payment/success",\n  "LinkUrlCancel": "https://shop.example/payment/cancel",\n  "Customer": {\n    "Code": "464566161",\n    "NameFirst": "First Name",\n    "NameLast": "Last Name",\n    "email": "customer@example.com",\n    "PhoneNumber": "37360000000"\n  },\n  "Currency": 498,\n  "ExpiryDate": "2026-12-31T23:59:59",\n  "Services": [\n    {\n      "Name": "Demo eShop",\n      "Description": "Order #1762444800000",\n      "Amount": 300,\n      "Products": [\n        {\n          "LineNo": 1,\n          "Code": "SKU-1",\n          "Name": "Demo product",\n          "Description": "Demo product",\n          "UnitPrice": 100,\n          "Quantity": 300,\n          "Amount": 300,\n          "TotalAmount": 300\n        }\n      ]\n    }\n  ],\n  "MoneyType": "All",\n  "Lang": "EN"\n}\n```\n\n### Поля запроса\n\n| Поле | Тип | Обязательно | Описание |\n|---|---|---|---|\n| `Order` | integer (int64) | да | Номер заказа у вас. Один заказ магазина = один `Order` (см. [повтор номера заказа](#/guides/errors-and-statuses)). |\n| `SaleAreaCode` | string | да | Код торговой зоны (сайта), выданный Paynet. |\n| `LinkUrlSuccess` | string | да | Куда покупатель вернётся после успешной оплаты. |\n| `LinkUrlCancel` | string | да | Куда покупатель вернётся после отмены. |\n| `Currency` | integer | да | Числовой код ISO 4217. `498` = MDL. |\n| `ExpiryDate` | string | да | Срок оплаты, `YYYY-MM-DDTHH:mm:ss`, местное время Кишинёва (`Europe/Chisinau`), в будущем. |\n| `Services` | array | да | Минимум одна услуга, см. ниже. |\n| `MoneyType` | string | да | `All`, `Card`, `Paynet`, `MIA` или `CashInvoice` (см. ниже). |\n| `Lang` | string | да | Язык платёжной страницы: `RO`, `RU` или `EN`. Регистр не важен (`EN` = `en`). Проверено на тестовой среде: при неизвестном значении страница открывается на английском. |\n| `Customer` | object | нет | Данные покупателя. Обязателен, чтобы [сохранить карту](#/guides/saved-cards) или оплатить сохранённой картой. |\n| `Customer.Code` | string | да, если передан `Customer` | ID покупателя в вашей системе. |\n| `Customer.NameFirst`, `NameLast`, `email`, `PhoneNumber` | string | нет | Данные покупателя. Обратите внимание: `email` с маленькой буквы. Если не передать `PhoneNumber`, покупателю придётся ввести телефон на платёжной странице (блок «Billing information»). Передавайте данные покупателя, если они у вас есть, — тогда покупателю не нужно вводить их самому. |\n| `CardLinkHash` | string | нет | Токен сохранённой карты этого покупателя, полученный в уведомлении. Передавайте вместе с тем же `Customer`. См. [Сохранение карт](#/guides/saved-cards). |\n\n`Services[]`:\n\n| Поле | Тип | Обязательно | Описание |\n|---|---|---|---|\n| `Name` | string | да | Название услуги. |\n| `Description` | string | да | Описание услуги. |\n| `Amount` | integer | да | Сумма услуги в минимальных единицах. |\n| `Products` | array | нет | Необязательно. Если передаёте товары, у каждого товара обязательны шесть полей (см. ниже). |\n\n`Services[].Products[]` — обязательные: `LineNo` (int), `Name` (string), `UnitPrice` (int), `Quantity` (int), `Amount` (int), `TotalAmount` (int). Необязательные: `Code` (string), `Description` (string). Проверено на тестовой среде: без любого из шести обязательных полей API отвечает `400`.\n\n**`Quantity` — в сотых долях:** `100` = 1 шт., `300` = 3 шт. В примере выше `"Quantity": 300` — это 3 шт. по `UnitPrice` 1,00 MDL.\n\n**Суммы** — целые числа в минимальных единицах (бани): `1201` = 12,01 MDL.\n\n**MoneyType** определяет, какие способы оплаты увидит покупатель:\n\n| `MoneyType` | Покупатель видит |\n|---|---|\n| `All` | все способы, подключённые мерчанту |\n| `Card` | карта (Visa/Mastercard), Apple Pay, Google Pay |\n| `Paynet` | кошелёк Paynet |\n| `MIA` | мгновенные платежи MIA |\n| `CashInvoice` | оплата наличными по счёту |\n\nОтдельного значения для Apple Pay и Google Pay нет: они показываются и при `Card`, и при `All`. Чем покупатель заплатил на самом деле, сообщает уведомление (`CARD`, `APPLEPAY`, `GOOGLEPAY`, `MIA_QR`, `PAYNET`, `CASH_INVOICE`).\n\n### Ответ\n\n```json\n{\n  "paymentId": 328731,\n  "paymentLink": "https://test.paynet.md/ecom/getecom/328731?s=8fa1bd0923368d3bb700fccacc263735",\n  "cardLinkHash": null,\n  "status": 1,\n  "order": 1762444800000,\n  "merchantCode": "265505",\n  "saleAreaCode": "onlidocumentation_md",\n  "amount": { "requestAmount": 300, "requestCurrency": 498, "amount": 300, "paidAmount": null },\n  "expiryDate": "2026-12-31 23:59:59",\n  "registered": "2026-11-09 18:16:41",\n  "paidDate": null,\n  "moneyType": "All"\n}\n```\n\n(Ответ тестовой среды, сокращён. После оплаты `status` = `4`, заполнены `paidDate` и `amount.paidAmount`. Полный ответ также содержит `customer`, `payer`, `services`, `cardLinkHash`, `signature`, `linkUrlSuccess`, `linkUrlCancel`.)\n\nСохраните `paymentId` вместе с заказом: это ключ для проверки статуса, возвратов и уведомлений.\n\n**Повтор запроса.** Если отправить тот же `Order` с теми же данными (пока он не оплачен), вернутся тот же `paymentId` и `paymentLink` — повтор после таймаута безопасен. Тот же `Order` с другими данными или после оплаты даёт `500 TECHNICAL_ERROR`. Если корзина изменилась, используйте новый `Order`.\n\n«Те же данные» значит буквально тот же запрос. Сохраните тело запроса вместе с заказом и при повторе отправляйте его без изменений: например, пересчитанный `ExpiryDate` — это уже другие данные.\n\n## 3. Перенаправьте покупателя\n\nОтправьте браузер покупателя на `paymentLink` (HTTP 302 или ссылка/кнопка). Сохраните эту ссылку вместе с заказом: полная ссылка есть только в ответе на `POST /api/order`, в ответах `GET /api/order/…` она сокращена, без номера платежа. После успешной оплаты покупатель вернётся на `LinkUrlSuccess`, а если оплата не прошла или отменена — на `LinkUrlCancel`.\n\n## 4. Обработайте уведомление\n\nКогда платёж оплачен, Paynet отправляет подписанный `POST` на ваш callback URL (`EventType` = `PAID`; о неуспешных платежах уведомлений нет). Проверьте заголовок `Hash`, сверьте `PaidAmount` с `Amount` и ответьте HTTP `200`. См. [Уведомления](#/guides/notifications).\n\n## 5. Проверьте статус\n\n```http\nGET /api/order/{paymentId}\nGET /api/order/merchant/{Order}\nAuthorization: Bearer <access_token>\n```\n\nОба запроса возвращают один и тот же объект платежа. Используйте их перед отгрузкой и если уведомление не пришло. См. [Ошибки и статусы](#/guides/errors-and-statuses).\n\n## Другие операции\n\n| Операция | Запрос | Примечание |\n|---|---|---|\n| Поиск платежей | `GET /api/order/search?from=…&to=…` | Дата-время **по Кишинёву** без `Z`, например `2026-03-09T08:40:05`. Пометку UTC (`Z`) API не учитывает: время в UTC сдвинет период на 2–3 часа, и свежие платежи не попадут в результат. Если за период нет платежей, API отвечает `404 NOT_FOUND_RECORD` — это пустой результат, а не ошибка. |\n| Возврат | `POST /api/order/refund` | Тело: `PaymentId`, `SaleAreaCode`, `RefundType` (`full` или `partial`), `Amount`, `Currency`, `Reason`. |\n| Удалить сохранённую карту | `POST /api/linked-cards/unlink` | Тело: `CardLinkHash`, `SaleAreaCode`, `CustomerCode`. |\n| Выписка | `GET /api/statement?dateStart=…&dateFinish=…` | Даты вида `2026-03-01`. Необязательный `accountId`. |\n| Выписка (Excel) | `GET /api/statement/download?dateStart=…&dateFinish=…` | Возвращает файл `.xlsx`. Период не более 31 дня. |\n\n## Пример: Node.js (18+)\n\n```javascript\nconst BASE_URL = \'https://ecom-api-test.paynet.md\';\n\nasync function getToken() {\n  const res = await fetch(`${BASE_URL}/auth`, {\n    method: \'POST\',\n    headers: { \'Content-Type\': \'application/json\' },\n    body: JSON.stringify({ grantType: \'password\', username: process.env.PAYNET_USER, password: process.env.PAYNET_PASSWORD }),\n  });\n  if (!res.ok) throw new Error(`Auth failed: ${res.status} ${await res.text()}`);\n  return (await res.json()).access_token;\n}\n\nasync function createOrder(token, order) {\n  const res = await fetch(`${BASE_URL}/api/order`, {\n    method: \'POST\',\n    headers: { \'Content-Type\': \'application/json\', Authorization: `Bearer ${token}` },\n    body: JSON.stringify(order),\n  });\n  const body = await res.json();\n  if (!res.ok) throw new Error(`Create order failed: ${res.status} ${JSON.stringify(body)}`);\n  return body; // { paymentId, paymentLink, status, ... }\n}\n```\n\n## Пример: PHP\n\n```php\n<?php\n$baseUrl = \'https://ecom-api-test.paynet.md\';\n\nfunction paynetRequest(string $method, string $url, ?array $body = null, ?string $token = null): array {\n    $headers = [\'Content-Type: application/json\', \'Accept: application/json\'];\n    if ($token) { $headers[] = \'Authorization: Bearer \' . $token; }\n    $ch = curl_init($url);\n    curl_setopt_array($ch, [\n        CURLOPT_CUSTOMREQUEST  => $method,\n        CURLOPT_RETURNTRANSFER => true,\n        CURLOPT_HTTPHEADER     => $headers,\n    ]);\n    if ($body !== null) { curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body)); }\n    $raw = curl_exec($ch);\n    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);\n    curl_close($ch);\n    $data = json_decode($raw, true);\n    if ($status !== 200) { throw new RuntimeException("Paynet error $status: $raw"); }\n    return $data;\n}\n\n$auth  = paynetRequest(\'POST\', "$baseUrl/auth", [\'grantType\' => \'password\', \'username\' => getenv(\'PAYNET_USER\'), \'password\' => getenv(\'PAYNET_PASSWORD\')]);\n$token = $auth[\'access_token\'];\n// $payment = paynetRequest(\'POST\', "$baseUrl/api/order", $order, $token);\n// header(\'Location: \' . $payment[\'paymentLink\']);\n```\n',"../../content/ru/ecom/04-saved-cards.md":`# Сохранение карт

Покупатель может сохранить карту при первой оплате, а в следующий раз выбрать её на странице Paynet, не вводя номер заново.

Работает только при [интеграции server-to-server](#/guides/server-to-server). В форме hosted checkout сохранение карт недоступно.

> **Важно:** это не списание без участия покупателя. Покупатель всегда проходит через страницу Paynet и подтверждает оплату. Paynet может запросить CVC или 3-D Secure — это зависит от настроек вашего магазина на стороне Paynet.

## Подключение

Сохранение карт включается для вашего \`SaleAreaCode\` на стороне Paynet: обратитесь к вашему менеджеру Paynet. Для общей тестовой торговой зоны \`onlidocumentation_md\` оно включено: сценарий можно проверить с тестовыми доступами.

## Что такое \`CardLinkHash\`

- Внутренний идентификатор сохранённой карты в Paynet. Это не номер карты и не сетевой токен Visa/Mastercard.
- Привязан к \`SaleAreaCode\` (она принадлежит одному мерчанту) и к \`Customer.Code\` покупателя.
- В другой торговой зоне, даже того же мерчанта, токен не работает — кроме случаев, когда Paynet объединил торговые зоны в группу на своей стороне.

## Как это работает

| Шаг | Кто | Что происходит |
|---|---|---|
| 1 | Вы | Создаёте заказ \`POST /api/order\` и передаёте объект \`Customer\`. Без \`Customer\` карта не сохраняется. |
| 2 | Покупатель | Оплачивает картой на странице Paynet. Галочка «сохранить карту» стоит по умолчанию; покупатель может её снять. |
| 3 | Paynet | Присылает уведомление \`PAID\` с \`Payment.CardLinkHash\`. Если покупатель снял галочку, там \`null\`. |
| 4 | Вы | Сохраняете \`CardLinkHash\` вместе с этим покупателем (его \`Customer.Code\`). |
| 5 | Вы | При следующей оплате передаёте в \`POST /api/order\` поле \`CardLinkHash\` и те же данные \`Customer\`. |
| 6 | Покупатель | Видит на странице Paynet сохранённую карту и подтверждает оплату. |

## Первая оплата

Обычный запрос [создания заказа](#/guides/server-to-server) с объектом \`Customer\`:

\`\`\`json
{
  "Order": 1762444800000,
  "SaleAreaCode": "onlidocumentation_md",
  "LinkUrlSuccess": "https://shop.example/payment/success",
  "LinkUrlCancel": "https://shop.example/payment/cancel",
  "Customer": {
    "Code": "464566161",
    "NameFirst": "First Name",
    "NameLast": "Last Name",
    "email": "customer@example.com",
    "PhoneNumber": "37360000000"
  },
  "Currency": 498,
  "ExpiryDate": "2026-12-31T23:59:59",
  "Services": [
    { "Name": "Demo eShop", "Description": "Order #1762444800000", "Amount": 300 }
  ],
  "MoneyType": "Card",
  "Lang": "RU"
}
\`\`\`

После оплаты в уведомлении \`PAID\` придёт токен:

\`\`\`json
{
  "Payment": {
    "Id": 1234567,
    "ExternalId": 1762444800000,
    "CardLinkHash": "1037153_b3f50103610e4fe9948ff8db553151f3"
  }
}
\`\`\`

(Фрагмент. Полный формат — в разделе [Уведомления](#/guides/notifications).)

## Повторная оплата

Новый заказ с новым \`Order\`, тем же \`Customer\` и сохранённым \`CardLinkHash\`:

\`\`\`json
{
  "Order": 1762531200000,
  "SaleAreaCode": "onlidocumentation_md",
  "LinkUrlSuccess": "https://shop.example/payment/success",
  "LinkUrlCancel": "https://shop.example/payment/cancel",
  "Customer": {
    "Code": "464566161",
    "NameFirst": "First Name",
    "NameLast": "Last Name",
    "email": "customer@example.com",
    "PhoneNumber": "37360000000"
  },
  "CardLinkHash": "1037153_b3f50103610e4fe9948ff8db553151f3",
  "Currency": 498,
  "ExpiryDate": "2026-12-31T23:59:59",
  "Services": [
    { "Name": "Demo eShop", "Description": "Order #1762531200000", "Amount": 300 }
  ],
  "MoneyType": "Card",
  "Lang": "RU"
}
\`\`\`

Дальше всё как обычно: отправьте покупателя по \`paymentLink\` и дождитесь уведомления \`PAID\`.

## Что проверено на тестовой среде

| Ситуация | Что происходит |
|---|---|
| Первая оплата с \`Customer\`, галочка оставлена | \`CardLinkHash\` приходит в уведомлении и в ответе \`GET /api/order/merchant/{Order}\` (поля \`cardLinkHash\` и \`customer.cardLinkHash\`) |
| Повторная оплата: тот же \`Customer\` + \`CardLinkHash\` | На странице Paynet показана сохранённая карта (маска и срок действия). Покупатель может выбрать её, ввести другую карту или удалить сохранённую |
| Чужой \`Customer.Code\` + тот же \`CardLinkHash\` | Заказ создаётся (\`200\`), но сохранённая карта **не показывается** — покупатель вводит карту заново |
| Несуществующий \`CardLinkHash\` | Заказ создаётся (\`200\`), страница оплаты обычная |

API не отклоняет неподходящий токен при создании заказа: защита срабатывает на странице оплаты. Поэтому храните токен строго в паре с покупателем, для которого он выдан.

## Правила

- \`CardLinkHash\` работает только вместе с тем \`Customer\`, для которого он выдан. Передавайте пару без изменений.
- \`CardLinkHash\` не входит в подпись уведомления. Прежде чем сохранить его, сверьте платёж и покупателя через API — см. [Что защищает подпись](#/guides/notifications).
- Токен действует, пока действует карта. Если карта истекла или перевыпущена, покупатель оплачивает новой картой, и вы получаете новый \`CardLinkHash\` — замените им старый.
- \`CardLinkHash\` в уведомлении может быть \`null\` (покупатель снял галочку или сохранение не включено). Это нормально: просто ничего не сохраняйте.
- Храните \`CardLinkHash\` на сервере и не показывайте его в браузере.
- Чтобы удалить карту (например, по просьбе покупателя), вызовите \`POST /api/linked-cards/unlink\` с \`CardLinkHash\`, \`SaleAreaCode\` и \`CustomerCode\`.
`,"../../content/ru/ecom/05-hosted-checkout.md":`# Hosted checkout (client-server)

В этой модели браузер покупателя отправляет заказ в Paynet подписанной HTML-формой (\`POST\`). Вызывать API для создания заказа не нужно, но \`Signature\` нужно рассчитать вашим секретным ключом **на сервере**.

| Среда | URL формы (action) |
|---|---|
| Тест | \`https://test.paynet.md/ecom/checkout\` |
| Продакшн | \`https://paynet.md/ecom/checkout\` |

## Сценарий

1. Покупатель нажимает «Оплатить» в вашем магазине.
2. Ваш сервер формирует поля формы и рассчитывает \`Signature\` (см. ниже).
3. Ваша страница выводит форму, которая автоматически отправляет поля на URL checkout.
4. Покупатель платит на странице Paynet и возвращается на \`LinkUrlSuccess\` (оплачено) или \`LinkUrlCancel\` (не прошло или отменено).
5. Paynet отправляет [уведомление](#/guides/notifications) \`PAID\` на ваш callback URL (о неуспешных платежах уведомлений нет).
6. Перед отгрузкой подтвердите оплату через \`GET /api/order/merchant/{Order}\` (server-to-server API, Bearer-токен): заказы, созданные формой, ищутся по вашему \`Order\`.

## Поля формы

| Поле | Обязательно | В подписи | Описание |
|---|---|---|---|
| \`Order\` | да | да | Номер заказа у вас (целое число). Один заказ магазина = один \`Order\`. |
| \`Currency\` | да | да | Числовой код ISO 4217, \`498\` = MDL. |
| \`Merchant\` | да | да | Ваш код мерчанта. |
| \`SaleAreaCode\` | да | да | Ваш код торговой зоны. |
| \`Amount\` | да | да | Сумма в минимальных единицах: \`1235\` = 12,35 MDL. |
| \`Description\` | да | да | Описание заказа, которое увидит покупатель. |
| \`ExpiryDate\` | да | да | Срок оплаты, \`YYYY-MM-DDTHH:mm:ss\`, местное время Кишинёва. |
| \`LinkUrlSuccess\` | да | да | URL возврата после успешной оплаты. |
| \`LinkUrlCancel\` | да | да | URL возврата после отмены. |
| \`Lang\` | да | да | Язык платёжной страницы, например \`ro\`, \`ru\`, \`en\`. |
| \`MoneyType\` | да | да | Показываемые способы оплаты: \`All\`, \`Card\` (карта, Apple Pay, Google Pay), \`Paynet\`, \`MIA\`, \`CashInvoice\`. |
| \`CustomerCode\` | нет | да | ID покупателя в вашей системе. |
| \`CustomerNameFirst\` | нет | да | Имя покупателя. |
| \`CustomerNameLast\` | нет | да | Фамилия покупателя. |
| \`CustomerPhoneNumber\` | нет | да | Телефон покупателя. |
| \`CustomerEmail\` | нет | да | Email покупателя. |
| \`ProductAmount\`, \`ProductBarcode\`, \`ProductCode\`, \`ProductDescription\`, \`ProductGroupId\`, \`ProductGroupName\`, \`ProductLineNo\`, \`ProductName\`, \`ProductUnitPrice\`, \`ProductQuantity\`, \`ProductUnitProduct\` | нет | нет | Необязательные данные о товаре. |
| \`Signature\` | да | — | \`Base64(MD5(RawData + SecretKey))\` с секретным ключом **hosted checkout**, см. ниже. |

## Подпись

1. Возьмите поля из таблицы с отметкой «В подписи», которые вы действительно передаёте (поля, которые не передаёте, пропустите).
2. Отсортируйте их по имени поля от A до Z.
3. Закодируйте каждое **значение** по RFC 3986 (\`encodeURIComponent\` плюс \`! ' ( ) *\`) в UTF-8 (в том числе кириллицу и румынскую диакритику). Правильные функции для PHP, JavaScript, Python, C#, Java и правила для спецсимволов: [Подписи](#/guides/signatures).
4. Склейте закодированные значения без разделителей → \`RawData\`.
5. \`Signature = Base64( MD5( RawData + SecretKey ) )\` — Base64 от «сырого» 16-байтового MD5, а не от hex-строки.

Полный разобранный пример с ожидаемым результатом — на странице [Подписи](#/guides/signatures). Используйте его как юнит-тест.

> **Важно:** считайте подпись на сервере. Секретный ключ никогда не должен попадать в HTML или JavaScript, который уходит в браузер.

## Пример формы

\`\`\`html
<form id="paynet" method="POST" action="https://test.paynet.md/ecom/checkout">
  <input type="hidden" name="Order" value="1762444800000">
  <input type="hidden" name="Currency" value="498">
  <input type="hidden" name="Merchant" value="265505">
  <input type="hidden" name="SaleAreaCode" value="onlidocumentation_md">
  <input type="hidden" name="Amount" value="1235">
  <input type="hidden" name="Description" value="Test&amp;Co SRL">
  <input type="hidden" name="CustomerCode" value="5555">
  <input type="hidden" name="CustomerNameFirst" value="First name">
  <input type="hidden" name="CustomerNameLast" value="Last name">
  <input type="hidden" name="CustomerPhoneNumber" value="060000000">
  <input type="hidden" name="CustomerEmail" value="test@gmail.com">
  <input type="hidden" name="ExpiryDate" value="2026-12-31T23:59:59">
  <input type="hidden" name="LinkUrlCancel" value="https://test.oplta.md/cancel">
  <input type="hidden" name="LinkUrlSuccess" value="https://test.oplta.md/ok">
  <input type="hidden" name="Lang" value="ro">
  <input type="hidden" name="MoneyType" value="Card">
  <input type="hidden" name="Signature" value="cxr/+yLYZp34aR0KXLkb2A==">
</form>
<script>document.getElementById('paynet').submit();<\/script>
\`\`\`

\`Signature\` выше верна именно для этих значений и тестового ключа. Значения в HTML-атрибутах нужно экранировать (\`&\` → \`&amp;\`); браузер отправит исходное значение, и подписывается именно оно. Не используйте в значениях переносы строк, HTML-теги (\`<b>\`) и HTML-сущности (\`&#039;\`): см. [Подписи](#/guides/signatures).

## Пример: подпись на Node.js

\`\`\`javascript
import crypto from 'node:crypto';

const SIGNED_FIELDS = ['Order', 'Currency', 'Merchant', 'SaleAreaCode', 'CustomerCode', 'CustomerNameFirst',
  'CustomerNameLast', 'CustomerPhoneNumber', 'CustomerEmail', 'ExpiryDate', 'Description', 'Amount',
  'LinkUrlCancel', 'LinkUrlSuccess', 'Lang', 'MoneyType'];

const encodeRfc3986 = (v) =>
  encodeURIComponent(v).replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());

export function checkoutSignature(fields, secretKey) {
  const rawData = SIGNED_FIELDS
    .filter((name) => fields[name] !== undefined && fields[name] !== null)
    .sort()
    .map((name) => encodeRfc3986(String(fields[name])))
    .join('');
  return crypto.createHash('md5').update(rawData + secretKey, 'utf8').digest('base64');
}
\`\`\`

## Пример: подпись на PHP

\`\`\`php
<?php
function checkoutSignature(array $fields, string $secretKey): string {
    $signed = ['Order', 'Currency', 'Merchant', 'SaleAreaCode', 'CustomerCode', 'CustomerNameFirst',
        'CustomerNameLast', 'CustomerPhoneNumber', 'CustomerEmail', 'ExpiryDate', 'Description', 'Amount',
        'LinkUrlCancel', 'LinkUrlSuccess', 'Lang', 'MoneyType'];
    $present = array_values(array_filter($signed, fn($name) => isset($fields[$name])));
    sort($present, SORT_STRING);
    $rawData = '';
    foreach ($present as $name) {
        $rawData .= rawurlencode((string) $fields[$name]); // RFC 3986
    }
    return base64_encode(md5($rawData . $secretKey, true));
}
\`\`\`

## Тестирование на портале

Откройте **E-commerce → Hosted checkout → Форма checkout (попробовать)**. Портал подставит уникальный \`Order\` и будущую \`ExpiryDate\`, сгенерирует подпись тестовым ключом и откроет тестовую страницу Paynet в новой вкладке.

Если отправить \`Order\`, который уже оплачен или находится в обработке у банка-эмитента, покупатель увидит страницу Paynet «Plata a fost respinsă» (счёт уже оплачен или в обработке).
`,"../../content/ru/ecom/06-testing.md":"# Тестирование\n\n## Тестовая среда\n\n| Что | Значение |\n|---|---|\n| Базовый URL API | `https://ecom-api-test.paynet.md` |\n| URL формы hosted checkout | `https://test.paynet.md/ecom/checkout` |\n| Логин / пароль API | `771064` / `sLgMnGWJ` |\n| Код мерчанта | `265505` |\n| Код торговой зоны | `onlidocumentation_md` |\n| Секретный ключ для подписи hosted checkout | `F90D6485-9CCC-458B-96A3-8958AF9B4458` |\n| Секретный ключ для уведомлений | `D9873689-E5F8-4272-A67F-0D8BA3F9BAA7` |\n\nЭти учётные данные общие для всех, кто тестирует на портале: чужие тестовые платежи видны в поиске и выписках. Если нужна изолированная среда, запросите в Paynet собственного тестового мерчанта.\n\n## Тестовая карта\n\n| Карта | Срок | CVV | Результат |\n|---|---|---|---|\n| Visa `4111 1111 1111 1111` | `12/27` | `777` | успешный платёж |\n\nТестовыми картами можно проверить только успешную оплату: карт для отказа и 3-D Secure нет. Обработку отказа всё равно нужно реализовать и проверить на имитированных ответах API: `status` = `5` и возврат покупателя на `LinkUrlCancel` (см. [Неуспешная оплата](#/guides/errors-and-statuses)). Когда реальный платёж не проходит, покупатель просто перенаправляется на `LinkUrlCancel`, уведомление не отправляется.\n\n## Из-за чего тесты падают\n\n- **Повторный `Order`.** Тот же `Order` с другими данными или уже оплаченный `Order` даёт `500 TECHNICAL_ERROR`. Портал генерирует новый `Order` сам (текущее время в миллисекундах).\n- **`ExpiryDate` в прошлом.** Указывайте будущую дату по местному времени Кишинёва. Портал ставит конец завтрашнего дня.\n- **Суммы в MDL вместо минимальных единиц.** `100` — это 1,00 MDL.\n- **Истёкший токен.** Токен живёт около 4 часов; после `401` снова вызовите `/auth`.\n- **Товары не сходятся.** Если передаёте `Products`, передавайте все поля товара и следите, чтобы `Amount` совпадали с `Amount` услуги.\n\n## Тестовые сценарии\n\n| # | Сценарий | Как | Ожидается |\n|---|---|---|---|\n| 1 | Аутентификация | `POST /auth` с тестовыми данными | `200`, `access_token` |\n| 2 | Неверный пароль | `POST /auth` с неверным паролем | `401`, `AUTHENTICATION_FAILED` |\n| 3 | Создание заказа | `POST /api/order` | `200`, `paymentId`, `paymentLink`, `status` `1` |\n| 4 | Повтор того же запроса | отправить сценарий 3 ещё раз без изменений | тот же `paymentId` и `paymentLink` |\n| 5 | Тот же `Order`, другая сумма | изменить `Amount`, оставить `Order` | `500`, `TECHNICAL_ERROR` |\n| 6 | Неверный запрос | `POST /api/order` без `Services` | `400` с объектом `errorInfo` (недостающее поле в `errors`) |\n| 7 | Без токена | `POST /api/order` без `Authorization` | `401`, `UNAUTHORIZED` |\n| 8 | Оплата | открыть `paymentLink`, оплатить тестовой картой | возврат на `LinkUrlSuccess` |\n| 9 | Статус | `GET /api/order/merchant/{Order}` | платёж с заполненным `paidDate` |\n| 10 | Неизвестный заказ | `GET /api/order/{id}` со случайным ID | `404`, `NOT_FOUND_RECORD` |\n| 11 | Уведомление | **Симулятор уведомлений** → ваш URL | обработчик проверяет `Hash` и возвращает `200` |\n| 12 | Неверный хэш | отправить уведомление с изменённым `Amount` | обработчик его отклоняет |\n| 13 | Повторное уведомление | отправить одно уведомление дважды | обработчик обрабатывает его один раз |\n| 14 | Hosted checkout | **Форма checkout (попробовать)** | открывается тестовая страница оплаты Paynet |\n| 15 | Возврат | `POST /api/order/refund` по оплаченному платежу | `200`; `status` становится `5` (полный) или `6` (частичный) |\n| 16 | Возврат больше оплаченного | `RefundType` `partial`, `Amount` больше `PaidAmount` | `400 INVALID_PARAMETER` |\n| 17 | Сохранение карты (если включено для вашего `SaleAreaCode`) | `POST /api/order` с `Customer`, оплатить, оставив галочку «сохранить карту» | в уведомлении `PAID` заполнен `CardLinkHash` |\n| 18 | Оплата сохранённой картой (если включено) | `POST /api/order` с `CardLinkHash` и тем же `Customer` | на странице Paynet показана сохранённая карта |\n| 19 | Покупатель ушёл без оплаты | открыть `paymentLink` и закрыть страницу, затем открыть ссылку снова | `status` остаётся `1`, оплатить можно |\n\n## Имитированные ответы для тестов отказов\n\nОтказ банка, ошибки возврата и повреждённые уведомления не воспроизвести тестовой картой. Для автотестов вашей интеграции используйте готовые ответы — они взяты из реальных ответов тестовой среды, уведомления подписаны тестовым ключом. Полный список: [mocks/index.json](mocks/index.json).\n\n| Файл | Что имитирует | Что должен сделать ваш код |\n|---|---|---|\n| [payment-status-3.json](mocks/payment-status-3.json) | Оплата ещё обрабатывается | Ждать, не создавать новый заказ |\n| [payment-status-5-declined.json](mocks/payment-status-5-declined.json) | Банк отклонил оплату | Предложить новую попытку с новым `Order` |\n| [payment-status-5-refunded.json](mocks/payment-status-5-refunded.json), [payment-status-6.json](mocks/payment-status-6.json) | Полный и частичный возврат | Не выполнять заказ повторно |\n| [refund-400-amount-or-second.json](mocks/refund-400-amount-or-second.json), [refund-404-unpaid.json](mocks/refund-404-unpaid.json) | Ошибки возврата | Показать понятную ошибку, не повторять автоматически |\n| [order-500-repeated-order.json](mocks/order-500-repeated-order.json), [order-400-errorinfo.json](mocks/order-400-errorinfo.json) | Повтор `Order`, нечитаемый запрос | Обработать оба формата ошибок |\n| [error-401-token.json](mocks/error-401-token.json) | Просроченный токен | Получить новый токен и повторить запрос один раз |\n| [notification-paid.json](mocks/notification-paid.json) | Верное уведомление `PAID` | Ответить `200`, выполнить заказ один раз |\n| [notification-paid-wrong-hash.json](mocks/notification-paid-wrong-hash.json) | Неверный `Hash` | Ответить `400`, ничего не менять |\n| [notification-paid-tampered-paidamount.json](mocks/notification-paid-tampered-paidamount.json) | Верный `Hash`, но изменён неподписанный `PaidAmount` | Сверка через API должна отправить заказ на проверку |\n\nОтвет `payment-status-5-declined.json` собран вручную: значение `status` реальное, остальные поля — как у неоплаченного платежа.\n\n## Тестирование с этого портала\n\nКнопки «Test API Request» вызывают тестовый API прямо из вашего браузера. Это работает на официальном домене портала. Если открыть копию портала с другого адреса, браузер может заблокировать вызовы (CORS) — тогда используйте cURL или Postman. Готовая коллекция Postman описана ниже.\n\n## Postman\n\nГотовая коллекция работает сразу после импорта, ничего править не нужно.\n\n1. Скачайте [коллекцию](postman/paynet-ecom.postman_collection.json) и [тестовое окружение](postman/paynet-test.postman_environment.json) (они же — в боковом меню под кнопкой «Postman collection»).\n2. В Postman: **Import** → выберите оба файла → справа вверху выберите окружение **Paynet — TEST**.\n3. Запустите **1. Payments → Create order**. Токен получается автоматически, `Order` и `ExpiryDate` каждый раз новые.\n4. В **Postman Console** появится `paymentLink` — откройте его и оплатите тестовой картой.\n5. Запустите **Get payment by Order**: `status` = `4` — оплачено. Затем можно выполнить **Refund**.\n\n| Что делает коллекция сама | Как |\n|---|---|\n| Получает и обновляет токен | Перед каждым запросом, если токена нет или он скоро истечёт |\n| Создаёт уникальный заказ | `Order` = текущее время в мс, `ExpiryDate` = завтра по Кишинёву |\n| Передаёт данные между запросами | Сохраняет `paymentId`, `paymentLink`, `lastOrder`, `cardLinkHash` |\n| Считает периоды | Поиск — последние 24 часа по времени Кишинёва, выписка — последние 7 дней |\n| Показывает ошибки | Код, сообщение, `details` и `traceId` в Postman Console |\n\nПапка **5. Error examples** специально вызывает ошибки `401`, `400` и `404`, чтобы было видно, как они выглядят.\n\nДля продакшна импортируйте [окружение PRODUCTION](postman/paynet-production.postman_environment.json) и заполните **свои** `username`, `password`, `saleAreaCode`. Не делитесь этим файлом после заполнения.\n","../../content/ru/ecom/07-example-shop.md":"# Пример магазина (Node.js)\n\nГотовая минимальная интеграция server-to-server: один сервер на Node.js 18+ без внешних библиотек. Исходный код: [paynet-example-shop-node.zip](sdk/paynet-example-shop-node.zip).\n\n> **Важно:** этот пример проверяется сквозным тестом на тестовой среде Paynet: робот покупает товар в примере, оплачивает его тестовой картой, отправляет уведомление и делает возврат. Поэтому код примера заведомо рабочий.\n\n## Запуск\n\nПример — готовый интернет-магазин, подключённый к тестовой среде Paynet. Он запускается на вашем компьютере; кроме Node.js ничего устанавливать и настраивать не нужно.\n\n### Перед началом: Node.js\n\nНужен **Node.js 18 или новее**. Откройте командную строку:\n\n| Система | Как открыть |\n|---|---|\n| Windows | **Win+R** → наберите `cmd` → **Enter** |\n| macOS | программа **Терминал** (Программы → Утилиты) |\n| Linux | **Терминал** (обычно **Ctrl+Alt+T**) |\n\nВведите команду и нажмите **Enter**:\n\n```\nnode --version\n```\n\nЕсли появился номер версии (например, `v22.11.0`), всё готово. Если появилась ошибка, установите Node.js с https://nodejs.org (кнопка **LTS**), закройте командную строку и откройте её заново.\n\n### Шаг 1. Скачайте архив и запустите магазин\n\nСкачайте [paynet-example-shop-node.zip](sdk/paynet-example-shop-node.zip). В командной строке введите по очереди, нажимая **Enter** после каждой строки:\n\n```\ncd Downloads\ntar -xf paynet-example-shop-node.zip\ncd node-shop\nnode server.mjs\n```\n\n| Команда | Что делает |\n|---|---|\n| `cd Downloads` | переходит в папку «Загрузки», куда браузер сохранил архив |\n| `tar -xf …zip` | распаковывает архив (Windows 10/11, macOS), появляется папка `node-shop` |\n| `cd node-shop` | переходит в папку магазина |\n| `node server.mjs` | запускает магазин |\n\n**Linux:** вместо `tar -xf paynet-example-shop-node.zip` введите `unzip paynet-example-shop-node.zip` (стандартный `tar` в Linux не открывает `.zip`; если команды `unzip` нет: `sudo apt install unzip`).\n\nПоявится строка `Demo shop on http://localhost:3000 …`. **Не закрывайте это окно**: пока оно открыто, магазин работает. Остановить магазин — **Ctrl+C**.\n\n> Архив сохранился не в «Загрузки»? Вместо `cd Downloads` наберите `cd ` с пробелом (в Windows — `cd /d ` с пробелом) и перетащите мышью в окно командной строки **папку, в которой лежит архив**: путь вставится сам. Перетаскивайте папку, а не сам архив `.zip`. В Linux с русским интерфейсом папка может называться `Загрузки`.\n\n### Шаг 2. Оплатите тестовый заказ\n\nОткройте в браузере http://localhost:3000, нажмите **Buy** и оплатите тестовой картой: номер `4111 1111 1111 1111`, срок `12/27`, CVV `777`. После оплаты вас вернёт в магазин.\n\n### Шаг 3. Отправьте уведомление об оплате\n\nОткройте http://localhost:3000/orders. Заказ в состоянии **`pending`**, и это нормально: магазин отмечает заказ оплаченным **только после уведомления от Paynet** — так же должен работать ваш настоящий магазин. Paynet отправляет уведомления на callback URL вашего мерчанта, и до `localhost` они не доходят. Поэтому во время разработки уведомление отправляют сами: скрипт проверит платёж через API, соберёт и подпишет уведомление так же, как Paynet.\n\nОткройте **вторую** командную строку и введите, подставив номер своего заказа из колонки **Order**:\n\n```\ncd Downloads/node-shop\nnode tools/send-test-notification.mjs <Order>\n```\n\nНапример: `node tools/send-test-notification.mjs 1794411831126`. Готовую команду для каждого заказа в состоянии `pending` магазин показывает на странице заказов.\n\n### Шаг 4. Проверьте результат\n\nОбновите http://localhost:3000/orders: заказ теперь **`paid`**, рядом кнопка возврата — можно попробовать вернуть деньги.\n\n### Если что-то не получилось\n\n| Сообщение | Причина и решение |\n|---|---|\n| `'node' is not recognized…` / `command not found: node` | Node.js не установлен или командная строка открыта до установки. Установите Node.js и откройте командную строку заново |\n| `The system cannot find the path specified` / `No such file or directory` после `cd Downloads` | Архив лежит в другой папке. Воспользуйтесь подсказкой под шагом 1 |\n| `The directory name is invalid` | Вы перетащили архив `.zip`, а не папку. Перетащите папку, в которой лежит архив |\n| `tar: This does not look like a tar archive` | У вас Linux: вместо `tar -xf` используйте `unzip paynet-example-shop-node.zip` |\n| `Cannot find module …server.mjs` | Командная строка открыта не в папке `node-shop`. Повторите шаг 1 |\n| `EADDRINUSE … 3000` | Магазин уже запущен в другом окне. Закройте это окно (или нажмите в нём **Ctrl+C**) и запустите снова |\n| `Payment is not paid (status 1)` | Оплата заказа не завершена. Оформите новый заказ и оплатите его до конца |\n| Заказ остаётся `pending` | Уведомление не отправлено. Выполните шаг 3 |\n\n## Что внутри\n\n| Файл | Что делает |\n|---|---|\n| `server.mjs` | Магазин: товар, создание заказа, переход на оплату, страницы возврата, приём уведомлений, возвраты |\n| `paynet-client.mjs` | Клиент API: кэш токена, создание заказа с безопасным повтором, поиск платежа, возврат |\n| `paynet-notifications.mjs` | Обработчик уведомлений — тот же код, что в разделе [Уведомления](#/guides/notifications) |\n| `store.mjs` | Хранение в JSON-файле — замените своей базой данных |\n| `tools/send-test-notification.mjs` | Отправка подписанного уведомления `PAID` на ваш адрес |\n\n## Какие правила показывает пример\n\n| Шаг | Как сделано в примере | Правило |\n|---|---|---|\n| Создание заказа | Уникальный `Order`; тело запроса сохраняется до вызова Paynet | Повтор — только с тем же телом ([Повтор номера заказа](#/guides/errors-and-statuses)) |\n| Срок оплаты | `ExpiryDate` = сейчас + 1 день по времени Кишинёва | `Europe/Chisinau` |\n| Возврат покупателя | Страница проверяет `status` через API, а не верит переходу | Переход на `LinkUrlSuccess` — не доказательство оплаты |\n| `status` = `1` | Кнопка «продолжить оплату» по той же ссылке | Покупатель не оплачивал |\n| `status` = `3` | Страница ждёт и обновляется | Банк ещё отвечает, новый заказ не создавать |\n| `status` = `5` | Кнопка «попробовать снова» создаёт новый заказ с новым `Order` | Заказ после отказа закрыт |\n| Уведомление | Подпись, один раз на `Payment.Id`, сразу `200`, затем сверка через API | [Что защищает подпись](#/guides/notifications) |\n| Возврат | Только при `status` = `4`, не больше `PaidAmount`, один раз | [Возвраты](#/guides/errors-and-statuses) |\n| Сохранённая карта | `CardLinkHash` из подтверждённого уведомления сохраняется для покупателя | [Сохранение карт](#/guides/saved-cards) |\n\n## Переход в бой\n\nЗадайте переменные окружения боевыми значениями — они отличаются от тестовых — и не храните их в коде:\n\n| Переменная | Значение |\n|---|---|\n| `PAYNET_API_URL` | `https://ecom-api.paynet.md` |\n| `PAYNET_USERNAME`, `PAYNET_PASSWORD` | боевые доступы API |\n| `PAYNET_SALE_AREA` | ваш код торговой зоны |\n| `PAYNET_NOTIFICATION_SECRET` | боевой ключ уведомлений |\n| `PUBLIC_URL` | адрес вашего магазина (для `LinkUrlSuccess` / `LinkUrlCancel`) |\n\nЗамените `store.mjs` своей базой данных и пройдите [чек-лист запуска](#/guides/go-live).\n","../../content/ru/ecom/08-go-live.md":`# Чек-лист запуска

## Перед переходом в продакшн

**Доступы и настройки**

- [ ] Вы получили от Paynet: боевого пользователя API, код мерчанта, код торговой зоны и **два** секретных ключа (для подписи hosted checkout и для уведомлений). Боевые доступы приходят на почту администратора вашей компании; это занимает от 5 минут до нескольких дней в зависимости от подключаемых функций.
- [ ] Все тестовые значения заменены боевыми: **боевые ключи и доступы отличаются от тестовых**.
- [ ] Код использует боевые адреса: API \`https://ecom-api.paynet.md\`, форма hosted checkout \`https://paynet.md/ecom/checkout\`.
- [ ] Секреты хранятся в настройках сервера (переменные окружения, vault), а не в коде или фронтенде.
- [ ] Ваш callback URL (HTTPS) зарегистрирован в Paynet.
- [ ] \`LinkUrlSuccess\` и \`LinkUrlCancel\` указывают на боевые страницы.

**Платежи**

- [ ] Каждый заказ магазина получает свой уникальный номер \`Order\`, в том числе после перезапусков и при параллельных запросах.
- [ ] \`ExpiryDate\` вычисляется по местному времени Кишинёва (\`Europe/Chisinau\`), например «сейчас + 1 день», а не задана жёстко.
- [ ] Суммы передаются в минимальных единицах и совпадают с итогом корзины.
- [ ] Hosted checkout: подпись считается на сервере и проходит [тестовые векторы](#/guides/signatures).

**Уведомления**

- [ ] Обработчик проверяет заголовок \`Hash\` ключом уведомлений.
- [ ] Обработчик читает \`Payment.Id\` и \`Payment.ExternalId\` (именно в таком написании).
- [ ] Обработчик идемпотентен (один \`Payment.Id\` = одно выполнение заказа).
- [ ] Обработчик проверяет, что \`PaidAmount\` равен \`Amount\` (если нет согласованной с Paynet акции).
- [ ] Обработчик отвечает \`200\` только после сохранения заказа.
- [ ] Резервная задача проверяет неоплаченные заказы через \`GET /api/order/{paymentId}\`, если уведомление не пришло. О неуспешных платежах уведомлений нет.

**Эксплуатация**

- [ ] Токен кэшируется и обновляется при \`401\`.
- [ ] Ошибки логируются вместе с \`traceId\`.
- [ ] Заказ не помечается оплаченным только потому, что покупатель вернулся на \`LinkUrlSuccess\`.
- [ ] Возвраты и выписки протестированы, если вы их используете.

## После запуска

- Проведите один реальный платёж на небольшую сумму и верните его.
- Сверьте платежи первого дня с выпиской (\`GET /api/statement\`): вы получаете \`PaidAmount\` за вычетом комиссии Paynet.
`,"../../content/ru/ecom/09-sdk.md":`# SDK для PHP и Node.js

Официальные библиотеки Paynet для серверной части магазина. Они берут на себя авторизацию, правила API, подписи и обработку ошибок, а вы пишете только логику магазина. Сторонних зависимостей нет.

| | PHP | Node.js |
|---|---|---|
| Версия | 1.0.0 | 1.0.0 |
| Требования | PHP 7.4+, расширения \`curl\` и \`json\` | Node.js 18+ |
| Скачать | [paynet-ecom-sdk-php-1.0.0.zip](sdk/paynet-ecom-sdk-php-1.0.0.zip) | [paynet-ecom-sdk-node-1.0.0.zip](sdk/paynet-ecom-sdk-node-1.0.0.zip) |
| Лицензия | MIT | MIT |

> **Важно:** SDK работает только на сервере. Логин, пароль и секретные ключи нельзя передавать в браузер или в мобильное приложение. Для приложений см. [Мобильные приложения](#/guides/mobile-apps).

## Что SDK делает за вас

| Задача | Без SDK | С SDK |
|---|---|---|
| Токен доступа | Получать через \`/auth\`, хранить, обновлять | Получается сам, обновляется при \`401\` |
| Создание заказа | Хранить тело запроса, повторять его без изменений при сбое сети | Повтор после сбоя сети — сам, с тем же телом |
| Возврат | Самому проверять: оплачен ли, не больше ли суммы, не было ли возврата | Правила проверяются **до** вызова API — понятная ошибка вместо отказа API |
| Уведомления | Собрать строку из 9 полей, MD5 + Base64, сверить неподписанные поля | \`parseNotification\` + \`confirmNotification\` |
| Форма hosted checkout | RFC 3986, сортировка полей, подпись | \`buildCheckoutForm\` возвращает готовый HTML |
| Ошибки | Три формата тела и разный регистр ключей | Одна ошибка: тип, код, \`traceId\`, подсказка |
| Время | \`ExpiryDate\`, поиск и выписки — по Кишинёву | Даты переводятся сами |

## Установка

Распакуйте архив в проект — получится папка \`paynet-ecom-sdk\`.

PHP:

\`\`\`php
require __DIR__ . '/paynet-ecom-sdk/autoload.php';
\`\`\`

Node.js:

\`\`\`javascript
import { PaynetClient } from './paynet-ecom-sdk/src/index.js';
\`\`\`

Проверить, что всё на месте: \`php paynet-ecom-sdk/tests/run.php\` или \`node --test paynet-ecom-sdk/test/unit.test.js\`.

## Подключение

PHP:

\`\`\`php
use Paynet\\Ecom\\PaynetClient;

$paynet = new PaynetClient([
    'username' => getenv('PAYNET_USERNAME'),
    'password' => getenv('PAYNET_PASSWORD'),
    'environment' => 'test', // 'production' — с боевыми доступами
]);
\`\`\`

Node.js:

\`\`\`javascript
import { PaynetClient } from './paynet-ecom-sdk/src/index.js';

export const paynet = new PaynetClient({
  username: process.env.PAYNET_USERNAME,
  password: process.env.PAYNET_PASSWORD,
  environment: 'test', // 'production' — с боевыми доступами
});
\`\`\`

В Node.js сохраните этот код в файл \`paynet.js\`: примеры ниже берут клиент оттуда. Тестовые доступы — на странице [Тестирование](#/guides/testing). Боевые отличаются от тестовых.

## Создать заказ и отправить покупателя на оплату

Сохраните тело запроса вместе с заказом: если нужно повторить запрос, отправляйте его без изменений — Paynet вернёт тот же платёж.

PHP:

\`\`\`php
use Paynet\\Ecom\\Time;

$order = [
    'Order' => 1762444800000, // номер заказа в вашем магазине
    'SaleAreaCode' => 'onlidocumentation_md',
    'LinkUrlSuccess' => 'https://shop.example/payment/success',
    'LinkUrlCancel' => 'https://shop.example/payment/cancel',
    'Customer' => ['Code' => 'customer-42', 'NameFirst' => 'Ion', 'NameLast' => 'Popescu', 'email' => 'ion@example.com', 'PhoneNumber' => '37360000000'],
    'ExpiryDate' => Time::expiryInHours(24), // через сутки, по Кишинёву
    'Currency' => 498,
    'Services' => [['Name' => 'My shop', 'Description' => 'Order #1762444800000', 'Amount' => 300]], // 300 = 3,00 MDL
    'MoneyType' => 'All',
    'Lang' => 'ro',
];
$created = $paynet->createOrder($order);
header('Location: ' . $created['paymentLink']);
\`\`\`

Node.js:

\`\`\`javascript
import { expiryInHours } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

const order = {
  Order: 1762444800000, // номер заказа в вашем магазине
  SaleAreaCode: 'onlidocumentation_md',
  LinkUrlSuccess: 'https://shop.example/payment/success',
  LinkUrlCancel: 'https://shop.example/payment/cancel',
  Customer: { Code: 'customer-42', NameFirst: 'Ion', NameLast: 'Popescu', email: 'ion@example.com', PhoneNumber: '37360000000' },
  ExpiryDate: expiryInHours(24), // через сутки, по Кишинёву
  Currency: 498,
  Services: [{ Name: 'My shop', Description: 'Order #1762444800000', Amount: 300 }], // 300 = 3,00 MDL
  MoneyType: 'All',
  Lang: 'ro',
};
const { paymentId, paymentLink } = await paynet.createOrder(order);
// перенаправьте покупателя на paymentLink
\`\`\`

## Проверить оплату

Перед отгрузкой проверяйте статус через API: возврат покупателя на \`LinkUrlSuccess\` ещё не означает оплату.

PHP:

\`\`\`php
use Paynet\\Ecom\\PaymentStatus;

$payment = $paynet->getPaymentByOrder(1762444800000);
if ($payment['status'] === PaymentStatus::PAID) {
    // заказ оплачен — можно выполнять
}
\`\`\`

Node.js:

\`\`\`javascript
import { PaymentStatus } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

const payment = await paynet.getPaymentByOrder(1762444800000);
if (payment.status === PaymentStatus.PAID) {
  // заказ оплачен — можно выполнять
}
\`\`\`

Статусы: \`1\` — не оплачен, \`3\` — в обработке (ждите, до суток), \`4\` — оплачен, \`6\` — оплачен, затем частично возвращён, \`5\` — не оплачен или возвращён полностью; \`5\` и \`6\` окончательные. \`isPaid\` возвращает \`true\` только для \`4\`. Подробнее: [Статусы и ошибки](#/guides/errors-and-statuses).

## Принять уведомление

Порядок шагов: проверить подпись → **сохранить уведомление** → ответить \`200\` → сверить платёж через API и выполнить заказ по сохранённой записи. Сохраняйте до ответа: после \`200\` Paynet больше не присылает это уведомление, и несохранённое уведомление потеряется, если дальше ваш код упадёт. Сумма оплаты (\`PaidAmount\`) и некоторые другие поля в подпись не входят — поэтому нужна сверка через API.

PHP:

\`\`\`php
use Paynet\\Ecom\\Notification;
use Paynet\\Ecom\\PaynetException;

try {
    $notification = Notification::parse(file_get_contents('php://input'), $_SERVER['HTTP_HASH'] ?? null, getenv('PAYNET_NOTIFICATION_KEY'));
} catch (PaynetException $e) {
    http_response_code(400);
    exit;
}
// 1. Сохраните уведомление (ваша функция, например запись в базу). Повтор приходит с тем же Payment.Id: верните false, если оно уже сохранено.
$isNew = saveNotification($notification);

// 2. Отвечайте 200 только после сохранения.
http_response_code(200);
// Отправить ответ сейчас и продолжить работу (PHP-FPM). Без FPM ответ уйдёт по окончании скрипта.
if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
}
if (!$isNew) {
    exit;
}

// 3. После ответа: сверьте через API и выполните заказ по сохранённой записи.
// Если этот шаг упадёт, запись останется необработанной: обработайте её позже (например, задачей по расписанию).
$check = Notification::confirm($paynet, $notification, ['amount' => 300, 'customerCode' => 'customer-42']);
if ($check['ok']) {
    // выполнить заказ и отметить сохранённую запись как обработанную
} else {
    // отправить на ручную проверку: $check['problems']
}
\`\`\`

Node.js:

\`\`\`javascript
import { parseNotification, confirmNotification } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

// rawBody — тело запроса как строка, без изменений; hash — заголовок Hash
export async function handlePaynetNotification(rawBody, hash, res) {
  let notification;
  try {
    notification = parseNotification(rawBody, hash, process.env.PAYNET_NOTIFICATION_KEY);
  } catch {
    res.writeHead(400).end();
    return;
  }
  // 1. Сохраните уведомление (ваша функция, например запись в базу). Повтор приходит с тем же Payment.Id: верните false, если оно уже сохранено.
  const isNew = await saveNotification(notification);

  // 2. Отвечайте 200 только после сохранения.
  res.writeHead(200).end();
  if (!isNew) return;

  // 3. После ответа: сверьте через API и выполните заказ по сохранённой записи.
  // Если этот шаг упадёт, запись останется необработанной: обработайте её позже (например, задачей по расписанию).
  const check = await confirmNotification(paynet, notification, { amount: 300, customerCode: 'customer-42' });
  if (check.ok) {
    // выполнить заказ и отметить сохранённую запись как обработанную
  } else {
    // отправить на ручную проверку: check.problems
  }
}
\`\`\`

Используйте **ключ уведомлений**, а не ключ формы checkout. Подробнее: [Уведомления](#/guides/notifications).

## Сделать возврат

В продакшне по одному платежу — **один** возврат (полный или частичный), в течение 180 дней, не больше оплаченной суммы, не для \`CASH_INVOICE\`. SDK проверяет эти правила до обращения к API. Тип (\`full\` / \`partial\`) определяется сам по сумме.

PHP:

\`\`\`php
$refund = $paynet->refund((int) $created['paymentId'], 'onlidocumentation_md', 300, null, 'Customer request');
\`\`\`

Node.js:

\`\`\`javascript
import { paynet } from './paynet.js';

const refund = await paynet.refund({ paymentId: 328731, saleAreaCode: 'onlidocumentation_md', amount: 300, reason: 'Customer request' });
\`\`\`

Результат приходит сразу в ответе, уведомления о возврате нет.

## Форма hosted checkout

Подпись считается на сервере, в браузер уходит только готовая форма. Нужен **ключ формы checkout**.

PHP:

\`\`\`php
use Paynet\\Ecom\\Checkout;

$form = Checkout::buildForm([
    'Order' => 1762444800000,
    'Merchant' => '265505',
    'SaleAreaCode' => 'onlidocumentation_md',
    'Amount' => 300,
    'Description' => 'Order #1762444800000',
    'LinkUrlSuccess' => 'https://shop.example/payment/success',
    'LinkUrlCancel' => 'https://shop.example/payment/cancel',
    'Lang' => 'ro',
    'MoneyType' => 'All',
], getenv('PAYNET_CHECKOUT_KEY'), 'test');
echo $form['html'];
\`\`\`

Node.js:

\`\`\`javascript
import { buildCheckoutForm } from './paynet-ecom-sdk/src/index.js';

const form = buildCheckoutForm({
  secretKey: process.env.PAYNET_CHECKOUT_KEY,
  environment: 'test',
  fields: {
    Order: 1762444800000,
    Merchant: '265505',
    SaleAreaCode: 'onlidocumentation_md',
    Amount: 300,
    Description: 'Order #1762444800000',
    LinkUrlSuccess: 'https://shop.example/payment/success',
    LinkUrlCancel: 'https://shop.example/payment/cancel',
    Lang: 'ro',
    MoneyType: 'All',
  },
});
// отдайте form.html в браузер
\`\`\`

\`Currency\` по умолчанию \`498\`, \`ExpiryDate\` — через сутки по Кишинёву.

## Ошибки

Любая ошибка API или нарушение правила — это \`PaynetException\` (PHP) или \`PaynetError\` (Node.js) с полями: тип (\`kind\`), HTTP-код, код Paynet, \`traceId\`, подсказка (\`hint\`) и признак «можно повторить» (\`retryable\`).

| Тип (\`kind\`) | Когда | Что делать |
|---|---|---|
| \`validation\` | \`400\`: неверные или недостающие поля | Исправить запрос по \`details\` |
| \`authentication\` | \`/auth\`: неверный логин или пароль | Проверить доступы (тест и продакшн — разные) |
| \`unauthorized\` | \`401\` даже после обновления токена | Проверить доступы |
| \`not_found\` | \`404 NOT_FOUND_RECORD\`: нет платежа; возврат неоплаченного | Проверить \`paymentId\` / \`Order\` |
| \`server\` | \`500 TECHNICAL_ERROR\` | Проверить заказ по \`Order\`; повтор \`Order\` с другими данными — нужен новый \`Order\` |
| \`network\` | Нет ответа (таймаут, сеть) | Проверить заказ по \`Order\`, повторить тот же запрос |
| \`rule\` | SDK не стал вызывать API: нарушено правило (например, второй возврат) | Прочитать сообщение — запрос не отправлялся |
| \`wrong_address\`, \`method_not_allowed\`, \`unsupported_media_type\` | \`404\` с пустым телом, \`405\`, \`415\` | Ошибка в настройке клиента — не должна возникать при работе через SDK |

PHP:

\`\`\`php
use Paynet\\Ecom\\PaynetException;

try {
    $paynet->refund(328731, 'onlidocumentation_md', 300);
} catch (PaynetException $e) {
    error_log($e->kind . ' ' . $e->errorCode . ' traceId=' . $e->traceId . ' — ' . $e->hint);
}
\`\`\`

Node.js:

\`\`\`javascript
import { PaynetError } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

try {
  await paynet.refund({ paymentId: 328731, saleAreaCode: 'onlidocumentation_md', amount: 300 });
} catch (error) {
  if (error instanceof PaynetError) console.error(error.kind, error.code, \`traceId=\${error.traceId}\`, error.hint);
  else throw error;
}
\`\`\`

При обращении в поддержку присылайте \`traceId\`.

## Методы SDK

| Что | PHP | Node.js | Метод API |
|---|---|---|---|
| Создать заказ | \`createOrder($order)\` | \`createOrder(order)\` | \`POST /api/order\` |
| Платёж по \`paymentId\` | \`getPayment($id)\` | \`getPayment(id)\` | \`GET /api/order/{id}\` |
| Платёж по номеру заказа | \`getPaymentByOrder($order)\` | \`getPaymentByOrder(order)\` | \`GET /api/order/merchant/{id}\` |
| Оплачен ли заказ | \`isPaid($order)\` | \`isPaid(order)\` | \`GET /api/order/merchant/{id}\` |
| Поиск за период | \`searchPayments($from, $to)\` | \`searchPayments({ from, to })\` | \`GET /api/order/search\` |
| Возврат | \`refund($paymentId, $saleArea, $amount, …)\` | \`refund({ paymentId, saleAreaCode, amount, … })\` | \`POST /api/order/refund\` |
| Удалить сохранённую карту | \`unlinkCard($hash, $saleArea, $customer)\` | \`unlinkCard({ cardLinkHash, saleAreaCode, customerCode })\` | \`POST /api/linked-cards/unlink\` |
| Выписка | \`getStatement($start, $finish)\` | \`getStatement({ dateStart, dateFinish })\` | \`GET /api/statement\` |
| Выписка \`.xlsx\` | \`downloadStatement($start, $finish)\` | \`downloadStatement({ dateStart, dateFinish })\` | \`GET /api/statement/download\` |
| Проверить уведомление | \`Notification::parse(…)\`, \`Notification::confirm(…)\` | \`parseNotification(…)\`, \`confirmNotification(…)\` | — |
| Форма hosted checkout | \`Checkout::buildForm(…)\` | \`buildCheckoutForm(…)\` | — |

Поиск: даты переводятся во время Кишинёва, пустой период возвращает пустой список (API в этом случае отвечает \`404\`).

## Как SDK проверены

- **Модульные тесты** (входят в архив): подписи по тестовым векторам со страницы [Подписи](#/guides/signatures), все форматы ошибок, обновление токена, правила возврата, время Кишинёва. Запускаются при каждой публикации портала.
- **Проверка на тестовой среде** (мерчант 265505): каждый SDK создаёт свой заказ, повторяет запрос, после оплаты тестовой картой проверяет статус \`4\`, поиск, частичный возврат, отказ во втором возврате, удаление сохранённой карты, выписки и ошибки. Результат 10.11.2026: PHP — 20 из 20, Node.js — 20 из 20.

## Поддержка

Вопросы по SDK — так же, как по API: в Telegram-чате с разработчиком Paynet (через вашего менеджера) или на [support@paynet.md](mailto:support@paynet.md). Присылайте \`traceId\` из ошибки. Подробнее: [Обращение в поддержку](#/guides/errors-and-statuses).
`,"../../content/ru/ecom/10-mobile-apps.md":`# Мобильные приложения

Отдельный мобильный SDK не нужен. Мобильное приложение принимает оплату через **ваш сервер** и **страницу оплаты Paynet**. Так устроены и другие платёжные системы с оплатой на своей странице.

> **Важно:** логин и пароль API, секретные ключи и токен нельзя хранить в приложении. Приложение может скачать и разобрать кто угодно — ключи будут найдены, и от имени магазина можно будет создавать заказы, делать возвраты и подделывать уведомления. Всё, что требует ключей, делает только сервер.

## Как это работает

| Шаг | Где | Что происходит |
|---|---|---|
| 1 | Приложение | Покупатель нажимает «Оплатить». Приложение отправляет заказ на **ваш сервер** |
| 2 | Ваш сервер | Создаёт заказ в Paynet ([SDK](#/guides/sdk) или [API](#/guides/server-to-server)) и возвращает приложению \`paymentLink\` |
| 3 | Приложение | Открывает \`paymentLink\` в **системном окне браузера**. Покупатель платит на странице Paynet |
| 4 | Paynet → ваш сервер | [Уведомление](#/guides/notifications) \`PAID\`. Сервер проверяет подпись и платёж |
| 5 | Paynet → приложение | После оплаты страница возвращает покупателя на \`LinkUrlSuccess\` (или \`LinkUrlCancel\`) |
| 6 | Приложение → ваш сервер | Приложение спрашивает у **своего сервера**, оплачен ли заказ. Решение — только по ответу сервера |

## Сервер: создать заказ для приложения

Пример на Node.js с [SDK](#/guides/sdk). Приложение вызывает \`POST /mobile/orders/{id}/pay\` и получает ссылку на оплату; \`GET /mobile/orders/{id}/status\` — оплачен ли заказ.

\`\`\`javascript
import http from 'node:http';
import { PaymentStatus } from './paynet-ecom-sdk/src/index.js';
import { paynet } from './paynet.js';

// В реальном магазине заказ берётся из вашей базы по id: сумма — из заказа, а не из запроса приложения.
// expiryDate сохраняется при создании заказа (например, expiryInHours(1)), чтобы повторное нажатие
// «Оплатить» отправляло в Paynet тот же самый запрос.
const findOrder = async (id) => ({ order: Number(id), amount: 300, customerCode: 'customer-42', customerPhone: '37360000000', expiryDate: '2026-11-10T19:00:00' });

http.createServer(async (req, res) => {
  const match = req.url.match(/^\\/mobile\\/orders\\/(\\d+)\\/(pay|status)$/);
  if (!match) return res.writeHead(404).end();
  const order = await findOrder(match[1]);

  if (match[2] === 'pay' && req.method === 'POST') {
    const { paymentLink } = await paynet.createOrder({
      Order: order.order,
      SaleAreaCode: 'onlidocumentation_md',
      LinkUrlSuccess: \`https://shop.example/app/payment/success?order=\${order.order}\`,
      LinkUrlCancel: \`https://shop.example/app/payment/cancel?order=\${order.order}\`,
      Customer: { Code: order.customerCode, PhoneNumber: order.customerPhone },
      ExpiryDate: order.expiryDate,
      Currency: 498,
      Services: [{ Name: 'My shop', Description: \`Order #\${order.order}\`, Amount: order.amount }],
      MoneyType: 'All',
      Lang: 'ro',
    });
    return res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ paymentLink }));
  }

  const payment = await paynet.getPaymentByOrder(order.order);
  res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ paid: payment.status === PaymentStatus.PAID, status: payment.status }));
}).listen(3000);
\`\`\`

Авторизуйте запросы приложения к вашему серверу так же, как остальные запросы вашего приложения. Повторное нажатие «Оплатить» по тому же заказу должно отправлять в Paynet **тот же** запрос — тогда Paynet вернёт тот же платёж.

## iOS: открыть страницу оплаты

Используйте \`SFSafariViewController\` — системное окно Safari внутри приложения.

\`\`\`swift
import SafariServices
import UIKit

func openPayment(_ paymentLink: String, from viewController: UIViewController) {
    guard let url = URL(string: paymentLink) else { return }
    let safari = SFSafariViewController(url: url)
    viewController.present(safari, animated: true)
}
\`\`\`

## Android: открыть страницу оплаты

Используйте Chrome Custom Tabs (библиотека \`androidx.browser\`).

\`\`\`kotlin
import android.content.Context
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent

fun openPayment(context: Context, paymentLink: String) {
    CustomTabsIntent.Builder().build().launchUrl(context, Uri.parse(paymentLink))
}
\`\`\`

## Возврат в приложение после оплаты

Укажите в \`LinkUrlSuccess\` и \`LinkUrlCancel\` адреса вашего сайта, привязанные к приложению: **Universal Links** (iOS) и **App Links** (Android). Тогда после оплаты откроется приложение, а если его нет — ваш сайт.

После возврата приложение **не считает заказ оплаченным** по одному факту возврата: оно запрашивает статус у вашего сервера (шаг 6). Если покупатель закрыл окно оплаты, не дойдя до конца, приложение тоже спрашивает статус у сервера.

## Рекомендации

- **Не используйте WebView** для страницы оплаты. В системном окне браузера покупатель видит адрес страницы Paynet, а Apple Pay и Google Pay во встроенном WebView могут не работать.
- **Сумму берите из заказа на сервере**, а не из запроса приложения.
- **Не выполняйте заказ до подтверждения сервером**: уведомление \`PAID\` с проверенной подписью или \`status\` = \`4\` через API.
- **Проверьте на реальных устройствах** перед запуском: оплата картой, Apple Pay (iPhone), Google Pay (Android), возврат в приложение, отмена оплаты.

## Что проверить перед запуском

- [ ] В приложении нет логина, пароля, ключей и токена Paynet.
- [ ] Заказ создаёт сервер; сумма берётся из заказа на сервере.
- [ ] Страница оплаты открывается в \`SFSafariViewController\` / Chrome Custom Tabs, а не в WebView.
- [ ] После оплаты и после отмены покупатель возвращается в приложение.
- [ ] Статус заказа приложение узнаёт у сервера, а сервер — из уведомления или через API.
- [ ] Повторное нажатие «Оплатить» не создаёт второй платёж по тому же заказу.
`}),ke=[{id:`common`,title:{en:`General`,ru:`Общее`,ro:`General`}},{id:`ecom`,title:{en:`E-commerce`,ru:`E-commerce`,ro:`E-commerce`}}],Ae={};Object.entries(Oe).forEach(([e,t])=>{let n=e.match(/content\/([a-z]{2})\/([a-z]+)\/(\d+)-([a-z0-9-]+)\.md$/);if(!n)return;let[,r,i,a,o]=n,s=(t.match(/^#\s+(.+)$/m)?.[1]||o).trim();Ae[r]||(Ae[r]=[]),Ae[r].push({slug:o,section:i,order:Number(a),title:s,source:t})});var je=e=>ke.findIndex(t=>t.id===e);Object.values(Ae).forEach(e=>e.sort((e,t)=>je(e.section)-je(t.section)||e.order-t.order));var Me=e=>Ae[e]||Ae.en||[],Ne=(e,t)=>Me(e).filter(e=>e.section===t),Pe=(e,t)=>Me(e).find(e=>e.slug===t)||(Ae.en||[]).find(e=>e.slug===t),Fe=e=>e.replace(/```[\s\S]*?```/g,` `).replace(/^\s*[-*]\s+\[[ x]\]\s+/gim,` `).replace(/[#>*`|]/g,` `).replace(/\[([^\]]+)\]\([^)]+\)/g,`$1`).replace(/\s+/g,` `).trim(),Ie={en:{section:`Guides`,copyForAi:`Copy for AI`,copied:`Copied`,openMarkdown:`Markdown`,forAi:`Docs for AI`,forAiHint:`Whole documentation as one text file for ChatGPT, Claude, Gemini and other assistants`,previous:`Previous`,next:`Next`,home:`Home`,apiMethods:`API methods (try it)`,checkoutForm:`Checkout form (try it)`,notificationSimulator:`Notification simulator`,plugins:`Plugins`,postmanEnvironments:`Environments`,postmanHowTo:`How to use`,searchPlaceholder:`Search the documentation…`,searchGuides:`Guides`,searchMethods:`API methods`,searchTools:`Tools`,noResults:`No results found`,homeTitle:`Paynet for developers`,homeSubtitle:`Everything you need to connect to Paynet: guides, API reference with an online tester, and documentation ready for AI assistants.`,homeProducts:`Products`,homeGeneral:`General topics`,homeEnvironments:`Environments`,quickStart:`Quick start`,apiReference:`API methods`,ecomCardText:`Accept online payments by card, Apple Pay, Google Pay, Paynet wallet, MIA and cash invoice on a Paynet-hosted payment page.`,ecomLinks:[{label:`Integration options`,hash:`#/guides/integration-options`},{label:`Quick start`,hash:`#/guides/getting-started`},{label:`Server-to-server`,hash:`#/guides/server-to-server`},{label:`Hosted checkout`,hash:`#/guides/hosted-checkout`},{label:`Plugins`,hash:`#/page/plugins`}],testEnv:`Test`,prodEnv:`Production`,envApi:`E-commerce API`,envCheckout:`Hosted checkout form`},ru:{section:`Руководства`,copyForAi:`Копировать для ИИ`,copied:`Скопировано`,openMarkdown:`Markdown`,forAi:`Документация для ИИ`,forAiHint:`Вся документация одним текстовым файлом для ChatGPT, Claude, Gemini и других ассистентов`,previous:`Назад`,next:`Далее`,home:`Главная`,apiMethods:`Методы API (попробовать)`,checkoutForm:`Форма checkout (попробовать)`,notificationSimulator:`Симулятор уведомлений`,plugins:`Плагины`,postmanEnvironments:`Окружения`,postmanHowTo:`Как пользоваться`,searchPlaceholder:`Поиск по документации…`,searchGuides:`Руководства`,searchMethods:`Методы API`,searchTools:`Инструменты`,noResults:`Ничего не найдено`,homeTitle:`Paynet для разработчиков`,homeSubtitle:`Всё, что нужно для подключения к Paynet: руководства, справочник API с онлайн-тестером и документация, готовая для ИИ-ассистентов.`,homeProducts:`Продукты`,homeGeneral:`Общие темы`,homeEnvironments:`Окружения`,quickStart:`Быстрый старт`,apiReference:`Методы API`,ecomCardText:`Приём онлайн-платежей картой, Apple Pay, Google Pay, кошельком Paynet, MIA и наличными по счёту на платёжной странице Paynet.`,ecomLinks:[{label:`Варианты интеграции`,hash:`#/guides/integration-options`},{label:`Быстрый старт`,hash:`#/guides/getting-started`},{label:`Server-to-server`,hash:`#/guides/server-to-server`},{label:`Hosted checkout`,hash:`#/guides/hosted-checkout`},{label:`Плагины`,hash:`#/page/plugins`}],testEnv:`Тест`,prodEnv:`Продакшн`,envApi:`E-commerce API`,envCheckout:`Форма hosted checkout`},ro:{section:`Ghiduri`,copyForAi:`Copiază pentru AI`,copied:`Copiat`,openMarkdown:`Markdown`,forAi:`Documentație pentru AI`,forAiHint:`Toată documentația într-un singur fișier text pentru ChatGPT, Claude, Gemini și alți asistenți`,previous:`Înapoi`,next:`Înainte`,home:`Acasă`,apiMethods:`Metode API (încercați)`,checkoutForm:`Formular checkout (încercați)`,notificationSimulator:`Simulator notificări`,plugins:`Pluginuri`,postmanEnvironments:`Medii`,postmanHowTo:`Cum se folosește`,searchPlaceholder:`Căutați în documentație…`,searchGuides:`Ghiduri`,searchMethods:`Metode API`,searchTools:`Instrumente`,noResults:`Niciun rezultat`,homeTitle:`Paynet pentru dezvoltatori`,homeSubtitle:`Tot ce aveți nevoie pentru conectarea la Paynet: ghiduri, referința API cu tester online și documentație pregătită pentru asistenții AI.`,homeProducts:`Produse`,homeGeneral:`Subiecte generale`,homeEnvironments:`Medii`,quickStart:`Primii pași`,apiReference:`Metode API`,ecomCardText:`Acceptați plăți online cu cardul, Apple Pay, Google Pay, portofelul Paynet, MIA și factură cu plată în numerar pe pagina de plată Paynet.`,ecomLinks:[{label:`Opțiuni de integrare`,hash:`#/guides/integration-options`},{label:`Primii pași`,hash:`#/guides/getting-started`},{label:`Server-to-server`,hash:`#/guides/server-to-server`},{label:`Hosted checkout`,hash:`#/guides/hosted-checkout`},{label:`Pluginuri`,hash:`#/page/plugins`}],testEnv:`Test`,prodEnv:`Producție`,envApi:`E-commerce API`,envCheckout:`Formular hosted checkout`}},Le=({language:e,onLanguageChange:t,apiInfo:n,onHome:r,onMenu:i,menuOpen:a})=>(0,B.jsx)(`header`,{className:`bg-white border-b border-paynet-gray-200 px-3 py-2.5 sm:px-6 sm:py-4 shadow-paynet-lg relative z-50`,children:(0,B.jsxs)(`div`,{className:`flex items-center justify-between gap-2`,children:[(0,B.jsxs)(`div`,{className:`flex items-center sm:items-end gap-2 sm:gap-3 min-w-0`,children:[i&&(0,B.jsx)(`button`,{type:`button`,onClick:i,"aria-label":a?`Close menu`:`Open menu`,"aria-expanded":a,className:`md:hidden -ml-1 p-2 rounded-paynet text-paynet-gray-700 hover:bg-paynet-light`,children:a?(0,B.jsx)(xe,{className:`w-6 h-6`}):(0,B.jsx)(se,{className:`w-6 h-6`})}),(0,B.jsxs)(`a`,{href:`https://merchant.paynet.md`,target:`_blank`,rel:`noopener noreferrer`,className:`flex items-center gap-3 hover:opacity-80 transition-opacity duration-200`,children:[(0,B.jsx)(`img`,{src:`logos/paynet_business.svg`,alt:`PayNet Logo`,className:`h-6 sm:h-8 w-auto`,onError:e=>{e.currentTarget.style.display=`none`,e.currentTarget.nextElementSibling?.classList.remove(`hidden`)}}),(0,B.jsx)(`div`,{className:`hidden w-12 h-12 bg-gradient-to-br from-paynet-primary to-paynet-secondary rounded-lg flex items-center justify-center shadow-paynet-lg`,children:(0,B.jsx)(`span`,{className:`text-white font-bold text-lg`,children:`PN`})})]}),(0,B.jsxs)(`button`,{type:`button`,onClick:r,className:`sm:ml-3 flex flex-col justify-end leading-none sm:-translate-y-1.5 text-left hover:opacity-80`,children:[(0,B.jsx)(`span`,{className:`text-xs bg-paynet-orange text-white px-2 py-0.5 rounded-full font-medium w-fit mb-0.5`,children:`API`}),(0,B.jsx)(`span`,{className:`hidden sm:inline text-sm text-paynet-gray-500 font-normal leading-none`,children:n?.title||`API Documentation Portal`})]})]}),(0,B.jsxs)(`div`,{className:`flex items-center gap-2 sm:gap-3 flex-shrink-0`,children:[(0,B.jsxs)(`a`,{href:`llms-full.txt`,target:`_blank`,rel:`noopener noreferrer`,title:Ie[e].forAiHint,className:`hidden lg:inline-flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-paynet border border-paynet-primary text-paynet-primary hover:bg-paynet-light transition-colors`,children:[(0,B.jsx)(T,{className:`w-4 h-4`}),Ie[e].forAi]}),(0,B.jsx)(De,{currentLanguage:e,onLanguageChange:t})]})]})}),Re=({author:e,version:t})=>(0,B.jsx)(`footer`,{className:`bg-white border-t border-paynet-gray-200 py-4 px-6 flex-shrink-0`,children:(0,B.jsx)(`div`,{className:`text-center`,children:(0,B.jsxs)(`p`,{className:`text-sm text-paynet-gray-600`,children:[(0,B.jsx)(`span`,{className:`font-medium text-paynet-primary`,children:e}),` • `,(0,B.jsxs)(`span`,{className:`text-paynet-gray-500`,children:[`API `,t]}),` • `,(0,B.jsx)(`a`,{href:`#/guides/changelog`,className:`text-paynet-gray-500 hover:text-paynet-primary underline underline-offset-2`,children:`Documentation v3`}),` • `,(0,B.jsx)(`a`,{href:`https://docs.paynet.md/psp/`,target:`_blank`,rel:`noopener noreferrer`,className:`text-paynet-gray-500 hover:text-paynet-primary underline underline-offset-2`,children:`Previous portal version`})]})})}),ze=[{id:`start`,title:{ru:`Начало работы`,en:`Get started`,ro:`Primii pași`},items:[{kind:`home`,icon:te,label:{ru:`Обзор`,en:`Overview`,ro:`Prezentare`}},{kind:`guide`,slug:`getting-started`,icon:Se,label:{ru:`Первый платёж`,en:`First payment`,ro:`Prima plată`}},{kind:`guide`,slug:`integration-options`,icon:ie,label:{ru:`Способы интеграции`,en:`Integration options`,ro:`Moduri de integrare`}},{kind:`guide`,slug:`testing`,icon:ee,label:{ru:`Тестирование`,en:`Testing`,ro:`Testare`}}]},{id:`integration`,title:{ru:`Интеграция`,en:`Integration`,ro:`Integrare`},items:[{kind:`guide`,slug:`server-to-server`,icon:he,label:{ru:`Server-to-server`,en:`Server-to-server`,ro:`Server-to-server`}},{kind:`guide`,slug:`sdk`,icon:ce,label:{ru:`SDK (PHP, Node.js)`,en:`SDK (PHP, Node.js)`,ro:`SDK (PHP, Node.js)`}},{kind:`guide`,slug:`hosted-checkout`,icon:A,label:{ru:`Hosted checkout`,en:`Hosted checkout`,ro:`Hosted checkout`}},{kind:`guide`,slug:`mobile-apps`,icon:_e,label:{ru:`Мобильные приложения`,en:`Mobile apps`,ro:`Aplicații mobile`}},{kind:`guide`,slug:`notifications`,icon:C,label:{ru:`Уведомления`,en:`Notifications`,ro:`Notificări`}},{kind:`guide`,slug:`signatures`,icon:re,label:{ru:`Подписи`,en:`Signatures`,ro:`Semnături`}},{kind:`guide`,slug:`saved-cards`,icon:M,label:{ru:`Сохранённые карты`,en:`Saved cards`,ro:`Carduri salvate`}},{kind:`guide`,slug:`errors-and-statuses`,icon:ne,label:{ru:`Статусы и ошибки`,en:`Statuses and errors`,ro:`Statusuri și erori`}},{kind:`guide`,slug:`example-shop`,icon:ge,label:{ru:`Пример магазина`,en:`Example shop`,ro:`Magazin exemplu`}},{kind:`guide`,slug:`go-live`,icon:D,label:{ru:`Выход в production`,en:`Go live`,ro:`Lansare în producție`}}]},{id:`help`,title:{ru:`Справка`,en:`Help`,ro:`Ajutor`},items:[{kind:`page`,page:`plugins`,icon:de,label:{ru:`Плагины`,en:`Plugins`,ro:`Pluginuri`}},{kind:`guide`,slug:`ai-assistants`,icon:T,label:{ru:`AI-ассистенты`,en:`AI assistants`,ro:`Asistenți AI`}},{kind:`guide`,slug:`faq`,icon:L,label:{ru:`Частые вопросы`,en:`FAQ`,ro:`Întrebări frecvente`}},{kind:`guide`,slug:`changelog`,icon:R,label:{ru:`Изменения`,en:`Changelog`,ro:`Modificări`}}]}],Be=F,Ve={name:`paths`,autor:`Paynet V2`,version:`2026.04.01`,language:`en,ro,ru`,paths:[{"/auth":[{method:`POST`,info:[{language:`en`,name:`Authentication and authorization.`,description:`To access the Paynet service and complete authorization, you need to obtain an authorization token. You can get this token by calling the service method described below and providing the parameters (username and password) received during partner registration.`},{language:`ro`,name:`Autentificare și autorizare.`,description:`Pentru a accesa serviciul Paynet și a finaliza autorizarea, trebuie să obțineți un token de autorizare. Acest token se obține apelând metoda serviciului descrisă mai jos și transmițând parametrii (username și password) primiți la înregistrarea partenerului.`},{language:`ru`,name:`Аутентификация и авторизация.`,description:`Для доступа к сервису Paynet и прохождения авторизации необходимо получить токен авторизации. Этот токен можно получить, вызвав метод сервиса, описанный ниже, и передав параметры (username и password), полученные при регистрации партнера.`}],responses:{200:{description:`Success executed authentication.`,content:{type:`application/json`,object:{access_token:`Ccxl7QQiMEoakkrUoiUn8PIgcmSN2ouP3XNjSmgqUH-Dn8UDg0...........`,token_type:`bearer`,expires_in:14399},schema:{$ref:`#/components/schemas/AuthResponse`}}},default:{description:`Error`,content:{type:`application/json`,object:null,schema:{$ref:`#/components/schemas/ErrorModel`}}},401:{description:`Wrong username or password.`,content:{type:`application/json`,object:{status:401,message:`Wrong credentials`,code:`AUTHENTICATION_FAILED`,traceId:`8d489156-7b1c-4bfb-b88b-7a946c1b862e`,details:null},schema:{$ref:`#/components/schemas/ErrorModel`}}}}}],"/api/order":[{method:`POST`,info:[{language:`en`,name:`Create an order`,description:`In order to perform a payment via Paynet API, the payment must first be registered in the Paynet system. The Create order method is used to create (register) a new payment order by transmitting the required payment details from the Partner’s system to Paynet. Upon successful registration, Paynet generates and returns a unique payment identifier (Payment ID). This Payment ID is then used to redirect the customer to the Paynet payment page, where the user can review, confirm, and complete the payment. In this model, direct server-to-server communication between the Partner and Paynet is required. Data signing is not mandatory, as authentication is handled via an authorization token.`},{language:`ro`,name:`Creați o plată.`,description:`Pentru a efectua o plată prin API-ul Paynet, plata trebuie mai întâi înregistrată în sistemul Paynet. Metoda Create order este utilizată pentru a crea (înregistra) o comandă nouă de plată prin transmiterea către Paynet a datelor de plată necesare din sistemul Partenerului. După înregistrarea cu succes, Paynet generează și returnează un identificator unic al plății (Payment ID). Acest Payment ID este apoi folosit pentru redirecționarea clientului către pagina de plată Paynet, unde utilizatorul poate verifica, confirma și finaliza plata. În acest model este necesară comunicarea directă server-to-server între Partener și Paynet. Semnarea datelor nu este obligatorie, deoarece autentificarea se face prin token de autorizare.`},{language:`ru`,name:`Создание операции`,description:`Чтобы выполнить оплату через API Paynet, платеж сначала необходимо зарегистрировать в системе Paynet. Метод Create order используется для создания (регистрации) нового платежного заказа путем передачи необходимых платежных данных из системы Партнера в Paynet. После успешной регистрации Paynet формирует и возвращает уникальный идентификатор платежа (Payment ID). Далее этот Payment ID используется для перенаправления клиента на платежную страницу Paynet, где пользователь может проверить данные, подтвердить и завершить оплату. В этой модели требуется прямое взаимодействие сервер-сервер между Партнером и Paynet. Подписание данных не является обязательным, так как аутентификация выполняется через авторизационный токен.`}],request:{},responses:{200:{description:`Order created. Real response from the test environment for the request example (status 1 = registered, not paid yet).`,content:{type:`application/json`,object:{paymentId:328731,paymentLink:`https://test.paynet.md/ecom/getecom/328731?s=8fa1bd0923368d3bb700fccacc263735`,cardLinkHash:null,status:1,message:null,order:17624448e5,merchantCode:`265505`,saleAreaCode:`onlidocumentation_md`,linkUrlSuccess:`https://shop.example/payment/success`,linkUrlCancel:`https://shop.example/payment/cancel`,signature:`8fa1bd0923368d3bb700fccacc263735`,amount:{requestAmount:300,requestCurrency:498,amount:300,paidAmount:null},customer:{code:`464566161`,nameFirst:`First Name`,nameLast:`Last Name`,email:`customer@example.com`,country:null,city:null,address:null,phoneNumber:`37360000000`,cardLinkHash:null},payer:null,expiryDate:`2026-12-31 23:59:59`,registered:`2026-11-09 18:16:41`,paidDate:null,services:[{name:`Demo eShop`,description:`Order #1762444800000`,amount:300,products:[{lineNo:1,name:`Demo eShop`,description:`Order #1762444800000`,unitPrice:300,unitProduct:null,quantity:100,amount:300,totalAmount:300}]}],moneyType:`Card`},schema:{$ref:`#/components/schemas/PaymentResponse`}}},400:{description:`Invalid request. Either the usual error body or, when the body cannot be read, an errorInfo object.`,content:{type:`application/json`,object:{status:400,message:`One or more entered parameters are incorrect.`,code:`INVALID_PARAMETER`,traceId:`9b9346f9-f83a-465d-ac8d-dc382c460c22`,details:`The invalid parameter is: XXXX`}}},401:{description:`Bearer token missing, invalid or expired. Keys are capitalised.`,content:{type:`application/json`,object:{Status:401,Message:`Access denied. The Bearer token is missing, invalid, or has expired.`,Code:`UNAUTHORIZED`,TraceId:`b4480a88-5942-455c-99ac-68d3547aaccb`},schema:{$ref:`#/components/schemas/ErrorModelUnauthorized`}}},500:{description:`Internal server error occurred while processing the request.`,content:{type:`application/json`,object:{status:500,message:`One or more errors occurred.`,code:`TECHNICAL_ERROR`,traceId:`c546f06c-3674-4b55-8e0f-ce8aac66f49f`,details:`Please verify the transmitted data and try again, or contact support.`},schema:{$ref:`#/components/schemas/ErrorModel`}}},default:{description:`Error`,content:{type:`application/json`,object:null,schema:{$ref:`#/components/schemas/ErrorModel`}}}}}],"/api/order/merchant/{id}":[{method:`GET`,info:[{language:`en`,name:`Get a payment info by merchant order id`,description:"Returns the payment registered with your order number (the `Order` value you sent when creating the payment). Use it when you do not have the Paynet paymentId, for example after a timeout during order creation. The response contains the current status, amounts, dates and payer details."},{language:`ro`,name:`Obține informații despre plată după numărul comenzii comerciantului`,description:"Returnează plata înregistrată cu numărul comenzii dvs. (valoarea `Order` transmisă la crearea plății). Folosiți-o când nu aveți paymentId Paynet, de exemplu după un timeout la crearea comenzii. Răspunsul conține statusul curent, sumele, datele și detaliile plătitorului."},{language:`ru`,name:`Получить операцию по номеру заказа мерчанта`,description:"Возвращает платёж, зарегистрированный с вашим номером заказа (значение `Order`, переданное при создании платежа). Используйте, если у вас нет paymentId Paynet, например после таймаута при создании заказа. Ответ содержит текущий статус, суммы, даты и данные плательщика."}],responses:{200:{description:`Payment found. Real response from the test environment (status 1 = registered, not paid yet).`,content:{type:`application/json`,object:{paymentId:328731,paymentLink:`https://test.paynet.md/ecom/getecom`,cardLinkHash:null,status:1,message:null,order:17624448e5,merchantCode:`265505`,saleAreaCode:`onlidocumentation_md`,linkUrlSuccess:`https://shop.example/payment/success`,linkUrlCancel:`https://shop.example/payment/cancel`,signature:null,amount:{requestAmount:300,requestCurrency:498,amount:300,paidAmount:null},customer:{code:`464566161`,nameFirst:`First Name`,nameLast:`Last Name`,email:`customer@example.com`,country:null,city:null,address:null,phoneNumber:`37360000000`,cardLinkHash:null},payer:null,expiryDate:`2026-12-31 23:59:59`,registered:`2026-11-09 18:16:41`,paidDate:null,services:[{name:`Demo eShop`,description:`Order #1762444800000`,amount:300,products:[{lineNo:1,name:`Demo eShop`,description:`Order #1762444800000`,unitPrice:300,unitProduct:null,quantity:100,amount:300,totalAmount:300}]}],moneyType:`Card`},schema:{$ref:`#/components/schemas/PaymentResponse`}}},401:{description:`Bearer token missing, invalid or expired. Keys are capitalised.`,content:{type:`application/json`,object:{Status:401,Message:`Access denied. The Bearer token is missing, invalid, or has expired.`,Code:`UNAUTHORIZED`,TraceId:`b4480a88-5942-455c-99ac-68d3547aaccb`},schema:{$ref:`#/components/schemas/ErrorModelUnauthorized`}}},404:{description:`Record not found.`,content:{type:`application/json`,object:{status:404,message:`Record not found`,code:`NOT_FOUND_RECORD`,traceId:`e8e43475-84c2-405a-803f-eb68208f03be`,details:`No records were found for the provided data`},schema:{$ref:`#/components/schemas/ErrorModel`}}},500:{description:`Internal server error occurred while processing the request.`,content:{type:`application/json`,object:{status:500,message:`One or more errors occurred.`,code:`TECHNICAL_ERROR`,traceId:`6bc2b683-e796-43ae-9775-6d9f116675a6`,details:`Please verify the transmitted data and try again, or contact support.`},schema:{$ref:`#/components/schemas/ErrorModel`}}},default:{description:`Error`,content:{type:`application/json`,object:null,schema:{$ref:`#/components/schemas/ErrorModel`}}}}}],"/api/order/refund":[{method:`POST`,info:[{language:`en`,name:`Refund a payment`,description:`The refund method is used to return funds for a previously completed payment. To perform a refund, the Partner must send the original PaymentId, refund amount, currency, sale area code, refund type, and the reason for the refund. The refund can be processed as either a full refund or a partial refund, depending on the RefundType and the amount provided in the request. After the refund request is processed, Paynet returns the result of the operation, allowing the Partner to confirm whether the refund was successfully registered and executed in the Paynet system.`},{language:`ro`,name:`Returnarea  plații.`,description:`Metoda de refund este utilizată pentru a returna fondurile unei plăți finalizate anterior. Pentru a efectua un refund, Partenerul trebuie să transmită PaymentId-ul inițial, suma refund-ului, valuta, codul zonei de vânzare, tipul refund-ului și motivul refund-ului. Refund-ul poate fi procesat fie ca refund total, fie ca refund parțial, în funcție de RefundType și de suma transmisă în cerere. După procesarea cererii de refund, Paynet returnează rezultatul operațiunii, permițând Partenerului să confirme dacă refund-ul a fost înregistrat și executat cu succes în sistemul Paynet.`},{language:`ru`,name:`Отмена операции`,description:`Метод refund используется для возврата средств по ранее завершенному платежу. Для выполнения refund Партнер должен передать исходный PaymentId, сумму возврата, валюту, код торговой зоны, тип refund и причину возврата. Refund может быть выполнен как полный или как частичный — в зависимости от RefundType и суммы, переданной в запросе. После обработки запроса на refund Paynet возвращает результат операции, что позволяет Партнеру подтвердить, что возврат был успешно зарегистрирован и выполнен в системе Paynet.`}],responses:{200:{description:`Refund done. Real response from the test environment. eventDate uses the format dd.MM.yyyy HH:mm:ss.`,content:{type:`application/json`,object:{paymentId:328733,saleAreaCode:`onlidocumentation_md`,customer:`464566161`,eventDate:`09.11.2026 18:17:54`,refundType:`full`,currency:498,amount:400,merchant:`265505`,cardMask:`411111******1111`,cardLinkHash:null,moneyType:`CYBER_SOURCE`},schema:{$ref:`#/components/schemas/RefundResponse`}}},401:{description:`Bearer token missing, invalid or expired. Keys are capitalised.`,content:{type:`application/json`,object:{Status:401,Message:`Access denied. The Bearer token is missing, invalid, or has expired.`,Code:`UNAUTHORIZED`,TraceId:`b4480a88-5942-455c-99ac-68d3547aaccb`},schema:{$ref:`#/components/schemas/ErrorModelUnauthorized`}}},500:{description:`Internal server error occurred while processing the request.`,content:{type:`application/json`,object:{status:500,message:`One or more errors occurred.`,code:`TECHNICAL_ERROR`,traceId:`6bc2b683-e796-43ae-9775-6d9f116675a6`,details:`Please verify the transmitted data and try again, or contact support.`},schema:{$ref:`#/components/schemas/ErrorModel`}}},default:{description:`Error`,content:{type:`application/json`,object:null,schema:{$ref:`#/components/schemas/ErrorModel`}}},400:{description:`Invalid refund: amount above the paid amount, or another refund of the same payment. details names RefundType.`,content:{type:`application/json`,object:{status:400,message:`One or more entered parameters are incorrect.`,code:`INVALID_PARAMETER`,traceId:`e353a049-9eca-44e9-bc17-e5c4816320da`,details:`The invalid parameter is: RefundType`},schema:{$ref:`#/components/schemas/ErrorModel`}}},404:{description:`Payment not found or not paid.`,content:{type:`application/json`,object:{status:404,message:`Record not found`,code:`NOT_FOUND_RECORD`,traceId:`72f97a7d-3a42-4c5f-9d8e-e98ee2aaa9ac`,details:`No records were found for the provided data`},schema:{$ref:`#/components/schemas/ErrorModel`}}}}}],"/api/linked-cards/unlink":[{method:`POST`,info:[{language:`en`,name:`Delete linked card`,description:`The delete linked card method is used to deactivate and remove a previously linked card from the Paynet system. When this method is executed, the specified card token is permanently invalidated, and the card is unlinked from the customer account. As a result, the token can no longer be used for any payment operations, including recurring or one-click payments. To perform this request, the Partner must provide the unique card identifier (CardLinkHash), the corresponding SaleAreaCode, and the CustomerCode associated with the card. This method ensures that sensitive payment credentials are securely removed and prevents any further unauthorized or unintended use.`},{language:`ro`,name:`Deconectați un card atașat`,description:`Metoda delete linked card este utilizată pentru a dezactiva și elimina un card legat anterior din sistemul Paynet. La executarea acestei metode, tokenul cardului specificat este invalidat permanent, iar cardul este deconectat de la contul clientului. Ca rezultat, tokenul nu mai poate fi utilizat pentru nicio operațiune de plată, inclusiv plăți recurente sau one-click. Pentru a efectua această solicitare, Partenerul trebuie să transmită identificatorul unic al cardului (CardLinkHash), SaleAreaCode corespunzător și CustomerCode asociat cardului. Această metodă asigură eliminarea securizată a credențialelor sensibile de plată și previne orice utilizare ulterioară neautorizată sau neintenționată.`},{language:`ru`,name:`Удаление токена карты`,description:`Метод delete linked card используется для деактивации и удаления ранее привязанной карты из системы Paynet. При выполнении этого метода указанный токен карты безвозвратно инвалидируется, а карта отвязывается от аккаунта клиента. В результате токен больше не может использоваться для каких-либо платежных операций, включая рекуррентные или one-click платежи. Для выполнения запроса Партнер должен передать уникальный идентификатор карты (CardLinkHash), соответствующий SaleAreaCode и CustomerCode, связанный с картой. Этот метод обеспечивает безопасное удаление чувствительных платежных данных и предотвращает любое дальнейшее несанкционированное или непреднамеренное использование.`}],responses:{200:{description:`Success executed unlink card.`,content:{type:`application/json`,object:{responseCode:`SUCCESS`}}},400:{description:`Invalid request. Either the usual error body or, when the body cannot be read, an errorInfo object.`,content:{type:`application/json`,object:{errorInfo:{type:`https://tools.ietf.org/html/rfc9110#section-15.5.1`,title:`One or more validation errors occurred.`,status:400,detail:null,instance:null,ppResponseCodeEnum:`TECHNICAL_ERROR`,ppResponseCode:1,ppResponseCodeText:`TECHNICAL_ERROR`,errors:{$:[`JSON deserialization for type '…DeleteLinkedCardRequest' was missing required properties including: 'cardLinkHash', 'saleAreaCode', 'customerCode'.`]},traceId:`00-7c209d88f31e3e5cd2f7bd88ae2f23c2-ad167338e418068c-00`}}}},401:{description:`Bearer token missing, invalid or expired. Keys are capitalised.`,content:{type:`application/json`,object:{Status:401,Message:`Access denied. The Bearer token is missing, invalid, or has expired.`,Code:`UNAUTHORIZED`,TraceId:`b4480a88-5942-455c-99ac-68d3547aaccb`},schema:{$ref:`#/components/schemas/ErrorModelUnauthorized`}}},404:{description:`Record not found.`,content:{type:`application/json`,object:{status:404,message:`Record not found`,code:`NOT_FOUND_RECORD`,traceId:`16ce780d-2e89-47b8-9cd2-6d0d136d9816`,details:`No records were found for the provided data`},schema:{$ref:`#/components/schemas/ErrorModel`}}},500:{description:`Internal server error occurred while processing the request.`,content:{type:`application/json`,object:{status:500,message:`One or more errors occurred.`,code:`TECHNICAL_ERROR`,traceId:`c546f06c-3674-4b55-8e0f-ce8aac66f49f`,details:`Please verify the transmitted data and try again, or contact support.`},schema:{$ref:`#/components/schemas/ErrorModel`}}},default:{description:`Error`,content:{type:`application/json`,object:null,schema:{$ref:`#/components/schemas/ErrorModel`}}}}}],"/api/order/{id}":[{method:`GET`,info:[{language:`en`,name:`Get a payment info by payment id`,description:`The get payment info method is used to retrieve detailed information about a specific payment using its unique identifier (PaymentId). To perform this request, the Partner must provide the payment ID in the request URL. Paynet will return the current status of the payment along with all relevant details, such as amount, currency, transaction status, and associated metadata. This method allows the Partner to verify the payment status, track transaction progress, and obtain up-to-date information about a previously registered payment.`},{language:`ro`,name:`Obține informații despre o tranzacție prin ID-ul de plată.`,description:`Metoda get payment info este utilizată pentru a obține informații detaliate despre o plată specifică folosind identificatorul său unic (PaymentId). Pentru a efectua această solicitare, Partenerul trebuie să transmită ID-ul plății în URL-ul cererii. Paynet va returna statusul curent al plății împreună cu toate detaliile relevante, precum suma, valuta, statusul tranzacției și metadatele asociate. Această metodă permite Partenerului să verifice statusul plății, să urmărească progresul tranzacției și să obțină informații actualizate despre o plată înregistrată anterior.`},{language:`ru`,name:`Получить операцию по ID платежа.`,description:`Метод get payment info используется для получения подробной информации о конкретном платеже по его уникальному идентификатору (PaymentId). Для выполнения этого запроса Партнер должен передать ID платежа в URL запроса. Paynet вернет текущий статус платежа вместе со всеми релевантными деталями, такими как сумма, валюта, статус транзакции и связанные метаданные. Этот метод позволяет Партнеру проверять статус платежа, отслеживать прогресс транзакции и получать актуальную информацию о ранее зарегистрированном платеже.`}],responses:{200:{description:`Payment found. Real response from the test environment (status 1 = registered, not paid yet).`,content:{type:`application/json`,object:{paymentId:328731,paymentLink:`https://test.paynet.md/ecom/getecom`,cardLinkHash:null,status:1,message:null,order:17624448e5,merchantCode:`265505`,saleAreaCode:`onlidocumentation_md`,linkUrlSuccess:`https://shop.example/payment/success`,linkUrlCancel:`https://shop.example/payment/cancel`,signature:null,amount:{requestAmount:300,requestCurrency:498,amount:300,paidAmount:null},customer:{code:`464566161`,nameFirst:`First Name`,nameLast:`Last Name`,email:`customer@example.com`,country:null,city:null,address:null,phoneNumber:`37360000000`,cardLinkHash:null},payer:null,expiryDate:`2026-12-31 23:59:59`,registered:`2026-11-09 18:16:41`,paidDate:null,services:[{name:`Demo eShop`,description:`Order #1762444800000`,amount:300,products:[{lineNo:1,name:`Demo eShop`,description:`Order #1762444800000`,unitPrice:300,unitProduct:null,quantity:100,amount:300,totalAmount:300}]}],moneyType:`Card`},schema:{$ref:`#/components/schemas/PaymentResponse`}}},401:{description:`Bearer token missing, invalid or expired. Keys are capitalised.`,content:{type:`application/json`,object:{Status:401,Message:`Access denied. The Bearer token is missing, invalid, or has expired.`,Code:`UNAUTHORIZED`,TraceId:`b4480a88-5942-455c-99ac-68d3547aaccb`},schema:{$ref:`#/components/schemas/ErrorModelUnauthorized`}}},404:{description:`Record not found.`,content:{type:`application/json`,object:{status:404,message:`Record not found`,code:`NOT_FOUND_RECORD`,traceId:`e8e43475-84c2-405a-803f-eb68208f03be`,details:`No records were found for the provided data`},schema:{$ref:`#/components/schemas/ErrorModel`}}},500:{description:`Internal server error occurred while processing the request.`,content:{type:`application/json`,object:{status:500,message:`One or more errors occurred.`,code:`TECHNICAL_ERROR`,traceId:`6bc2b683-e796-43ae-9775-6d9f116675a6`,details:`Please verify the transmitted data and try again, or contact support.`},schema:{$ref:`#/components/schemas/ErrorModel`}}},default:{description:`Error`,content:{type:`application/json`,object:null,schema:{$ref:`#/components/schemas/ErrorModel`}}}}}],"/api/statement/download":[{method:`GET`,info:[{language:`en`,name:`Download statement`,description:`Generates the merchant statement for the period from dateStart to dateFinish and returns it as an Excel (.xlsx) file. The period must not exceed 31 days.`},{language:`ro`,name:`Descărcați extrasul`,description:`Generează extrasul comerciantului pentru perioada dateStart – dateFinish și îl returnează ca fișier Excel (.xlsx). Perioada nu trebuie să depășească 31 de zile.`},{language:`ru`,name:`Скачать выписку`,description:`Формирует выписку мерчанта за период от dateStart до dateFinish и возвращает её файлом Excel (.xlsx). Период не должен превышать 31 день.`}],responses:{200:{description:`Statement as an .xlsx file.`,content:{type:`application/json`,object:{}}},400:{description:`Invalid request parameters.`,content:{type:`application/json`,object:{status:400,message:`One or more entered parameters are incorrect.`,code:`INVALID_PARAMETER`,traceId:`cf5573ee-4749-4190-8a1a-881ee53e7c0a`,details:`The invalid parameter is: dateStart | dateFinish`},schema:{$ref:`#/components/schemas/ErrorModel`}}},401:{description:`Bearer token missing, invalid or expired. Keys are capitalised.`,content:{type:`application/json`,object:{Status:401,Message:`Access denied. The Bearer token is missing, invalid, or has expired.`,Code:`UNAUTHORIZED`,TraceId:`b4480a88-5942-455c-99ac-68d3547aaccb`},schema:{$ref:`#/components/schemas/ErrorModelUnauthorized`}}},500:{description:`Internal server error occurred while processing the request.`,content:{type:`application/json`,object:{status:500,message:`One or more errors occurred.`,code:`TECHNICAL_ERROR`,traceId:`6bc2b683-e796-43ae-9775-6d9f116675a6`,details:`Please verify the transmitted data and try again, or contact support.`},schema:{$ref:`#/components/schemas/ErrorModel`}}},default:{description:`Error`,content:{type:`application/json`,object:null,schema:{$ref:`#/components/schemas/ErrorModel`}}}}}],"/api/statement":[{method:`GET`,info:[{language:`en`,name:`Get statement`,description:`Retrieves a list of payment transactions for a specified period based on the provided start and end dates. Used for generating statements and transaction reporting.`},{language:`ro`,name:`Obține extras`,description:`Returnează lista tranzacțiilor de plată pentru o perioadă specificată, pe baza datelor de început și sfârșit. Este utilizat pentru generarea extraselor și rapoartelor de tranzacții.`},{language:`ru`,name:`Получить список операций`,description:`Возвращает список платёжных операций за указанный период на основе даты начала и окончания. Используется для формирования выписок и отчётности по транзакциям.`}],responses:{200:{description:`Statement for the period.`,content:{type:`application/json`,object:{statementDaily:[],totals:{startBalance:18e4,totalDebit:0,totalCredit:0,finalBalance:18e4}},schema:{$ref:`#/components/schemas/StatementResponse`}}},400:{description:`One or more entered parameters are incorrect.`,content:{type:`application/json`,object:{status:400,message:`One or more entered parameters are incorrect.`,code:`INVALID_PARAMETER`,traceId:`9697f2c8-b1c2-490a-84b3-8adda9bc22e9`,details:`The invalid parameter is: dateStart | dateFinish`},schema:{$ref:`#/components/schemas/ErrorModel`}}},401:{description:`Bearer token missing, invalid or expired. Keys are capitalised.`,content:{type:`application/json`,object:{Status:401,Message:`Access denied. The Bearer token is missing, invalid, or has expired.`,Code:`UNAUTHORIZED`,TraceId:`b4480a88-5942-455c-99ac-68d3547aaccb`},schema:{$ref:`#/components/schemas/ErrorModelUnauthorized`}}},500:{description:`Internal server error occurred while processing the request.`,content:{type:`application/json`,object:{status:500,message:`One or more errors occurred.`,code:`TECHNICAL_ERROR`,traceId:`6bc2b683-e796-43ae-9775-6d9f116675a6`,details:`Please verify the transmitted data and try again, or contact support.`},schema:{$ref:`#/components/schemas/ErrorModel`}}},default:{description:`Error`,content:{type:`application/json`,object:null,schema:{$ref:`#/components/schemas/ErrorModel`}}}}}],"/api/order/search":[{method:`GET`,info:[{language:`en`,name:`Get transaction list`,description:`The get transaction list method is used to retrieve a list of payments within a specified date and time interval. To perform this request, the Partner must provide the from and to parameters in the query string, defining the start and end of the search period. Paynet will return a collection of transactions that were created or processed within the specified timeframe. Each transaction record includes relevant details such as payment ID, amount, currency, status, and timestamps. This method allows the Partner to perform transaction monitoring, reporting, and reconciliation over a defined period.`},{language:`ro`,name:`Obține lista tranzacțiilor`,description:`Metoda get transaction list este utilizată pentru a obține o listă de plăți într-un interval specificat de dată și timp. Pentru a efectua această solicitare, Partenerul trebuie să transmită parametrii from și to în query string, definind începutul și sfârșitul perioadei de căutare. Paynet va returna o colecție de tranzacții care au fost create sau procesate în intervalul specificat. Fiecare înregistrare de tranzacție include detalii relevante precum ID-ul plății, suma, valuta, statusul și marcajele de timp. Această metodă permite Partenerului să efectueze monitorizarea tranzacțiilor, raportarea și reconcilierea pe o perioadă definită.`},{language:`ru`,name:`Список операций за период`,description:`Метод get transaction list используется для получения списка платежей за указанный интервал даты и времени. Для выполнения этого запроса Партнер должен передать параметры from и to в query string, определяя начало и конец периода поиска. Paynet вернет набор транзакций, которые были созданы или обработаны в заданном временном диапазоне. Каждая запись транзакции содержит релевантные данные, такие как ID платежа, сумма, валюта, статус и временные метки. Этот метод позволяет Партнеру выполнять мониторинг транзакций, формировать отчетность и проводить сверку за определенный период.`}],responses:{200:{description:`Payments found for the period.`,content:{type:`application/json`,object:{},schema:{$ref:`#/components/schemas/PaymentSearchResponse`}}},400:{description:`One or more entered parameters are incorrect.`,content:{type:`application/json`,object:{status:400,message:`One or more entered parameters are incorrect.`,code:`INVALID_PARAMETER`,traceId:`9697f2c8-b1c2-490a-84b3-8adda9bc22e9`,details:`The invalid parameter is: dateStart | dateFinish`},schema:{$ref:`#/components/schemas/ErrorModel`}}},401:{description:`Bearer token missing, invalid or expired. Keys are capitalised.`,content:{type:`application/json`,object:{Status:401,Message:`Access denied. The Bearer token is missing, invalid, or has expired.`,Code:`UNAUTHORIZED`,TraceId:`b4480a88-5942-455c-99ac-68d3547aaccb`},schema:{$ref:`#/components/schemas/ErrorModelUnauthorized`}}},500:{description:`Internal server error occurred while processing the request.`,content:{type:`application/json`,object:{status:500,message:`One or more errors occurred.`,code:`TECHNICAL_ERROR`,traceId:`6bc2b683-e796-43ae-9775-6d9f116675a6`,details:`Please verify the transmitted data and try again, or contact support.`},schema:{$ref:`#/components/schemas/ErrorModel`}}},default:{description:`Error`,content:{type:`application/json`,object:null,schema:{$ref:`#/components/schemas/ErrorModel`}}}}}]}]};function He(e,t,n,r){let i=Ve.paths;for(let r of i){let i=Object.keys(r).find(t=>t===e);if(i&&r[i]){let e=r[i].find(e=>e.method.toLowerCase()===t.toLowerCase());if(e&&e.info){let t=e.info.find(e=>e.language===n);if(t)return{name:t.name,description:t.description,responses:e.responses};let r=e.info.find(e=>e.language===`en`);if(r)return{name:r.name,description:r.description,responses:e.responses}}}}return{name:r||`${t.toUpperCase()} ${e.split(`/`).pop()||e}`,description:r||`${t.toUpperCase()} method for ${e}`,responses:void 0}}var Ue=e=>e===`GET`?`bg-green-100 text-green-700`:e===`POST`?`bg-blue-100 text-blue-700`:e===`PUT`?`bg-orange-100 text-orange-800`:`bg-red-100 text-red-800`,We=(e,t)=>{let n=e.toLowerCase().indexOf(t);if(n<0)return;let r=Math.max(0,n-50),i=Math.min(e.length,n+t.length+70);return`${r>0?`…`:``}${e.slice(r,i)}${i<e.length?`…`:``}`},Ge=({language:e,categories:t,route:n,navigate:r,searchQuery:i,onSearchChange:a})=>{let o=Ie[e],s=i.trim().toLowerCase(),c=_.useMemo(()=>t.flatMap(e=>e.endpoints),[t]),[l,u]=_.useState(!0),d=_.useCallback(t=>He(t.path,t.method,e,t.summary).name.replace(/\.$/,``),[e]),f=e=>n.kind===`guide`&&n.slug===e,p=e=>n.kind===`page`&&n.page===e,m=e=>n.kind===`api`&&n.endpointId===e,h=e=>`./postman/${e}`,g=_.useMemo(()=>{let t=ke.flatMap(t=>Ne(e,t.id).map(n=>({id:`guide-${n.slug}`,group:`guides`,title:n.title,subtitle:t.title[e],text:Fe(n.source),code:n.source.toLowerCase(),hash:`#/guides/${n.slug}`}))),n=c.map(t=>{let n=He(t.path,t.method,e,t.summary);return{id:`api-${t.id}`,group:`methods`,title:n.name.replace(/\.$/,``),subtitle:`${t.method} ${t.path}`,text:`${n.description||``} ${(t.parameters||[]).map(e=>e.name).join(` `)}`,code:`${t.path} ${(t.parameters||[]).map(e=>`${e.name} ${e.description||``}`).join(` `)}`.toLowerCase(),method:t.method,hash:`#/api/${t.id}`}}),r=[{id:`tool-checkout`,title:o.checkoutForm,text:`hosted checkout signature form Order Amount MoneyType`,hash:`#/page/checkout-form`},{id:`tool-notification`,title:o.notificationSimulator,text:`notification webhook callback Hash PAID`,hash:`#/page/notification-simulator`},{id:`tool-plugins`,title:o.plugins,text:`plugins WordPress WooCommerce OpenCart PrestaShop Magento CS-Cart Shopify Cybersource`,hash:`#/page/plugins`}].map(e=>({...e,group:`tools`,subtitle:``,code:e.text.toLowerCase()}));return[...t,...n,...r]},[e,c,o]),v=_.useMemo(()=>s.length<2?[]:g.map(e=>{let t=e.title.toLowerCase(),n=e.subtitle.toLowerCase(),r=e.text.toLowerCase(),i=0;return t===s?i=300:t.startsWith(s)?i=200:t.includes(s)?i=150:n.includes(s)?i=100:r.includes(s)?i=60+Math.min(20,r.split(s).length):e.code.includes(s)&&(i=40),{id:e.id,group:e.group,title:e.title,snippet:i<150&&We(e.text,s)||e.subtitle,method:`method`in e?e.method:void 0,hash:e.hash,score:i}}).filter(e=>e.score>0).sort((e,t)=>t.score-e.score),[s,g]),y={guides:o.searchGuides,methods:o.searchMethods,tools:o.searchTools},b=e=>{r(e),a(``)},x=(e,t,n)=>(0,B.jsxs)(`span`,{className:`flex items-center gap-3`,title:n&&n!==t?n:void 0,children:[(0,B.jsx)(e,{className:`w-4 h-4 flex-shrink-0 text-paynet-gray-500`,strokeWidth:1.75}),(0,B.jsx)(`span`,{children:t})]}),S=(e,t,n,r=``)=>(0,B.jsx)(`button`,{type:`button`,onClick:n,className:`w-full text-left px-3 py-2 rounded-lg text-sm transition-all duration-200 ${r} ${t?`bg-white border-l-4 border-paynet-primary shadow-paynet-lg font-semibold text-paynet-gray-900`:`text-paynet-gray-700 hover:bg-paynet-light`}`,children:e}),C=(e,t)=>S((0,B.jsxs)(`span`,{className:`inline-flex items-center gap-2`,children:[(0,B.jsx)(ye,{className:`w-3.5 h-3.5 text-paynet-primary`}),e]}),p(t),()=>r(`#/page/${t}`),`pl-10`),w=(0,B.jsxs)(`div`,{className:`pl-7`,children:[(0,B.jsxs)(`button`,{type:`button`,onClick:()=>u(e=>!e),className:`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm text-paynet-gray-700 hover:bg-paynet-light`,children:[(0,B.jsxs)(`span`,{className:`inline-flex items-center gap-2`,children:[(0,B.jsx)(ye,{className:`w-3.5 h-3.5 text-paynet-primary`}),o.apiMethods]}),(0,B.jsx)(k,{className:`w-4 h-4 text-paynet-gray-500 transition-transform ${l?`rotate-90`:``}`})]}),l&&(0,B.jsx)(`div`,{className:`space-y-1 pl-3 mt-1`,children:c.map(e=>(0,B.jsx)(`button`,{type:`button`,onClick:()=>r(`#/api/${e.id}`),className:`w-full text-left px-3 py-2 rounded-lg transition-all duration-200 ${m(e.id)?`bg-white border-l-4 border-paynet-primary shadow-paynet-lg`:`hover:bg-paynet-light`}`,children:(0,B.jsxs)(`div`,{className:`flex items-start gap-2`,children:[(0,B.jsx)(`span`,{className:`text-[10px] font-mono px-1.5 py-0.5 rounded font-semibold mt-0.5 ${Ue(e.method)}`,children:e.method}),(0,B.jsx)(`span`,{className:`text-sm text-paynet-gray-800 leading-snug`,children:d(e)})]})},e.id))})]});return(0,B.jsxs)(`div`,{className:`w-full md:w-72 lg:w-80 h-full bg-paynet-gray-50 border-r border-paynet-gray-200 flex flex-col md:flex-shrink-0 min-h-0`,children:[(0,B.jsxs)(`div`,{className:`p-5 border-b border-paynet-gray-200 flex-shrink-0 bg-white`,children:[(0,B.jsxs)(`div`,{className:`relative`,children:[(0,B.jsx)(pe,{className:`absolute left-3 top-1/2 transform -translate-y-1/2 text-paynet-gray-400 w-4 h-4`}),(0,B.jsx)(`input`,{type:`search`,placeholder:o.searchPlaceholder,value:i,onChange:e=>a(e.target.value),className:`w-full pl-10 pr-9 py-3 border border-paynet-gray-300 rounded-lg focus:ring-2 focus:ring-paynet-primary focus:border-transparent transition-all duration-200 bg-white text-sm [&::-webkit-search-cancel-button]:hidden`}),i&&(0,B.jsx)(`button`,{type:`button`,onClick:()=>a(``),className:`absolute right-3 top-1/2 -translate-y-1/2 text-paynet-gray-400 hover:text-paynet-gray-700`,"aria-label":`Clear`,children:(0,B.jsx)(xe,{className:`w-4 h-4`})})]}),(0,B.jsxs)(`a`,{href:h(`paynet-ecom.postman_collection.json`),download:!0,className:`mt-3 w-full inline-flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-paynet-primary bg-white border border-paynet-gray-200 hover:bg-paynet-light rounded-lg transition-colors`,children:[(0,B.jsx)(N,{className:`w-4 h-4`}),`Postman collection`]}),(0,B.jsxs)(`div`,{className:`mt-1.5 flex flex-wrap justify-center gap-x-2 text-xs text-paynet-gray-500`,children:[(0,B.jsxs)(`span`,{children:[o.postmanEnvironments,`:`]}),(0,B.jsx)(`a`,{href:h(`paynet-test.postman_environment.json`),download:!0,className:`text-paynet-primary hover:underline`,children:`TEST`}),(0,B.jsx)(`a`,{href:h(`paynet-production.postman_environment.json`),download:!0,className:`text-paynet-primary hover:underline`,children:`PRODUCTION`}),(0,B.jsx)(`button`,{type:`button`,onClick:()=>r(`#/guides/testing`),className:`text-paynet-primary hover:underline`,children:o.postmanHowTo})]})]}),(0,B.jsx)(`nav`,{className:`p-4 flex-1 overflow-y-auto min-h-0 bg-paynet-gray-50`,children:s.length>=2?(0,B.jsxs)(`div`,{className:`space-y-4`,children:[[`guides`,`methods`,`tools`].map(e=>{let t=v.filter(t=>t.group===e).slice(0,10);return t.length?(0,B.jsxs)(`div`,{children:[(0,B.jsx)(`div`,{className:`text-xs font-semibold uppercase tracking-wide text-paynet-gray-500 mb-2 px-1`,children:y[e]}),(0,B.jsx)(`div`,{className:`space-y-1`,children:t.map(e=>(0,B.jsxs)(`button`,{type:`button`,onClick:()=>b(e.hash),className:`w-full text-left p-3 rounded-lg bg-white hover:bg-paynet-light hover:shadow-paynet transition-all`,children:[(0,B.jsxs)(`div`,{className:`flex items-center gap-2`,children:[e.method&&(0,B.jsx)(`span`,{className:`text-[10px] font-mono px-1.5 py-0.5 rounded font-semibold ${Ue(e.method)}`,children:e.method}),(0,B.jsx)(`span`,{className:`text-sm font-medium text-paynet-gray-900`,children:e.title})]}),e.snippet&&(0,B.jsx)(`div`,{className:`text-xs text-paynet-gray-500 mt-1 line-clamp-2`,children:e.snippet})]},e.id))})]},e):null}),v.length===0&&(0,B.jsx)(`div`,{className:`text-sm text-paynet-gray-500 px-3 py-2 bg-white rounded-lg`,children:o.noResults})]}):(0,B.jsx)(`div`,{className:`space-y-6`,children:ze.map((t,i)=>{let a=ke.flatMap(t=>Ne(e,t.id)),s=new Set(ze.flatMap(e=>e.items.map(e=>e.kind===`guide`?e.slug:``))),c=i===ze.length-1?a.filter(e=>!s.has(e.slug)):[];return(0,B.jsxs)(`div`,{children:[(0,B.jsx)(`div`,{className:`text-xs font-semibold uppercase tracking-wider text-paynet-gray-500 mb-2 px-3`,children:t.title[e]}),(0,B.jsxs)(`div`,{className:`space-y-0.5`,children:[t.items.map(t=>{if(t.kind===`home`)return(0,B.jsx)(_.Fragment,{children:S(x(t.icon,t.label[e]),n.kind===`home`,()=>r(`#/`))},`home`);if(t.kind===`page`)return(0,B.jsx)(_.Fragment,{children:S(x(t.icon,t.label[e]),p(t.page),()=>r(`#/page/${t.page}`))},t.page);let i=a.find(e=>e.slug===t.slug);return i?(0,B.jsxs)(_.Fragment,{children:[S(x(t.icon,t.label[e],i.title),f(t.slug),()=>r(`#/guides/${t.slug}`)),t.slug===`notifications`&&C(o.notificationSimulator,`notification-simulator`),t.slug===`server-to-server`&&w,t.slug===`hosted-checkout`&&C(o.checkoutForm,`checkout-form`)]},t.slug):null}),c.map(e=>(0,B.jsx)(_.Fragment,{children:S(x(Be,e.title),f(e.slug),()=>r(`#/guides/${e.slug}`))},e.slug))]})]},t.id)})})})]})},Ke=`<!DOCTYPE html>
<html>
<head>
    <title>Authentication Information</title>
</head>
<body>
    <div class="auth-info">
        <p>All API requests require authentication using the following headers:</p>        
        <div class="auth-keys-full">
            <div class="auth-key">
                <h3>Authorization</h3>
                <p>Value: <b>Bearer {{token}}</b>. The token must be obtained via the <code>/auth</code> endpoint.</p>
            </div>
        </div>
        
        <div class="auth-example">
            <h3>Example Headers:</h3>
            <pre><code>Headers:
Authorization: Bearer MFL3Az5eYT9JFAxT....L2iG20KPnDQw6Zhw5uW7QftBpATXdP_......
Accept-Language: en-US
Content-Type: application/json
</code></pre>
        </div>
        
        <div class="auth-note">
            <p><strong>Note:</strong> You can obtain your API credentials from the PayNet Developer Portal after creating an account. 
            You will need:
            <ul>
                <li><b>username</b> — your user identifier</li>
                <li><b>password</b> — your account password</li>
            </ul>
            </p>
        </div>
    </div>
</body>
</html>`,qe=`<!DOCTYPE html>
<html>
<head>
    <title>Informații despre Autentificare</title>
</head>
<body>
    <div class="auth-info">
        <p>Toate cererile către API necesită autentificare dublă utilizând următoarele antete (headers):</p>        
        <div class="auth-keys-full">
            <div class="auth-key">
                <h3>Authorization</h3>
                <p> Valoarea <b> Bearer {{token}} </b>, tokenul trebuie obținut prin metoda de autentificare /auth</p>
            </div>
        </div>
        
        <div class="auth-example">
            <h3>Exemplu de Headere:</h3>
            <pre><code>Headere:
                <b> Authorization: </b>  Bearer MFL3Az5eYT9JFAxT .... L2iG20KPnDQw6Zhw5uW7QftBpATXdP_ ......
                <b> Accept-Language: </b>  ro-RO
                <b> Content-Type: </b>  application/json</code>
            </pre>
        </div>
        
        <div class="auth-note">
            <p><strong>Notă:</strong> Puteți obține credențialele API în portalul pentru dezvoltatori PayNet după crearea unui cont. 
            Este necesar să obțineți username (numele utilizatorului) și password (parola).</p>
        </div>
    </div>
</body>
</html>`,Je=`<!DOCTYPE html>
<html>
<head>
    <title>Информация об Аутентификации</title>
</head>
<body>
    <div class="auth-info">
        <p>Все запросы к API требуют двойной аутентификации с использованием следующих заголовков в header:</p>        
        <div class="auth-keys-full">
            <div class="auth-key">
                <h3>Authorization</h3>
                <p> Значение <b> Bearer {{token}} </b> ,  значение токена необходимо получить на методе Авторизации /auth</p>
            </div>
        </div>
        
        <div class="auth-example">
            <h3>Пример Заголовков:</h3>
            <pre><code>Заголовки:
                <b> Authorization: </b>  Bearer MFL3Az5eYT9JFAxT .... L2iG20KPnDQw6Zhw5uW7QftBpATXdP_ ......
                <b> Accept-Language: </b>  ru-RU
                <b> Content-Type: </b>  application/json</code>
            </pre>
        </div>
        
        <div class="auth-note">
            <p><strong>Примечание:</strong> Вы можете получить свои API-учетные данные на портале разработчиков PayNet после создания учетной записи. 
            Вам необходимо получить username - название пользователя,  password - это будет пароль</p>
        </div>
    </div>
</body>
</html>`,Ye=({t:e,language:t})=>{let[n,r]=_.useState(!1);return(0,B.jsxs)(`div`,{className:`mb-10 bg-gradient-to-r from-paynet-light to-paynet-gray-50 rounded-paynet border border-paynet-gray-200 overflow-hidden w-full max-w-none`,children:[(0,B.jsxs)(`button`,{onClick:()=>r(!n),className:`w-full p-4 sm:p-6 flex items-center justify-between hover:bg-paynet-gray-50 transition-colors`,children:[(0,B.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,B.jsx)(oe,{className:`w-5 h-5 text-paynet-primary`}),(0,B.jsx)(`h2`,{className:`text-lg sm:text-xl font-semibold text-paynet-primary`,children:e.common.authentication})]}),n?(0,B.jsx)(O,{className:`w-5 h-5 text-paynet-primary transition-transform`}):(0,B.jsx)(k,{className:`w-5 h-5 text-paynet-primary transition-transform`})]}),n&&(0,B.jsxs)(B.Fragment,{children:[(0,B.jsx)(`div`,{className:`auth-content p-4 sm:p-6 pt-0 w-full`,dangerouslySetInnerHTML:{__html:(()=>{switch(t){case`ro`:return qe;case`ru`:return Je;default:return Ke}})()}}),(0,B.jsxs)(`div`,{className:`grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 sm:p-6 pt-0 w-full`,children:[(0,B.jsx)(`div`,{className:`bg-white p-3 sm:p-4 rounded-paynet border border-paynet-gray-200 w-full`,children:(0,B.jsxs)(`div`,{className:`flex items-center gap-2 mb-2`,children:[(0,B.jsx)(z,{className:`w-4 h-4 text-paynet-primary`}),(0,B.jsx)(`span`,{className:`font-mono text-xs sm:text-sm font-semibold text-paynet-primary break-all`,children:`username`})]})}),(0,B.jsx)(`div`,{className:`bg-white p-3 sm:p-4 rounded-paynet border border-paynet-gray-200 w-full`,children:(0,B.jsxs)(`div`,{className:`flex items-center gap-2 mb-2`,children:[(0,B.jsx)(z,{className:`w-4 h-4 text-paynet-primary`}),(0,B.jsx)(`span`,{className:`font-mono text-xs sm:text-sm font-semibold text-paynet-primary break-all`,children:`password`})]})})]})]})]})},Xe={en:{button:`Copy for AI`,copied:`Copied`,more:`More AI options`,copyPage:`Copy page`,copyPageHint:`Markdown for ChatGPT, Claude, Gemini…`,view:`View as Markdown`,viewHint:`This page as plain text`,openIn:e=>`Open in ${e}`,openHint:`Ask about this page`,geminiHint:`Prompt is copied: paste it in Gemini`,connect:`Connect an AI assistant`,connectHint:`Cursor, VS Code, Claude Code, Codex`,prompt:(e,t,n)=>`Read the Paynet developer documentation page "${e}": ${t}\nFull documentation: ${n}\nThen help me with my integration. Use only this documentation as the source of truth.`},ru:{button:`Копировать для ИИ`,copied:`Скопировано`,more:`Другие действия для ИИ`,copyPage:`Копировать страницу`,copyPageHint:`Markdown для ChatGPT, Claude, Gemini…`,view:`Открыть как Markdown`,viewHint:`Эта страница простым текстом`,openIn:e=>`Открыть в ${e}`,openHint:`Задать вопрос по этой странице`,geminiHint:`Запрос скопирован: вставьте его в Gemini`,connect:`Подключить ИИ-помощника`,connectHint:`Cursor, VS Code, Claude Code, Codex`,prompt:(e,t,n)=>`Прочитай страницу документации Paynet для разработчиков «${e}»: ${t}\nПолная документация: ${n}\nЗатем помоги мне с интеграцией. Используй только эту документацию как источник. Отвечай на русском.`},ro:{button:`Copiază pentru AI`,copied:`Copiat`,more:`Alte acțiuni pentru AI`,copyPage:`Copiază pagina`,copyPageHint:`Markdown pentru ChatGPT, Claude, Gemini…`,view:`Deschide ca Markdown`,viewHint:`Această pagină ca text simplu`,openIn:e=>`Deschide în ${e}`,openHint:`Întreabă despre această pagină`,geminiHint:`Cererea e copiată: lipește-o în Gemini`,connect:`Conectează un asistent AI`,connectHint:`Cursor, VS Code, Claude Code, Codex`,prompt:(e,t,n)=>`Citește pagina de documentație Paynet pentru dezvoltatori „${e}”: ${t}\nDocumentația completă: ${n}\nApoi ajută-mă cu integrarea. Folosește doar această documentație ca sursă. Răspunde în română.`}},Ze=()=>window.location.href.split(`#`)[0].replace(/[^/]*$/,``),Qe=({language:e,title:t,markdownPath:n,markdownLanguage:r,markdown:i,onNavigate:a})=>{let o=Xe[e]||Xe.en,[s,c]=_.useState(!1),[l,u]=_.useState(!1),[d,f]=_.useState(null),p=_.useRef(null),m=new URL(n,Ze()).href,h=new URL(`llms-full.txt`,Ze()).href,g=o.prompt(t,m,h);_.useEffect(()=>{if(!s)return;let e=e=>{p.current&&!p.current.contains(e.target)&&c(!1)},t=e=>e.key===`Escape`&&c(!1);return document.addEventListener(`mousedown`,e),document.addEventListener(`keydown`,t),()=>{document.removeEventListener(`mousedown`,e),document.removeEventListener(`keydown`,t)}},[s]),_.useEffect(()=>{if(f(null),i!==void 0)return;let e=!1;return fetch(n).then(e=>e.ok?e.text():null).then(t=>!e&&f(t)).catch(()=>void 0),()=>{e=!0}},[n,i]);let v=()=>`${i??d??`${t}\n${m}`}\n\n---\nSource: ${m}\nFull documentation for AI assistants: ${h}\n`,y=async e=>{try{await navigator.clipboard.writeText(e),u(!0),setTimeout(()=>u(!1),2e3)}catch{u(!1)}},b=e=>{window.open(e,`_blank`,`noopener,noreferrer`),c(!1)},x=(e,t,n,r,i,a=!1)=>(0,B.jsxs)(`button`,{type:`button`,role:`menuitem`,onClick:i,className:`w-full flex items-start gap-3 px-3 py-2 rounded-md text-left hover:bg-paynet-light transition-colors`,children:[(0,B.jsx)(`span`,{className:`mt-0.5 text-paynet-gray-600`,children:t}),(0,B.jsxs)(`span`,{className:`min-w-0`,children:[(0,B.jsxs)(`span`,{className:`flex items-center gap-1 text-sm font-medium text-paynet-gray-900`,children:[n,a&&(0,B.jsx)(P,{className:`w-3 h-3 text-paynet-gray-400`})]}),(0,B.jsx)(`span`,{className:`block text-xs text-paynet-gray-500`,children:r})]})]},e);return(0,B.jsxs)(`div`,{ref:p,className:`relative inline-flex`,children:[(0,B.jsxs)(`button`,{type:`button`,onClick:()=>y(v()),className:`inline-flex items-center gap-1.5 text-sm font-medium pl-3 pr-2.5 py-1.5 rounded-l-paynet border border-paynet-primary text-paynet-primary bg-white hover:bg-paynet-light transition-colors`,children:[l?(0,B.jsx)(D,{className:`w-4 h-4`}):(0,B.jsx)(T,{className:`w-4 h-4`}),l?o.copied:o.button]}),(0,B.jsx)(`button`,{type:`button`,onClick:()=>c(e=>!e),"aria-haspopup":`menu`,"aria-expanded":s,"aria-label":o.more,title:o.more,className:`inline-flex items-center px-2 py-1.5 rounded-r-paynet border border-l-0 border-paynet-primary text-paynet-primary bg-white hover:bg-paynet-light transition-colors`,children:(0,B.jsx)(O,{className:`w-4 h-4 transition-transform ${s?`rotate-180`:``}`})}),s&&(0,B.jsxs)(`div`,{role:`menu`,className:`absolute right-0 top-full mt-2 w-80 z-30 bg-white border border-paynet-gray-200 rounded-paynet shadow-lg p-1.5`,children:[x(`copy`,(0,B.jsx)(j,{className:`w-4 h-4`}),o.copyPage,o.copyPageHint,()=>{y(v()),c(!1)}),x(`view`,(0,B.jsx)(F,{className:`w-4 h-4`}),`${o.view} (${r})`,o.viewHint,()=>b(n),!0),(0,B.jsx)(`div`,{className:`my-1 border-t border-paynet-gray-100`}),x(`chatgpt`,(0,B.jsx)(ve,{className:`w-4 h-4`}),o.openIn(`ChatGPT`),o.openHint,()=>b(`https://chatgpt.com/?q=${encodeURIComponent(g)}`),!0),x(`claude`,(0,B.jsx)(ve,{className:`w-4 h-4`}),o.openIn(`Claude`),o.openHint,()=>b(`https://claude.ai/new?q=${encodeURIComponent(g)}`),!0),x(`gemini`,(0,B.jsx)(ve,{className:`w-4 h-4`}),o.openIn(`Gemini`),o.geminiHint,()=>{y(g),b(`https://gemini.google.com/app`)},!0),(0,B.jsx)(`div`,{className:`my-1 border-t border-paynet-gray-100`}),x(`connect`,(0,B.jsx)(ue,{className:`w-4 h-4`}),o.connect,o.connectHint,()=>{c(!1),a(`#/guides/ai-assistants`)})]})]})},$e=e=>e.replace(/\s+/g,` `).trim(),et={ru:Object.fromEntries(Object.entries({"A descriptive reason or justification for processing the refund.":`Причина или обоснование выполнения возврата.`,Error:`Ошибка`,"Gets or sets a human-readable, descriptive error message intended for the client.":`Содержит человеко-читаемое описание ошибки для клиента.`,"Gets or sets an optional unique identifier used for request tracing and debugging in the logs.":`Содержит необязательный уникальный идентификатор для трассировки запроса и отладки в логах.`,"Gets or sets optional technical details or additional context regarding the error (e.g., specific validation failures).":`Содержит необязательные технические детали или дополнительный контекст ошибки (например, конкретные ошибки валидации).`,"Gets or sets the HTTP status code associated with the error (e.g., 400, 401, 500).":`Содержит HTTP-статус, связанный с ошибкой (например, 400, 401, 500).`,"Gets or sets the internal business logic error code or its string representation.":`Содержит внутренний код ошибки бизнес-логики или его строковое представление.`,"Handles operations related to merchant financial statements, including data retrieval and exporting reports.":`Описывает операции с финансовыми выписками мерчанта, включая получение данных и экспорт отчетов.`,"Handles operations related to saved or linked payment cards for authorized users.":`Описывает операции с сохраненными/привязанными платежными картами авторизованных пользователей.`,"Only token.":`Только токен.`,"Psp Controller":`Контроллер PSP.`,"Represents a service included in the payment request.":`Представляет услугу, включенную в платежный запрос.`,"Represents a single product item within a service.":`Представляет отдельную товарную позицию внутри услуги.`,"Represents a standardized error response returned by the API.":`Представляет стандартизированный ответ API с ошибкой.`,"Represents the customer details for a payment.":`Представляет данные клиента для платежа.`,"Represents the payload for initiating a payment request.":`Представляет тело запроса для инициации платежа.`,"Represents the payload for initiating a payment request. Fields not marked as required are optional.":`Представляет тело запроса для инициации платежа. Поля, не отмеченные как обязательные, являются необязательными.`,"Represents the payload required to initiate a refund for a specific payment transaction.":`Представляет тело запроса, необходимое для инициации возврата по конкретной платежной транзакции.`,"Represents the payload required to unlink a saved payment card.":`Представляет тело запроса, необходимое для отвязки сохраненной платежной карты.`,"The URL to redirect to if the payment is canceled.":`URL для перенаправления в случае отмены платежа.`,"The URL to redirect to upon a successful payment.":`URL для перенаправления при успешной оплате.`,"The authentication request model.":`Модель запроса аутентификации.`,'The authorization grant type (e.g., "password").':`Тип grant для авторизации (например, "password").`,"The code identifying the specific sale area or merchant environment.":`Код, определяющий конкретную торговую зону или окружение мерчанта.`,"The code identifying the specific sale area or point of sale where the original transaction occurred.":`Код, определяющий конкретную торговую зону или точку продаж, где произошла исходная транзакция.`,"The code representing the sale area or merchant location.":`Код торговой зоны или локации мерчанта.`,"The currency code.":`Код валюты.`,"The description of the service.":`Описание услуги.`,"End of the search period in Chișinău local time, YYYY-MM-DDTHH:mm:ss (a trailing Z is ignored).":`Конец периода поиска по времени Кишинёва, YYYY-MM-DDTHH:mm:ss (пометка Z не учитывается).`,"The ending date of the report period (must be within 31 days of the start date).":`Дата окончания отчетного периода (должна быть в пределах 31 дня от даты начала).`,"The ending date of the statement period.":`Дата окончания периода выписки.`,"The exact amount to be refunded.":`Точная сумма к возврату.`,"The expiration date and time for this payment request. Format YYYY-MM-DDTHH:mm:ss, Chisinau local time (Europe/Chisinau); must be in the future.":`Дата и время истечения срока действия платёжного запроса. Формат YYYY-MM-DDTHH:mm:ss, местное время Кишинёва (Europe/Chisinau); должна быть в будущем.`,"The final total amount including any taxes or discounts.":`Итоговая сумма с учетом налогов или скидок.`,"The line number or position of the product in the list.":`Порядковый номер или позиция товара в списке.`,"The list of services included in this payment.":`Список услуг, включенных в этот платеж.`,"The name of the product.":`Название товара.`,"The name of the service.":`Название услуги.`,"The numeric ISO code of the currency for the refund amount.":`Числовой код ISO валюты суммы возврата.`,"The payload containing the details needed to identify and unlink the card.":`Тело запроса с данными, необходимыми для идентификации и отвязки карты.`,"The payload containing the necessary details to process the refund.":`Тело запроса с данными, необходимыми для обработки возврата.`,"The payload containing the payment details":`Тело запроса с платежными данными.`,"The price per single unit of the product.":`Цена за одну единицу товара.`,"Quantity in hundredths: 100 = 1 pc, 300 = 3 pcs.":`Количество в сотых долях: 100 = 1 шт., 300 = 3 шт.`,"Start of the search period in Chișinău local time, YYYY-MM-DDTHH:mm:ss (a trailing Z is ignored).":`Начало периода поиска по времени Кишинёва, YYYY-MM-DDTHH:mm:ss (пометка Z не учитывается).`,"The starting date of the report period.":`Дата начала отчетного периода.`,"The starting date of the statement period.":`Дата начала периода выписки.`,"The total amount for this quantity in minor units (usually UnitPrice * Quantity / 100).":`Сумма за это количество в минимальных единицах (обычно UnitPrice * Quantity / 100).`,"The total amount for this service.":`Общая сумма по этой услуге.`,"The type of money or payment method used.":`Используемый тип средств или способ оплаты.`,'Payment methods shown to the customer: "All" — all methods enabled for the merchant; "Card" — card (Visa/Mastercard), Apple Pay, Google Pay; "Paynet" — Paynet wallet; "MIA" — MIA instant payments; "CashInvoice" — cash invoice.':`Способы оплаты, которые увидит покупатель: "All" — все способы, подключённые мерчанту; "Card" — карта (Visa/Mastercard), Apple Pay, Google Pay; "Paynet" — кошелёк Paynet; "MIA" — мгновенные платежи MIA; "CashInvoice" — оплата наличными по счёту.`,'The type of refund: "full" or "partial".':`Тип возврата: "full" (полный) или "partial" (частичный).`,"The unique code or identifier for the customer.":`Уникальный код или идентификатор клиента.`,"The unique hash identifying the specific card to be unlinked.":`Уникальный хэш, идентифицирующий конкретную карту для отвязки.`,"The unique identifier for the order.":`Уникальный идентификатор заказа.`,"The unique identifier of the payment transaction to retrieve.":`Уникальный идентификатор платежной транзакции для получения данных.`,"The unique identifier or code of the customer who owns the linked card.":`Уникальный идентификатор или код клиента, которому принадлежит привязанная карта.`,"The unique internal identifier of the original payment transaction to be refunded.":`Уникальный внутренний идентификатор исходной платежной транзакции для возврата.`,"The unique order identifier provided by the merchant.":`Уникальный идентификатор заказа, предоставленный мерчантом.`,"The user's password in plain text.":`Пароль пользователя в открытом виде.`,"The user's username.":`Имя пользователя.`,"User controller":`Контроллер пользователя.`,"(Optional) A list of specific products under this service.":`(Необязательно) Список конкретных товаров в рамках этой услуги.`,"(Optional) A list of specific products under this service. If you send products, LineNo, Name, UnitPrice, Quantity, Amount and TotalAmount are required; Code and Description are optional.":`(Необязательно) Список конкретных товаров в рамках этой услуги. Если передаёте товары, обязательны LineNo, Name, UnitPrice, Quantity, Amount и TotalAmount; Code и Description — необязательны.`,"(Optional) The customer's email address.":`(Необязательно) Email клиента.`,"(Optional) The customer's first name.":`(Необязательно) Имя клиента.`,"(Optional) The customer's last name.":`(Необязательно) Фамилия клиента.`,"(Optional) The customer's phone number.":`(Необязательно) Номер телефона клиента.`,"(Optional) The description of the product.":`(Необязательно) Описание товара.`,"Return URL after a successful payment, as sent in the order. Can be null in GET /api/order/search results (seen on the test environment).":`Адрес возврата после успешной оплаты, как передан в заказе. В результатах GET /api/order/search может быть null (замечено на тестовой среде).`,"Return URL after a failed or cancelled payment, as sent in the order. Can be null in GET /api/order/search results (seen on the test environment).":`Адрес возврата после неуспешной или отменённой оплаты, как передан в заказе. В результатах GET /api/order/search может быть null (замечено на тестовой среде).`,'(Optional) The customer\'s phone number. If it is not sent, the customer types it on the payment page (block "Billing information").':`(Необязательно) Телефон покупателя. Если не передать, покупатель вводит его на платёжной странице (блок «Billing information»).`,"(Optional) The hash of the linked card if using a saved payment method.":`(Необязательно) Хэш привязанной карты при использовании сохраненного способа оплаты.`,"(Optional) Linked-card hash. If CardLinkHash is provided, the full Customer object (Code, NameFirst, NameLast, email, PhoneNumber) becomes required.":`(Необязательно) Хэш связанной карты. Если передан CardLinkHash, полный объект Customer (Code, NameFirst, NameLast, email, PhoneNumber) становится обязательным.`,"(Optional) The specific account identifier to filter the statement.":`(Необязательно) Конкретный идентификатор счета для фильтрации выписки.`,"(Optional) The unit of measurement for the product (e.g., kg, pcs).":`(Необязательно) Единица измерения товара (например, кг, шт).`}).map(([e,t])=>[$e(e),t])),ro:Object.fromEntries(Object.entries({"A descriptive reason or justification for processing the refund.":`Motivul sau justificarea procesării rambursării.`,Error:`Eroare`,"Gets or sets a human-readable, descriptive error message intended for the client.":`Conține un mesaj de eroare clar, destinat clientului.`,"Gets or sets an optional unique identifier used for request tracing and debugging in the logs.":`Conține un identificator unic opțional folosit pentru urmărirea cererii și depanare în loguri.`,"Gets or sets optional technical details or additional context regarding the error (e.g., specific validation failures).":`Conține detalii tehnice opționale sau context suplimentar privind eroarea (de exemplu, eșecuri specifice de validare).`,"Gets or sets the HTTP status code associated with the error (e.g., 400, 401, 500).":`Conține codul de status HTTP asociat erorii (de ex. 400, 401, 500).`,"Gets or sets the internal business logic error code or its string representation.":`Conține codul intern de eroare al logicii de business sau reprezentarea lui textuală.`,"Handles operations related to merchant financial statements, including data retrieval and exporting reports.":`Gestionează operațiuni legate de extrasele financiare ale comerciantului, inclusiv preluarea datelor și exportul rapoartelor.`,"Handles operations related to saved or linked payment cards for authorized users.":`Gestionează operațiuni legate de cardurile de plată salvate sau asociate pentru utilizatorii autorizați.`,"Only token.":`Doar token.`,"Psp Controller":`Controler PSP.`,"Represents a service included in the payment request.":`Reprezintă un serviciu inclus în cererea de plată.`,"Represents a single product item within a service.":`Reprezintă un produs individual din cadrul unui serviciu.`,"Represents a standardized error response returned by the API.":`Reprezintă un răspuns de eroare standardizat returnat de API.`,"Represents the customer details for a payment.":`Reprezintă datele clientului pentru o plată.`,"Represents the payload for initiating a payment request.":`Reprezintă payload-ul pentru inițierea unei cereri de plată.`,"Represents the payload for initiating a payment request. Fields not marked as required are optional.":`Reprezintă payload-ul pentru inițierea unei cereri de plată. Câmpurile care nu sunt marcate ca obligatorii sunt opționale.`,"Represents the payload required to initiate a refund for a specific payment transaction.":`Reprezintă payload-ul necesar pentru inițierea unei rambursări pentru o tranzacție de plată specifică.`,"Represents the payload required to unlink a saved payment card.":`Reprezintă payload-ul necesar pentru deconectarea unui card de plată salvat.`,"The URL to redirect to if the payment is canceled.":`URL-ul de redirecționare dacă plata este anulată.`,"The URL to redirect to upon a successful payment.":`URL-ul de redirecționare după o plată reușită.`,"The authentication request model.":`Modelul cererii de autentificare.`,'The authorization grant type (e.g., "password").':`Tipul grant-ului de autorizare (de ex. "password").`,"The code identifying the specific sale area or merchant environment.":`Codul care identifică zona de vânzare specifică sau mediul comerciantului.`,"The code identifying the specific sale area or point of sale where the original transaction occurred.":`Codul care identifică zona de vânzare sau punctul de vânzare unde a avut loc tranzacția inițială.`,"The code representing the sale area or merchant location.":`Codul care reprezintă zona de vânzare sau locația comerciantului.`,"The currency code.":`Codul valutei.`,"The description of the service.":`Descrierea serviciului.`,"End of the search period in Chișinău local time, YYYY-MM-DDTHH:mm:ss (a trailing Z is ignored).":`Sfârșitul perioadei de căutare în ora Chișinăului, YYYY-MM-DDTHH:mm:ss (marcajul Z este ignorat).`,"The ending date of the report period (must be within 31 days of the start date).":`Data de sfârșit a perioadei de raportare (trebuie să fie în maximum 31 de zile de la data de început).`,"The ending date of the statement period.":`Data de sfârșit a perioadei extrasului.`,"The exact amount to be refunded.":`Suma exactă care trebuie rambursată.`,"The expiration date and time for this payment request. Format YYYY-MM-DDTHH:mm:ss, Chisinau local time (Europe/Chisinau); must be in the future.":`Data și ora expirării cererii de plată. Format YYYY-MM-DDTHH:mm:ss, ora locală Chișinău (Europe/Chisinau); trebuie să fie în viitor.`,"The final total amount including any taxes or discounts.":`Suma totală finală, inclusiv taxe sau reduceri.`,"The line number or position of the product in the list.":`Numărul de linie sau poziția produsului în listă.`,"The list of services included in this payment.":`Lista serviciilor incluse în această plată.`,"The name of the product.":`Denumirea produsului.`,"The name of the service.":`Denumirea serviciului.`,"The numeric ISO code of the currency for the refund amount.":`Codul ISO numeric al valutei pentru suma rambursării.`,"The payload containing the details needed to identify and unlink the card.":`Payload-ul care conține detaliile necesare pentru identificarea și deconectarea cardului.`,"The payload containing the necessary details to process the refund.":`Payload-ul care conține detaliile necesare pentru procesarea rambursării.`,"The payload containing the payment details":`Payload-ul care conține detaliile plății.`,"The price per single unit of the product.":`Prețul pentru o unitate de produs.`,"Quantity in hundredths: 100 = 1 pc, 300 = 3 pcs.":`Cantitatea în sutimi: 100 = 1 buc., 300 = 3 buc.`,"Start of the search period in Chișinău local time, YYYY-MM-DDTHH:mm:ss (a trailing Z is ignored).":`Începutul perioadei de căutare în ora Chișinăului, YYYY-MM-DDTHH:mm:ss (marcajul Z este ignorat).`,"The starting date of the report period.":`Data de început a perioadei de raportare.`,"The starting date of the statement period.":`Data de început a perioadei extrasului.`,"The total amount for this quantity in minor units (usually UnitPrice * Quantity / 100).":`Suma pentru această cantitate în unități minime (de obicei UnitPrice * Quantity / 100).`,"The total amount for this service.":`Suma totală pentru acest serviciu.`,"The type of money or payment method used.":`Tipul de bani sau metoda de plată utilizată.`,'Payment methods shown to the customer: "All" — all methods enabled for the merchant; "Card" — card (Visa/Mastercard), Apple Pay, Google Pay; "Paynet" — Paynet wallet; "MIA" — MIA instant payments; "CashInvoice" — cash invoice.':`Metodele de plată afișate clientului: "All" — toate metodele activate pentru comerciant; "Card" — card (Visa/Mastercard), Apple Pay, Google Pay; "Paynet" — portofel Paynet; "MIA" — plăți instant MIA; "CashInvoice" — factură cu plată în numerar.`,'The type of refund: "full" or "partial".':`Tipul rambursării: "full" (integrală) sau "partial" (parțială).`,"The unique code or identifier for the customer.":`Codul unic sau identificatorul clientului.`,"The unique hash identifying the specific card to be unlinked.":`Hash-ul unic care identifică cardul specific ce trebuie deconectat.`,"The unique identifier for the order.":`Identificatorul unic al comenzii.`,"The unique identifier of the payment transaction to retrieve.":`Identificatorul unic al tranzacției de plată ce trebuie obținută.`,"The unique identifier or code of the customer who owns the linked card.":`Identificatorul unic sau codul clientului care deține cardul asociat.`,"The unique internal identifier of the original payment transaction to be refunded.":`Identificatorul intern unic al tranzacției de plată inițiale care urmează să fie rambursată.`,"The unique order identifier provided by the merchant.":`Identificatorul unic al comenzii furnizat de comerciant.`,"The user's password in plain text.":`Parola utilizatorului în text simplu.`,"The user's username.":`Numele de utilizator.`,"User controller":`Controler utilizator.`,"(Optional) A list of specific products under this service.":`(Opțional) O listă de produse specifice din acest serviciu.`,"(Optional) A list of specific products under this service. If you send products, LineNo, Name, UnitPrice, Quantity, Amount and TotalAmount are required; Code and Description are optional.":`(Opțional) O listă de produse specifice din acest serviciu. Dacă trimiteți produse, sunt obligatorii LineNo, Name, UnitPrice, Quantity, Amount și TotalAmount; Code și Description sunt opționale.`,"(Optional) The customer's email address.":`(Opțional) Adresa de email a clientului.`,"(Optional) The customer's first name.":`(Opțional) Prenumele clientului.`,"(Optional) The customer's last name.":`(Opțional) Numele de familie al clientului.`,"(Optional) The customer's phone number.":`(Opțional) Numărul de telefon al clientului.`,"(Optional) The description of the product.":`(Opțional) Descrierea produsului.`,"Return URL after a successful payment, as sent in the order. Can be null in GET /api/order/search results (seen on the test environment).":`Adresa de revenire după plata reușită, așa cum a fost trimisă în comandă. În rezultatele GET /api/order/search poate fi null (observat în mediul de test).`,"Return URL after a failed or cancelled payment, as sent in the order. Can be null in GET /api/order/search results (seen on the test environment).":`Adresa de revenire după plata eșuată sau anulată, așa cum a fost trimisă în comandă. În rezultatele GET /api/order/search poate fi null (observat în mediul de test).`,'(Optional) The customer\'s phone number. If it is not sent, the customer types it on the payment page (block "Billing information").':`(Opțional) Telefonul clientului. Dacă nu este trimis, clientul îl introduce pe pagina de plată (blocul „Billing information”).`,"(Optional) The hash of the linked card if using a saved payment method.":`(Opțional) Hash-ul cardului asociat, dacă se folosește o metodă de plată salvată.`,"(Optional) Linked-card hash. If CardLinkHash is provided, the full Customer object (Code, NameFirst, NameLast, email, PhoneNumber) becomes required.":`(Opțional) Hash-ul cardului legat. Dacă este transmis CardLinkHash, întregul obiect Customer (Code, NameFirst, NameLast, email, PhoneNumber) devine obligatoriu.`,"(Optional) The specific account identifier to filter the statement.":`(Opțional) Identificatorul specific al contului pentru filtrarea extrasului.`,"(Optional) The unit of measurement for the product (e.g., kg, pcs).":`(Opțional) Unitatea de măsură pentru produs (de ex. kg, buc).`}).map(([e,t])=>[$e(e),t]))},tt=(e,t)=>{if(!e)return``;if(t===`en`)return e;let n=$e(e);return n.startsWith(`UI language for payment page`)?t===`ru`?`Язык платёжной страницы: RO, RU или EN; регистр не важен (EN = en). При неизвестном значении страница открывается на английском.`:`Limba paginii de plată: RO, RU sau EN; majusculele nu contează (EN = en). La o valoare necunoscută pagina se deschide în engleză.`:et[t]?.[n]||e},nt=400,rt=e=>e.replace(/([.\]])/g,`$1\0`).split(`\0`).filter(Boolean).map((e,t)=>(0,B.jsxs)(_.Fragment,{children:[t>0&&(0,B.jsx)(`wbr`,{}),(0,B.jsx)(`span`,{className:`whitespace-nowrap`,children:e})]},t)),it=({item:e})=>(0,B.jsxs)(B.Fragment,{children:[e.type&&(0,B.jsx)(`span`,{className:`bg-paynet-gray-100 text-paynet-gray-700 px-1.5 py-0.5 rounded text-xs font-mono`,children:e.type}),e.in&&(0,B.jsx)(`span`,{className:`px-1.5 py-0.5 text-xs rounded ${e.in===`path`?`bg-purple-100 text-purple-800`:e.in===`query`?`bg-blue-100 text-blue-800`:`bg-paynet-light text-paynet-dark`}`,children:e.in})]}),at=({items:e,labels:t})=>{let n=_.useRef(null),[r,i]=_.useState(!0);return _.useLayoutEffect(()=>{let e=n.current;if(!e)return;let t=()=>i(e.clientWidth>=nt);if(t(),typeof ResizeObserver>`u`)return;let r=new ResizeObserver(t);return r.observe(e),()=>r.disconnect()},[]),(0,B.jsx)(`div`,{ref:n,"data-param-list":!0,className:`w-full`,children:r?(0,B.jsx)(`div`,{className:`rounded-lg border border-paynet-gray-200 overflow-hidden`,children:(0,B.jsxs)(`table`,{className:`w-full`,children:[(0,B.jsx)(`thead`,{className:`bg-paynet-gray-50`,children:(0,B.jsxs)(`tr`,{children:[(0,B.jsx)(`th`,{className:`px-4 py-3 text-left text-sm font-semibold text-paynet-primary`,children:t.name||`Parameter`}),(0,B.jsx)(`th`,{className:`px-4 py-3 text-left text-sm font-semibold text-paynet-primary whitespace-nowrap`,children:t.requiredHeader||t.required}),(0,B.jsx)(`th`,{className:`px-4 py-3 text-left text-sm font-semibold text-paynet-primary`,children:t.description||`Description`})]})}),(0,B.jsx)(`tbody`,{className:`divide-y divide-paynet-gray-200`,children:e.map((e,n)=>(0,B.jsxs)(`tr`,{className:`align-top hover:bg-paynet-gray-50 transition-colors duration-150`,children:[(0,B.jsxs)(`td`,{className:`px-4 py-3`,children:[(0,B.jsx)(`code`,{className:`block font-mono text-sm font-semibold text-paynet-gray-900`,children:rt(e.name)}),(0,B.jsx)(`div`,{className:`mt-1 flex flex-wrap gap-1`,children:(0,B.jsx)(it,{item:e})})]}),(0,B.jsx)(`td`,{className:`px-4 py-3 text-sm whitespace-nowrap`,children:e.required?(0,B.jsxs)(`span`,{className:`inline-flex items-center gap-1 text-paynet-error font-medium`,children:[(0,B.jsx)(b,{className:`w-4 h-4`}),t.required]}):(0,B.jsxs)(`span`,{className:`inline-flex items-center gap-1 text-paynet-success`,children:[(0,B.jsx)(E,{className:`w-4 h-4`}),t.optional]})}),(0,B.jsx)(`td`,{className:`px-4 py-3 text-sm text-paynet-gray-600 break-words`,children:e.description})]},`${e.name}-${n}`))})]})}):(0,B.jsx)(`div`,{className:`divide-y divide-paynet-gray-200 border-y border-paynet-gray-200`,children:e.map((e,n)=>(0,B.jsxs)(`div`,{className:`py-3`,children:[(0,B.jsxs)(`div`,{className:`flex flex-wrap items-center gap-x-2 gap-y-1`,children:[(0,B.jsx)(`code`,{className:`font-mono text-sm font-semibold text-paynet-gray-900`,children:rt(e.name)}),(0,B.jsx)(it,{item:e}),(0,B.jsx)(`span`,{className:`text-xs font-medium ${e.required?`text-paynet-error`:`text-paynet-gray-500`}`,children:e.required?t.required:t.optional})]}),e.description&&(0,B.jsx)(`p`,{className:`mt-1 text-sm text-paynet-gray-600 break-words`,children:e.description})]},`${e.name}-${n}`))})})},ot=({endpoint:e,baseUrl:t,servers:n=[],t:r,language:i,spec:a={},onNavigate:o=e=>{window.location.hash=e}})=>{let[s,c]=_.useState(()=>{let e=n.findIndex(e=>e.description?.toLowerCase().includes(`sandbox`)||e.url?.toLowerCase().includes(`test`));return e>=0?e:0}),[l,u]=_.useState(null),[d,f]=_.useState(``),[p,m]=_.useState(null),h=e=>e.replace(/(".*?")\s*:/g,`<span style="color: #60A5FA;">$1</span>:`).replace(/:\s*(".*?")/g,`: <span style="color: #34D399;">$1</span>`).replace(/:\s*(\d+\.?\d*)/g,`: <span style="color: #F59E0B;">$1</span>`).replace(/:\s*(true|false)/g,`: <span style="color: #EF4444;">$1</span>`).replace(/:\s*(null)/g,`: <span style="color: #9CA3AF;">$1</span>`).replace(/([{}[\],])/g,`<span style="color: #D1D5DB;">$1</span>`),g=async(e,t)=>{try{await navigator.clipboard.writeText(e),m(t),setTimeout(()=>m(null),2e3)}catch(e){console.error(`Failed to copy request body:`,e)}},v=He(e.path,e.method,i,e.summary),y=n.length>0?n:[{url:t,description:`Default Server`}],b=y[s],x=v.responses||e.responses,S=Object.keys(x),C=S.join(`,`),w=v.responses?.[d],T=v.responses?void 0:e.responses[d],E=w??T,O=a?.paths?.[e.path]?.[e.method.toLowerCase()]?.requestBody,k=e=>e.toLowerCase(),A=e=>{if(!e)return null;if(e.$ref&&typeof e.$ref==`string`){let t=e.$ref.split(`/`),n=t[t.length-1];return a?.components?.schemas?.[n]||null}return e},M=e=>Array.isArray(e)?`array`:e===null?`null`:typeof e,N=e=>{let t=a?.components?.schemas;if(!t||typeof t!=`object`)return null;let n=Object.keys(e).map(k);if(n.length===0)return null;let r=null,i=0;return Object.values(t).forEach(e=>{if(!e||e.type!==`object`||!e.properties)return;let t=Object.keys(e.properties).map(k),a=n.filter(e=>t.includes(e)).length/n.length;a>i&&(i=a,r=e)}),i>=.5?r:null},P=_.useMemo(()=>{if(!O?.content)return[];let e=O.content[`application/json`],t=Object.values(O.content)[0],n=e||t;if(!n)return[];let a=n.example&&typeof n.example==`object`?n.example:null,o=A(n.schema)||(a?N(a):null),s=[],c=new Set,l=(e,t)=>e?.type?e.type:e?.$ref?`object`:M(t),u=e=>{c.has(e.name)||(c.add(e.name),s.push(e))},d=(e,t,n=``,a=!1,o)=>{let s=A(e),c=l(s,t);if(n&&u({name:n,type:c,in:`body`,required:a,description:tt(s?.description,i)||r.common.description}),c===`object`){let e=s?.properties||{},r=new Set(Array.isArray(s?.required)?s.required:[]),i=t&&typeof t==`object`&&!Array.isArray(t)?t:{},a=Object.keys(e),c=Object.keys(i);Array.from(new Set([...a,...c])).forEach(t=>{let a=e[t],s=c.find(e=>k(e)===k(t))||t,l=o||s,u=n?`${n}.${l}`:l;d(a,i[s],u,r.has(t),s)})}else if(c===`array`){let e=A(s?.items),r=Array.isArray(t)&&t.length>0?t[0]:void 0,i=`${n}[]`;d(e,r,i,a)}};return(o||a)&&d(o,a,``,!1),s},[O,a,r.common.description,i]);_.useEffect(()=>{if(S.length>0){let e=S.includes(`200`)?`200`:S[0];f(e)}},[C]);let ee=async t=>{try{let n=`${t}${e.path}`;await navigator.clipboard.writeText(n),u(n),setTimeout(()=>u(null),2e3)}catch(e){console.error(`Failed to copy URL:`,e)}},I=e=>!e||!e.properties?[]:Object.entries(e.properties).map(([t,n])=>({name:t,type:n.type||`object`,required:Array.isArray(e.required)&&e.required.includes(t)||n.required===!0||!1,description:tt(n.description,i)||(n.example===void 0?``:String(n.example))}));return(0,B.jsxs)(`div`,{className:`w-full max-w-none`,children:[(0,B.jsxs)(`div`,{className:`mb-4 sm:mb-8`,children:[(0,B.jsxs)(`div`,{className:`flex flex-wrap items-center gap-3 mb-2 sm:mb-3`,children:[(0,B.jsx)(`span`,{className:`text-xs font-mono px-2 py-1 rounded ${e.method===`GET`?`bg-green-100 text-green-700`:e.method===`POST`?`bg-blue-100 text-blue-700`:e.method===`PUT`?`bg-orange-100 text-orange-800`:`bg-red-100 text-red-800`}`,children:e.method}),(0,B.jsx)(`h1`,{className:`text-xl sm:text-2xl lg:text-3xl font-bold text-paynet-primary`,children:v.name}),(0,B.jsx)(`div`,{className:`ml-auto`,children:(0,B.jsx)(Qe,{language:i,title:`${e.method} ${e.path} — ${v.name}`,markdownPath:`docs/api/${e.id.replace(/^-+|-+$/g,``)}.md`,markdownLanguage:`EN`,onNavigate:o})})]}),(0,B.jsxs)(`div`,{className:`bg-white p-4 sm:p-6 rounded-lg shadow-paynet-lg border border-paynet-gray-200 w-full`,children:[(0,B.jsx)(`h2`,{className:`text-lg sm:text-xl font-semibold text-paynet-primary mb-3 sm:mb-4`,children:r.common.methodDescription}),(0,B.jsx)(`p`,{className:`text-sm sm:text-base text-paynet-gray-700 leading-relaxed`,children:v.description})]})]}),(0,B.jsxs)(`div`,{className:`mb-8 bg-white p-4 sm:p-6 rounded-lg shadow-paynet-lg border border-paynet-gray-200 w-full`,children:[(0,B.jsx)(`h2`,{className:`text-lg sm:text-xl font-semibold text-paynet-primary mb-3 sm:mb-4`,children:r.common.requestTypeAndUrl}),(0,B.jsx)(`div`,{className:`space-y-4`,children:(0,B.jsxs)(`div`,{children:[(0,B.jsxs)(`span`,{className:`text-sm font-medium text-paynet-gray-600 block mb-3`,children:[r.common.name,` URL:`]}),y.length>1&&(0,B.jsx)(`div`,{className:`flex flex-col sm:flex-row mb-3 bg-paynet-gray-100 rounded-lg p-1 gap-1 sm:gap-0`,children:y.map((e,t)=>(0,B.jsx)(`button`,{onClick:()=>c(t),className:`flex-1 px-3 py-2 text-sm font-medium rounded-md transition-all duration-200 ${s===t?`bg-white text-paynet-primary shadow-paynet font-semibold`:`text-paynet-gray-600 hover:text-paynet-gray-900`}`,children:e.description},t))}),(0,B.jsxs)(`div`,{className:`relative`,children:[(0,B.jsxs)(`code`,{className:`text-base font-mono text-paynet-gray-900 bg-paynet-gray-50 px-4 py-3 pr-12 rounded-lg block break-all border border-paynet-gray-200`,children:[b.url,e.path]}),(0,B.jsx)(`button`,{onClick:()=>ee(b.url),className:`absolute top-3 right-3 p-2 bg-paynet-gray-200 hover:bg-paynet-gray-300 rounded-md transition-all duration-200 hover:scale-105`,title:r.common.copyToClipboard,children:l===`${b.url}${e.path}`?(0,B.jsx)(D,{className:`w-4 h-4 text-paynet-success`}):(0,B.jsx)(j,{className:`w-4 h-4 text-paynet-gray-600`})})]})]})})]}),e.description&&!v.description&&(0,B.jsxs)(`div`,{className:`mb-8 bg-white p-4 sm:p-6 rounded-lg shadow-paynet-lg border border-paynet-gray-200 w-full`,children:[(0,B.jsx)(`h2`,{className:`text-lg sm:text-xl font-semibold text-paynet-primary mb-3 sm:mb-4 flex items-center gap-2`,children:(0,B.jsxs)(`span`,{children:[`OpenAPI `,r.common.methodDescription]})}),(0,B.jsx)(`p`,{className:`text-sm sm:text-base text-paynet-gray-700 leading-relaxed`,children:e.description})]}),e.path!==`/auth`&&(0,B.jsx)(Ye,{t:r,language:i}),(e.parameters&&e.parameters.length>0||P.length>0)&&(0,B.jsxs)(`div`,{className:`space-y-4 mb-8`,children:[e.parameters&&e.parameters.length>0&&(0,B.jsxs)(`div`,{className:`bg-white p-4 sm:p-6 rounded-lg shadow-paynet-lg border border-paynet-gray-200 w-full`,children:[(0,B.jsx)(`h2`,{className:`text-lg sm:text-xl font-semibold text-paynet-primary mb-3 sm:mb-4`,children:r.common.parameters}),(0,B.jsx)(at,{items:e.parameters.map(e=>({name:e.name,type:e.type,in:e.in,required:!!e.required,description:tt(e.description,i)||``})),labels:{required:r.common.required,optional:r.common.optional,name:r.common.name,description:r.common.description}})]}),P.length>0&&(0,B.jsxs)(`div`,{className:`bg-white p-4 sm:p-6 rounded-lg shadow-paynet-lg border border-paynet-gray-200 w-full`,children:[(0,B.jsxs)(`h3`,{className:`text-lg sm:text-xl font-semibold text-paynet-primary mb-3 sm:mb-4`,children:[r.common.parameters,` - `,r.common.description]}),(0,B.jsx)(at,{items:P.map(e=>({name:e.name,type:e.type,in:e.in,required:!!e.required,description:e.description})),labels:{required:r.common.required,optional:r.common.optional,name:r.common.name,description:r.common.description}})]})]}),O&&(0,B.jsxs)(`div`,{className:`mb-8 bg-white p-4 sm:p-6 rounded-lg shadow-paynet-lg border border-paynet-gray-200 w-full`,children:[(0,B.jsx)(`h2`,{className:`text-lg sm:text-xl font-semibold text-paynet-primary mb-3 sm:mb-4`,children:`Request Body`}),O.content&&(0,B.jsxs)(`div`,{className:`mb-4`,children:[(0,B.jsx)(`span`,{className:`text-sm font-medium text-paynet-gray-600 block mb-2`,children:`Content-Type:`}),(0,B.jsx)(`div`,{className:`flex flex-wrap gap-2`,children:Object.keys(O.content).map(e=>(0,B.jsx)(`span`,{className:`bg-paynet-gray-100 px-3 py-1 rounded-md text-sm font-mono font-semibold text-paynet-gray-800`,children:e},e))})]}),O.content&&Object.entries(O.content).map(([e,t])=>{if(t.example&&e===`application/json`){let n=JSON.stringify(t.example,null,2);return(0,B.jsxs)(`div`,{className:`mb-6`,children:[(0,B.jsxs)(`div`,{className:`flex items-center justify-between mb-3`,children:[(0,B.jsxs)(`span`,{className:`text-sm font-medium text-paynet-gray-600 flex items-center gap-2`,children:[(0,B.jsx)(F,{className:`w-4 h-4`}),`Request Body Example:`]}),(0,B.jsx)(`button`,{onClick:()=>g(n,e),className:`flex items-center gap-2 px-3 py-1.5 bg-paynet-primary hover:bg-paynet-secondary text-white text-xs font-medium rounded-paynet transition-all duration-200 hover:scale-105 shadow-paynet`,title:r.common.copyToClipboard,children:p===e?(0,B.jsxs)(B.Fragment,{children:[(0,B.jsx)(D,{className:`w-3 h-3`}),r.common.copied]}):(0,B.jsxs)(B.Fragment,{children:[(0,B.jsx)(j,{className:`w-3 h-3`}),r.common.copyToClipboard]})})]}),(0,B.jsx)(`div`,{className:`relative`,children:(0,B.jsxs)(`div`,{className:`bg-gray-900 p-4 rounded-lg text-sm overflow-x-auto border border-gray-700 w-full font-mono relative`,children:[(0,B.jsx)(`div`,{className:`absolute top-2 right-2 bg-green-600 text-white px-2 py-1 rounded text-xs font-semibold`,children:`JSON`}),(0,B.jsx)(`pre`,{className:`text-gray-100`,children:(0,B.jsx)(`code`,{dangerouslySetInnerHTML:{__html:h(JSON.stringify(t.example,null,2))}})})]})})]},e)}return t.schema&&t.schema.properties?(0,B.jsxs)(`div`,{className:`mb-4`,children:[(0,B.jsx)(`span`,{className:`text-sm font-medium text-paynet-gray-600 block mb-3`,children:`Schema Properties:`}),(0,B.jsx)(at,{items:I(t.schema),labels:{required:r.common.required,optional:r.common.optional,name:r.common.name,description:r.common.description}})]},e):null})]}),(0,B.jsxs)(`div`,{className:`mb-8 bg-white p-4 sm:p-6 rounded-lg shadow-paynet-lg border border-paynet-gray-200 w-full`,children:[(0,B.jsx)(`h2`,{className:`text-lg sm:text-xl font-semibold text-paynet-primary mb-3 sm:mb-4`,children:r.common.responses}),(0,B.jsx)(`div`,{className:`flex flex-wrap gap-2 mb-4`,children:S.map(e=>(0,B.jsx)(`button`,{onClick:()=>f(e),className:`px-4 py-2 text-sm font-mono rounded-lg transition-all duration-200 font-semibold ${d===e?e.startsWith(`2`)?`bg-paynet-success text-white shadow-paynet-lg`:e.startsWith(`4`)?`bg-paynet-error text-white shadow-paynet-lg`:e.startsWith(`5`)?`bg-red-600 text-white shadow-paynet-lg`:`bg-paynet-primary text-white shadow-paynet-lg`:e.startsWith(`2`)?`bg-green-50 text-paynet-success hover:bg-green-100 border border-green-200`:e.startsWith(`4`)?`bg-red-50 text-paynet-error hover:bg-red-100 border border-red-200`:e.startsWith(`5`)?`bg-red-50 text-red-700 hover:bg-red-100 border border-red-200`:`bg-paynet-light text-paynet-primary hover:bg-blue-100 border border-paynet-gray-200`}`,children:e},e))}),d&&E&&(0,B.jsx)(`div`,{className:`border border-paynet-gray-200 rounded-lg p-4 bg-paynet-gray-50 w-full`,children:(0,B.jsxs)(`div`,{className:`mb-4`,children:[(0,B.jsxs)(`div`,{className:`flex items-center gap-3 mb-3`,children:[(0,B.jsx)(`span`,{className:`px-3 py-1 text-sm font-mono rounded-full font-semibold ${d.startsWith(`2`)?`bg-green-100 text-paynet-success`:d.startsWith(`4`)?`bg-red-100 text-paynet-error`:d.startsWith(`5`)?`bg-red-100 text-red-700`:`bg-paynet-gray-100 text-paynet-gray-800`}`,children:d}),(0,B.jsx)(`span`,{className:`text-sm font-medium text-paynet-gray-900`,children:E.description})]}),w?.content?(0,B.jsxs)(`div`,{className:`space-y-3`,children:[(0,B.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,B.jsx)(`span`,{className:`text-xs font-medium text-paynet-gray-600`,children:`Content-Type:`}),(0,B.jsx)(`span`,{className:`text-xs font-mono bg-paynet-gray-100 px-2 py-1 rounded-md text-paynet-gray-800 font-semibold`,children:w.content.type})]}),(0,B.jsxs)(`div`,{children:[(0,B.jsx)(`span`,{className:`text-xs font-medium text-paynet-gray-600 block mb-2`,children:`Response Body:`}),(0,B.jsx)(`pre`,{className:`bg-white p-4 rounded-lg text-sm overflow-x-auto border border-paynet-gray-200 w-full font-mono`,children:(0,B.jsx)(`code`,{children:JSON.stringify(w.content.object,null,2)})})]})]}):T?.content?(0,B.jsxs)(`div`,{children:[(0,B.jsx)(`span`,{className:`text-xs font-medium text-paynet-gray-600 block mb-2`,children:`Schema:`}),(0,B.jsx)(`pre`,{className:`bg-white p-4 rounded-lg text-sm overflow-x-auto border border-paynet-gray-200 w-full font-mono`,children:(0,B.jsx)(`code`,{children:JSON.stringify(T.content[`application/json`]?.schema,null,2)})})]}):null]})})]})]})},st=[{name:`Shopify`,logoUrl:`logos/shopify.png`,downloadUrl:`https://developer.cybersource.com/technology-partners/Shopify_Managed.html`},{name:`WordPress`,logoUrl:`logos/wordpress.png`,downloadUrl:`https://info.paynet.md/plugin/cms-wordpress.zip`},{name:`OpenCart`,logoUrl:`logos/opencart.png`,downloadUrl:`https://info.paynet.md/plugin/cms-opencart.zip`},{name:`CS-Cart`,logoUrl:`logos/cscart.png`,downloadUrl:`https://info.paynet.md/plugin/cms-cscart.zip`},{name:`PrestaShop`,logoUrl:`logos/prestashop.png`,downloadUrl:`https://info.paynet.md/plugin/cms-prestashop.zip`},{name:`Magento`,logoUrl:`logos/magento.png`,downloadUrl:`https://info.paynet.md/plugin/cms-magento.zip`}],ct=()=>(0,B.jsxs)(`div`,{className:`w-full max-w-none`,children:[(0,B.jsxs)(`div`,{className:`mb-4 sm:mb-8`,children:[(0,B.jsxs)(`div`,{className:`flex items-center gap-3 mb-2 sm:mb-3`,children:[(0,B.jsx)(de,{className:`w-6 sm:w-8 h-6 sm:h-8 text-paynet-primary`}),(0,B.jsx)(`h1`,{className:`text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900`,children:`Plugins`})]}),(0,B.jsx)(`p`,{className:`text-sm sm:text-base text-paynet-gray-700`,children:`Download ready-to-use ecommerce plugins for supported platforms.`})]}),(0,B.jsx)(`div`,{className:`grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6`,children:st.map(e=>(0,B.jsxs)(`div`,{className:`bg-white border border-paynet-gray-200 rounded-lg shadow-paynet-lg p-5 flex flex-col items-center text-center`,children:[(0,B.jsx)(`div`,{className:`h-24 sm:h-28 w-full mb-4 flex items-center justify-center`,children:(0,B.jsx)(`img`,{src:e.logoUrl,alt:e.name,className:`max-h-full max-w-[85%] object-contain`,loading:`lazy`,onError:e=>{e.currentTarget.style.display=`none`}})}),(0,B.jsx)(`div`,{className:`text-base sm:text-lg font-semibold text-paynet-gray-900 mb-3`,children:e.name}),(0,B.jsxs)(`a`,{href:e.downloadUrl,target:`_blank`,rel:`noreferrer`,className:`inline-flex items-center gap-2 px-4 py-2 rounded-md bg-paynet-primary text-white text-sm font-medium hover:bg-paynet-secondary transition-colors`,children:[(0,B.jsx)(N,{className:`w-4 h-4`}),`Download`]})]},e.name))})]}),lt=[7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21],ut=Array.from({length:64},(e,t)=>Math.floor(Math.abs(Math.sin(t+1))*2**32)>>>0);function dt(e){let t=e.length*8,n=((e.length+8>>6)+1)*64,r=new Uint8Array(n);r.set(e),r[e.length]=128;let i=new DataView(r.buffer);i.setUint32(n-8,t>>>0,!0),i.setUint32(n-4,Math.floor(t/2**32),!0);let a=1732584193,o=4023233417,s=2562383102,c=271733878,l=Array(16);for(let e=0;e<n;e+=64){for(let t=0;t<16;t+=1)l[t]=i.getUint32(e+t*4,!0);let t=a,n=o,r=s,u=c;for(let e=0;e<64;e+=1){let i,a;e<16?(i=n&r|~n&u,a=e):e<32?(i=u&n|~u&r,a=(5*e+1)%16):e<48?(i=n^r^u,a=(3*e+5)%16):(i=r^(n|~u),a=7*e%16);let o=t+i+ut[e]+l[a]>>>0;t=u,u=r,r=n,n=n+(o<<lt[e]|o>>>32-lt[e])>>>0}a=a+t>>>0,o=o+n>>>0,s=s+r>>>0,c=c+u>>>0}let u=new Uint8Array(16),d=new DataView(u.buffer);return[a,o,s,c].forEach((e,t)=>d.setUint32(t*4,e,!0)),u}function ft(e){let t=dt(new TextEncoder().encode(e)),n=``;return t.forEach(e=>{n+=String.fromCharCode(e)}),btoa(n)}var pt=e=>String(e).padStart(2,`0`),mt=()=>{let e=new Date;return e.setDate(e.getDate()+1),`${e.getFullYear()}-${pt(e.getMonth()+1)}-${pt(e.getDate())}T23:59:59`},V=()=>Date.now(),ht=e=>{if(!e||typeof e!=`object`||Array.isArray(e))return e;let t={...e};return`Order`in t&&(t.Order=V()),`ExpiryDate`in t&&(t.ExpiryDate=mt()),t},gt=`paynet_last_order`,_t=`paynet-last-order`;function vt(e,t,n){let r=String(e??``).trim();if(!/^\d+$/.test(r))return;let i={order:r,paymentId:n==null?void 0:String(n),source:t,createdAt:Date.now()};try{localStorage.setItem(gt,JSON.stringify(i))}catch{}window.dispatchEvent(new Event(_t))}function yt(){try{let e=localStorage.getItem(gt);if(!e)return null;let t=JSON.parse(e);return t&&typeof t.order==`string`?t:null}catch{return null}}function bt(){let[e,t]=_.useState(()=>yt());return _.useEffect(()=>{let e=()=>t(yt()),n=t=>{t.key===gt&&e()};return window.addEventListener(_t,e),window.addEventListener(`storage`,n),window.addEventListener(`focus`,e),()=>{window.removeEventListener(_t,e),window.removeEventListener(`storage`,n),window.removeEventListener(`focus`,e)}},[]),e}var xt=({language:e})=>{let t=e===`ru`,n=e===`ro`,r=(e,r,i)=>t?r:n?i:e,i={Order:{ru:`Идентификатор заказа партнера в вашей системе.`,ro:`Identificatorul comenzii partenerului în sistemul tău.`},Currency:{ru:`Числовой код валюты ISO 4217 (пример: 498).`,ro:`Cod numeric valută ISO 4217 (exemplu: 498).`},Merchant:{ru:`PartnerID / MerchantCode.`,ro:`PartnerID / MerchantCode.`},SaleAreaCode:{ru:`Код торговой зоны партнера.`,ro:`Codul zonei de vânzare al partenerului.`},Amount:{ru:`Сумма платежа.`,ro:`Suma plății.`},Description:{ru:`Описание заказа/услуги.`,ro:`Descrierea comenzii/serviciului.`},CustomerCode:{ru:`Код клиента в системе партнера.`,ro:`Codul clientului în sistemul partenerului.`},CustomerNameFirst:{ru:`Имя клиента.`,ro:`Prenumele clientului.`},CustomerNameLast:{ru:`Фамилия клиента.`,ro:`Numele de familie al clientului.`},CustomerPhoneNumber:{ru:`Номер телефона клиента.`,ro:`Numărul de telefon al clientului.`},CustomerEmail:{ru:`Email адрес клиента.`,ro:`Adresa de email a clientului.`},ExpiryDate:{ru:`Время истечения оплаты (ISO 8601).`,ro:`Data/ora expirării plății (ISO 8601).`},ProductAmount:{ru:`Сумма товара.`,ro:`Suma produsului.`},ProductBarcode:{ru:`Штрихкод товара.`,ro:`Codul de bare al produsului.`},ProductCode:{ru:`Код товара у партнера.`,ro:`Codul produsului în sistemul partenerului.`},ProductDescription:{ru:`Описание товара.`,ro:`Descrierea produsului.`},ProductGroupId:{ru:`Идентификатор группы товара.`,ro:`Identificatorul grupului de produse.`},ProductGroupName:{ru:`Название группы товара.`,ro:`Denumirea grupului de produse.`},ProductLineNo:{ru:`Номер строки товара.`,ro:`Numărul liniei produsului.`},ProductName:{ru:`Название товара.`,ro:`Denumirea produsului.`},ProductUnitPrice:{ru:`Цена за единицу товара.`,ro:`Prețul unitar al produsului.`},ProductQuantity:{ru:`Количество товара.`,ro:`Cantitatea produsului.`},ProductUnitProduct:{ru:`Тип / единица измерения товара.`,ro:`Tipul / unitatea de măsură a produsului.`},LinkUrlCancel:{ru:`URL для редиректа при отмене оплаты.`,ro:`URL de redirecționare la anularea plății.`},LinkUrlSuccess:{ru:`URL для редиректа после успешной оплаты.`,ro:`URL de redirecționare după plata reușită.`},Lang:{ru:`Язык интерфейса платежной страницы (пример: ro).`,ro:`Limba interfeței paginii de plată (exemplu: ro).`},MoneyType:{ru:`Код платежного инструмента.`,ro:`Codul instrumentului de plată.`},Signature:{ru:`Base64(MD5(RawData + SecretKey), raw bytes).`,ro:`Base64(MD5(RawData + SecretKey), raw bytes).`}},a=(e,t)=>{let n=i[e];return n?r(t,n.ru,n.ro):t},o=`https://test.paynet.md/ecom/checkout`,s=`265505`,c=`F90D6485-9CCC-458B-96A3-8958AF9B4458`,l=`onlidocumentation_md`,u={Order:V(),Currency:`498`,Merchant:s,SaleAreaCode:l,Amount:`1235`,Description:`Test&Co SRL`,CustomerCode:`5555`,CustomerNameFirst:`First name`,CustomerNameLast:`Last name`,CustomerPhoneNumber:`060000000`,CustomerEmail:`test@gmail.com`,ExpiryDate:mt(),ProductAmount:100,ProductBarcode:13243546,ProductCode:`PRODUCT1`,ProductDescription:`Demo product`,ProductGroupId:`22`,ProductGroupName:`Demo group`,ProductLineNo:1,ProductName:`Demo product`,ProductUnitPrice:100,ProductQuantity:1,ProductUnitProduct:1,LinkUrlCancel:`https://test.oplta.md/cancel`,LinkUrlSuccess:`https://test.oplta.md/ok`,Lang:`ro`,MoneyType:`Card`},[d,f]=_.useState(JSON.stringify(u,null,2)),[p,m]=_.useState(``),[h,g]=_.useState(``),[v,y]=_.useState(``),[b,x]=_.useState(``),[S,C]=_.useState(`html`),[w,T]=_.useState(!1),E=[{name:`Order`,type:`long`,input:`body`,required:!0,description:`Partner order identifier in your system.`},{name:`Currency`,type:`string`,input:`body`,required:!0,description:`ISO 4217 numeric currency code (example: 498).`},{name:`Merchant`,type:`string`,input:`body`,required:!0,description:`PartnerID / MerchantCode.`},{name:`SaleAreaCode`,type:`string`,input:`body`,required:!0,description:`Partner sale area code.`},{name:`Amount`,type:`string`,input:`body`,required:!0,description:`Payment amount.`},{name:`Description`,type:`string`,input:`body`,required:!0,description:`Order/service description.`},{name:`CustomerCode`,type:`string`,input:`body`,required:!1,description:`Customer code in partner system.`},{name:`CustomerNameFirst`,type:`string`,input:`body`,required:!1,description:`Customer first name.`},{name:`CustomerNameLast`,type:`string`,input:`body`,required:!1,description:`Customer last name.`},{name:`CustomerPhoneNumber`,type:`string`,input:`body`,required:!1,description:`Customer phone number.`},{name:`CustomerEmail`,type:`string`,input:`body`,required:!1,description:`Customer email address.`},{name:`ExpiryDate`,type:`datetime`,input:`body`,required:!0,description:`Payment expiration timestamp (ISO 8601).`},{name:`ProductAmount`,type:`long`,input:`body`,required:!1,description:`Product amount.`},{name:`ProductBarcode`,type:`long`,input:`body`,required:!1,description:`Product barcode.`},{name:`ProductCode`,type:`string`,input:`body`,required:!1,description:`Partner product code.`},{name:`ProductDescription`,type:`string`,input:`body`,required:!1,description:`Product description.`},{name:`ProductGroupId`,type:`string`,input:`body`,required:!1,description:`Product group identifier.`},{name:`ProductGroupName`,type:`string`,input:`body`,required:!1,description:`Product group name.`},{name:`ProductLineNo`,type:`int`,input:`body`,required:!1,description:`Product line number.`},{name:`ProductName`,type:`string`,input:`body`,required:!1,description:`Product name.`},{name:`ProductUnitPrice`,type:`long`,input:`body`,required:!1,description:`Product unit price.`},{name:`ProductQuantity`,type:`int`,input:`body`,required:!1,description:`Product quantity.`},{name:`ProductUnitProduct`,type:`string`,input:`body`,required:!1,description:`Product unit type / measure.`},{name:`LinkUrlCancel`,type:`string`,input:`body`,required:!0,description:`Redirect URL when payment is canceled.`},{name:`LinkUrlSuccess`,type:`string`,input:`body`,required:!0,description:`Redirect URL after successful payment flow.`},{name:`Lang`,type:`string`,input:`body`,required:!0,description:`UI language for payment page (example: ro).`},{name:`MoneyType`,type:`string`,input:`body`,required:!0,description:`Payment instrument code.`},{name:`Signature`,type:`string`,input:`body`,required:!0,description:`Base64(MD5(RawData + SecretKey), raw bytes).`}],O=e=>e==null?``:String(e),k=[`Order`,`Currency`,`Merchant`,`SaleAreaCode`,`CustomerCode`,`CustomerNameFirst`,`CustomerNameLast`,`CustomerPhoneNumber`,`CustomerEmail`,`ExpiryDate`,`Description`,`Amount`,`LinkUrlCancel`,`LinkUrlSuccess`,`Lang`,`MoneyType`],A=e=>encodeURIComponent(e).replace(/[!'()*]/g,e=>`%${e.charCodeAt(0).toString(16).toUpperCase()}`),M=e=>k.filter(t=>e[t]!==void 0&&e[t]!==null).sort((e,t)=>e.localeCompare(t)).map(t=>A(O(e[t]))).join(``),N=()=>{try{x(``);let e=JSON.parse(d);e.Merchant=s,e.SaleAreaCode=l;let t=ft(M(e)+c);e.Signature=t,m(t),g(JSON.stringify(e,null,2)),y(``)}catch(e){x(`Cannot generate signature: ${e instanceof Error?e.message:`Invalid input`}`)}},P=()=>{if(!h)x(`Generate signature first.`);else{x(``),y(``);try{let e=JSON.parse(h),t=document.createElement(`form`);t.method=`POST`,t.action=o,t.target=`_blank`,t.style.display=`none`,L(e).forEach(({name:e,value:n})=>{let r=document.createElement(`input`);r.type=`hidden`,r.name=e,r.value=n,t.appendChild(r)}),document.body.appendChild(t),t.submit(),t.remove(),vt(e.Order,`checkout-form`),y(`Payment form submitted in a new browser tab.`)}catch(e){x(`Cannot open payment page: ${e instanceof Error?e.message:`Unknown error`}`)}}},ee=()=>{let e=h||d;try{return JSON.stringify(JSON.parse(e),null,2)}catch{return e}},I=e=>e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#39;`),L=e=>{let t=[],n=(e,r,i)=>{e==null?t.push({name:r,value:``}):Array.isArray(e)?e.forEach((e,t)=>{n(e,`${r}[${t}]`,`array`)}):typeof e==`object`?Object.entries(e).forEach(([e,t])=>{let a=i===`array`?`${r}[${e}]`:r?`${r}.${e}`:e;n(t,a,`object`)}):t.push({name:r,value:String(e)})};return Object.entries(e).forEach(([e,t])=>{n(t,e,`root`)}),t},R=()=>{let e=h||d,t;try{t=JSON.parse(e)}catch{return`<!-- Invalid JSON payload. Please fix Request Body first. -->`}let n=L(t).map(({name:e,value:t})=>`<input type="hidden" name="${I(e)}" value="${I(t)}" />`).join(`
`);return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Paynet Ecom Checkout Form</title>
</head>
<body>
  <form method="POST" action="${I(o)}">
${n}
    <input type="submit" value="GO to a payment gateway of paynet" />
  </form>
</body>
</html>`};return(0,B.jsxs)(`div`,{className:`w-full max-w-none`,children:[(0,B.jsx)(`div`,{className:`mb-4 sm:mb-8`,children:(0,B.jsxs)(`div`,{className:`flex items-center gap-3 mb-2 sm:mb-3`,children:[(0,B.jsx)(`span`,{className:`text-xs font-mono px-2 py-1 rounded bg-blue-100 text-blue-700 font-semibold`,children:`POST`}),(0,B.jsx)(`h1`,{className:`text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900`,children:r(`Hosted checkout form`,`Форма hosted checkout`,`Formular hosted checkout`)})]})}),(0,B.jsxs)(`div`,{className:`bg-gradient-to-r from-paynet-light to-paynet-gray-50 rounded-paynet border border-paynet-gray-200 overflow-hidden w-full max-w-none`,children:[(0,B.jsxs)(`div`,{className:`w-full p-4 sm:p-6 flex items-center gap-3`,children:[(0,B.jsx)(F,{className:`w-5 h-5 text-paynet-primary`}),(0,B.jsx)(`h2`,{className:`text-lg sm:text-xl font-semibold text-paynet-primary`,children:r(`Hosted checkout form`,`Форма hosted checkout`,`Formular hosted checkout`)})]}),(0,B.jsx)(`div`,{className:`p-4 sm:p-6 pt-0`,children:(0,B.jsxs)(`div`,{className:`xl:flex xl:items-start xl:gap-6`,children:[(0,B.jsxs)(`div`,{className:`xl:flex-1 min-w-0`,children:[(0,B.jsxs)(`div`,{className:`mb-6 bg-white p-4 rounded-lg border border-paynet-gray-200`,children:[(0,B.jsx)(`h3`,{className:`text-base sm:text-lg font-semibold text-paynet-primary mb-2`,children:`Method Description`}),(0,B.jsx)(`p`,{className:`text-sm sm:text-base text-paynet-gray-700 leading-relaxed`,children:r("Creates a hosted checkout (client-server) payment request for `/ecom/checkout`, signs it with the secret key and opens the Paynet test payment page in a new tab. See the Hosted checkout and Signatures guides for the algorithm and test vectors.","Создаёт платёжный запрос hosted checkout (client-server) для `/ecom/checkout`, подписывает его секретным ключом и открывает тестовую страницу оплаты Paynet в новой вкладке. Алгоритм и тестовые векторы — в руководствах «Hosted checkout» и «Подписи».","Creează o cerere de plată hosted checkout (client-server) pentru `/ecom/checkout`, o semnează cu cheia secretă și deschide pagina de plată de test Paynet într-un tab nou. Algoritmul și vectorii de test sunt în ghidurile „Hosted checkout” și „Semnături”.")})]}),(0,B.jsxs)(`div`,{className:`mb-6 bg-white p-4 rounded-lg border border-paynet-gray-200`,children:[(0,B.jsx)(`h3`,{className:`text-base sm:text-lg font-semibold text-paynet-primary mb-2`,children:`Test credentials`}),(0,B.jsxs)(`div`,{className:`grid grid-cols-1 lg:grid-cols-2 gap-4 mb-2`,children:[(0,B.jsxs)(`div`,{children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`TEST Request URL`}),(0,B.jsx)(`input`,{value:o,readOnly:!0,className:`w-full px-3 py-2 border border-paynet-gray-300 rounded-md text-sm bg-paynet-gray-50 font-mono`})]}),(0,B.jsxs)(`div`,{children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`Live Request URL`}),(0,B.jsx)(`input`,{value:`https://paynet.md/ecom/checkout`,readOnly:!0,className:`w-full px-3 py-2 border border-paynet-gray-300 rounded-md text-sm bg-paynet-gray-50 font-mono`})]}),(0,B.jsxs)(`div`,{children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`MerchantCode`}),(0,B.jsx)(`input`,{value:s,readOnly:!0,className:`w-full px-3 py-2 border border-paynet-gray-300 rounded-md text-sm bg-paynet-gray-50 font-mono`})]}),(0,B.jsxs)(`div`,{children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`User login`}),(0,B.jsx)(`input`,{value:`771064`,readOnly:!0,className:`w-full px-3 py-2 border border-paynet-gray-300 rounded-md text-sm bg-paynet-gray-50 font-mono`})]}),(0,B.jsxs)(`div`,{children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`Password`}),(0,B.jsx)(`input`,{value:`sLgMnGWJ`,readOnly:!0,className:`w-full px-3 py-2 border border-paynet-gray-300 rounded-md text-sm bg-paynet-gray-50 font-mono`})]}),(0,B.jsxs)(`div`,{children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`SaleAreaCode`}),(0,B.jsx)(`input`,{value:l,readOnly:!0,className:`w-full px-3 py-2 border border-paynet-gray-300 rounded-md text-sm bg-paynet-gray-50 font-mono`})]}),(0,B.jsxs)(`div`,{className:`lg:col-span-2`,children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`SecretKey`}),(0,B.jsx)(`input`,{value:c,readOnly:!0,className:`w-full px-3 py-2 border border-paynet-gray-300 rounded-md text-sm bg-paynet-gray-50 font-mono`})]})]})]}),(0,B.jsxs)(`div`,{className:`mb-6`,children:[(0,B.jsx)(`h3`,{className:`text-base sm:text-lg font-semibold text-paynet-primary mb-1`,children:`Parameters - Description`}),(0,B.jsx)(at,{items:E.map(e=>({name:e.name,type:e.type,in:e.input,required:!!e.required,description:String(a(e.name,e.description)??``)})),labels:{required:`Required`,optional:`Optional`,name:`Name`,description:`Description`}})]}),(0,B.jsxs)(`div`,{className:`mb-6 bg-white p-4 rounded-lg border border-paynet-gray-200`,children:[(0,B.jsx)(`h3`,{className:`text-base sm:text-lg font-semibold text-paynet-primary mb-2`,children:`Signature generation`}),(0,B.jsx)(`p`,{className:`text-sm sm:text-base text-paynet-gray-700 leading-relaxed mb-3`,children:r(`Signature is generated using sorted parameters, RFC3986 URL encoding, and MD5 (raw bytes):`,`Подпись формируется из отсортированных параметров с кодированием RFC3986 и MD5 (raw bytes):`,`Semnătura se generează din parametri sortați, cu codare RFC3986 și MD5 (raw bytes):`)}),(0,B.jsx)(`pre`,{className:`bg-paynet-gray-900 text-paynet-gray-100 p-3 rounded-md text-xs sm:text-sm overflow-x-auto mb-3`,children:`RawData = concat(rawurlencode(value) for all signing fields sorted by key)
Signature = Base64(MD5(RawData + SecretKey))`}),(0,B.jsx)(`p`,{className:`text-sm sm:text-base text-paynet-gray-700 leading-relaxed mb-2`,children:r(`Signing fields:`,`Поля, используемые для подписи:`,`Câmpurile folosite la semnare:`)}),(0,B.jsx)(`pre`,{className:`bg-paynet-gray-900 text-paynet-gray-100 p-3 rounded-md text-xs sm:text-sm overflow-x-auto mb-3 whitespace-pre-wrap`,children:`Order, Currency, Merchant, SaleAreaCode, CustomerCode, CustomerNameFirst,
CustomerNameLast, CustomerPhoneNumber, CustomerEmail, ExpiryDate, Description,
Amount, LinkUrlCancel, LinkUrlSuccess, Lang, MoneyType`}),(0,B.jsx)(`p`,{className:`text-sm sm:text-base text-paynet-gray-700 leading-relaxed`,children:r(`Keys are sorted alphabetically before concatenation. Any field not present in JSON is skipped.`,`Ключи сортируются по алфавиту перед конкатенацией. Поля, отсутствующие в JSON, пропускаются.`,`Cheile sunt sortate alfabetic înainte de concatenare. Câmpurile lipsă din JSON sunt omise.`)})]})]}),(0,B.jsx)(`div`,{className:`xl:w-144 w-full mt-4 xl:mt-0`,children:(0,B.jsxs)(`div`,{className:`bg-gradient-to-r from-paynet-light to-paynet-gray-50 rounded-paynet border border-paynet-gray-200 overflow-hidden w-full max-w-none`,children:[(0,B.jsx)(`div`,{className:`w-full p-4 sm:p-6 flex items-center justify-between`,children:(0,B.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,B.jsx)(F,{className:`w-5 h-5 text-paynet-primary`}),(0,B.jsx)(`h3`,{className:`text-base sm:text-lg font-semibold text-paynet-primary`,children:`Code Examples`})]})}),(0,B.jsxs)(`div`,{className:`p-4 sm:p-6 pt-0`,children:[(0,B.jsxs)(`div`,{className:`mb-4`,children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`Request Body (JSON)`}),(0,B.jsx)(`textarea`,{rows:Math.max(4,d.split(`
`).reduce((e,t)=>e+Math.max(1,Math.ceil(t.length/64)),0)),spellCheck:!1,value:d,onChange:e=>{f(e.target.value),g(``),m(``)},className:`w-full px-3 py-2 border border-paynet-gray-300 rounded-md text-sm font-mono leading-5 resize-y`})]}),(0,B.jsxs)(`div`,{className:`flex flex-col sm:flex-row gap-3 mb-4`,children:[(0,B.jsx)(`button`,{onClick:N,className:`px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-md`,children:`Generate Signature`}),(0,B.jsxs)(`button`,{onClick:P,className:`px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-md flex items-center justify-center gap-2`,children:[(0,B.jsx)(me,{className:`w-4 h-4`}),`Send Test Request`]})]}),p&&(0,B.jsxs)(`div`,{className:`mb-4`,children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`Generated Signature`}),(0,B.jsx)(`code`,{className:`block bg-paynet-gray-50 border border-paynet-gray-200 px-3 py-2 rounded-md text-sm break-all`,children:p})]}),(0,B.jsxs)(`div`,{className:`mb-4`,children:[(0,B.jsxs)(`div`,{className:`flex items-center justify-between mb-2`,children:[(0,B.jsxs)(`div`,{className:`flex gap-2`,children:[(0,B.jsx)(`button`,{onClick:()=>C(`html`),className:`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${S===`html`?`bg-paynet-primary text-white`:`bg-paynet-gray-100 text-paynet-gray-700 hover:bg-paynet-gray-200`}`,children:`HTML`}),(0,B.jsx)(`button`,{onClick:()=>C(`json`),className:`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${S===`json`?`bg-paynet-primary text-white`:`bg-paynet-gray-100 text-paynet-gray-700 hover:bg-paynet-gray-200`}`,children:`JSON`})]}),(0,B.jsx)(`button`,{onClick:async()=>{let e=S===`html`?R():ee();await navigator.clipboard.writeText(e),T(!0),setTimeout(()=>T(!1),2e3)},className:`flex items-center gap-2 px-3 py-1.5 bg-paynet-primary hover:bg-paynet-secondary text-white text-xs font-medium rounded-paynet transition-all duration-200`,children:w?(0,B.jsxs)(B.Fragment,{children:[(0,B.jsx)(D,{className:`w-3 h-3`}),`Copied`]}):(0,B.jsxs)(B.Fragment,{children:[(0,B.jsx)(j,{className:`w-3 h-3`}),`Copy`]})})]}),(0,B.jsx)(`pre`,{className:`bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto whitespace-pre-wrap`,children:S===`html`?R():ee()})]}),b&&(0,B.jsx)(`div`,{className:`mb-4 p-3 bg-red-50 border border-red-200 rounded-md text-sm text-red-700`,children:b}),v&&(0,B.jsxs)(`div`,{children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`Response`}),(0,B.jsx)(`pre`,{className:`bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto whitespace-pre-wrap`,children:v})]})]})]})})]})})]})]})};function H(e,t){if(t!==void 0&&t!==``){let{type:n}=e.schema||e;switch(n){case`integer`:{let e=parseInt(t);return isNaN(e)?t:e}case`number`:{let e=parseFloat(t);return isNaN(e)?t:e}case`boolean`:return t.toLowerCase()===`true`;default:return t}}let{type:n,format:r,example:i,enum:a,schema:o}=e.schema||e;if(i!==void 0)return i;if(a&&a.length>0)return a[0];switch(n){case`string`:return r===`date`?`2024-01-01`:r===`date-time`?`2024-01-01T00:00:00Z`:r===`email`?`user@example.com`:r===`uuid`?`123e4567-e89b-12d3-a456-426614174000`:e.name?.toLowerCase().includes(`id`)?`example_id`:`example_${e.name||`value`}`;case`integer`:return 123;case`number`:return 123.45;case`boolean`:return!0;case`array`:return[H({schema:o?.items||{type:`string`}})];case`object`:return{};default:return`example_${e.name||`value`}`}}function St(e){if(e.example)return e.example;switch(e.type){case`object`:{let t={},n=e.properties;return n&&Object.keys(n).forEach(e=>{t[e]=St(n[e])}),t}case`array`:return e.items?[St(e.items)]:[];case`string`:return e.format===`date`?`2024-01-01`:e.format===`date-time`?`2024-01-01T00:00:00Z`:e.format===`email`?`user@example.com`:e.enum?.[0]||`example_string`;case`integer`:return e.enum?.[0]||123;case`number`:return e.enum?.[0]||123.45;case`boolean`:return!0;default:return null}}var Ct=null;function wt(e){Ct=e,e?localStorage.setItem(`tps_api_token`,e):localStorage.removeItem(`tps_api_token`)}function Tt(){if(Ct)return Ct;let e=localStorage.getItem(`tps_api_token`);return e?(Ct=e,e):null}function Et(){Ct=null,localStorage.removeItem(`tps_api_token`)}function Dt(e,t,n={},r=``){let i=e.path.match(/\{([^}]+)\}/g)?.map(e=>({name:e.slice(1,-1),in:`path`,required:!0,schema:{type:`string`}}))||[],a=[...e.parameters||[],...i.filter(t=>!e.parameters?.some(e=>e.name===t.name))],o=`https://ecom-api-test.paynet.md`;if(t.servers&&t.servers.length>0){let e=t.servers.find(e=>e.description?.toLowerCase().includes(`sandbox`)||e.url?.toLowerCase().includes(`test`));o=e?e.url:t.servers.length>1?t.servers[1].url:t.servers[0].url}let s=a.filter(e=>e.in===`path`),c=a.filter(e=>e.in===`query`),l=a.filter(e=>e.in===`header`),u=e.path;s.forEach(e=>{let t=H(e,n[e.name]);u=u.replace(`{${e.name}}`,String(t))});let d=c.length>0?`?`+c.map(e=>{let t=H(e,n[e.name]);return`${e.name}=${encodeURIComponent(String(t))}`}).join(`&`):``,f={};if(f[`Accept-Language`]=`en-US`,[`POST`,`PUT`,`PATCH`].includes(e.method)){let n=t.paths[e.path]?.[e.method.toLowerCase()]?.requestBody;f[`Content-Type`]=n?.content&&Object.keys(n.content).length>0?Object.keys(n.content)[0]:e.parameters&&e.parameters.length>0?`application/x-www-form-urlencoded`:`application/json`}if(u!==`/auth`){let e=Tt();f.Authorization=e?`Bearer ${e}`:`Bearer {{_token_}}`}l.forEach(e=>{f[e.name]=String(H(e,n[e.name]))});let p;if([`POST`,`PUT`,`PATCH`].includes(e.method)){let i=t.paths[e.path]?.[e.method.toLowerCase()]?.requestBody;if(i?.content){if(i.content[`application/x-www-form-urlencoded`]){let e={},t=i.content[`application/x-www-form-urlencoded`].schema,r=t?.properties;t&&r&&Object.keys(r).forEach(t=>{let i=n[t];i!==void 0&&i!==``?e[t]=i:r[t].example===void 0?e[t]=H({schema:r[t],name:t}):e[t]=r[t].example}),p=Object.entries(e).map(([e,t])=>`${e}=${encodeURIComponent(String(t))}`).join(`&`)}else if(i.content[`application/json`]){if(r&&r.trim())try{JSON.parse(r),p=r}catch{p=r}else i.content[`application/json`].example?p=JSON.stringify(i.content[`application/json`].example,null,2):i.content[`application/json`].schema&&(p=JSON.stringify(St(i.content[`application/json`].schema),null,2))}}}return{method:e.method,url:`${o}${u}${d}`,headers:f,...p&&{body:p}}}async function Ot(e){let t=Date.now();try{let n={method:e.method,headers:{...e.headers},...e.body&&{body:e.body}},r=await fetch(e.url,n),i=Date.now()-t,a={};r.headers.forEach((e,t)=>{a[t]=e});let o,s=r.headers.get(`content-type`);try{if(s&&s.includes(`application/vnd.ms-excel`)){let e=await r.blob(),t=window.URL.createObjectURL(e),n=document.createElement(`a`);n.href=t,n.download=`download_${Date.now()}.xlsx`,document.body.appendChild(n),n.click(),window.URL.revokeObjectURL(t),document.body.removeChild(n),o=`Excel file downloaded successfully (${e.size} bytes)`}else o=s&&s.includes(`application/json`)?await r.json():await r.text()}catch{o=await r.text()}if(e.method===`POST`&&/\/api\/order\/?(\?|$)/.test(e.url)&&r.status===200&&o&&typeof o==`object`)try{let t=e.body?JSON.parse(e.body):{};vt(t.Order??t.order,`api`,o.paymentId)}catch{}if(e.url.includes(`/auth`)&&r.status===200&&o&&typeof o==`object`){let e=o.access_token;e&&(wt(String(e)),console.log(`✅ Auth token saved successfully`))}return{status:r.status,statusText:r.statusText,headers:a,data:o,responseTime:i}}catch(n){let r=Date.now()-t,i=n instanceof TypeError&&(n.message.includes(`CORS`)||n.message.includes(`Network request failed`)||n.message.includes(`Failed to fetch`));return{status:0,statusText:i?`CORS Policy Restriction`:`Network Error`,headers:{},data:null,responseTime:r,error:i?`CORS policy prevents direct API testing from browser for ${e.url}. The server needs to allow cross-origin requests. Use the generated code examples in your backend or API testing tools like Postman.`:n instanceof Error?n.message:`Unknown error occurred`}}}function kt(e){if(e.error)return`❌ Error: ${e.error}\nResponse Time: ${e.responseTime}ms`;let t=`Status: ${e.status} ${e.statusText}\n`;return t+=`Response Time: ${e.responseTime}ms\n\n`,e.headers[`content-type`]&&(t+=`Content-Type: ${e.headers[`content-type`]}\n`),e.headers[`content-length`]&&(t+=`Content-Length: ${e.headers[`content-length`]}\n`),t+=`
Response Body:
`,typeof e.data==`object`?t+=JSON.stringify(e.data,null,2):t+=String(e.data),t}var At=({language:e})=>{let t=e===`ru`,n=e===`ro`,r=(e,r,i)=>t?r:n?i:e,i={Eventid:{ru:`Уникальный идентификатор callback-события для трассировки и дедупликации.`,ro:`Identificator unic al evenimentului callback pentru trasabilitate și deduplicare.`},EventType:{ru:`Всегда PAID: уведомления приходят только об успешных платежах.`,ro:`Mereu PAID: se notifică doar plățile reușite.`},Message:{ru:`Текстовое сообщение о результате обработки в контексте callback.`,ro:`Mesaj text despre rezultatul procesării în contextul callback-ului.`},EventDate:{ru:`Время создания уведомления в Paynet (ISO 8601).`,ro:`Momentul creării notificării în Paynet (ISO 8601).`},"Payment.Id":{ru:`Идентификатор платежа в Paynet; используйте как idempotency key.`,ro:`Identificatorul plății în Paynet; folosește-l ca cheie de idempotență.`},"Payment.ExternalId":{ru:`Идентификатор заказа мерчанта, изначально отправленный вашей системой.`,ro:`Identificatorul comenzii merchantului trimis inițial de sistemul tău.`},"Payment.SaleAreaCode":{ru:`Код торговой зоны, связанной с платежом.`,ro:`Codul zonei de vânzare asociate plății.`},"Payment.Merchant":{ru:`Код мерчанта, которому принадлежит платеж.`,ro:`Codul merchantului care deține această operațiune de plată.`},"Payment.Customer":{ru:`Идентификатор клиента из вашей системы, если передавался при создании заказа.`,ro:`Referința clientului din sistemul tău, dacă a fost transmisă la crearea comenzii.`},"Payment.StatusDate":{ru:`Время, когда платеж получил указанный статус.`,ro:`Momentul în care plata a atins statusul raportat.`},"Payment.Amount":{ru:`Сумма заказа в минимальных единицах, как её передал мерчант.`,ro:`Suma comenzii în unități minime, așa cum a trimis-o comerciantul.`},"Payment.PaidAmount":{ru:`Фактически оплаченная сумма. Должна совпадать с Amount, кроме согласованных с Paynet акций.`,ro:`Suma plătită efectiv. Trebuie să fie egală cu Amount, cu excepția promoțiilor convenite cu Paynet.`},"Payment.CardMask":{ru:`Маскированный PAN для карточных платежей.`,ro:`PAN mascat returnat pentru plățile cu card.`},"Payment.CardExpireMonth":{ru:`Месяц срока действия карты (если доступен).`,ro:`Luna expirării cardului (dacă este disponibilă).`},"Payment.CardExpireYear":{ru:`Год срока действия карты (если доступен).`,ro:`Anul expirării cardului (dacă este disponibil).`},"Payment.CardIssuer":{ru:`Название или идентификатор эмитента карты.`,ro:`Numele sau identificatorul emitentului cardului.`},"Payment.CardLinkHash":{ru:`Хеш связанной карты для сценариев linked-card.`,ro:`Hash-ul cardului legat pentru scenarii linked-card.`},"Payment.MoneyType":{ru:`Чем заплатил покупатель: CARD, APPLEPAY, GOOGLEPAY, MIA_QR, PAYNET, CASH_INVOICE.`,ro:`Cum a plătit clientul: CARD, APPLEPAY, GOOGLEPAY, MIA_QR, PAYNET, CASH_INVOICE.`},"Payment.PayerName":{ru:`Имя плательщика из данных карты/платежа.`,ro:`Prenumele plătitorului din datele cardului/plății.`},"Payment.PayerSurname":{ru:`Фамилия плательщика из данных карты/платежа.`,ro:`Numele de familie al plătitorului din datele cardului/plății.`},"Payment.PayerIDNP":{ru:`Персональный идентификатор плательщика, если передан.`,ro:`Identificatorul personal al plătitorului, dacă este furnizat.`},"Payment.RRN":{ru:`RRN эквайера для отслеживания транзакции.`,ro:`RRN-ul achizitorului pentru urmărirea tranzacției.`},"Header.Hash":{ru:"Подпись уведомления, передаваемая в HTTP-заголовке `Hash`.",ro:"Semnătura notificării transmisă în antetul HTTP `Hash`."}},a=(e,t)=>{let n=i[e];return n?r(t,n.ru,n.ro):t},o={grantType:`password`,username:`771064`,password:`sLgMnGWJ`},[s,c]=_.useState(!0),[l,u]=_.useState(`D9873689-E5F8-4272-A67F-0D8BA3F9BAA7`),[d,f]=_.useState(`https://your-domain.com/paynet/notification`),[p,m]=_.useState(!1),[h,g]=_.useState(``),[v,y]=_.useState(``),[b,x]=_.useState(``),[S,w]=_.useState(``),[T,E]=_.useState(``),[A,M]=_.useState(``),N=bt(),P=_.useRef(``),ee=_.useRef(A);ee.current=A,_.useEffect(()=>{if(!N)return;let e=ee.current;(e.trim()===``||e===P.current)&&(P.current=N.order,e!==N.order&&(M(N.order),oe(!1),ie(null)))},[N]);let[I,L]=_.useState(!1),[R,te]=_.useState(``),[ne,re]=_.useState(``),[z,ie]=_.useState(null),[ae,oe]=_.useState(!1),[se,ce]=_.useState(`node`),[le,ue]=_.useState(!1),de=[{name:`Eventid`,type:`long`,input:`body`,required:!0,description:`Unique callback event identifier for traceability and deduplication.`},{name:`EventType`,type:`string`,input:`body`,required:!0,description:`Always PAID: only successful payments are notified.`},{name:`Message`,type:`string`,input:`body`,required:!1,description:`Human-readable processing message for callback context.`},{name:`EventDate`,type:`datetime`,input:`body`,required:!0,description:`When Paynet created this notification event (ISO 8601).`},{name:`Payment.Id`,type:`long`,input:`body`,required:!0,description:`Paynet payment identifier; use as idempotency key on your side.`},{name:`Payment.ExternalId`,type:`long`,input:`body`,required:!0,description:`Merchant order identifier originally sent by your system.`},{name:`Payment.SaleAreaCode`,type:`string`,input:`body`,required:!1,description:`Sale area code associated with the payment.`},{name:`Payment.Merchant`,type:`string`,input:`body`,required:!0,description:`Merchant code that owns this payment operation.`},{name:`Payment.Customer`,type:`string`,input:`body`,required:!1,description:`Customer reference from your system, if provided at order creation.`},{name:`Payment.StatusDate`,type:`datetime`,input:`body`,required:!0,description:`Timestamp when payment reached the reported status.`},{name:`Payment.Amount`,type:`long`,input:`body`,required:!0,description:`Order amount in minor units, as sent by the merchant.`},{name:`Payment.PaidAmount`,type:`long`,input:`body`,required:!1,description:`Amount actually paid. Must equal Amount unless a promotion is agreed with Paynet.`},{name:`Payment.CardMask`,type:`string`,input:`body`,required:!1,description:`Masked PAN returned for card payments.`},{name:`Payment.CardExpireMonth`,type:`string`,input:`body`,required:!1,description:`Card expiration month (if available).`},{name:`Payment.CardExpireYear`,type:`string`,input:`body`,required:!1,description:`Card expiration year (if available).`},{name:`Payment.CardIssuer`,type:`string`,input:`body`,required:!1,description:`Card issuer name or identifier.`},{name:`Payment.CardLinkHash`,type:`string`,input:`body`,required:!1,description:`Card link hash for linked-card scenarios.`},{name:`Payment.MoneyType`,type:`string`,input:`body`,required:!1,description:`How the customer paid: CARD, APPLEPAY, GOOGLEPAY, MIA_QR, PAYNET, CASH_INVOICE.`},{name:`Payment.PayerName`,type:`string`,input:`body`,required:!1,description:`Payer first name from card/payment data.`},{name:`Payment.PayerSurname`,type:`string`,input:`body`,required:!1,description:`Payer surname from card/payment data.`},{name:`Payment.PayerIDNP`,type:`string`,input:`body`,required:!1,description:`Payer personal identifier when provided.`},{name:`Payment.RRN`,type:`string`,input:`body`,required:!1,description:`Acquirer retrieval reference number for transaction tracking.`},{name:`Header.Hash`,type:`string`,input:`header`,required:!0,description:"Notification signature sent in `Hash` HTTP header."}],fe=e=>{if(e==null)return``;let t=String(e).trim();return t?t.includes(`T`)?t:t.replace(` `,`T`):``},pe=async()=>{if(!ae){y(`Please run Get first to load transaction data before sending notification.`);return}if(!l.trim()){y(`Secret key for notification is required.`);return}if(!d.trim()){y(`Notification URL is required.`);return}if(m(!0),y(``),g(``),w(``),E(``),(R||me(z))!==`paid`){y(r(`This order is not paid. Paynet sends notifications only for paid payments (EventType = PAID), so nothing is sent.`,`Этот заказ не оплачен. Paynet отправляет уведомления только об оплаченных платежах (EventType = PAID), поэтому ничего не отправлено.`,`Această comandă nu este plătită. Paynet trimite notificări doar pentru plățile achitate (EventType = PAID), deci nu se trimite nimic.`)),m(!1);return}let e=(...e)=>e.find(e=>e!=null),t=e=>typeof e==`object`&&e?e:{},n=t(e(z?.payment,z?.Payment)),i=t(e(z?.payer,z?.Payer,n?.payer,n?.Payer)),a=Number(e(z?.paymentId,z?.id,n?.Id,n?.id,A)),o=Number(e(z?.order,z?.externalID,z?.externalId,n?.ExternalId,n?.externalId,a)),s=Number(e(n?.Amount,n?.amount,t(z?.amount).amount,t(z?.amount).requestAmount,z?.amount,0)),c=e=>e==null?``:String(e),u=e=>{if(e==null)return null;let t=String(e);return t.length<9?null:`${t.slice(0,4)}XXXX${t.slice(8)}`},f=e(n?.StatusDate,n?.statusDate,z?.paidDate,z?.statusDate,z?.registered,new Date().toISOString()),p=fe(f),h=u(e(n?.Customer,n?.customer,t(z?.customer).code,typeof z?.customer==`string`?z.customer:void 0,z?.customerCode)??null),_=String(e(n?.Merchant,n?.merchant,z?.merchantCode,`265505`)),v=Number.isFinite(s)?s:0,b=Number.isFinite(a)?a:Date.now(),S=Number.isFinite(o)?o:Date.now(),C=Number(z?.eventid??z?.eventId??z?.paymentEventId),T={Eventid:Number.isFinite(C)?C:Date.now(),EventType:`PAID`,Message:`Request processed successfully`,EventDate:fe(z?.paidDate??p),Payment:{Id:b,ExternalId:S,SaleAreaCode:String(e(n?.SaleAreaCode,n?.saleAreaCode,z?.saleAreaCode,`onlidocumentation_md`)),Merchant:_,Customer:h,StatusDate:p,Amount:v,PaidAmount:v,CardMask:e(n?.CardMask,n?.cardMask,i?.cardMask,i?.CardMask,z?.cardMask)??null,CardExpireMonth:e(n?.CardExpireMonth,n?.cardExpireMonth,i?.cardExpireMonth,i?.CardExpireMonth,z?.cardExpireMonth)??null,CardExpireYear:e(n?.CardExpireYear,n?.cardExpireYear,i?.cardExpireYear,i?.CardExpireYear,z?.cardExpireYear)??null,CardIssuer:e(n?.CardIssuer,n?.cardIssuer,i?.cardIssuer,i?.CardIssuer,z?.cardIssuer,``)??``,CardLinkHash:e(n?.CardLinkHash,n?.cardLinkHash,i?.cardLinkHash,i?.CardLinkHash,z?.cardLinkHash)??null,MoneyType:e(n?.MoneyType,n?.moneyType,i?.moneyType,i?.MoneyType,z?.moneyType)??null,PayerName:e(n?.PayerName,n?.payerName,i?.payerName,i?.PayerName,z?.payerName)??null,PayerSurname:e(n?.PayerSurname,n?.payerSurname,i?.payerSurname,i?.PayerSurname,z?.payerSurname)??null,PayerIDNP:e(n?.PayerIDNP,n?.payerIDNP,i?.payerIDNP,i?.PayerIDNP,z?.payerIDNP)??null,RRN:e(n?.RRN,n?.rrn,i?.rrn,i?.RRN,z?.rrn)??null}},D=c(T.EventDate)+c(T.Eventid)+c(T.EventType)+c(T.Payment.Amount)+c(T.Payment.Customer)+c(T.Payment.ExternalId)+c(T.Payment.Id)+c(T.Payment.Merchant)+c(T.Payment.StatusDate),O=ft(D+l.trim());w(O),E(D),x(JSON.stringify(T,null,2));try{let e=await fetch(d,{method:`POST`,headers:{"Content-Type":`application/json`,Accept:`application/json`,Hash:O},body:JSON.stringify(T)}),t=await e.text(),n=t;try{n=JSON.stringify(JSON.parse(t),null,2)}catch{}g(`Status: ${e.status} ${e.statusText}\n\n${n}`)}catch(e){y(`Request failed: ${e instanceof Error?e.message:`Unknown error`}. Browser CORS restrictions may block direct calls.`)}finally{m(!1)}},me=e=>{let t=[e?.eventType,e?.paymentStatus,e?.statusText,typeof e?.status==`string`?e.status:``].filter(Boolean).join(` `).toLowerCase();return t.includes(`paid`)||t.includes(`success`)||t.includes(`approved`)||t.includes(`complete`)||e?.paidDate?`paid`:`fail`},he=async()=>{let e=await fetch(`https://ecom-api-test.paynet.md/auth`,{method:`POST`,headers:{"Content-Type":`application/json`,Accept:`application/json`},body:JSON.stringify(o)});if(!e.ok)throw Error(`Auth failed with status ${e.status}`);let t=await e.json(),n=typeof t?.access_token==`string`?t.access_token:typeof t?.token==`string`?t.token:``;if(!n)throw Error(`Auth response does not contain access token.`);return wt(n),n},ge=async()=>Tt()||he(),_e=()=>se===`php`?`<?php
function normalize($value) {
  return ($value === null) ? '' : strval($value);
}

function buildPreparedString($notification) {
  return
    normalize($notification['EventDate'] ?? null) .
    normalize($notification['Eventid'] ?? null) .
    normalize($notification['EventType'] ?? null) .
    normalize($notification['Payment']['Amount'] ?? null) .
    normalize($notification['Payment']['Customer'] ?? null) .
    normalize($notification['Payment']['ExternalId'] ?? null) .
    normalize($notification['Payment']['Id'] ?? null) .
    normalize($notification['Payment']['Merchant'] ?? null) .
    normalize($notification['Payment']['StatusDate'] ?? null);
}

function verifyNotificationHash($notification, $secretKey, $headerHash) {
  $prepared = buildPreparedString($notification);
  $expected = base64_encode(md5($prepared . $secretKey, true));
  return hash_equals($expected, $headerHash);
}`:`import crypto from 'crypto';

const normalize = (value) => (value === null || value === undefined ? '' : String(value));

function buildPreparedString(notification) {
  return (
    normalize(notification.EventDate) +
    normalize(notification.Eventid) +
    normalize(notification.EventType) +
    normalize(notification.Payment?.Amount) +
    normalize(notification.Payment?.Customer) +
    normalize(notification.Payment?.ExternalId) +
    normalize(notification.Payment?.Id) +
    normalize(notification.Payment?.Merchant) +
    normalize(notification.Payment?.StatusDate)
  );
}

function verifyNotificationHash(notification, secretKey, headerHash) {
  const prepared = buildPreparedString(notification);
  const expected = crypto
    .createHash('md5')
    .update(prepared + secretKey, 'utf8')
    .digest('base64');
  return expected === headerHash;
}`;return(0,B.jsxs)(`div`,{className:`w-full max-w-none`,children:[(0,B.jsx)(`div`,{className:`mb-4 sm:mb-8`,children:(0,B.jsxs)(`div`,{className:`flex items-center gap-3 mb-2 sm:mb-3`,children:[(0,B.jsx)(`span`,{className:`text-xs font-mono px-2 py-1 rounded bg-blue-100 text-blue-700 font-semibold`,children:`POST`}),(0,B.jsx)(`h1`,{className:`text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900`,children:r(`Notification simulator`,`Симулятор уведомлений`,`Simulator notificări`)})]})}),(0,B.jsxs)(`div`,{className:`bg-gradient-to-r from-paynet-light to-paynet-gray-50 rounded-paynet border border-paynet-gray-200 overflow-hidden w-full max-w-none`,children:[(0,B.jsxs)(`button`,{onClick:()=>c(!s),className:`w-full p-4 sm:p-6 flex items-center justify-between hover:bg-paynet-gray-50 transition-colors`,children:[(0,B.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,B.jsx)(C,{className:`w-5 h-5 text-paynet-primary`}),(0,B.jsx)(`h2`,{className:`text-lg sm:text-xl font-semibold text-paynet-primary`,children:r(`Notification simulator`,`Симулятор уведомлений`,`Simulator notificări`)})]}),s?(0,B.jsx)(O,{className:`w-5 h-5 text-paynet-primary transition-transform`}):(0,B.jsx)(k,{className:`w-5 h-5 text-paynet-primary transition-transform`})]}),s&&(0,B.jsx)(`div`,{className:`p-4 sm:p-6 pt-0`,children:(0,B.jsxs)(`div`,{className:`xl:flex xl:items-start xl:gap-6`,children:[(0,B.jsxs)(`div`,{className:`xl:flex-1 min-w-0`,children:[(0,B.jsxs)(`div`,{className:`bg-white p-4 rounded-lg border border-paynet-gray-200`,children:[(0,B.jsx)(`h3`,{className:`text-base sm:text-lg font-semibold text-paynet-primary mb-2`,children:`Method Description`}),(0,B.jsx)(`p`,{className:`text-sm sm:text-base text-paynet-gray-700 leading-relaxed mb-3`,children:r(`Paynet sends a callback when a payment is paid. Notifications are server-to-server requests to your backend callback URL and must be processed reliably.`,`Paynet отправляет callback, когда платёж оплачен. Уведомления — это server-to-server запросы на callback URL вашего бэкенда, их нужно обрабатывать надёжно.`,`Paynet trimite un callback când plata este achitată. Notificările sunt cereri server-to-server către URL-ul de callback al backend-ului dvs. și trebuie procesate fiabil.`)}),(0,B.jsxs)(`ul`,{className:`list-disc pl-5 space-y-2 text-sm sm:text-base text-paynet-gray-700`,children:[(0,B.jsx)(`li`,{children:r(`Paynet sends a callback only when a payment is paid (EventType = PAID). A failed payment produces no callback: the customer is redirected to LinkUrlCancel.`,`Paynet отправляет callback только когда платёж оплачен (EventType = PAID). При неуспешной оплате callback нет: покупатель перенаправляется на LinkUrlCancel.`,`Paynet trimite callback doar când plata este achitată (EventType = PAID). La o plată eșuată nu există callback: clientul este redirecționat la LinkUrlCancel.`)}),(0,B.jsx)(`li`,{children:r(`Flow is server-to-server, so callback endpoint must be implemented on backend side.`,`Поток server-to-server, поэтому callback endpoint должен быть реализован на backend.`,`Fluxul este server-to-server, deci endpoint-ul de callback trebuie implementat pe backend.`)}),(0,B.jsx)(`li`,{children:r("Use `Payment.Id` as idempotency key to prevent duplicate business processing. Keys are case-sensitive: `Id`, `ExternalId`.","Используйте `Payment.Id` как ключ идемпотентности, чтобы избежать повторной обработки. Ключи чувствительны к регистру: `Id`, `ExternalId`.","Folosește `Payment.Id` ca cheie de idempotență pentru a preveni procesarea dublă. Cheile țin cont de majuscule: `Id`, `ExternalId`.")}),(0,B.jsx)(`li`,{children:r("Return HTTP `200` only after signature validation and successful internal processing.","Возвращайте HTTP `200` только после проверки подписи и успешной внутренней обработки.","Returnează HTTP `200` doar după validarea semnăturii și procesarea internă cu succes.")})]})]}),(0,B.jsxs)(`div`,{className:`mt-6 bg-white p-4 rounded-lg border border-paynet-gray-200`,children:[(0,B.jsx)(`h3`,{className:`text-base sm:text-lg font-semibold text-paynet-primary mb-2`,children:`Merchant UX flow`}),(0,B.jsxs)(`ol`,{className:`list-decimal pl-5 space-y-2 text-sm sm:text-base text-paynet-gray-700`,children:[(0,B.jsx)(`li`,{children:r("Paste your callback URL into `MerchantSystemUrl (callback URL)`.","Вставьте ваш callback URL в `MerchantSystemUrl (callback URL)`.","Introdu URL-ul tău de callback în `MerchantSystemUrl (callback URL)`.")}),(0,B.jsx)(`li`,{children:r("Enter the merchant order number (`Order`) you used when creating the payment.","Введите номер заказа мерчанта (`Order`), который вы указали при создании платежа.","Introdu numărul comenzii comerciantului (`Order`) folosit la crearea plății.")}),(0,B.jsx)(`li`,{children:r("Click `Get` to load transaction state from `GET /api/order/merchant/{'{id}'}`.","Нажмите `Get`, чтобы загрузить состояние транзакции через `GET /api/order/merchant/{'{id}'}`.","Apasă `Get` pentru a încărca starea tranzacției din `GET /api/order/merchant/{'{id}'}`.")}),(0,B.jsx)(`li`,{children:r("Check business status (`paid` / `fail` / `Fail - transaction doesn't exist`).","Проверьте бизнес-статус (`paid` / `fail` / `Fail - transaction doesn't exist`).","Verifică statusul business (`paid` / `fail` / `Fail - transaction doesn't exist`).")}),(0,B.jsx)(`li`,{children:r("Click `Send notification` to post callback payload to your URL and verify signature.","Нажмите `Send notification`, чтобы отправить callback payload на ваш URL и проверить подпись.","Apasă `Send notification` pentru a trimite payload-ul callback către URL-ul tău și a verifica semnătura.")}),(0,B.jsx)(`li`,{children:r(`CORS is needed only here, because the simulator posts from your browser. Real Paynet notifications come from the Paynet server and do not need CORS; confirm real delivery with a test payment.`,`CORS нужен только здесь, потому что симулятор отправляет запрос из браузера. Настоящие уведомления приходят с сервера Paynet, CORS им не нужен; реальную доставку проверьте тестовым платежом.`,`CORS este necesar doar aici, deoarece simulatorul trimite din browser. Notificările reale Paynet vin de la serverul Paynet și nu au nevoie de CORS; verificați livrarea reală cu o plată de test.`)})]})]}),(0,B.jsxs)(`div`,{className:`mt-6`,children:[(0,B.jsx)(`h3`,{className:`text-base sm:text-lg font-semibold text-paynet-primary mb-1`,children:`Parameters - Description`}),(0,B.jsx)(at,{items:de.map(e=>({name:e.name,type:e.type,in:e.input,required:!!e.required,description:String(a(e.name,e.description)??``)})),labels:{required:`Required`,optional:`Optional`,name:`Name`,description:`Description`}})]}),(0,B.jsxs)(`div`,{className:`mt-6 bg-white p-4 rounded-lg border border-paynet-gray-200`,children:[(0,B.jsx)(`h3`,{className:`text-base sm:text-lg font-semibold text-paynet-primary mb-2`,children:`Signature validation`}),(0,B.jsx)(`p`,{className:`text-sm sm:text-base text-paynet-gray-700 leading-relaxed mb-3`,children:r("Verify every notification before trusting business status. Build `PreparedString` in strict order and compare expected hash with `Header.Hash`.","Проверяйте каждое уведомление до принятия бизнес-статуса. Формируйте `PreparedString` в строгом порядке и сравнивайте ожидаемый hash с `Header.Hash`.","Verifică fiecare notificare înainte de a accepta statusul business. Construiește `PreparedString` în ordine strictă și compară hash-ul așteptat cu `Header.Hash`.")}),(0,B.jsx)(`pre`,{className:`bg-paynet-gray-900 text-paynet-gray-100 p-3 rounded-md text-xs sm:text-sm overflow-x-auto mb-3 whitespace-pre-wrap`,children:`ExpectedHash = Base64(MD5(PreparedString + SecretKey))
Accept notification only if ExpectedHash === Header.Hash`}),(0,B.jsx)(`pre`,{className:`bg-paynet-gray-900 text-paynet-gray-100 p-3 rounded-md text-xs sm:text-sm overflow-x-auto mb-3 whitespace-pre-wrap`,children:`PreparedString =
EventDate + Eventid + EventType + Payment.Amount + Payment.Customer +
Payment.ExternalId + Payment.Id + Payment.Merchant + Payment.StatusDate`}),(0,B.jsx)(`p`,{className:`text-xs sm:text-sm text-paynet-gray-600 mb-3`,children:r(`Order is strict. Empty fields must be treated as empty strings.`,`Порядок строго фиксирован. Пустые поля нужно обрабатывать как пустые строки.`,`Ordinea este strictă. Câmpurile goale trebuie tratate ca șiruri goale.`)}),(0,B.jsxs)(`ol`,{className:`list-decimal pl-5 space-y-2 text-sm sm:text-base text-paynet-gray-700 mb-3`,children:[(0,B.jsx)(`li`,{children:r(`Parse notification and normalize missing fields to empty strings.`,`Распарсьте уведомление и нормализуйте отсутствующие поля как пустые строки.`,`Parsează notificarea și normalizează câmpurile lipsă la șiruri goale.`)}),(0,B.jsx)(`li`,{children:r("Build `PreparedString` in exact order and append `SecretKey`.","Соберите `PreparedString` в точном порядке и добавьте `SecretKey`.","Construiește `PreparedString` în ordinea exactă și adaugă `SecretKey`.")}),(0,B.jsx)(`li`,{children:r("Compute hash and compare with `Header.Hash` (constant-time comparison).","Вычислите hash и сравните с `Header.Hash` (сравнение constant-time).","Calculează hash-ul și compară-l cu `Header.Hash` (comparație constant-time).")})]}),(0,B.jsxs)(`div`,{className:`border border-paynet-gray-200 rounded-md p-3 bg-paynet-gray-50`,children:[(0,B.jsxs)(`div`,{className:`flex items-center justify-between mb-2`,children:[(0,B.jsxs)(`div`,{className:`flex gap-2`,children:[(0,B.jsx)(`button`,{onClick:()=>ce(`node`),className:`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${se===`node`?`bg-paynet-primary text-white`:`bg-white text-paynet-gray-700 border border-paynet-gray-300`}`,children:`Node.js`}),(0,B.jsx)(`button`,{onClick:()=>ce(`php`),className:`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${se===`php`?`bg-paynet-primary text-white`:`bg-white text-paynet-gray-700 border border-paynet-gray-300`}`,children:`PHP`})]}),(0,B.jsx)(`button`,{onClick:async()=>{await navigator.clipboard.writeText(_e()),ue(!0),setTimeout(()=>ue(!1),2e3)},className:`flex items-center gap-2 px-3 py-1.5 bg-paynet-primary hover:bg-paynet-secondary text-white text-xs font-medium rounded-paynet transition-all duration-200`,children:le?(0,B.jsxs)(B.Fragment,{children:[(0,B.jsx)(D,{className:`w-3 h-3`}),`Copied`]}):(0,B.jsxs)(B.Fragment,{children:[(0,B.jsx)(j,{className:`w-3 h-3`}),`Copy sample verifier code`]})})]}),(0,B.jsx)(`pre`,{className:`bg-gray-900 text-gray-100 p-3 rounded-md text-xs sm:text-sm overflow-x-auto whitespace-pre-wrap`,children:_e()})]})]})]}),(0,B.jsx)(`div`,{className:`xl:w-144 w-full mt-4 xl:mt-0`,children:(0,B.jsxs)(`div`,{className:`bg-gradient-to-r from-paynet-light to-paynet-gray-50 rounded-paynet border border-paynet-gray-200 overflow-hidden w-full max-w-none`,children:[(0,B.jsx)(`div`,{className:`w-full p-4 sm:p-6 flex items-center justify-between`,children:(0,B.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,B.jsx)(F,{className:`w-5 h-5 text-paynet-primary`}),(0,B.jsx)(`h3`,{className:`text-base sm:text-lg font-semibold text-paynet-primary`,children:`Code Examples`})]})}),(0,B.jsx)(`div`,{className:`p-4 sm:p-6 pt-0`,children:(0,B.jsxs)(`div`,{className:`bg-white p-4 rounded-lg border border-paynet-gray-200`,children:[(0,B.jsx)(`h3`,{className:`text-base sm:text-lg font-semibold text-paynet-primary mb-2`,children:`Notification endpoint`}),(0,B.jsx)(`div`,{className:`mb-2`,children:(0,B.jsxs)(`div`,{className:`max-w-2xl`,children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`Secret key for notification`}),(0,B.jsx)(`input`,{value:l,onChange:e=>u(e.target.value),className:`w-full px-3 py-2 border border-paynet-gray-300 rounded-md text-sm font-mono mb-3`,placeholder:`Enter secret key used for signature validation`}),(0,B.jsx)(`p`,{className:`-mt-2 mb-3 text-xs text-paynet-gray-500`,children:r(`Pre-filled with the public test key of the shared test merchant. Replace it with your own test key if you have one. Never enter a production key here.`,`Уже заполнен публичным тестовым ключом общего тестового мерчанта. Если у вас есть свой тестовый ключ, замените его. Боевой ключ сюда не вводите.`,`Completat deja cu cheia publică de test a comerciantului de test comun. Dacă aveți propria cheie de test, înlocuiți-o. Nu introduceți aici cheia de producție.`)}),(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`MerchantSystemUrl (callback URL)`}),(0,B.jsx)(`input`,{value:d,onChange:e=>f(e.target.value),className:`w-full px-3 py-2 border border-paynet-gray-300 rounded-md text-sm font-mono`,placeholder:`https://your-domain.com/paynet/notification`})]})}),(0,B.jsx)(`p`,{className:`text-xs sm:text-sm text-paynet-gray-600`,children:r(`Set the public HTTPS endpoint that will receive Paynet notification payloads.`,`Укажите публичный HTTPS endpoint, который будет получать payload уведомлений Paynet.`,`Setează endpoint-ul public HTTPS care va primi payload-urile de notificare Paynet.`)}),(0,B.jsxs)(`div`,{className:`mt-4 max-w-xl`,children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`Merchant order number (Order)`}),(0,B.jsxs)(`div`,{className:`flex gap-2`,children:[(0,B.jsx)(`input`,{value:A,onChange:e=>{M(e.target.value),oe(!1),ie(null)},className:`w-full px-3 py-2 border border-paynet-gray-300 rounded-md text-sm font-mono`,placeholder:`317184`}),(0,B.jsx)(`button`,{onClick:async()=>{if(!A.trim()){re(`Merchant order number (Order) is required.`);return}let e=A.trim(),t=`https://ecom-api-test.paynet.md/api/order/merchant/${encodeURIComponent(e)}`;L(!0),re(``),te(``),oe(!1),ie(null);try{let n=await ge(),r=await fetch(t,{method:`GET`,headers:{Accept:`application/json`,Authorization:`Bearer ${n}`}});r.status===401&&(n=await he(),r=await fetch(t,{method:`GET`,headers:{Accept:`application/json`,Authorization:`Bearer ${n}`}}));let i=await r.text(),a=null;try{a=i?JSON.parse(i):null}catch{a=null}let o=a&&typeof a==`object`?{...a,_httpStatus:r.status,_transactionId:e}:{_httpStatus:r.status,_transactionId:e};if(ie(o),oe(!0),!r.ok){let e=r.status===404||o?.code===`NOT_FOUND_RECORD`;te(e?`Fail - transaction doesn't exist`:`fail`);return}if(o?.code===`NOT_FOUND_RECORD`){te(`Fail - transaction doesn't exist`);return}te(me(o))}catch(e){let t=e instanceof Error?e.message:`Unknown error`,n=t.includes(`Auth failed with status 401`);re(`${n?`No token / unauthorized. `:``}Get payment info failed: ${t}. Browser CORS restrictions may block direct calls.`),te(`fail`),oe(!1),ie(null)}finally{L(!1)}},disabled:I,className:`px-4 py-2 bg-paynet-primary hover:bg-paynet-secondary disabled:bg-gray-400 text-white text-sm font-medium rounded-md`,children:I?`Getting...`:`Get`})]}),N&&A===N.order&&(0,B.jsx)(`p`,{className:`mt-1 text-xs text-paynet-gray-500`,children:r(`Filled in automatically: the last order created on this site${N.source===`checkout-form`?` (sent via the checkout form)`:``}, ${new Date(N.createdAt).toLocaleTimeString()}. You can enter another number.`,`Подставлен автоматически: последний заказ, созданный на этом сайте${N.source===`checkout-form`?` (отправлен через форму checkout)`:``}, ${new Date(N.createdAt).toLocaleTimeString()}. Можно ввести другой номер.`,`Completat automat: ultima comandă creată pe acest site${N.source===`checkout-form`?` (trimisă prin formularul checkout)`:``}, ${new Date(N.createdAt).toLocaleTimeString()}. Puteți introduce alt număr.`)})]}),ne&&(0,B.jsx)(`div`,{className:`mt-4 p-3 bg-red-50 border border-red-200 rounded-md text-sm text-red-700`,children:ne}),R&&(0,B.jsxs)(`div`,{className:`mt-4`,children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`Payment status`}),(0,B.jsx)(`div`,{className:`inline-flex items-center px-3 py-1.5 rounded-md text-sm font-semibold ${R===`paid`?`bg-green-100 text-green-700`:`bg-red-100 text-red-700`}`,children:R})]}),(0,B.jsx)(`div`,{className:`mt-4`,children:(0,B.jsx)(`button`,{onClick:pe,disabled:p||!ae,className:`px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white text-sm font-medium rounded-md`,children:p?`Sending...`:`Send notification`})}),v&&(0,B.jsx)(`div`,{className:`mt-4 p-3 bg-red-50 border border-red-200 rounded-md text-sm text-red-700`,children:v}),h&&(0,B.jsxs)(`div`,{className:`mt-4`,children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`Notification response`}),(0,B.jsx)(`pre`,{className:`bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto whitespace-pre-wrap`,children:h})]}),b&&(0,B.jsxs)(`div`,{className:`mt-4`,children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`Sent notification payload`}),(0,B.jsx)(`pre`,{className:`bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto whitespace-pre-wrap`,children:b})]}),S&&(0,B.jsxs)(`div`,{className:`mt-4`,children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`Sent Hash header`}),(0,B.jsx)(`code`,{className:`block bg-paynet-gray-50 border border-paynet-gray-200 px-3 py-2 rounded-md text-sm break-all`,children:S})]}),T&&(0,B.jsxs)(`div`,{className:`mt-4`,children:[(0,B.jsx)(`label`,{className:`block text-sm font-medium text-paynet-gray-700 mb-1`,children:`Sent PreparedString`}),(0,B.jsx)(`code`,{className:`block bg-paynet-gray-50 border border-paynet-gray-200 px-3 py-2 rounded-md text-sm break-all`,children:T})]}),(0,B.jsx)(`p`,{className:`mt-4 text-xs sm:text-sm text-paynet-gray-600`,children:r(`This tool sends a test callback simulation from documentation UI. It is not a live production push from Paynet systems.`,`Этот инструмент отправляет тестовую симуляцию callback из UI документации. Это не боевая отправка из систем Paynet.`,`Acest instrument trimite o simulare de callback de test din UI-ul documentației. Nu este un push live de producție din sistemele Paynet.`)})]})})]})})]})})]})]})},jt={curl:{target:`shell`,client:`curl`},javascript:{target:`javascript`,client:`fetch`},node:{target:`node`,client:`native`},python:{target:`python`,client:`requests`},php:{target:`php`,client:`curl`},java:{target:`java`,client:`okhttp`},csharp:{target:`csharp`,client:`httpclient`},go:{target:`go`,client:`native`},ruby:{target:`ruby`,client:`native`}};function Mt(e,t,n,r=!0){let i=e.customParameterValues||{},a=e.customRequestBody,o=e.path.match(/\{([^}]+)\}/g)?.map(e=>({name:e.slice(1,-1),in:`path`,required:!0,schema:{type:`string`}}))||[],s=[...e.parameters||[],...o.filter(t=>!e.parameters?.some(e=>e.name===t.name))],c=t;if(r&&n.servers&&n.servers.length>0){let e=n.servers.find(e=>e.description?.toLowerCase().includes(`sandbox`)||e.url?.toLowerCase().includes(`test`));c=e?e.url:n.servers.length>1?n.servers[1].url:n.servers[0].url}let l=s.filter(e=>e.in===`path`),u=s.filter(e=>e.in===`query`),d=s.filter(e=>e.in===`header`),f=e.path;l.forEach(e=>{let t=H(e,i[e.name]);f=f.replace(`{${e.name}}`,String(t))});let p=u.length>0?`?`+u.map(e=>{let t=H(e,i[e.name]);return`${e.name}=${encodeURIComponent(String(t))}`}).join(`&`):``,m={};if(m[`Accept-Language`]=`en-US`,[`POST`,`PUT`,`PATCH`].includes(e.method)){let t=n.paths[e.path]?.[e.method.toLowerCase()]?.requestBody;m[`Content-Type`]=t?.content&&Object.keys(t.content).length>0?Object.keys(t.content)[0]:e.parameters&&e.parameters.length>0?`application/x-www-form-urlencoded`:`application/json`}if(n.components?.securitySchemes&&f!==`/auth`){let e=Tt();m.Authorization=e?`Bearer ${e}`:`Bearer {{_token_}}`}d.forEach(e=>{m[e.name]=String(H(e,i[e.name]))});let h;if([`POST`,`PUT`,`PATCH`].includes(e.method)){let t=n.paths[e.path]?.[e.method.toLowerCase()]?.requestBody;if(t?.content){if(t.content[`application/x-www-form-urlencoded`]){let e={},n=t.content[`application/x-www-form-urlencoded`].schema,r=n?.properties;n&&r&&Object.keys(r).forEach(t=>{let n=i[t];n!==void 0&&n!==``?e[t]=n:r[t].example===void 0?e[t]=H({schema:r[t],name:t}):e[t]=r[t].example}),h=Object.entries(e).map(([e,t])=>`${e}=${encodeURIComponent(String(t))}`).join(`&`)}else if(t.content[`application/json`]){if(a)try{h=JSON.parse(a)}catch{h=a}else t.content[`application/json`].example?h=ht(t.content[`application/json`].example):t.content[`application/json`].schema&&(h=St(t.content[`application/json`].schema))}}}return{method:e.method,url:`${c}${f}${p}`,headers:m,...h&&{body:typeof h==`string`?h:JSON.stringify(h,null,2)}}}var Nt={curl:e=>{let t=Object.entries(e.headers).map(([e,t])=>`-H "${e}: ${t}"`).join(` \\
  `),n=e.body?` \\\n  -d '${e.body}'`:``;return`curl -X ${e.method} \\\n  "${e.url}" \\\n  ${t}${n}`},javascript:e=>{let t={method:e.method,headers:e.headers,...e.body&&{body:e.body}};return`const response = await fetch('${e.url}', ${JSON.stringify(t,null,2)});

const data = await response.json();
console.log(data);`},python:e=>{let t=JSON.stringify(e.headers,null,2).replace(/"/g,`'`),n=e.body?`\n\ndata = ${e.body}\nresponse = requests.${e.method.toLowerCase()}(url, headers=headers, json=data)`:`\n\nresponse = requests.${e.method.toLowerCase()}(url, headers=headers)`;return`import requests
import json

url = "${e.url}"
headers = ${t}${n}

data = response.json()
print(data)`},php:e=>{let t=Object.entries(e.headers).map(([e,t])=>`    '${e}: ${t}'`).join(`,
`),n=e.body?`,\n  CURLOPT_POSTFIELDS => '${e.body.replace(/'/g,`\\'`)}'`:``;return`<?php
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => '${e.url}',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_CUSTOMREQUEST => '${e.method}',
  CURLOPT_HTTPHEADER => array(
${t}
  )${n}
));

$response = curl_exec($curl);
curl_close($curl);

$data = json_decode($response, true);
print_r($data);
?>`},java:e=>{let t=Object.entries(e.headers).map(([e,t])=>`    .header("${e}", "${t}")`).join(`
`),n=e.body?`.POST(HttpRequest.BodyPublishers.ofString("${e.body.replace(/"/g,`\\"`).replace(/\n/g,`\\n`)}"))`:`.${e.method}()`;return`import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;

HttpClient client = HttpClient.newHttpClient();
HttpRequest request = HttpRequest.newBuilder()
    .uri(URI.create("${e.url}"))
${t}
    ${n}
    .build();

HttpResponse<String> response = client.send(request, 
    HttpResponse.BodyHandlers.ofString());

System.out.println(response.body());`},csharp:e=>{let t=Object.entries(e.headers).map(([e,t])=>`        client.DefaultRequestHeaders.Add("${e}", "${t}");`).join(`
`),n;if(e.method===`GET`)n=`GetAsync(url)`;else if(e.body){let t=e.body.replace(/"/g,`\\"`).replace(/\n/g,`\\n`);n=`${e.method===`POST`?`PostAsync`:e.method===`PUT`?`PutAsync`:`SendAsync`}(url, new StringContent("${t}", Encoding.UTF8, "application/json"))`}else n=`${e.method}Async(url)`;return`using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

class Program
{
    private static readonly HttpClient client = new HttpClient();
    
    static async Task Main()
    {
${t}
        
        string url = "${e.url}";
        
        HttpResponseMessage response = await client.${n};
        string responseBody = await response.Content.ReadAsStringAsync();
        
        Console.WriteLine(responseBody);
    }
}`}};async function Pt({endpoint:e,baseUrl:t,spec:n}){let r=Mt(e,t,n,!0),i={};for(let e of Object.keys(jt))try{let t=Nt[e];t&&(i[e]={language:e,label:Ft(e),source:t(r)})}catch(t){console.warn(`Failed to generate ${e} code:`,t),i[e]={language:e,label:Ft(e),source:`// Code generation failed for ${e}\n// Request: ${r.method} ${r.url}`}}return i}function Ft(e){return{curl:`cURL`,javascript:`JavaScript`,node:`Node.js`,python:`Python`,php:`PHP`,java:`Java`,csharp:`C#`,go:`Go`,ruby:`Ruby`}[e]||e.charAt(0).toUpperCase()+e.slice(1)}var It=({endpoint:e,baseUrl:t,spec:n,t:r})=>{let[i,a]=(0,_.useState)(`curl`),[o,s]=(0,_.useState)(null),[c,l]=(0,_.useState)({}),[u,d]=(0,_.useState)(!0),[f,p]=(0,_.useState)({}),[m,h]=(0,_.useState)({}),[g,v]=(0,_.useState)(!1),[y,b]=(0,_.useState)({}),[x,S]=(0,_.useState)({}),[C,w]=(0,_.useState)(null);_.useEffect(()=>{let e=Tt();w(e)},[]);let T=Object.keys(c),O=n?.paths?.[e.path]?.[e.method.toLowerCase()]?.requestBody,k=e.path.match(/\{([^}]+)\}/g)?.map(e=>({name:e.slice(1,-1),in:`path`,required:!0,description:`Path parameter: ${e.slice(1,-1)}`,type:`string`}))||[],A=[...e.parameters||[],...k.filter(t=>!e.parameters?.some(e=>e.name===t.name))],M=A.length>0,N=O?.content&&Object.keys(O.content).some(e=>e===`application/x-www-form-urlencoded`),P=O?.content&&Object.keys(O.content).some(e=>e===`application/json`),F=P,ee=f[e.id]||{},I=m[e.id]||``,L=y[e.id]||null,R=x[e.id]||!1;_.useEffect(()=>{if(A.length>0||N){let t={};if(A.forEach(e=>{t[e.name]=``}),N){let e=O.content[`application/x-www-form-urlencoded`];e.schema&&e.schema.properties&&Object.keys(e.schema.properties).forEach(e=>{t[e]=``})}p(n=>({...n,[e.id]:t}))}},[e.id,A.length,N]),_.useEffect(()=>{if(P){let t=O.content[`application/json`]?.example;h(t?n=>({...n,[e.id]:JSON.stringify(ht(t),null,2)}):t=>({...t,[e.id]:`{}`}))}},[e.id,P,O]);let te=M||!!N||!!F,ne=JSON.stringify(ee),re=T.join(`,`),z=`edit`,ie=_.useRef(!1),oe=_.useRef(null);_.useLayoutEffect(()=>{let e=oe.current;e&&(e.style.height=`auto`,e.style.height=`${e.scrollHeight+2}px`)}),_.useEffect(()=>{if(!n||P&&!I)return;let r=!1,i=setTimeout(async()=>{try{let i=await Pt({endpoint:{...e,customParameterValues:ee,customRequestBody:I},baseUrl:t,spec:n});r||l(i)}catch(e){console.error(`Failed to generate code snippets:`,e),r||l({})}finally{r||(ie.current=!0,d(!1))}},ie.current?300:0);return()=>{r=!0,clearTimeout(i)}},[e.id,t,n,I,ne]),_.useEffect(()=>{a(te?z:`curl`)},[e.id]),_.useEffect(()=>{i!==z&&T.length>0&&!T.includes(i)&&a(T[0])},[re,i]);let se=async(e,t)=>{try{await navigator.clipboard.writeText(e),s(t),setTimeout(()=>s(null),2e3)}catch(e){console.error(`Failed to copy code:`,e)}},ce=(t,n)=>{p(r=>({...r,[e.id]:{...r[e.id],[t]:n}}))},ue=t=>{h(n=>({...n,[e.id]:t}))},de=async()=>{if(n){v(!0),b(t=>({...t,[e.id]:null}));try{let t=await Ot(Dt(e,n,ee,I));if(b(n=>({...n,[e.id]:t})),S(t=>({...t,[e.id]:!0})),e.path===`/auth`&&t.status===200){let e=Tt();w(e)}}catch(t){console.error(`API test failed:`,t),b(n=>({...n,[e.id]:{status:0,statusText:`Test Failed`,headers:{},data:null,responseTime:0,error:t instanceof Error?t.message:`Unknown error occurred`}})),S(t=>({...t,[e.id]:!0}))}finally{v(!1)}}};if(u)return(0,B.jsx)(`div`,{className:`text-center py-8`,children:(0,B.jsx)(`div`,{className:`text-paynet-gray-600`,children:r.common.generatingCodeExamples})});if(T.length===0)return(0,B.jsx)(`div`,{className:`text-center py-8`,children:(0,B.jsx)(`div`,{className:`text-paynet-gray-600`,children:r.common.noCodeExamplesAvailable})});let fe=N?Object.entries(O.content[`application/x-www-form-urlencoded`]?.schema?.properties||{}):[],pe=N?O.content[`application/x-www-form-urlencoded`]?.schema?.required:void 0,he=Array.isArray(pe)?pe:[],ge=Math.max(3,I.split(`
`).length),_e=i===z,ve=_e?I:c[i]?.source||``,ye=(e,t,n,r,i)=>(0,B.jsxs)(`div`,{className:`grid grid-cols-1 sm:grid-cols-[minmax(0,10rem)_minmax(0,1fr)] gap-1 sm:gap-3 items-center`,children:[(0,B.jsx)(`label`,{className:`text-xs font-medium text-gray-700 font-mono break-all`,title:i,children:t}),(0,B.jsx)(`input`,{type:`text`,value:n,onChange:t=>ce(e,t.target.value),placeholder:r,title:i,className:`px-3 py-1.5 border border-gray-300 rounded-md text-sm font-mono focus:ring-2 focus:ring-paynet-primary focus:border-transparent`})]},e);return(0,B.jsxs)(`div`,{children:[(0,B.jsxs)(`div`,{className:`flex items-center justify-between gap-3 mb-3`,children:[(0,B.jsx)(`h3`,{className:`text-lg font-semibold text-gray-900`,children:r.common.codeExamples}),(0,B.jsxs)(`div`,{className:`flex items-center gap-2 text-xs text-gray-600`,children:[(0,B.jsx)(`span`,{className:`w-2 h-2 rounded-full ${C?`bg-green-500`:`bg-gray-400`}`}),(0,B.jsxs)(`span`,{title:C?`${C.substring(0,20)}…`:void 0,children:[`Auth Token: `,C?`Active`:`Not Set`]}),C&&(0,B.jsx)(`button`,{onClick:()=>{Et(),w(null)},className:`text-red-600 hover:text-red-800 font-medium`,children:`Clear`})]})]}),(0,B.jsxs)(`div`,{className:`border border-gray-200 rounded-lg`,children:[(0,B.jsxs)(`div`,{className:`flex flex-wrap border-b border-gray-200 bg-gray-50 rounded-t-lg overflow-hidden`,children:[te&&(0,B.jsxs)(`button`,{onClick:()=>a(z),className:`px-4 py-2 text-sm font-medium transition-colors inline-flex items-center gap-1.5 ${_e?`bg-white text-paynet-primary border-b-2 border-paynet-primary`:`text-gray-600 hover:text-gray-900 hover:bg-gray-100`}`,children:[(0,B.jsx)(le,{className:`w-3.5 h-3.5`}),F?`JSON`:r.common.parameters]},z),T.map(e=>(0,B.jsx)(`button`,{onClick:()=>a(e),className:`px-4 py-2 text-sm font-medium transition-colors ${i===e?`bg-white text-paynet-primary border-b-2 border-paynet-primary`:`text-gray-600 hover:text-gray-900 hover:bg-gray-100`}`,children:c[e]?.label||e},e))]}),_e?(0,B.jsxs)(`div`,{className:`p-4 bg-white space-y-3`,children:[(A.length>0||fe.length>0)&&(0,B.jsxs)(`div`,{className:`space-y-2`,children:[A.map(e=>ye(e.name,(0,B.jsxs)(B.Fragment,{children:[e.name,(0,B.jsxs)(`span`,{className:`text-gray-400 font-sans`,children:[` (`,e.in,`)`]}),(e.required||e.in===`path`)&&(0,B.jsx)(`span`,{className:`text-red-500 ml-0.5`,children:`*`})]}),ee[e.name]||``,e.name===`from`?`2026-03-01`:e.name===`to`?`2026-03-31`:r.common.enterParameter.replace(`{parameter}`,e.name),e.description)),fe.map(([e,t])=>ye(e,(0,B.jsxs)(B.Fragment,{children:[e,he.includes(e)&&(0,B.jsx)(`span`,{className:`text-red-500 ml-0.5`,children:`*`})]}),ee[e]||``,r.common.enterParameter.replace(`{parameter}`,e),t?.description))]}),F&&(0,B.jsxs)(`div`,{children:[(0,B.jsx)(`textarea`,{ref:oe,value:I,onChange:e=>ue(e.target.value),placeholder:r.common.enterJsonRequestBody,rows:ge,spellCheck:!1,"aria-label":r.common.requestBody,className:`w-full px-3 py-2 border border-gray-300 rounded-md text-sm font-mono leading-5 resize-none overflow-hidden focus:ring-2 focus:ring-paynet-primary focus:border-transparent`}),(0,B.jsxs)(`div`,{className:`flex justify-between items-center mt-1 gap-3`,children:[(0,B.jsxs)(`span`,{className:`text-xs text-gray-500`,children:[r.common.contentType,`: `,Object.keys(O.content)[0]]}),(0,B.jsx)(`button`,{onClick:()=>{try{ue(JSON.stringify(JSON.parse(I),null,2))}catch{}},className:`text-xs text-paynet-primary hover:underline`,children:r.common.formatJson})]})]}),(0,B.jsx)(`p`,{className:`text-xs text-gray-500`,children:r.common.codeSyncHint})]}):(0,B.jsx)(`pre`,{className:`bg-gray-900 text-gray-100 p-4 overflow-x-auto text-sm m-0`,children:(0,B.jsx)(`code`,{className:`whitespace-pre-wrap break-words`,children:c[i]?.source||`Code not available`})}),(0,B.jsxs)(`div`,{className:`sticky bottom-0 z-10 flex items-center gap-2 p-3 border-t border-gray-200 bg-gray-50 rounded-b-lg`,children:[(0,B.jsx)(`button`,{onClick:de,disabled:g,className:`flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white text-sm font-medium rounded-md transition-colors`,children:g?(0,B.jsxs)(B.Fragment,{children:[(0,B.jsx)(ae,{className:`w-4 h-4 animate-spin`}),r.common.testing]}):(0,B.jsxs)(B.Fragment,{children:[(0,B.jsx)(me,{className:`w-4 h-4`}),r.common.testApiRequest]})}),(0,B.jsx)(`button`,{onClick:()=>se(ve,i),className:`p-2 border border-gray-300 bg-white hover:bg-gray-100 rounded-md transition-colors`,title:r.common.copyToClipboard,"aria-label":r.common.copyToClipboard,children:o===i?(0,B.jsx)(D,{className:`w-4 h-4 text-green-600`}):(0,B.jsx)(j,{className:`w-4 h-4 text-gray-600`})})]})]}),R&&L&&(0,B.jsxs)(`div`,{className:`mt-6`,children:[(0,B.jsxs)(`div`,{className:`flex items-center justify-between mb-4`,children:[(0,B.jsxs)(`h4`,{className:`text-md font-semibold text-gray-900 flex items-center gap-2`,children:[L.error?(0,B.jsx)(be,{className:`w-5 h-5 text-red-500`}):L.status>=200&&L.status<300?(0,B.jsx)(E,{className:`w-5 h-5 text-green-500`}):(0,B.jsx)(be,{className:`w-5 h-5 text-red-500`}),r.common.apiResponse]}),(0,B.jsx)(`button`,{onClick:()=>S(t=>({...t,[e.id]:!1})),className:`text-sm text-gray-500 hover:text-gray-700`,children:r.common.hide})]}),(0,B.jsxs)(`div`,{className:`border border-gray-200 rounded-lg overflow-hidden`,children:[(0,B.jsx)(`div`,{className:`px-4 py-3 text-sm font-medium ${L.error?`bg-red-50 text-red-800`:L.status>=200&&L.status<300?`bg-green-50 text-green-800`:L.status>=400&&L.status<500?`bg-yellow-50 text-yellow-800`:`bg-red-50 text-red-800`}`,children:L.error?`❌ ${L.error}`:`${L.status} ${L.statusText} • ${L.responseTime}ms`}),(0,B.jsxs)(`div`,{className:`relative`,children:[(0,B.jsx)(`pre`,{className:`bg-gray-900 text-gray-100 p-4 overflow-x-auto text-sm max-h-96`,children:(0,B.jsx)(`code`,{className:`whitespace-pre-wrap break-words`,children:kt(L)})}),(0,B.jsx)(`button`,{onClick:()=>{let e=kt(L);navigator.clipboard.writeText(e)},className:`absolute top-4 right-4 p-2 bg-gray-800 hover:bg-gray-700 rounded-md transition-colors`,title:r.common.copyResponse,children:(0,B.jsx)(j,{className:`w-4 h-4 text-gray-300`})})]})]})]})]})},Lt=e=>e.toLowerCase().replace(/`/g,``).replace(/[^\p{L}\p{N}\s-]/gu,``).trim().replace(/\s+/g,`-`),Rt=e=>e.trim().replace(/^\|/,``).replace(/\|$/,``).split(/(?<!\\)\|/).map(e=>e.trim().replace(/\\\|/g,`|`)),U=e=>/^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)*\|?\s*$/.test(e),zt=e=>{let t=e.replace(/\r\n/g,`
`).split(`
`),n=[],r=0;for(;r<t.length;){let e=t[r];if(!e.trim()){r+=1;continue}let i=e.match(/^```(\S*)\s*$/);if(i){let e=[];for(r+=1;r<t.length&&!/^```\s*$/.test(t[r]);)e.push(t[r]),r+=1;r+=1,n.push({kind:`code`,lang:i[1]||``,code:e.join(`
`)});continue}let a=e.match(/^(#{1,4})\s+(.*)$/);if(a){n.push({kind:`heading`,level:a[1].length,text:a[2].trim()}),r+=1;continue}if(/^(-{3,}|\*{3,})\s*$/.test(e)){n.push({kind:`hr`}),r+=1;continue}if(e.trim().startsWith(`|`)&&r+1<t.length&&U(t[r+1])){let i=Rt(e),a=[];for(r+=2;r<t.length&&t[r].trim().startsWith(`|`);)a.push(Rt(t[r])),r+=1;n.push({kind:`table`,header:i,rows:a});continue}if(/^>\s?/.test(e)){let e=[];for(;r<t.length&&/^>\s?/.test(t[r]);)e.push(t[r].replace(/^>\s?/,``)),r+=1;n.push({kind:`quote`,text:e.join(`
`)});continue}let o=e.match(/^(\s*)([-*]|\d+\.)\s+(.*)$/);if(o){let e=/\d+\./.test(o[2]),i=[];for(;r<t.length;){let e=t[r].match(/^(\s*)([-*]|\d+\.)\s+(.*)$/);if(e){let t=e[1].length>=2,n=e[3].replace(/^\[ \]\s+/,`☐ `).replace(/^\[x\]\s+/i,`☑ `);i.push(t?`\u00a0\u00a0\u00a0\u00a0\u2022 ${n}`:n),r+=1}else if(t[r].trim()&&/^\s{2,}\S/.test(t[r])&&i.length)i[i.length-1]+=` ${t[r].trim()}`,r+=1;else break}n.push({kind:`list`,ordered:e,items:i});continue}let s=[];for(;r<t.length&&t[r].trim()&&!/^(#{1,4})\s/.test(t[r])&&!/^```/.test(t[r])&&!/^>\s?/.test(t[r])&&!/^(\s*)([-*]|\d+\.)\s+/.test(t[r])&&!t[r].trim().startsWith(`|`);)s.push(t[r].trim()),r+=1;n.push({kind:`paragraph`,text:s.join(` `)})}return n},Bt=({text:e,onNavigate:t})=>{let n=[],r=/(`[^`]+`)|(\*\*[^*]+\*\*)|(\[[^\]]+\]\([^)\s]+\))|(\*[^*\s][^*]*\*)/g,i=0,a,o=0;for(;(a=r.exec(e))!==null;){a.index>i&&n.push(e.slice(i,a.index));let r=a[0];if(r.startsWith("`"))n.push((0,B.jsx)(`code`,{className:`px-1.5 py-0.5 rounded bg-paynet-gray-100 text-paynet-gray-800 font-mono text-[0.85em] break-words`,children:r.slice(1,-1)},o++));else if(r.startsWith(`**`))n.push((0,B.jsx)(`strong`,{className:`font-semibold text-paynet-gray-900`,children:(0,B.jsx)(Bt,{text:r.slice(2,-2),onNavigate:t})},o++));else if(r.startsWith(`[`)){let e=r.match(/^\[([^\]]+)\]\(([^)\s]+)\)$/),i=e?e[1]:r,a=e?e[2]:`#`,s=a.startsWith(`#`);n.push((0,B.jsx)(`a`,{href:a,onClick:e=>{s&&t&&(e.preventDefault(),t(a))},target:s?void 0:`_blank`,rel:s?void 0:`noopener noreferrer`,className:`text-paynet-primary hover:text-paynet-secondary underline underline-offset-2`,children:(0,B.jsx)(Bt,{text:i,onNavigate:t})},o++))}else n.push((0,B.jsx)(`em`,{children:(0,B.jsx)(Bt,{text:r.slice(1,-1),onNavigate:t})},o++));i=a.index+r.length}return i<e.length&&n.push(e.slice(i)),(0,B.jsx)(B.Fragment,{children:n})},Vt=({code:e,lang:t})=>{let[n,r]=_.useState(!1);return(0,B.jsxs)(`div`,{className:`relative group mb-5`,children:[(0,B.jsxs)(`div`,{className:`flex items-center justify-between bg-paynet-gray-800 text-paynet-gray-300 text-xs px-4 py-1.5 rounded-t-paynet font-mono`,children:[(0,B.jsx)(`span`,{children:t||`text`}),(0,B.jsxs)(`button`,{type:`button`,onClick:async()=>{try{await navigator.clipboard.writeText(e),r(!0),setTimeout(()=>r(!1),2e3)}catch{r(!1)}},className:`flex items-center gap-1 hover:text-white transition-colors`,children:[n?(0,B.jsx)(D,{className:`w-3.5 h-3.5`}):(0,B.jsx)(j,{className:`w-3.5 h-3.5`}),n?`Copied`:`Copy`]})]}),(0,B.jsx)(`pre`,{className:`bg-paynet-gray-900 text-paynet-gray-100 p-4 rounded-b-paynet overflow-x-auto text-[13px] leading-relaxed font-mono`,children:(0,B.jsx)(`code`,{children:e})})]})},Ht=e=>{let t=e.toLowerCase();return/^\*\*(draft|черновик|ciornă)/.test(t)?`bg-paynet-orange-light border-paynet-orange text-paynet-gray-800`:/^\*\*(important|warning|важно|внимание|important)/.test(t)?`bg-red-50 border-paynet-error text-paynet-gray-800`:`bg-paynet-light border-paynet-primary text-paynet-gray-700`},Ut=({source:e,onNavigate:t})=>{let n=_.useMemo(()=>zt(e),[e]);return(0,B.jsx)(`div`,{className:`guide-content text-paynet-gray-700 leading-relaxed`,children:n.map((e,n)=>{switch(e.kind){case`heading`:{let r=Lt(e.text);return e.level===1?(0,B.jsx)(`h1`,{id:r,className:`text-2xl sm:text-3xl font-bold text-paynet-primary mb-4`,children:(0,B.jsx)(Bt,{text:e.text,onNavigate:t})},n):e.level===2?(0,B.jsx)(`h2`,{id:r,className:`text-xl sm:text-2xl font-semibold text-paynet-primary mt-10 mb-4 pb-2 border-b border-paynet-gray-200`,children:(0,B.jsx)(Bt,{text:e.text,onNavigate:t})},n):e.level===3?(0,B.jsx)(`h3`,{id:r,className:`text-lg font-semibold text-paynet-gray-800 mt-7 mb-3`,children:(0,B.jsx)(Bt,{text:e.text,onNavigate:t})},n):(0,B.jsx)(`h4`,{id:r,className:`text-base font-semibold text-paynet-gray-800 mt-5 mb-2`,children:(0,B.jsx)(Bt,{text:e.text,onNavigate:t})},n)}case`paragraph`:return(0,B.jsx)(`p`,{className:`mb-4`,children:(0,B.jsx)(Bt,{text:e.text,onNavigate:t})},n);case`list`:{let r=e.ordered?`ol`:`ul`;return(0,B.jsx)(r,{className:`${e.ordered?`list-decimal`:`list-disc`} pl-6 mb-4 space-y-1.5`,children:e.items.map((e,n)=>(0,B.jsx)(`li`,{className:e.startsWith(`\xA0`)||/^[\u2610\u2611] /.test(e)?`list-none -ml-4`:``,children:(0,B.jsx)(Bt,{text:e,onNavigate:t})},n))},n)}case`code`:return(0,B.jsx)(Vt,{code:e.code,lang:e.lang},n);case`table`:return(0,B.jsxs)(_.Fragment,{children:[(0,B.jsx)(`div`,{className:`sm:hidden mb-5 space-y-2`,children:e.rows.map((n,r)=>(0,B.jsxs)(`div`,{className:`border border-paynet-gray-200 rounded-paynet bg-white px-3 py-2.5 text-sm`,children:[(0,B.jsx)(`div`,{className:`font-semibold text-paynet-gray-900 mb-1 break-words`,children:(0,B.jsx)(Bt,{text:n[0]||``,onNavigate:t})}),n.slice(1).map((n,r)=>n.trim()&&n.trim()!==`—`?(0,B.jsxs)(`div`,{className:`mt-1 break-words`,children:[e.header[r+1]&&(0,B.jsx)(`span`,{className:`text-paynet-gray-500 text-xs uppercase tracking-wide block`,children:(0,B.jsx)(Bt,{text:e.header[r+1],onNavigate:t})}),(0,B.jsx)(`span`,{className:`text-paynet-gray-800`,children:(0,B.jsx)(Bt,{text:n,onNavigate:t})})]},r):null)]},r))}),(0,B.jsx)(`div`,{className:`hidden sm:block overflow-x-auto mb-5 border border-paynet-gray-200 rounded-paynet`,children:(0,B.jsxs)(`table`,{className:`min-w-full text-sm`,children:[(0,B.jsx)(`thead`,{className:`bg-paynet-light`,children:(0,B.jsx)(`tr`,{children:e.header.map((e,n)=>(0,B.jsx)(`th`,{className:`text-left font-semibold text-paynet-gray-800 px-3 py-2 border-b border-paynet-gray-200 whitespace-nowrap`,children:(0,B.jsx)(Bt,{text:e,onNavigate:t})},n))})}),(0,B.jsx)(`tbody`,{children:e.rows.map((e,n)=>(0,B.jsx)(`tr`,{className:`odd:bg-white even:bg-paynet-gray-50 align-top`,children:e.map((e,n)=>(0,B.jsx)(`td`,{className:`px-3 py-2 border-b border-paynet-gray-100`,children:(0,B.jsx)(Bt,{text:e,onNavigate:t})},n))},n))})]})})]},n);case`quote`:return(0,B.jsx)(`div`,{className:`border-l-4 rounded-r-paynet px-4 py-3 mb-5 ${Ht(e.text)}`,children:e.text.split(/\n{2,}/).map((e,n)=>(0,B.jsx)(`p`,{className:`mb-1 last:mb-0`,children:(0,B.jsx)(Bt,{text:e.replace(/\n/g,` `),onNavigate:t})},n))},n);case`hr`:return(0,B.jsx)(`hr`,{className:`my-8 border-paynet-gray-200`},n);default:return null}})})},Wt=({guide:e,language:t,onNavigate:n})=>{let r=Ie[t],i=Me(t).filter(t=>t.section===e.section),a=i.findIndex(t=>t.slug===e.slug),o=a>0?i[a-1]:null,s=a>=0&&a<i.length-1?i[a+1]:null;return(0,B.jsxs)(`article`,{className:`max-w-4xl`,children:[(0,B.jsx)(`div`,{className:`flex flex-wrap items-center justify-end gap-2 mb-4`,children:(0,B.jsx)(Qe,{language:t,title:e.title,markdownPath:t===`en`?`docs/${e.slug}.md`:`docs/${t}/${e.slug}.md`,markdownLanguage:t.toUpperCase(),markdown:e.source,onNavigate:n})}),(0,B.jsx)(Ut,{source:e.source,onNavigate:n}),(0,B.jsxs)(`nav`,{className:`flex justify-between gap-4 mt-12 pt-6 border-t border-paynet-gray-200`,children:[o?(0,B.jsxs)(`button`,{type:`button`,onClick:()=>n(`#/guides/${o.slug}`),className:`text-left group flex items-center gap-2 text-paynet-gray-600 hover:text-paynet-primary`,children:[(0,B.jsx)(x,{className:`w-4 h-4`}),(0,B.jsxs)(`span`,{children:[(0,B.jsx)(`span`,{className:`block text-xs text-paynet-gray-400`,children:r.previous}),(0,B.jsx)(`span`,{className:`font-medium`,children:o.title})]})]}):(0,B.jsx)(`span`,{}),s?(0,B.jsxs)(`button`,{type:`button`,onClick:()=>n(`#/guides/${s.slug}`),className:`text-right group flex items-center gap-2 text-paynet-gray-600 hover:text-paynet-primary`,children:[(0,B.jsxs)(`span`,{children:[(0,B.jsx)(`span`,{className:`block text-xs text-paynet-gray-400`,children:r.next}),(0,B.jsx)(`span`,{className:`font-medium`,children:s.title})]}),(0,B.jsx)(S,{className:`w-4 h-4`})]}):(0,B.jsx)(`span`,{})]})]})},Gt=({language:e,onNavigate:t})=>{let n=Ie[e],r=Ne(e,`common`),i=(e,n)=>(0,B.jsxs)(`button`,{type:`button`,onClick:()=>t(n),className:`inline-flex items-center gap-1 text-sm font-medium text-paynet-primary hover:text-paynet-secondary`,children:[e,(0,B.jsx)(S,{className:`w-3.5 h-3.5`})]},n);return(0,B.jsxs)(`div`,{className:`max-w-5xl`,children:[(0,B.jsxs)(`section`,{className:`mb-10`,children:[(0,B.jsx)(`h1`,{className:`text-3xl sm:text-4xl font-bold text-paynet-primary mb-3`,children:n.homeTitle}),(0,B.jsx)(`p`,{className:`text-base sm:text-lg text-paynet-gray-600 max-w-3xl mb-6`,children:n.homeSubtitle}),(0,B.jsxs)(`div`,{className:`flex flex-wrap gap-3`,children:[(0,B.jsxs)(`button`,{type:`button`,onClick:()=>t(`#/guides/getting-started`),className:`inline-flex items-center gap-2 px-4 py-2.5 rounded-paynet bg-paynet-primary text-white font-medium hover:bg-paynet-secondary transition-colors`,children:[(0,B.jsx)(fe,{className:`w-4 h-4`}),n.quickStart]}),(0,B.jsxs)(`button`,{type:`button`,onClick:()=>t(`#/guides/server-to-server`),className:`inline-flex items-center gap-2 px-4 py-2.5 rounded-paynet border border-paynet-primary text-paynet-primary bg-white font-medium hover:bg-paynet-light transition-colors`,children:[(0,B.jsx)(w,{className:`w-4 h-4`}),n.apiReference]}),(0,B.jsxs)(`a`,{href:`llms-full.txt`,target:`_blank`,rel:`noopener noreferrer`,className:`inline-flex items-center gap-2 px-4 py-2.5 rounded-paynet border border-paynet-gray-300 text-paynet-gray-700 bg-white font-medium hover:bg-paynet-gray-50 transition-colors`,title:n.forAiHint,children:[(0,B.jsx)(T,{className:`w-4 h-4`}),n.forAi]})]})]}),(0,B.jsxs)(`section`,{className:`mb-10`,children:[(0,B.jsx)(`h2`,{className:`text-xl font-semibold text-paynet-gray-900 mb-4`,children:n.homeProducts}),(0,B.jsx)(`div`,{className:`grid gap-5 sm:grid-cols-2 lg:grid-cols-3`,children:(0,B.jsxs)(`div`,{className:`bg-white rounded-paynet border border-paynet-gray-200 shadow-paynet p-6 flex flex-col border-b-4 border-b-paynet-primary`,children:[(0,B.jsxs)(`div`,{className:`flex items-center gap-2 mb-3`,children:[(0,B.jsx)(ge,{className:`w-5 h-5 text-paynet-primary`}),(0,B.jsx)(`h3`,{className:`text-lg font-semibold text-paynet-gray-900`,children:`E-commerce`})]}),(0,B.jsx)(`p`,{className:`text-sm text-paynet-gray-600 mb-4 flex-1`,children:n.ecomCardText}),(0,B.jsx)(`div`,{className:`flex flex-col items-start gap-1.5`,children:n.ecomLinks.map(e=>i(e.label,e.hash))})]})})]}),(0,B.jsxs)(`section`,{className:`mb-10`,children:[(0,B.jsx)(`h2`,{className:`text-xl font-semibold text-paynet-gray-900 mb-4`,children:n.homeGeneral}),(0,B.jsx)(`div`,{className:`grid gap-4 sm:grid-cols-2 lg:grid-cols-4`,children:r.map(e=>(0,B.jsxs)(`button`,{type:`button`,onClick:()=>t(`#/guides/${e.slug}`),className:`text-left bg-white rounded-paynet border border-paynet-gray-200 p-4 hover:border-paynet-primary hover:shadow-paynet transition-all`,children:[(0,B.jsx)(`div`,{className:`font-medium text-paynet-gray-900 mb-1`,children:e.title}),(0,B.jsx)(`div`,{className:`text-xs text-paynet-primary inline-flex items-center gap-1`,children:(0,B.jsx)(S,{className:`w-3 h-3`})})]},e.slug))})]}),(0,B.jsxs)(`section`,{className:`mb-6`,children:[(0,B.jsx)(`h2`,{className:`text-xl font-semibold text-paynet-gray-900 mb-4`,children:n.homeEnvironments}),(0,B.jsx)(`div`,{className:`overflow-x-auto border border-paynet-gray-200 rounded-paynet`,children:(0,B.jsxs)(`table`,{className:`min-w-full text-sm`,children:[(0,B.jsx)(`thead`,{className:`bg-paynet-light`,children:(0,B.jsxs)(`tr`,{children:[(0,B.jsx)(`th`,{className:`text-left font-semibold text-paynet-gray-800 px-3 py-2`}),(0,B.jsx)(`th`,{className:`text-left font-semibold text-paynet-gray-800 px-3 py-2`,children:n.testEnv}),(0,B.jsx)(`th`,{className:`text-left font-semibold text-paynet-gray-800 px-3 py-2`,children:n.prodEnv})]})}),(0,B.jsxs)(`tbody`,{children:[(0,B.jsxs)(`tr`,{className:`bg-white`,children:[(0,B.jsx)(`td`,{className:`px-3 py-2 font-medium text-paynet-gray-800`,children:n.envApi}),(0,B.jsx)(`td`,{className:`px-3 py-2 font-mono text-xs`,children:`https://ecom-api-test.paynet.md`}),(0,B.jsx)(`td`,{className:`px-3 py-2 font-mono text-xs`,children:`https://ecom-api.paynet.md`})]}),(0,B.jsxs)(`tr`,{className:`bg-paynet-gray-50`,children:[(0,B.jsx)(`td`,{className:`px-3 py-2 font-medium text-paynet-gray-800`,children:n.envCheckout}),(0,B.jsx)(`td`,{className:`px-3 py-2 font-mono text-xs`,children:`https://test.paynet.md/ecom/checkout`}),(0,B.jsx)(`td`,{className:`px-3 py-2 font-mono text-xs`,children:`https://paynet.md/ecom/checkout`})]})]})]})})]})]})},Kt={en:{common:{search:`Search`,endpoints:`Endpoints`,projectInfo:`Info`,codeExamples:`Code Examples`,name:`Name`,type:`Type`,in:`In`,required:`Required`,optional:`Optional`,description:`Description`,copyToClipboard:`Copy to clipboard`,copied:`Copied!`,authentication:`Authentication`,quickLinks:`Quick Links`,contactSupport:`Contact Support`,termsOfService:`Terms of Service`,secure:`Secure`,fast:`Fast`,global:`Global`,secureDesc:`Industry-standard security with dual authentication and PCI DSS compliance`,fastDesc:`Real-time transaction processing with comprehensive monitoring`,globalDesc:`Multi-currency support with international payment processing`,requestTypeAndUrl:`Request Type and URL`,methodDescription:`Method Description`,responses:`Responses`,customizeRequest:`Customize Request`,showInput:`Show Input`,hideInput:`Hide Input`,parameters:`Parameters`,requestBody:`Request Body`,enterJsonRequestBody:`Enter JSON request body`,formatJson:`Format JSON`,updateCodeExamples:`Update Code Examples`,codeSyncHint:`Code tabs (cURL, JavaScript, PHP…) are built from this request automatically.`,editTab:`Edit`,testApiRequest:`Test API Request`,testing:`Testing...`,generating:`Generating...`,apiResponse:`API Response`,hide:`Hide`,copyResponse:`Copy Response`,generatingCodeExamples:`Generating code examples...`,noCodeExamplesAvailable:`No code examples available`,pathParameter:`Path parameter`,bodyParameter:`Body parameter`,enterParameter:`Enter {parameter}`,contentType:`Content-Type`,corsWarning:`Testing external APIs from browser is limited by CORS policy. Use the generated code examples in your backend or API testing tools.`,corsError:`Cannot test external APIs directly from browser due to CORS policy`},welcome:{title:`Welcome to TPS API Documentation`,subtitle:`Comprehensive documentation for Transfer Payment System (PSP) API including balance management, transactions, and transfer operations. Select an endpoint from the sidebar to get started.`,authTitle:`Authentication`,authDescription:`All API requests require dual authentication using both TPS API Key and X-API-KEY. Include both keys in the request headers:`,authNote:`You can obtain your API credentials from the PayNet developer portal after creating an account.`},placeholders:{searchEndpoints:`Search endpoints...`,selectEndpoint:`Select an endpoint to view code examples`,switchToEndpoints:`Switch to Endpoints view to see code examples`,noEndpointSelected:`Select an endpoint from the sidebar to get started.`,downloadPostmanCollection:`Download Postman Collection`},ecommerce:{pageTitle:`Ecommerce`,mainTitle:`Payment Processing by Paynet`,introParagraph1:`Paynet provides a modern online payment solution that enables businesses to accept payments securely, quickly, and conveniently through a wide range of payment methods.`,introParagraph2:`With a single integration, you gain access to both local and international payment options, ensuring high conversion rates and a seamless user experience.`,paymentMethodsTitle:`Available Payment Methods`,paymentMethodsIntro:`Paynet allows you to accept payments via:`,paymentVisaTitle:`💳 Visa & MasterCard bank cards`,paymentVisaDesc:`Support for both local and international cards with advanced security and 3D Secure authentication`,paymentPaynetWalletTitle:`💼 Paynet cards and wallets`,paymentPaynetWalletDesc:`Payments within the Paynet ecosystem with instant transaction confirmation`,paymentMiaTitle:`⚡ MIA Instant Payments`,paymentMiaDesc:`Real-time account-to-account payments available 24/7`,paymentAppleGoogleTitle:`📱 Apple Pay & Google Pay`,paymentAppleGoogleDesc:`Fast and convenient one-click payments from mobile devices without entering card details`,paymentCashTitle:`💵 Cash via Paynet terminal network`,paymentCashDesc:`Ability to pay in cash through a wide network of self-service terminals across the country`,keyBenefitsTitle:`Key Benefits`,benefitSingleIntegration:`Single integration — one API for all payment methods`,benefitConversion:`High conversion rates — support for popular payment options`,benefitSecurity:`Security — PCI DSS compliance and advanced protection mechanisms`,benefitInstant:`Instant processing — fast transaction execution and confirmation`,benefitFlexibility:`Flexibility — supports various business models and use cases`},serverServer:{pageTitle:`Server-Server model`,mainTitle:`Server-to-server integration with Paynet`,introParagraph1:`In the Server-Server model your backend systems communicate directly with Paynet over HTTPS. Requests and responses are exchanged machine-to-machine—without relying on a customer browser for core API flows.`,introParagraph2:`This model fits automated order lifecycle, refunds, payment status checks, statements, and reporting. It gives you full control on the server side, predictable behaviour under load, and straightforward integration with your existing services.`,characteristicsTitle:`Integration characteristics`,characteristicsIntro:`Typical traits of a server-server integration:`,aspect1Title:`🔐 HTTPS and transport security`,aspect1Desc:`All calls use TLS. Keep credentials out of logs, rotate keys when needed, and restrict outbound access from your application tier.`,aspect2Title:`🔑 Token-based authentication`,aspect2Desc:`Protected endpoints use Bearer tokens obtained through the authentication flow. Tokens are sent in headers—never in URLs or client-side storage on a public site.`,aspect3Title:`📦 JSON payloads`,aspect3Desc:`Requests and responses are JSON unless an endpoint explicitly returns another content type (for example file download).`,aspect4Title:`⚙️ Automation-friendly`,aspect4Desc:`Designed for retries, batch jobs, reconciliation, and monitoring from your back office or integration layer.`,aspect5Title:`📊 Operational visibility`,aspect5Desc:`Combine API responses with your own logging and alerting to track payment lifecycle and investigate issues quickly.`,keyBenefitsTitle:`Key benefits`,benefit1:`Direct server control — no dependency on end-user browsers for API calls`,benefit2:`Stable integration surface — suitable for production workloads and automation`,benefit3:`Clear security model — headers, TLS, and token usage aligned with API best practices`,benefit4:`Covers full lifecycle — create orders, query status, refunds, and reporting where applicable`,benefit5:`Same documentation as endpoints — use the methods listed under this section in the sidebar`},clientServer:{pageTitle:`Client-Server model`,mainTitle:`Client-to-server integration with Paynet`,introParagraph1:`In the Client-Server model, payment data is prepared on your side and sent to Paynet through the client flow. The customer is redirected to Paynet payment pages to complete authentication and payment.`,introParagraph2:`This model is useful when checkout starts in the browser or mobile app. To protect request integrity, payment payloads are signed before redirect and validated by both systems.`,characteristicsTitle:`Integration characteristics`,characteristicsIntro:`Typical traits of a client-server integration:`,aspect1Title:`🔐 Signed payload instead of token auth`,aspect1Desc:`Core protection is based on request signing using a shared secret key. Keep the key private and generate signatures on trusted backend only.`,aspect2Title:`🧾 Structured payment payload`,aspect2Desc:`You send order, customer, services, products, currency, expiry date, and merchant metadata in a strictly defined structure.`,aspect3Title:`↪️ Redirect-based customer journey`,aspect3Desc:`After payload submission, the customer is redirected to Paynet pages to select method, confirm, and complete payment.`,aspect4Title:`🔁 Return URLs and status tracking`,aspect4Desc:`Integration includes success/cancel URLs and follow-up status checks so your system can finalize order state reliably.`,aspect5Title:`📣 Notification verification`,aspect5Desc:`Payment notifications are also signed. Your backend should verify signatures and handle duplicate callbacks idempotently.`,keyBenefitsTitle:`Key benefits`,benefit1:`Fast checkout adoption — works naturally with web and mobile payment journeys`,benefit2:`Strong integrity controls — signatures protect sensitive payment fields`,benefit3:`Flexible customer experience — keep your storefront flow and redirect only for payment step`,benefit4:`Clear settlement flow — combine redirect result with API status and notifications`,benefit5:`Operational safety — deterministic signing rules and callback validation`}},ro:{common:{search:`Căutare`,endpoints:`Metode`,projectInfo:`Info`,codeExamples:`Exemple de cod`,name:`Nume`,type:`Tip`,in:`În`,required:`Obligatoriu`,optional:`Opțional`,description:`Descriere`,copyToClipboard:`Copiază în clipboard`,copied:`Copiat!`,authentication:`Autentificare`,quickLinks:`Link-uri rapide`,contactSupport:`Contactează suportul`,termsOfService:`Termeni și condiții`,secure:`Securizat`,fast:`Rapid`,global:`Global`,secureDesc:`Securitate standard în industrie cu autentificare duală și conformitate PCI DSS`,fastDesc:`Procesare de tranzacții în timp real cu monitorizare cuprinzătoare`,globalDesc:`Suport multi-valută cu procesare de plăți internaționale`,requestTypeAndUrl:`Tipul Cererii și URL`,methodDescription:`Descrierea Metodei`,responses:`Răspunsuri`,customizeRequest:`Personalizează Cererea`,showInput:`Arată Input`,hideInput:`Ascunde Input`,parameters:`Parametri`,requestBody:`Corpul Cererii`,enterJsonRequestBody:`Introduceți corpul cererii JSON`,formatJson:`Formatează JSON`,updateCodeExamples:`Actualizează Exemplele de Cod`,codeSyncHint:`Filele cu cod (cURL, JavaScript, PHP…) se generează automat din această cerere.`,editTab:`Editează`,testApiRequest:`Testează Cererea API`,testing:`Se testează...`,generating:`Se generează...`,apiResponse:`Răspunsul API`,hide:`Ascunde`,copyResponse:`Copiază Răspunsul`,generatingCodeExamples:`Se generează exemple de cod...`,noCodeExamplesAvailable:`Nu sunt disponibile exemple de cod`,pathParameter:`Parametru de cale`,bodyParameter:`Parametru de corp`,enterParameter:`Introduceți {parameter}`,contentType:`Tip-Conținut`,corsWarning:`Testarea API-urilor externe din browser este limitată de politica CORS. Utilizați exemplele de cod generate în backend-ul dvs. sau în instrumentele de testare API.`,corsError:`Nu se pot testa API-urile externe direct din browser din cauza politicii CORS`},welcome:{title:`Bun venit la documentația API TPS`,subtitle:`Documentație cuprinzătoare pentru API-ul Transfer Payment System (PSP) incluzând gestionarea soldului, tranzacțiile și operațiunile de transfer. Selectați un punct final din bara laterală pentru a începe.`,authTitle:`Autentificare`,authDescription:`Toate cererile API necesită autentificare duală folosind atât TPS API Key cât și X-API-KEY. Includeți ambele chei în anteturile cererii:`,authNote:`Puteți obține acreditările API din portalul pentru dezvoltatori PayNet după crearea unui cont.`},placeholders:{searchEndpoints:`Căutați puncte finale...`,selectEndpoint:`Selectați un punct final pentru a vedea exemple de cod`,switchToEndpoints:`Comutați la vizualizarea Puncte finale pentru a vedea exemple de cod`,noEndpointSelected:`Selectați un punct final din bara laterală pentru a începe.`,downloadPostmanCollection:`Descărcați Colecția Postman`},ecommerce:{pageTitle:`Ecommerce`,mainTitle:`Procesare plăți prin Paynet`,introParagraph1:`Paynet oferă o soluție modernă de plată online care permite comercianților să accepte plăți în mod sigur, rapid și convenabil printr-o gamă largă de metode de plată.`,introParagraph2:`Cu o singură integrare, obțineți acces la opțiuni de plată locale și internaționale, asigurând rate ridicate de conversie și o experiență utilizator fluidă.`,paymentMethodsTitle:`Metode de plată disponibile`,paymentMethodsIntro:`Paynet vă permite să acceptați plăți prin:`,paymentVisaTitle:`💳 Carduri bancare Visa și MasterCard`,paymentVisaDesc:`Suport pentru carduri locale și internaționale cu securitate avansată și autentificare 3D Secure`,paymentPaynetWalletTitle:`💼 Carduri și portofele Paynet`,paymentPaynetWalletDesc:`Plăți în ecosistemul Paynet cu confirmare instantanee a tranzacției`,paymentMiaTitle:`⚡ Plăți instant MIA`,paymentMiaDesc:`Plăți în timp real între conturi, disponibile 24/7`,paymentAppleGoogleTitle:`📱 Apple Pay și Google Pay`,paymentAppleGoogleDesc:`Plăți rapide și convenabile cu un singur clic de pe dispozitive mobile, fără să introduceți datele cardului`,paymentCashTitle:`💵 Numerar prin rețeaua de terminale Paynet`,paymentCashDesc:`Posibilitatea de a plăti numerar printr-o rețea largă de terminale self-service în țară`,keyBenefitsTitle:`Beneficii principale`,benefitSingleIntegration:`Integrare unică — un singur API pentru toate metodele de plată`,benefitConversion:`Rate ridicate de conversie — suport pentru opțiuni de plată populare`,benefitSecurity:`Securitate — conformitate PCI DSS și mecanisme avansate de protecție`,benefitInstant:`Procesare instantanee — execuție și confirmare rapidă a tranzacțiilor`,benefitFlexibility:`Flexibilitate — suportă diverse modele de business și scenarii de utilizare`},serverServer:{pageTitle:`Model Server-Server`,mainTitle:`Integrare server-la-server cu Paynet`,introParagraph1:`În modelul Server-Server sistemele dvs. de backend comunică direct cu Paynet prin HTTPS. Cererile și răspunsurile sunt schimbate între servere—fără a depinde de browserul clientului pentru fluxurile principale de API.`,introParagraph2:`Acest model este potrivit pentru automatizarea ciclului de viață al comenzilor, rambursări, verificarea stării plății, extrase și rapoarte. Oferă control complet pe server, comportament predictibil sub sarcină și integrare simplă cu serviciile existente.`,characteristicsTitle:`Caracteristici de integrare`,characteristicsIntro:`Trăsături tipice ale unei integrări server-server:`,aspect1Title:`🔐 HTTPS și securitatea transportului`,aspect1Desc:`Toate apelurile folosesc TLS. Păstrați credențialele în afara jurnalelor, rotiți cheile când e nevoie și restricționați accesul ieșitor din nivelul de aplicație.`,aspect2Title:`🔑 Autentificare bazată pe token`,aspect2Desc:`Endpoint-urile protejate folosesc token-uri Bearer obținute prin fluxul de autentificare. Token-urile se trimit în anteturi—niciodată în URL-uri sau pe partea clientului publică.`,aspect3Title:`📦 Payload-uri JSON`,aspect3Desc:`Cererile și răspunsurile sunt JSON, cu excepția cazurilor în care un endpoint returnează explicit alt tip de conținut (de exemplu descărcare fișier).`,aspect4Title:`⚙️ Potrivit pentru automatizare`,aspect4Desc:`Conceput pentru reîncercări, job-uri batch, reconciliere și monitorizare din back-office sau stratul de integrare.`,aspect5Title:`📊 Vizibilitate operațională`,aspect5Desc:`Combinați răspunsurile API cu propriile loguri și alerte pentru a urmări ciclul de viață al plăților și a investiga rapid problemele.`,keyBenefitsTitle:`Beneficii principale`,benefit1:`Control direct pe server — fără dependență de browserele utilizatorilor pentru apeluri API`,benefit2:`Suprafață de integrare stabilă — potrivită pentru producție și automatizare`,benefit3:`Model de securitate clar — anteturi, TLS și utilizarea token-urilor aliniată cu bunele practici API`,benefit4:`Acoperă ciclul complet — creare comenzi, interogare status, rambursări și raportare unde se aplică`,benefit5:`Aceeași documentație ca endpoint-urile — folosiți metodele listate sub această secțiune în bara laterală`},clientServer:{pageTitle:`Model Client-Server`,mainTitle:`Integrare client-server cu Paynet`,introParagraph1:`În modelul Client-Server, datele de plată sunt pregătite de sistemul dvs. și transmise către Paynet prin fluxul clientului. Clientul este redirecționat către paginile Paynet pentru autentificare și finalizarea plății.`,introParagraph2:`Modelul este potrivit pentru checkout web și mobil, unde fluxul începe în browser sau aplicație. Pentru protejarea integrității datelor, payload-ul de plată este semnat înainte de redirect și verificat de ambele sisteme.`,characteristicsTitle:`Caracteristici de integrare`,characteristicsIntro:`Trăsături tipice ale unei integrări client-server:`,aspect1Title:`🔐 Semnătură în loc de autentificare pe token`,aspect1Desc:`Protecția principală se bazează pe semnarea cererii cu o cheie secretă comună. Cheia trebuie păstrată doar pe backend-ul de încredere.`,aspect2Title:`🧾 Payload de plată structurat`,aspect2Desc:`Se transmit comanda, datele clientului, serviciile, produsele, moneda, data expirării și metadatele merchantului într-o structură strict definită.`,aspect3Title:`↪️ Flux redirect pentru client`,aspect3Desc:`După trimiterea datelor, clientul este redirecționat pe paginile Paynet pentru alegerea metodei de plată, confirmare și finalizare.`,aspect4Title:`🔁 Return URL și urmărirea statusului`,aspect4Desc:`Integrarea include URL-uri de succes/anulare și verificări ulterioare de status pentru finalizarea corectă a comenzii.`,aspect5Title:`📣 Validarea notificărilor`,aspect5Desc:`Notificările de plată sunt, de asemenea, semnate. Backend-ul trebuie să valideze semnătura și să proceseze idempotent callback-urile duplicate.`,keyBenefitsTitle:`Beneficii principale`,benefit1:`Adoptare rapidă în checkout — potrivit natural pentru fluxuri web și mobile`,benefit2:`Control puternic al integrității — semnăturile protejează câmpurile sensibile de plată`,benefit3:`Experiență flexibilă pentru client — păstrați fluxul magazinului și redirecționați doar la pasul de plată`,benefit4:`Flux de decontare clar — combinați rezultatul redirectului cu status API și notificări`,benefit5:`Siguranță operațională — reguli deterministe de semnare și validare callback`}},ru:{common:{search:`Поиск`,endpoints:`Методы`,projectInfo:`O проекте`,codeExamples:`Примеры кода`,name:`Имя`,type:`Тип`,in:`В`,required:`Обязательно`,optional:`Необязательно`,description:`Описание`,copyToClipboard:`Скопировать в буфер`,copied:`Скопировано!`,authentication:`Аутентификация`,quickLinks:`Быстрые ссылки`,contactSupport:`Связаться с поддержкой`,termsOfService:`Условия использования`,secure:`Безопасный`,fast:`Быстрый`,global:`Глобальный`,secureDesc:`Отраслевая безопасность с двойной аутентификацией и соответствием PCI DSS`,fastDesc:`Обработка транзакций в реальном времени с комплексным мониторингом`,globalDesc:`Поддержка нескольких валют с международной обработкой платежей`,requestTypeAndUrl:`Тип запроса и URL`,methodDescription:`Описание метода`,responses:`Ответы`,customizeRequest:`Настроить Запрос`,showInput:`Показать Ввод`,hideInput:`Скрыть Ввод`,parameters:`Параметры`,requestBody:`Тело Запроса`,enterJsonRequestBody:`Введите JSON тело запроса`,formatJson:`Форматировать JSON`,updateCodeExamples:`Обновить Примеры Кода`,codeSyncHint:`Вкладки с кодом (cURL, JavaScript, PHP…) собираются из этого запроса автоматически.`,editTab:`Изменить`,testApiRequest:`Тестировать API Запрос`,testing:`Тестирование...`,generating:`Генерация...`,apiResponse:`Ответ API`,hide:`Скрыть`,copyResponse:`Копировать Ответ`,generatingCodeExamples:`Генерация примеров кода...`,noCodeExamplesAvailable:`Примеры кода недоступны`,pathParameter:`Параметр пути`,bodyParameter:`Параметр тела`,enterParameter:`Введите {parameter}`,contentType:`Тип-Содержимого`,corsWarning:`Тестирование внешних API из браузера ограничено CORS политикой. Используйте сгенерированные примеры кода в вашем бэкенде или инструментах тестирования API.`,corsError:`Невозможно тестировать внешние API напрямую из браузера из-за CORS политики`},welcome:{title:`Добро пожаловать в документацию TPS API`,subtitle:`Комплексная документация для API системы переводов платежей (PSP), включая управление балансом, транзакции и операции переводов. Выберите конечную точку из боковой панели, чтобы начать.`,authTitle:`Аутентификация`,authDescription:`Все API-запросы требуют двойной аутентификации с использованием как TPS API Key, так и X-API-KEY. Включите оба ключа в заголовки запроса:`,authNote:`Вы можете получить свои API-учетные данные на портале разработчиков PayNet после создания учетной записи.`},placeholders:{searchEndpoints:`Поиск конечных точек...`,selectEndpoint:`Выберите конечную точку для просмотра примеров кода`,switchToEndpoints:`Переключитесь на просмотр конечных точек, чтобы увидеть примеры кода`,noEndpointSelected:`Выберите конечную точку из боковой панели, чтобы начать.`,downloadPostmanCollection:`Скачать Postman коллекцию`},ecommerce:{pageTitle:`Ecommerce`,mainTitle:`Приём платежей через Paynet`,introParagraph1:`Paynet предлагает современное онлайн-решение для приёма платежей: безопасно, быстро и удобно для бизнеса — с широким набором способов оплаты.`,introParagraph2:`Одна интеграция открывает доступ к локальным и международным способам оплаты, высокой конверсии и удобному пользовательскому опыту.`,paymentMethodsTitle:`Доступные способы оплаты`,paymentMethodsIntro:`Через Paynet вы можете принимать платежи:`,paymentVisaTitle:`💳 Банковские карты Visa и MasterCard`,paymentVisaDesc:`Поддержка локальных и международных карт с усиленной безопасностью и 3D Secure`,paymentPaynetWalletTitle:`💼 Карты и кошельки Paynet`,paymentPaynetWalletDesc:`Платежи в экосистеме Paynet с мгновенным подтверждением операции`,paymentMiaTitle:`⚡ MIA — мгновенные платежи`,paymentMiaDesc:`Переводы между счетами в реальном времени, круглосуточно`,paymentAppleGoogleTitle:`📱 Apple Pay и Google Pay`,paymentAppleGoogleDesc:`Быстрая оплата в один клик с мобильных устройств без ввода реквизитов карты`,paymentCashTitle:`💵 Наличные через сеть терминалов Paynet`,paymentCashDesc:`Оплата наличными через широкую сеть сетевых терминалов самообслуживания по стране`,keyBenefitsTitle:`Ключевые преимущества`,benefitSingleIntegration:`Единая интеграция — один API для всех способов оплаты`,benefitConversion:`Высокая конверсия — поддержка популярных способов оплаты`,benefitSecurity:`Безопасность — соответствие PCI DSS и современные механизмы защиты`,benefitInstant:`Мгновенная обработка — быстрое проведение и подтверждение транзакций`,benefitFlexibility:`Гибкость — разные бизнес-модели и сценарии использования`},serverServer:{pageTitle:`Модель Server-Server`,mainTitle:`Серверная интеграция с Paynet`,introParagraph1:`В модели Server–Server ваши серверные системы обмениваются данными с Paynet напрямую по HTTPS. Запросы и ответы передаются «машина-с-машиной» — без участия браузера клиента в основных операциях API.`,introParagraph2:`Подходит для автоматизации жизненного цикла заказов, возвратов, проверки статуса платежа, выписок и отчётности. Даёт полный контроль на стороне сервера, предсказуемое поведение под нагрузкой и простую связку с вашими сервисами.`,characteristicsTitle:`Особенности интеграции`,characteristicsIntro:`Типичные характеристики серверной интеграции:`,aspect1Title:`🔐 HTTPS и безопасность канала`,aspect1Desc:`Все вызовы идут по TLS. Храните ключи вне логов, при необходимости ротируйте их и ограничивайте исходящий доступ с приложения.`,aspect2Title:`🔑 Аутентификация по токену`,aspect2Desc:`Защищённые методы используют Bearer-токен, полученный в процессе авторизации. Токен передаётся в заголовках — не в URL и не на публичном клиенте.`,aspect3Title:`📦 JSON в запросах и ответах`,aspect3Desc:`Формат JSON, если явно не указан другой тип контента (например, скачивание файла).`,aspect4Title:`⚙️ Удобно для автоматизации`,aspect4Desc:`Подходит для повторов, пакетных задач, сверки и мониторинга из бэк-офиса или интеграционного слоя.`,aspect5Title:`📊 Операционная прозрачность`,aspect5Desc:`Сочетайте ответы API с вашими логами и алертами, чтобы отслеживать жизненный цикл платежей и быстрее разбирать инциденты.`,keyBenefitsTitle:`Ключевые преимущества`,benefit1:`Прямой контроль на сервере — без зависимости от браузера пользователя для вызовов API`,benefit2:`Стабильная среда интеграции — для продакшена и автоматизации`,benefit3:`Понятная модель безопасности — заголовки, TLS и использование токенов по best practices`,benefit4:`Полный цикл — создание заказов, статус, возвраты и отчётность где применимо`,benefit5:`Та же документация, что методы — используйте список в сайдбаре в этой секции`},clientServer:{pageTitle:`Модель Client-Server`,mainTitle:`Клиент-серверная интеграция с Paynet`,introParagraph1:`В модели Client-Server данные платежа формируются на вашей стороне и передаются в Paynet через клиентский сценарий. Клиент перенаправляется на платёжные страницы Paynet для подтверждения и завершения оплаты.`,introParagraph2:`Модель подходит для веб- и мобильного checkout, где сценарий начинается в браузере или приложении. Для защиты целостности данных платежный payload подписывается до редиректа и проверяется обеими системами.`,characteristicsTitle:`Особенности интеграции`,characteristicsIntro:`Типичные характеристики client-server интеграции:`,aspect1Title:`🔐 Подпись вместо токен-авторизации`,aspect1Desc:`Основная защита строится на подписи запроса с использованием общего секретного ключа. Ключ хранится только на доверенной серверной стороне.`,aspect2Title:`🧾 Структурированный платёжный payload`,aspect2Desc:`Передаются заказ, данные клиента, услуги, товары, валюта, срок оплаты и merchant-параметры в строго определённом формате.`,aspect3Title:`↪️ Redirect-сценарий для клиента`,aspect3Desc:`После передачи данных клиент перенаправляется на страницы Paynet для выбора метода оплаты, подтверждения и завершения платежа.`,aspect4Title:`🔁 Return URL и контроль статуса`,aspect4Desc:`Интеграция включает URL успеха/отмены и последующую проверку статуса, чтобы ваша система корректно финализировала заказ.`,aspect5Title:`📣 Валидация уведомлений`,aspect5Desc:`Уведомления о платеже также подписаны. Бэкенд должен проверять подпись и идемпотентно обрабатывать дубликаты callback.`,keyBenefitsTitle:`Ключевые преимущества`,benefit1:`Быстрое внедрение checkout — естественно подходит для web и mobile сценариев оплаты`,benefit2:`Защита целостности данных — подпись покрывает критичные поля платежа`,benefit3:`Гибкий UX — витрина остаётся у вас, редирект только на этапе оплаты`,benefit4:`Прозрачный расчётный поток — совмещайте результат редиректа, статус API и уведомления`,benefit5:`Операционная надёжность — детерминированные правила подписи и проверка callback`}}},qt=e=>Kt[e]||Kt.en,Jt={name:`info`,author:` Paynet Services SRL `,version:`2026.04.01`,language:`en,ro,ru`,items:[{en:{title:`API Documentation Portal`,description:`API for Transfer Payment System`,contact:{name:`API Support`,email:`support@paynet.md`,url:`https://paynet.md/support`},license:{name:`MIT`,url:`https://paynet.md/licenses/MIT`}},ro:{title:`Portal de Documentație API`,description:`API pentru Sistemul de Transfer de Plăți`,contact:{name:`Suport API`,email:`support@paynet.md`,url:`https://paynet.md/support`},license:{name:`MIT`,url:`https://paynet.md/licenses/MIT`}},ru:{title:`Портал Документации API`,description:`API для Системы Переводов Платежей`,contact:{name:`Поддержка API`,email:`support@paynet.md`,url:`https://paynet.md/support`},license:{name:`MIT`,url:`https://paynet.md/licenses/MIT`}}}]},Yt=()=>{let[e,t]=(0,_.useState)(()=>localStorage.getItem(`tps-api-language`)||`en`),n=qt(e);return(0,_.useEffect)(()=>{document.documentElement.lang=e},[e]),{language:e,changeLanguage:e=>{t(e),localStorage.setItem(`tps-api-language`,e)},t:n,apiInfo:{...Jt.items.find(t=>t[e])?.[e]||Jt.items.find(e=>e.en)?.en||{title:`API Documentation Portal`,description:`API Documentation`},author:Jt.author,version:Jt.version}}},Xt={name:`tags`,author:`Paynet V1`,version:`2026.04.01`,language:`en,ro,ru`,items:[{en:[{name:`Users`,description:`User management operations`},{name:`Auth`,description:`Authorization and tokens`}],ro:[{name:`Users`,description:`Utilizatori management operations`},{name:`Auth`,description:`Authorization and tokens`}],ru:[{name:`Users`,description:`Операции с пользователями`},{name:`Auth`,description:`Авторизация и токены`}]}]},Zt=[`POST /auth`,`POST /api/order`,`POST /api/order/refund`,`GET /api/order/{id}`,`GET /api/order/merchant/{id}`,`POST /api/linked-cards/unlink`,`GET /api/order/search`,`GET /api/statement`,`GET /api/statement/download`];function Qt(e){let t=`${e.method} ${e.path}`,n=Zt.indexOf(t);return n===-1?2**53-1:n}function $t(e,t){let n=Xt.items[0],r=n[t];if(r){let t=r.find(t=>t.name===e);if(t)return t.description}return n.en.find(t=>t.name===e)?.description||`${e} related endpoints`}function en(e,t=`en`){let n={};return Object.entries(e.paths).forEach(([e,r])=>{Object.entries(r).forEach(([r,i])=>{let a=i.tags?.[0]||`General`;n[a]||(n[a]={id:a.toLowerCase().replace(/\s+/g,`-`),name:$t(a,t),description:$t(a,t),endpoints:[]});let o={id:`${r}-${e}`.replace(/[{}/]/g,`-`).replace(/-+/g,`-`),method:r.toUpperCase(),path:e,summary:He(e,r.toUpperCase(),t,i.summary).name,description:i.description,parameters:i.parameters?.map(e=>({name:e.name,in:e.in,description:e.description,required:e.required,type:e.schema.type})),responses:i.responses};n[a].endpoints.push(o)})}),Object.values(n).map(e=>({...e,endpoints:[...e.endpoints].sort((e,t)=>{let n=Qt(e)-Qt(t);return n===0?e.path.localeCompare(t.path):n})})).sort((e,t)=>{let n=e.endpoints.length>0?Math.min(...e.endpoints.map(Qt)):2**53-1,r=t.endpoints.length>0?Math.min(...t.endpoints.map(Qt)):2**53-1;return n===r?e.name.localeCompare(t.name):n-r})}var tn=`{
  "openapi": "3.0.1",
  "info": {
    "title": "Paynet E-commerce API",
    "version": "v1",
    "description": "Server-to-server API for Paynet e-commerce payments (Moldova): create orders, redirect the customer to the Paynet payment page, check payment status, refund, unlink saved cards and download statements.\\n\\nAuthentication: call POST /auth, then send \`Authorization: Bearer <access_token>\`.\\nAmounts are integers in minor units (100 = 1.00 MDL). Currency is ISO 4217 numeric (498 = MDL).\\nOne shop order = one \`Order\`: repeating it with the same data returns the same payment; with different data or after payment it fails with 500 TECHNICAL_ERROR.\\n\`ExpiryDate\` is YYYY-MM-DDTHH:mm:ss in Chisinau local time (Europe/Chisinau) and must be in the future.\\n\\nGuides, hosted checkout form and notification (webhook) signatures: see llms-full.txt next to this file."
  },
  "servers": [
    {
      "url": "https://ecom-api-test.paynet.md",
      "description": "Test environment"
    },
    {
      "url": "https://ecom-api.paynet.md",
      "description": "Production environment"
    }
  ],
  "paths": {
    "/api/linked-cards/unlink": {
      "post": {
        "tags": [
          "LinkedCard"
        ],
        "summary": "Delete linked card",
        "requestBody": {
          "description": "The payload containing the details needed to identify and unlink the card.",
          "content": {
            "application/json": {
              "example": {
                "CardLinkHash": "1037153_b3f50103610e4fe9948ff8db553151f3",
                "SaleAreaCode": "onlidocumentation_md",
                "CustomerCode": "customer_code"
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Success executed unlink card.",
            "content": {
              "application/json": {
                "example": {
                  "responseCode": "SUCCESS"
                }
              }
            }
          },
          "400": {
            "description": "Invalid request. Either the usual error body or, when the body cannot be read, an errorInfo object.",
            "content": {
              "application/json": {
                "schema": {
                  "oneOf": [
                    {
                      "$ref": "#/components/schemas/ErrorModel"
                    },
                    {
                      "$ref": "#/components/schemas/ErrorInfoResponse"
                    }
                  ]
                },
                "example": {
                  "errorInfo": {
                    "type": "https://tools.ietf.org/html/rfc9110#section-15.5.1",
                    "title": "One or more validation errors occurred.",
                    "status": 400,
                    "detail": null,
                    "instance": null,
                    "ppResponseCodeEnum": "TECHNICAL_ERROR",
                    "ppResponseCode": 1,
                    "ppResponseCodeText": "TECHNICAL_ERROR",
                    "errors": {
                      "$": [
                        "JSON deserialization for type '…DeleteLinkedCardRequest' was missing required properties including: 'cardLinkHash', 'saleAreaCode', 'customerCode'."
                      ]
                    },
                    "traceId": "00-7c209d88f31e3e5cd2f7bd88ae2f23c2-ad167338e418068c-00"
                  }
                }
              }
            }
          },
          "401": {
            "description": "Bearer token missing, invalid or expired. Keys are capitalised.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModelUnauthorized"
                },
                "example": {
                  "Status": 401,
                  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
                  "Code": "UNAUTHORIZED",
                  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
                }
              }
            }
          },
          "404": {
            "description": "Record not found.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 404,
                  "message": "Record not found",
                  "code": "NOT_FOUND_RECORD",
                  "traceId": "16ce780d-2e89-47b8-9cd2-6d0d136d9816",
                  "details": "No records were found for the provided data"
                }
              }
            }
          },
          "500": {
            "description": "Internal server error occurred while processing the request.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 500,
                  "message": "One or more errors occurred.",
                  "code": "TECHNICAL_ERROR",
                  "traceId": "c546f06c-3674-4b55-8e0f-ce8aac66f49f",
                  "details": "Please verify the transmitted data and try again, or contact support."
                }
              }
            }
          },
          "default": {
            "description": "Error",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                }
              }
            }
          }
        },
        "description": "The delete linked card method is used to deactivate and remove a previously linked card from the Paynet system. When this method is executed, the specified card token is permanently invalidated, and the card is unlinked from the customer account. As a result, the token can no longer be used for any payment operations, including recurring or one-click payments. To perform this request, the Partner must provide the unique card identifier (CardLinkHash), the corresponding SaleAreaCode, and the CustomerCode associated with the card. This method ensures that sensitive payment credentials are securely removed and prevents any further unauthorized or unintended use."
      }
    },
    "/api/order": {
      "post": {
        "tags": [
          "Order"
        ],
        "summary": "Create an order",
        "requestBody": {
          "description": "The payload containing the payment details",
          "content": {
            "application/json": {
              "example": {
                "Order": 1762444800000,
                "SaleAreaCode": "onlidocumentation_md",
                "LinkUrlSuccess": "https://shop.example/payment/success",
                "LinkUrlCancel": "https://shop.example/payment/cancel",
                "Customer": {
                  "Code": "464566161",
                  "NameFirst": "First Name",
                  "NameLast": "Last Name",
                  "email": "customer@example.com",
                  "PhoneNumber": "37360000000"
                },
                "Currency": 498,
                "ExpiryDate": "2026-12-31T23:59:59",
                "Services": [
                  {
                    "Name": "Demo eShop",
                    "Description": "Order #1762444800000",
                    "Amount": 300
                  }
                ],
                "MoneyType": "Card",
                "Lang": "EN"
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Order created. Real response from the test environment for the request example (status 1 = registered, not paid yet).",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/PaymentResponse"
                },
                "example": {
                  "paymentId": 328731,
                  "paymentLink": "https://test.paynet.md/ecom/getecom/328731?s=8fa1bd0923368d3bb700fccacc263735",
                  "cardLinkHash": null,
                  "status": 1,
                  "message": null,
                  "order": 1762444800000,
                  "merchantCode": "265505",
                  "saleAreaCode": "onlidocumentation_md",
                  "linkUrlSuccess": "https://shop.example/payment/success",
                  "linkUrlCancel": "https://shop.example/payment/cancel",
                  "signature": "8fa1bd0923368d3bb700fccacc263735",
                  "amount": {
                    "requestAmount": 300,
                    "requestCurrency": 498,
                    "amount": 300,
                    "paidAmount": null
                  },
                  "customer": {
                    "code": "464566161",
                    "nameFirst": "First Name",
                    "nameLast": "Last Name",
                    "email": "customer@example.com",
                    "country": null,
                    "city": null,
                    "address": null,
                    "phoneNumber": "37360000000",
                    "cardLinkHash": null
                  },
                  "payer": null,
                  "expiryDate": "2026-12-31 23:59:59",
                  "registered": "2026-11-09 18:16:41",
                  "paidDate": null,
                  "services": [
                    {
                      "name": "Demo eShop",
                      "description": "Order #1762444800000",
                      "amount": 300,
                      "products": [
                        {
                          "lineNo": 1,
                          "name": "Demo eShop",
                          "description": "Order #1762444800000",
                          "unitPrice": 300,
                          "unitProduct": null,
                          "quantity": 100,
                          "amount": 300,
                          "totalAmount": 300
                        }
                      ]
                    }
                  ],
                  "moneyType": "Card"
                }
              }
            }
          },
          "400": {
            "description": "Invalid request. Either the usual error body or, when the body cannot be read, an errorInfo object.",
            "content": {
              "application/json": {
                "schema": {
                  "oneOf": [
                    {
                      "$ref": "#/components/schemas/ErrorModel"
                    },
                    {
                      "$ref": "#/components/schemas/ErrorInfoResponse"
                    }
                  ]
                },
                "example": {
                  "status": 400,
                  "message": "One or more entered parameters are incorrect.",
                  "code": "INVALID_PARAMETER",
                  "traceId": "9b9346f9-f83a-465d-ac8d-dc382c460c22",
                  "details": "The invalid parameter is: XXXX"
                }
              }
            }
          },
          "401": {
            "description": "Bearer token missing, invalid or expired. Keys are capitalised.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModelUnauthorized"
                },
                "example": {
                  "Status": 401,
                  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
                  "Code": "UNAUTHORIZED",
                  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
                }
              }
            }
          },
          "500": {
            "description": "Internal server error occurred while processing the request.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 500,
                  "message": "One or more errors occurred.",
                  "code": "TECHNICAL_ERROR",
                  "traceId": "c546f06c-3674-4b55-8e0f-ce8aac66f49f",
                  "details": "Please verify the transmitted data and try again, or contact support."
                }
              }
            }
          },
          "default": {
            "description": "Error",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                }
              }
            }
          }
        },
        "description": "In order to perform a payment via Paynet API, the payment must first be registered in the Paynet system. The Create order method is used to create (register) a new payment order by transmitting the required payment details from the Partner’s system to Paynet. Upon successful registration, Paynet generates and returns a unique payment identifier (Payment ID). This Payment ID is then used to redirect the customer to the Paynet payment page, where the user can review, confirm, and complete the payment. In this model, direct server-to-server communication between the Partner and Paynet is required. Data signing is not mandatory, as authentication is handled via an authorization token."
      }
    },
    "/api/order/{id}": {
      "get": {
        "tags": [
          "Order"
        ],
        "summary": "Get a payment info by payment id",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "description": "The unique identifier of the payment transaction to retrieve.",
            "required": true,
            "schema": {
              "type": "integer",
              "format": "int64"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Payment found. Real response from the test environment (status 1 = registered, not paid yet).",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/PaymentResponse"
                },
                "example": {
                  "paymentId": 328731,
                  "paymentLink": "https://test.paynet.md/ecom/getecom",
                  "cardLinkHash": null,
                  "status": 1,
                  "message": null,
                  "order": 1762444800000,
                  "merchantCode": "265505",
                  "saleAreaCode": "onlidocumentation_md",
                  "linkUrlSuccess": "https://shop.example/payment/success",
                  "linkUrlCancel": "https://shop.example/payment/cancel",
                  "signature": null,
                  "amount": {
                    "requestAmount": 300,
                    "requestCurrency": 498,
                    "amount": 300,
                    "paidAmount": null
                  },
                  "customer": {
                    "code": "464566161",
                    "nameFirst": "First Name",
                    "nameLast": "Last Name",
                    "email": "customer@example.com",
                    "country": null,
                    "city": null,
                    "address": null,
                    "phoneNumber": "37360000000",
                    "cardLinkHash": null
                  },
                  "payer": null,
                  "expiryDate": "2026-12-31 23:59:59",
                  "registered": "2026-11-09 18:16:41",
                  "paidDate": null,
                  "services": [
                    {
                      "name": "Demo eShop",
                      "description": "Order #1762444800000",
                      "amount": 300,
                      "products": [
                        {
                          "lineNo": 1,
                          "name": "Demo eShop",
                          "description": "Order #1762444800000",
                          "unitPrice": 300,
                          "unitProduct": null,
                          "quantity": 100,
                          "amount": 300,
                          "totalAmount": 300
                        }
                      ]
                    }
                  ],
                  "moneyType": "Card"
                }
              }
            }
          },
          "401": {
            "description": "Bearer token missing, invalid or expired. Keys are capitalised.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModelUnauthorized"
                },
                "example": {
                  "Status": 401,
                  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
                  "Code": "UNAUTHORIZED",
                  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
                }
              }
            }
          },
          "404": {
            "description": "Record not found.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 404,
                  "message": "Record not found",
                  "code": "NOT_FOUND_RECORD",
                  "traceId": "e8e43475-84c2-405a-803f-eb68208f03be",
                  "details": "No records were found for the provided data"
                }
              }
            }
          },
          "500": {
            "description": "Internal server error occurred while processing the request.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 500,
                  "message": "One or more errors occurred.",
                  "code": "TECHNICAL_ERROR",
                  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
                  "details": "Please verify the transmitted data and try again, or contact support."
                }
              }
            }
          },
          "default": {
            "description": "Error",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                }
              }
            }
          }
        },
        "description": "The get payment info method is used to retrieve detailed information about a specific payment using its unique identifier (PaymentId). To perform this request, the Partner must provide the payment ID in the request URL. Paynet will return the current status of the payment along with all relevant details, such as amount, currency, transaction status, and associated metadata. This method allows the Partner to verify the payment status, track transaction progress, and obtain up-to-date information about a previously registered payment."
      }
    },
    "/api/order/merchant/{id}": {
      "get": {
        "tags": [
          "Order"
        ],
        "summary": "Get a payment info by merchant order id",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "description": "The unique order identifier provided by the merchant.",
            "required": true,
            "schema": {
              "type": "integer",
              "format": "int64"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Payment found. Real response from the test environment (status 1 = registered, not paid yet).",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/PaymentResponse"
                },
                "example": {
                  "paymentId": 328731,
                  "paymentLink": "https://test.paynet.md/ecom/getecom",
                  "cardLinkHash": null,
                  "status": 1,
                  "message": null,
                  "order": 1762444800000,
                  "merchantCode": "265505",
                  "saleAreaCode": "onlidocumentation_md",
                  "linkUrlSuccess": "https://shop.example/payment/success",
                  "linkUrlCancel": "https://shop.example/payment/cancel",
                  "signature": null,
                  "amount": {
                    "requestAmount": 300,
                    "requestCurrency": 498,
                    "amount": 300,
                    "paidAmount": null
                  },
                  "customer": {
                    "code": "464566161",
                    "nameFirst": "First Name",
                    "nameLast": "Last Name",
                    "email": "customer@example.com",
                    "country": null,
                    "city": null,
                    "address": null,
                    "phoneNumber": "37360000000",
                    "cardLinkHash": null
                  },
                  "payer": null,
                  "expiryDate": "2026-12-31 23:59:59",
                  "registered": "2026-11-09 18:16:41",
                  "paidDate": null,
                  "services": [
                    {
                      "name": "Demo eShop",
                      "description": "Order #1762444800000",
                      "amount": 300,
                      "products": [
                        {
                          "lineNo": 1,
                          "name": "Demo eShop",
                          "description": "Order #1762444800000",
                          "unitPrice": 300,
                          "unitProduct": null,
                          "quantity": 100,
                          "amount": 300,
                          "totalAmount": 300
                        }
                      ]
                    }
                  ],
                  "moneyType": "Card"
                }
              }
            }
          },
          "401": {
            "description": "Bearer token missing, invalid or expired. Keys are capitalised.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModelUnauthorized"
                },
                "example": {
                  "Status": 401,
                  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
                  "Code": "UNAUTHORIZED",
                  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
                }
              }
            }
          },
          "404": {
            "description": "Record not found.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 404,
                  "message": "Record not found",
                  "code": "NOT_FOUND_RECORD",
                  "traceId": "e8e43475-84c2-405a-803f-eb68208f03be",
                  "details": "No records were found for the provided data"
                }
              }
            }
          },
          "500": {
            "description": "Internal server error occurred while processing the request.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 500,
                  "message": "One or more errors occurred.",
                  "code": "TECHNICAL_ERROR",
                  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
                  "details": "Please verify the transmitted data and try again, or contact support."
                }
              }
            }
          },
          "default": {
            "description": "Error",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                }
              }
            }
          }
        },
        "description": "Returns the payment registered with your order number (the \`Order\` value you sent when creating the payment). Use it when you do not have the Paynet paymentId, for example after a timeout during order creation. The response contains the current status, amounts, dates and payer details."
      }
    },
    "/api/order/search": {
      "get": {
        "tags": [
          "Order"
        ],
        "summary": "Get transaction list",
        "parameters": [
          {
            "name": "from",
            "in": "query",
            "required": true,
            "description": "Start of the search period in Chișinău local time, YYYY-MM-DDTHH:mm:ss (a trailing Z is ignored).",
            "schema": {
              "type": "string",
              "format": "date-time"
            }
          },
          {
            "name": "to",
            "in": "query",
            "required": true,
            "description": "End of the search period in Chișinău local time, YYYY-MM-DDTHH:mm:ss (a trailing Z is ignored).",
            "schema": {
              "type": "string",
              "format": "date-time"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Payments found for the period.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/PaymentSearchResponse"
                }
              }
            }
          },
          "400": {
            "description": "One or more entered parameters are incorrect.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 400,
                  "message": "One or more entered parameters are incorrect.",
                  "code": "INVALID_PARAMETER",
                  "traceId": "9697f2c8-b1c2-490a-84b3-8adda9bc22e9",
                  "details": "The invalid parameter is: dateStart | dateFinish"
                }
              }
            }
          },
          "401": {
            "description": "Bearer token missing, invalid or expired. Keys are capitalised.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModelUnauthorized"
                },
                "example": {
                  "Status": 401,
                  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
                  "Code": "UNAUTHORIZED",
                  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
                }
              }
            }
          },
          "500": {
            "description": "Internal server error occurred while processing the request.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 500,
                  "message": "One or more errors occurred.",
                  "code": "TECHNICAL_ERROR",
                  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
                  "details": "Please verify the transmitted data and try again, or contact support."
                }
              }
            }
          },
          "default": {
            "description": "Error",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                }
              }
            }
          }
        },
        "description": "The get transaction list method is used to retrieve a list of payments within a specified date and time interval. To perform this request, the Partner must provide the from and to parameters in the query string, defining the start and end of the search period. Paynet will return a collection of transactions that were created or processed within the specified timeframe. Each transaction record includes relevant details such as payment ID, amount, currency, status, and timestamps. If no payments match the period, the API answers 404 NOT_FOUND_RECORD (an empty result). This method allows the Partner to perform transaction monitoring, reporting, and reconciliation over a defined period."
      }
    },
    "/api/order/refund": {
      "post": {
        "tags": [
          "Order"
        ],
        "summary": "Refund a payment",
        "requestBody": {
          "description": "The payload containing the necessary details to process the refund.",
          "content": {
            "application/json": {
              "example": {
                "PaymentId": 328733,
                "Amount": 400,
                "SaleAreaCode": "onlidocumentation_md",
                "Currency": 498,
                "RefundType": "full",
                "Reason": "Was customer error!"
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Refund done. Real response from the test environment. eventDate uses the format dd.MM.yyyy HH:mm:ss.",
            "content": {
              "application/json": {
                "example": {
                  "paymentId": 328733,
                  "saleAreaCode": "onlidocumentation_md",
                  "customer": "464566161",
                  "eventDate": "09.11.2026 18:17:54",
                  "refundType": "full",
                  "currency": 498,
                  "amount": 400,
                  "merchant": "265505",
                  "cardMask": "411111******1111",
                  "cardLinkHash": null,
                  "moneyType": "CYBER_SOURCE"
                },
                "schema": {
                  "$ref": "#/components/schemas/RefundResponse"
                }
              }
            }
          },
          "401": {
            "description": "Bearer token missing, invalid or expired. Keys are capitalised.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModelUnauthorized"
                },
                "example": {
                  "Status": 401,
                  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
                  "Code": "UNAUTHORIZED",
                  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
                }
              }
            }
          },
          "500": {
            "description": "Internal server error occurred while processing the request.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 500,
                  "message": "One or more errors occurred.",
                  "code": "TECHNICAL_ERROR",
                  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
                  "details": "Please verify the transmitted data and try again, or contact support."
                }
              }
            }
          },
          "default": {
            "description": "Error",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                }
              }
            }
          },
          "400": {
            "description": "Invalid refund: amount above the paid amount, or another refund of the same payment. details names RefundType.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 400,
                  "message": "One or more entered parameters are incorrect.",
                  "code": "INVALID_PARAMETER",
                  "traceId": "e353a049-9eca-44e9-bc17-e5c4816320da",
                  "details": "The invalid parameter is: RefundType"
                }
              }
            }
          },
          "404": {
            "description": "Payment not found or not paid.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 404,
                  "message": "Record not found",
                  "code": "NOT_FOUND_RECORD",
                  "traceId": "72f97a7d-3a42-4c5f-9d8e-e98ee2aaa9ac",
                  "details": "No records were found for the provided data"
                }
              }
            }
          }
        },
        "description": "The refund method is used to return funds for a previously completed payment. To perform a refund, the Partner must send the original PaymentId, refund amount, currency, sale area code, refund type, and the reason for the refund. The refund can be processed as either a full refund or a partial refund, depending on the RefundType and the amount provided in the request. After the refund request is processed, Paynet returns the result of the operation, allowing the Partner to confirm whether the refund was successfully registered and executed in the Paynet system."
      }
    },
    "/api/statement": {
      "get": {
        "tags": [
          "Statement"
        ],
        "summary": "Get statement",
        "parameters": [
          {
            "name": "dateStart",
            "in": "query",
            "required": true,
            "description": "The starting date of the statement period.",
            "schema": {
              "type": "string",
              "format": "date-time"
            }
          },
          {
            "name": "dateFinish",
            "in": "query",
            "required": true,
            "description": "The ending date of the statement period.",
            "schema": {
              "type": "string",
              "format": "date-time"
            }
          },
          {
            "name": "accountId",
            "in": "query",
            "description": "(Optional) The specific account identifier to filter the statement.",
            "schema": {
              "type": "integer",
              "format": "int32"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Statement for the period.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StatementResponse"
                },
                "example": {
                  "statementDaily": [],
                  "totals": {
                    "startBalance": 180000,
                    "totalDebit": 0,
                    "totalCredit": 0,
                    "finalBalance": 180000
                  }
                }
              }
            }
          },
          "400": {
            "description": "One or more entered parameters are incorrect.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 400,
                  "message": "One or more entered parameters are incorrect.",
                  "code": "INVALID_PARAMETER",
                  "traceId": "9697f2c8-b1c2-490a-84b3-8adda9bc22e9",
                  "details": "The invalid parameter is: dateStart | dateFinish"
                }
              }
            }
          },
          "401": {
            "description": "Bearer token missing, invalid or expired. Keys are capitalised.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModelUnauthorized"
                },
                "example": {
                  "Status": 401,
                  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
                  "Code": "UNAUTHORIZED",
                  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
                }
              }
            }
          },
          "500": {
            "description": "Internal server error occurred while processing the request.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 500,
                  "message": "One or more errors occurred.",
                  "code": "TECHNICAL_ERROR",
                  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
                  "details": "Please verify the transmitted data and try again, or contact support."
                }
              }
            }
          },
          "default": {
            "description": "Error",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                }
              }
            }
          }
        },
        "description": "Retrieves a list of payment transactions for a specified period based on the provided start and end dates. Used for generating statements and transaction reporting."
      }
    },
    "/api/statement/download": {
      "get": {
        "tags": [
          "Statement"
        ],
        "summary": "Download statement",
        "parameters": [
          {
            "name": "dateStart",
            "in": "query",
            "required": true,
            "description": "The starting date of the report period.",
            "schema": {
              "type": "string",
              "format": "date-time"
            }
          },
          {
            "name": "dateFinish",
            "in": "query",
            "required": true,
            "description": "The ending date of the report period (must be within 31 days of the start date).",
            "schema": {
              "type": "string",
              "format": "date-time"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Statement as an .xlsx file.",
            "content": {
              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
                "schema": {
                  "type": "string",
                  "format": "binary"
                }
              }
            }
          },
          "400": {
            "description": "Invalid request parameters.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 400,
                  "message": "One or more entered parameters are incorrect.",
                  "code": "INVALID_PARAMETER",
                  "traceId": "cf5573ee-4749-4190-8a1a-881ee53e7c0a",
                  "details": "The invalid parameter is: dateStart | dateFinish"
                }
              }
            }
          },
          "401": {
            "description": "Bearer token missing, invalid or expired. Keys are capitalised.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModelUnauthorized"
                },
                "example": {
                  "Status": 401,
                  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
                  "Code": "UNAUTHORIZED",
                  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
                }
              }
            }
          },
          "500": {
            "description": "Internal server error occurred while processing the request.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 500,
                  "message": "One or more errors occurred.",
                  "code": "TECHNICAL_ERROR",
                  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
                  "details": "Please verify the transmitted data and try again, or contact support."
                }
              }
            }
          },
          "default": {
            "description": "Error",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                }
              }
            }
          }
        },
        "description": "Generates the merchant statement for the period from dateStart to dateFinish and returns it as an Excel (.xlsx) file. The period must not exceed 31 days."
      }
    },
    "/auth": {
      "post": {
        "tags": [
          "User"
        ],
        "summary": "Authentication and authorization",
        "requestBody": {
          "description": "",
          "content": {
            "application/json": {
              "example": {
                "grantType": "password",
                "username": "771064",
                "password": "sLgMnGWJ"
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Success executed authentication.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/AuthResponse"
                },
                "example": {
                  "access_token": "Ccxl7QQiMEoakkrUoiUn8PIgcmSN2ouP3XNjSmgqUH-Dn8UDg0...........",
                  "token_type": "bearer",
                  "expires_in": 14399
                }
              }
            }
          },
          "default": {
            "description": "Error",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                }
              }
            }
          },
          "401": {
            "description": "Wrong username or password.",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ErrorModel"
                },
                "example": {
                  "status": 401,
                  "message": "Wrong credentials",
                  "code": "AUTHENTICATION_FAILED",
                  "traceId": "8d489156-7b1c-4bfb-b88b-7a946c1b862e",
                  "details": null
                }
              }
            }
          }
        },
        "description": "To access the Paynet service and complete authorization, you need to obtain an authorization token. You can get this token by calling the service method described below and providing the parameters (username and password) received during partner registration."
      }
    }
  },
  "components": {
    "schemas": {
      "AuthRequest": {
        "required": [
          "grantType",
          "password",
          "username"
        ],
        "type": "object",
        "properties": {
          "grantType": {
            "minLength": 1,
            "type": "string",
            "description": "The authorization grant type (e.g., \\"password\\")."
          },
          "username": {
            "minLength": 1,
            "type": "string",
            "description": "The user's username."
          },
          "password": {
            "minLength": 1,
            "type": "string",
            "description": "The user's password in plain text."
          }
        },
        "additionalProperties": false,
        "description": "The authentication request model."
      },
      "Customer": {
        "required": [
          "Code"
        ],
        "type": "object",
        "properties": {
          "Code": {
            "type": "string",
            "description": "The unique code or identifier for the customer.",
            "nullable": true
          },
          "NameFirst": {
            "type": "string",
            "description": "(Optional) The customer's first name.",
            "nullable": true
          },
          "NameLast": {
            "type": "string",
            "description": "(Optional) The customer's last name.",
            "nullable": true
          },
          "email": {
            "type": "string",
            "description": "(Optional) The customer's email address.",
            "nullable": true
          },
          "PhoneNumber": {
            "type": "string",
            "description": "(Optional) The customer's phone number. If it is not sent, the customer types it on the payment page (block \\"Billing information\\").",
            "nullable": true
          }
        },
        "additionalProperties": false,
        "description": "Represents the customer details for a payment."
      },
      "DeleteLinkedCardRequest": {
        "required": [
          "CardLinkHash",
          "CustomerCode",
          "SaleAreaCode"
        ],
        "type": "object",
        "properties": {
          "CardLinkHash": {
            "type": "string",
            "description": "The unique hash identifying the specific card to be unlinked.",
            "nullable": true
          },
          "SaleAreaCode": {
            "type": "string",
            "description": "The code identifying the specific sale area or merchant environment.",
            "nullable": true
          },
          "CustomerCode": {
            "type": "string",
            "description": "The unique identifier or code of the customer who owns the linked card.",
            "nullable": true
          }
        },
        "additionalProperties": false,
        "description": "Represents the payload required to unlink a saved payment card."
      },
      "ErrorModel": {
        "required": [
          "code",
          "message"
        ],
        "type": "object",
        "properties": {
          "status": {
            "type": "integer",
            "description": "Gets or sets the HTTP status code associated with the error (e.g., 400, 401, 500).",
            "format": "int32"
          },
          "message": {
            "type": "string",
            "description": "Gets or sets a human-readable, descriptive error message intended for the client.",
            "nullable": true
          },
          "code": {
            "type": "string",
            "description": "Gets or sets the internal business logic error code or its string representation.",
            "nullable": true
          },
          "traceId": {
            "type": "string",
            "description": "Gets or sets an optional unique identifier used for request tracing and debugging in the logs.",
            "nullable": true
          },
          "details": {
            "type": "string",
            "description": "Gets or sets optional technical details or additional context regarding the error \\r\\n(e.g., specific validation failures).",
            "nullable": true
          }
        },
        "additionalProperties": false,
        "description": "Represents a standardized error response returned by the API."
      },
      "PaymentRequest": {
        "required": [
          "Currency",
          "ExpiryDate",
          "Lang",
          "LinkUrlCancel",
          "LinkUrlSuccess",
          "MoneyType",
          "Order",
          "SaleAreaCode",
          "Services"
        ],
        "type": "object",
        "properties": {
          "Order": {
            "type": "integer",
            "description": "The unique identifier for the order.",
            "format": "int64"
          },
          "SaleAreaCode": {
            "type": "string",
            "description": "The code representing the sale area or merchant location.",
            "nullable": true
          },
          "LinkUrlSuccess": {
            "type": "string",
            "description": "The URL to redirect to upon a successful payment.",
            "nullable": true
          },
          "LinkUrlCancel": {
            "type": "string",
            "description": "The URL to redirect to if the payment is canceled.",
            "nullable": true
          },
          "CardLinkHash": {
            "type": "string",
            "description": "(Optional) Linked-card hash. If CardLinkHash is provided, the full Customer object (Code, NameFirst, NameLast, email, PhoneNumber) becomes required.",
            "nullable": true
          },
          "Customer": {
            "$ref": "#/components/schemas/Customer"
          },
          "Currency": {
            "type": "integer",
            "description": "The currency code.",
            "format": "int32"
          },
          "ExpiryDate": {
            "type": "string",
            "description": "The expiration date and time for this payment request. Format YYYY-MM-DDTHH:mm:ss, Chisinau local time (Europe/Chisinau); must be in the future.",
            "format": "date-time"
          },
          "Services": {
            "type": "array",
            "items": {
              "$ref": "#/components/schemas/Service"
            },
            "description": "The list of services included in this payment.",
            "nullable": true
          },
          "MoneyType": {
            "enum": [
              "All",
              "Card",
              "Paynet",
              "MIA",
              "CashInvoice"
            ],
            "type": "string",
            "description": "Payment methods shown to the customer: \\"All\\" — all methods enabled for the merchant; \\"Card\\" — card (Visa/Mastercard), Apple Pay, Google Pay; \\"Paynet\\" — Paynet wallet; \\"MIA\\" — MIA instant payments; \\"CashInvoice\\" — cash invoice."
          },
          "Lang": {
            "type": "string",
            "description": "UI language for payment page: RO, RU or EN; upper or lower case (EN = en). An unknown value opens the page in English.",
            "nullable": true
          }
        },
        "additionalProperties": false,
        "description": "Represents the payload for initiating a payment request. Fields not marked as required are optional."
      },
      "Product": {
        "required": [
          "Amount",
          "LineNo",
          "Name",
          "Quantity",
          "TotalAmount",
          "UnitPrice"
        ],
        "type": "object",
        "properties": {
          "LineNo": {
            "type": "integer",
            "description": "The line number or position of the product in the list.",
            "format": "int32"
          },
          "Name": {
            "type": "string",
            "description": "The name of the product.",
            "nullable": true
          },
          "Description": {
            "type": "string",
            "description": "(Optional) The description of the product.",
            "nullable": true
          },
          "Code": {
            "type": "string",
            "description": "(Optional) Partner product code.",
            "nullable": true
          },
          "UnitPrice": {
            "type": "integer",
            "description": "The price per single unit of the product.",
            "format": "int64"
          },
          "Quantity": {
            "type": "integer",
            "description": "Quantity in hundredths: 100 = 1 pc, 300 = 3 pcs.",
            "format": "int64"
          },
          "Amount": {
            "type": "integer",
            "description": "The total amount for this quantity in minor units (usually UnitPrice * Quantity / 100).",
            "format": "int64"
          },
          "TotalAmount": {
            "type": "integer",
            "description": "The final total amount including any taxes or discounts.",
            "format": "int64"
          }
        },
        "additionalProperties": false,
        "description": "Represents a single product item within a service."
      },
      "RefundRequest": {
        "required": [
          "PaymentId",
          "SaleAreaCode",
          "RefundType",
          "Amount",
          "Currency",
          "Reason"
        ],
        "type": "object",
        "properties": {
          "PaymentId": {
            "type": "integer",
            "description": "The unique internal identifier of the original payment transaction to be refunded.",
            "format": "int64"
          },
          "SaleAreaCode": {
            "type": "string",
            "description": "The code identifying the specific sale area or point of sale where the original transaction occurred."
          },
          "RefundType": {
            "type": "string",
            "description": "The type of refund: \\"full\\" or \\"partial\\".",
            "enum": [
              "full",
              "partial"
            ]
          },
          "Amount": {
            "type": "integer",
            "description": "The exact amount to be refunded.",
            "format": "int64"
          },
          "Currency": {
            "type": "integer",
            "description": "The numeric ISO code of the currency for the refund amount.",
            "format": "int32"
          },
          "Reason": {
            "type": "string",
            "description": "A descriptive reason or justification for processing the refund."
          }
        },
        "additionalProperties": false,
        "description": "Represents the payload required to initiate a refund for a specific payment transaction."
      },
      "Service": {
        "required": [
          "Amount",
          "Description",
          "Name"
        ],
        "type": "object",
        "properties": {
          "Name": {
            "type": "string",
            "description": "The name of the service.",
            "nullable": true
          },
          "Description": {
            "type": "string",
            "description": "The description of the service.",
            "nullable": true
          },
          "Amount": {
            "type": "integer",
            "description": "The total amount for this service.",
            "format": "int64"
          },
          "Products": {
            "type": "array",
            "items": {
              "$ref": "#/components/schemas/Product"
            },
            "description": "(Optional) A list of specific products under this service. If you send products, LineNo, Name, UnitPrice, Quantity, Amount and TotalAmount are required; Code and Description are optional.",
            "nullable": true
          }
        },
        "additionalProperties": false,
        "description": "Represents a service included in the payment request."
      },
      "AuthResponse": {
        "type": "object",
        "properties": {
          "access_token": {
            "type": "string",
            "description": "Bearer token for the Authorization header."
          },
          "token_type": {
            "type": "string",
            "description": "Always \\"bearer\\"."
          },
          "expires_in": {
            "type": "integer",
            "description": "Token lifetime in seconds (about 4 hours)."
          }
        },
        "description": "Successful authentication response."
      },
      "PaymentResponse": {
        "type": "object",
        "description": "Payment object returned by create/get endpoints.",
        "properties": {
          "paymentId": {
            "type": "integer",
            "format": "int64",
            "description": "Paynet payment ID. Store it with your order."
          },
          "paymentLink": {
            "type": "string",
            "description": "URL of the Paynet payment page. Redirect the customer here."
          },
          "cardLinkHash": {
            "type": "string",
            "nullable": true,
            "description": "Saved card hash (linked-card scenarios)."
          },
          "status": {
            "type": "integer",
            "description": "Payment status code. A new order has status 1."
          },
          "message": {
            "type": "string",
            "nullable": true
          },
          "order": {
            "type": "integer",
            "format": "int64",
            "description": "Your order number (Order)."
          },
          "merchantCode": {
            "type": "string"
          },
          "saleAreaCode": {
            "type": "string"
          },
          "linkUrlSuccess": {
            "type": "string",
            "nullable": true,
            "description": "Return URL after a successful payment, as sent in the order. Can be null in GET /api/order/search results (seen on the test environment)."
          },
          "linkUrlCancel": {
            "type": "string",
            "nullable": true,
            "description": "Return URL after a failed or cancelled payment, as sent in the order. Can be null in GET /api/order/search results (seen on the test environment)."
          },
          "signature": {
            "type": "string",
            "nullable": true,
            "description": "Internal value of the payment link (equals the s parameter of paymentLink); null in GET responses. Not a signature to verify."
          },
          "amount": {
            "type": "object",
            "properties": {
              "requestAmount": {
                "type": "integer"
              },
              "requestCurrency": {
                "type": "integer"
              },
              "amount": {
                "type": "integer"
              },
              "paidAmount": {
                "type": "integer",
                "nullable": true,
                "description": "Amount actually paid, minor units; null until the payment is paid."
              }
            }
          },
          "customer": {
            "type": "object",
            "nullable": true,
            "properties": {
              "code": {
                "type": "string",
                "nullable": true
              },
              "nameFirst": {
                "type": "string",
                "nullable": true
              },
              "nameLast": {
                "type": "string",
                "nullable": true
              },
              "email": {
                "type": "string",
                "nullable": true
              },
              "country": {
                "type": "string",
                "nullable": true
              },
              "city": {
                "type": "string",
                "nullable": true
              },
              "address": {
                "type": "string",
                "nullable": true
              },
              "phoneNumber": {
                "type": "string",
                "nullable": true
              },
              "cardLinkHash": {
                "type": "string",
                "nullable": true
              }
            }
          },
          "payer": {
            "type": "object",
            "nullable": true,
            "description": "Payer details after payment.",
            "properties": {
              "cardMask": {
                "type": "string",
                "nullable": true
              },
              "rrn": {
                "type": "string",
                "nullable": true
              },
              "cardExpireMonth": {
                "type": "string",
                "nullable": true
              },
              "cardExpireYear": {
                "type": "string",
                "nullable": true
              },
              "cardIssuer": {
                "type": "string",
                "nullable": true
              },
              "cardLinkHash": {
                "type": "string",
                "nullable": true
              },
              "moneyType": {
                "type": "string",
                "nullable": true
              },
              "payerName": {
                "type": "string",
                "nullable": true
              },
              "payerSurname": {
                "type": "string",
                "nullable": true
              },
              "payerIDNP": {
                "type": "string",
                "nullable": true
              }
            }
          },
          "expiryDate": {
            "type": "string",
            "description": "Format \\"YYYY-MM-DD HH:mm:ss\\"."
          },
          "registered": {
            "type": "string"
          },
          "paidDate": {
            "type": "string",
            "nullable": true,
            "description": "Set when the payment is paid."
          },
          "services": {
            "type": "array",
            "items": {
              "type": "object"
            }
          },
          "moneyType": {
            "type": "string"
          }
        }
      },
      "ErrorModelUnauthorized": {
        "type": "object",
        "description": "401 for a missing, invalid or expired Bearer token. Note the capitalised keys.",
        "required": [
          "Status",
          "Message",
          "Code"
        ],
        "properties": {
          "Status": {
            "type": "integer"
          },
          "Message": {
            "type": "string"
          },
          "Code": {
            "type": "string"
          },
          "TraceId": {
            "type": "string",
            "nullable": true
          }
        }
      },
      "ErrorInfoResponse": {
        "type": "object",
        "description": "400 when the request body cannot be read (invalid JSON, wrong types, missing required fields).",
        "required": [
          "errorInfo"
        ],
        "properties": {
          "errorInfo": {
            "type": "object",
            "properties": {
              "type": {
                "type": "string",
                "nullable": true
              },
              "title": {
                "type": "string",
                "nullable": true
              },
              "status": {
                "type": "integer"
              },
              "detail": {
                "type": "string",
                "nullable": true
              },
              "instance": {
                "type": "string",
                "nullable": true
              },
              "ppResponseCodeEnum": {
                "type": "string",
                "nullable": true
              },
              "ppResponseCode": {
                "type": "integer",
                "nullable": true
              },
              "ppResponseCodeText": {
                "type": "string",
                "nullable": true
              },
              "errors": {
                "type": "object",
                "nullable": true,
                "description": "Problem fields and messages."
              },
              "traceId": {
                "type": "string",
                "nullable": true
              },
              "ppResponseCodeDescription": {
                "type": "string",
                "nullable": true
              }
            }
          }
        }
      },
      "RefundResponse": {
        "type": "object",
        "description": "Refund result (immediate; no notification is sent).",
        "properties": {
          "paymentId": {
            "type": "integer",
            "format": "int64"
          },
          "saleAreaCode": {
            "type": "string"
          },
          "customer": {
            "type": "string",
            "nullable": true
          },
          "eventDate": {
            "type": "string",
            "description": "Format DD.MM.YYYY HH:mm:ss"
          },
          "refundType": {
            "type": "string"
          },
          "currency": {
            "type": "integer"
          },
          "amount": {
            "type": "integer"
          },
          "merchant": {
            "type": "string"
          },
          "cardMask": {
            "type": "string",
            "nullable": true
          },
          "cardLinkHash": {
            "type": "string",
            "nullable": true
          },
          "moneyType": {
            "type": "string",
            "nullable": true,
            "description": "Processing code, e.g. CYBER_SOURCE (not the notification MoneyType)."
          }
        }
      },
      "PaymentSearchResponse": {
        "type": "object",
        "properties": {
          "payments": {
            "type": "array",
            "items": {
              "$ref": "#/components/schemas/PaymentResponse"
            }
          }
        }
      },
      "StatementResponse": {
        "type": "object",
        "properties": {
          "statementDaily": {
            "type": "array",
            "items": {
              "type": "object"
            }
          },
          "totals": {
            "type": "object",
            "properties": {
              "startBalance": {
                "type": "integer"
              },
              "totalDebit": {
                "type": "integer"
              },
              "totalCredit": {
                "type": "integer"
              },
              "finalBalance": {
                "type": "integer"
              }
            }
          }
        }
      }
    },
    "securitySchemes": {
      "Bearer": {
        "type": "http",
        "description": "Only token.",
        "scheme": "Bearer",
        "bearerFormat": "JWT"
      }
    }
  },
  "security": [
    {
      "Bearer": []
    }
  ],
  "tags": [
    {
      "name": "LinkedCard",
      "description": "Handles operations related to saved or linked payment cards for authorized users."
    },
    {
      "name": "Order",
      "description": "Psp Controller"
    },
    {
      "name": "Statement",
      "description": "Handles operations related to merchant financial statements, including data retrieval and exporting reports."
    },
    {
      "name": "User",
      "description": "User controller"
    }
  ]
}
`;function nn(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,`default`)?e.default:e}var rn={},an={},on={},sn;function cn(){if(sn)return on;sn=1;function e(e){return e==null}function t(e){return typeof e==`object`&&!!e}function n(t){return Array.isArray(t)?t:e(t)?[]:[t]}function r(e,t){if(t){let n=Object.keys(t);for(let r=0,i=n.length;r<i;r+=1){let i=n[r];e[i]=t[i]}}return e}function i(e,t){let n=``;for(let r=0;r<t;r+=1)n+=e;return n}function a(e){return e===0&&1/e==-1/0}return on.isNothing=e,on.isObject=t,on.toArray=n,on.repeat=i,on.isNegativeZero=a,on.extend=r,on}var ln,un;function dn(){if(un)return ln;un=1;function e(e,t){let n=``,r=e.reason||`(unknown reason)`;return e.mark?(e.mark.name&&(n+=`in "`+e.mark.name+`" `),n+=`(`+(e.mark.line+1)+`:`+(e.mark.column+1)+`)`,!t&&e.mark.snippet&&(n+=`

`+e.mark.snippet),r+` `+n):r}function t(t,n){Error.call(this),this.name=`YAMLException`,this.reason=t,this.mark=n,this.message=e(this,!1),Error.captureStackTrace?Error.captureStackTrace(this,this.constructor):this.stack=Error().stack||``}return t.prototype=Object.create(Error.prototype),t.prototype.constructor=t,t.prototype.toString=function(t){return this.name+`: `+e(this,t)},ln=t,ln}var fn,pn;function mn(){if(pn)return fn;pn=1;let e=cn();function t(e,t,n,r,i){let a=``,o=``,s=Math.floor(i/2)-1;return r-t>s&&(a=` ... `,t=r-s+a.length),n-r>s&&(o=` ...`,n=r+s-o.length),{str:a+e.slice(t,n).replace(/\t/g,`→`)+o,pos:r-t+a.length}}function n(t,n){return e.repeat(` `,n-t.length)+t}function r(r,i){if(i=Object.create(i||null),!r.buffer)return null;i.maxLength||(i.maxLength=79),typeof i.indent!=`number`&&(i.indent=1),typeof i.linesBefore!=`number`&&(i.linesBefore=3),typeof i.linesAfter!=`number`&&(i.linesAfter=2);let a=/\r?\n|\r|\0/g,o=[0],s=[],c,l=-1;for(;c=a.exec(r.buffer);)s.push(c.index),o.push(c.index+c[0].length),r.position<=c.index&&l<0&&(l=o.length-2);l<0&&(l=o.length-1);let u=``,d=Math.min(r.line+i.linesAfter,s.length).toString().length,f=i.maxLength-(i.indent+d+3);for(let a=1;a<=i.linesBefore&&!(l-a<0);a++){let c=t(r.buffer,o[l-a],s[l-a],r.position-(o[l]-o[l-a]),f);u=e.repeat(` `,i.indent)+n((r.line-a+1).toString(),d)+` | `+c.str+`
`+u}let p=t(r.buffer,o[l],s[l],r.position,f);u+=e.repeat(` `,i.indent)+n((r.line+1).toString(),d)+` | `+p.str+`
`,u+=e.repeat(`-`,i.indent+d+3+p.pos)+`^
`;for(let a=1;a<=i.linesAfter&&!(l+a>=s.length);a++){let c=t(r.buffer,o[l+a],s[l+a],r.position-(o[l]-o[l+a]),f);u+=e.repeat(` `,i.indent)+n((r.line+a+1).toString(),d)+` | `+c.str+`
`}return u.replace(/\n$/,``)}return fn=r,fn}var hn,gn;function _n(){if(gn)return hn;gn=1;let e=dn(),t=[`kind`,`multi`,`resolve`,`construct`,`instanceOf`,`predicate`,`represent`,`representName`,`defaultStyle`,`styleAliases`],n=[`scalar`,`sequence`,`mapping`];function r(e){let t={};return e!==null&&Object.keys(e).forEach(function(n){e[n].forEach(function(e){t[String(e)]=n})}),t}function i(i,a){if(a||={},Object.keys(a).forEach(function(n){if(t.indexOf(n)===-1)throw new e(`Unknown option "`+n+`" is met in definition of "`+i+`" YAML type.`)}),this.options=a,this.tag=i,this.kind=a.kind||null,this.resolve=a.resolve||function(){return!0},this.construct=a.construct||function(e){return e},this.instanceOf=a.instanceOf||null,this.predicate=a.predicate||null,this.represent=a.represent||null,this.representName=a.representName||null,this.defaultStyle=a.defaultStyle||null,this.multi=a.multi||!1,this.styleAliases=r(a.styleAliases||null),n.indexOf(this.kind)===-1)throw new e(`Unknown kind "`+this.kind+`" is specified for "`+i+`" YAML type.`)}return hn=i,hn}var vn,yn;function bn(){if(yn)return vn;yn=1;let e=dn(),t=_n();function n(e,t){let n=[];return e[t].forEach(function(e){let t=n.length;n.forEach(function(n,r){n.tag===e.tag&&n.kind===e.kind&&n.multi===e.multi&&(t=r)}),n[t]=e}),n}function r(){let e={scalar:{},sequence:{},mapping:{},fallback:{},multi:{scalar:[],sequence:[],mapping:[],fallback:[]}};function t(t){t.multi?(e.multi[t.kind].push(t),e.multi.fallback.push(t)):e[t.kind][t.tag]=e.fallback[t.tag]=t}for(let e=0,n=arguments.length;e<n;e+=1)arguments[e].forEach(t);return e}function i(e){return this.extend(e)}return i.prototype.extend=function(a){let o=[],s=[];if(a instanceof t)s.push(a);else if(Array.isArray(a))s=s.concat(a);else if(a&&(Array.isArray(a.implicit)||Array.isArray(a.explicit)))a.implicit&&(o=o.concat(a.implicit)),a.explicit&&(s=s.concat(a.explicit));else throw new e(`Schema.extend argument should be a Type, [ Type ], or a schema definition ({ implicit: [...], explicit: [...] })`);o.forEach(function(n){if(!(n instanceof t))throw new e(`Specified list of YAML types (or a single Type object) contains a non-Type object.`);if(n.loadKind&&n.loadKind!==`scalar`)throw new e(`There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.`);if(n.multi)throw new e(`There is a multi type in the implicit list of a schema. Multi tags can only be listed as explicit.`)}),s.forEach(function(n){if(!(n instanceof t))throw new e(`Specified list of YAML types (or a single Type object) contains a non-Type object.`)});let c=Object.create(i.prototype);return c.implicit=(this.implicit||[]).concat(o),c.explicit=(this.explicit||[]).concat(s),c.compiledImplicit=n(c,`implicit`),c.compiledExplicit=n(c,`explicit`),c.compiledTypeMap=r(c.compiledImplicit,c.compiledExplicit),c},vn=i,vn}var xn,Sn;function Cn(){return Sn||(Sn=1,xn=new(_n())(`tag:yaml.org,2002:str`,{kind:`scalar`,construct:function(e){return e===null?``:e}})),xn}var wn,Tn;function En(){return Tn||(Tn=1,wn=new(_n())(`tag:yaml.org,2002:seq`,{kind:`sequence`,construct:function(e){return e===null?[]:e}})),wn}var Dn,On;function kn(){return On||(On=1,Dn=new(_n())(`tag:yaml.org,2002:map`,{kind:`mapping`,construct:function(e){return e===null?{}:e}})),Dn}var An,jn;function Mn(){return jn||(jn=1,An=new(bn())({explicit:[Cn(),En(),kn()]})),An}var Nn,Pn;function Fn(){if(Pn)return Nn;Pn=1;let e=_n();function t(e){if(e===null)return!0;let t=e.length;return t===1&&e===`~`||t===4&&(e===`null`||e===`Null`||e===`NULL`)}function n(){return null}function r(e){return e===null}return Nn=new e(`tag:yaml.org,2002:null`,{kind:`scalar`,resolve:t,construct:n,predicate:r,represent:{canonical:function(){return`~`},lowercase:function(){return`null`},uppercase:function(){return`NULL`},camelcase:function(){return`Null`},empty:function(){return``}},defaultStyle:`lowercase`}),Nn}var In,Ln;function Rn(){if(Ln)return In;Ln=1;let e=_n();function t(e){if(e===null)return!1;let t=e.length;return t===4&&(e===`true`||e===`True`||e===`TRUE`)||t===5&&(e===`false`||e===`False`||e===`FALSE`)}function n(e){return e===`true`||e===`True`||e===`TRUE`}function r(e){return Object.prototype.toString.call(e)===`[object Boolean]`}return In=new e(`tag:yaml.org,2002:bool`,{kind:`scalar`,resolve:t,construct:n,predicate:r,represent:{lowercase:function(e){return e?`true`:`false`},uppercase:function(e){return e?`TRUE`:`FALSE`},camelcase:function(e){return e?`True`:`False`}},defaultStyle:`lowercase`}),In}var zn,Bn;function Vn(){if(Bn)return zn;Bn=1;let e=cn(),t=_n();function n(e){return e>=48&&e<=57||e>=65&&e<=70||e>=97&&e<=102}function r(e){return e>=48&&e<=55}function i(e){return e>=48&&e<=57}function a(e){if(e===null)return!1;let t=e.length,a=0,s=!1;if(!t)return!1;let c=e[a];if((c===`-`||c===`+`)&&(c=e[++a]),c===`0`){if(a+1===t)return!0;if(c=e[++a],c===`b`){for(a++;a<t;a++){if(c=e[a],c!==`0`&&c!==`1`)return!1;s=!0}return s&&isFinite(o(e))}if(c===`x`){for(a++;a<t;a++){if(!n(e.charCodeAt(a)))return!1;s=!0}return s&&isFinite(o(e))}if(c===`o`){for(a++;a<t;a++){if(!r(e.charCodeAt(a)))return!1;s=!0}return s&&isFinite(o(e))}}for(;a<t;a++){if(!i(e.charCodeAt(a)))return!1;s=!0}return s?isFinite(o(e)):!1}function o(e){let t=e,n=1,r=t[0];if((r===`-`||r===`+`)&&(r===`-`&&(n=-1),t=t.slice(1),r=t[0]),t===`0`)return 0;if(r===`0`){if(t[1]===`b`)return n*parseInt(t.slice(2),2);if(t[1]===`x`)return n*parseInt(t.slice(2),16);if(t[1]===`o`)return n*parseInt(t.slice(2),8)}return n*parseInt(t,10)}function s(e){return o(e)}function c(t){return Object.prototype.toString.call(t)===`[object Number]`&&t%1==0&&!e.isNegativeZero(t)}return zn=new t(`tag:yaml.org,2002:int`,{kind:`scalar`,resolve:a,construct:s,predicate:c,represent:{binary:function(e){return e>=0?`0b`+e.toString(2):`-0b`+e.toString(2).slice(1)},octal:function(e){return e>=0?`0o`+e.toString(8):`-0o`+e.toString(8).slice(1)},decimal:function(e){return e.toString(10)},hexadecimal:function(e){return e>=0?`0x`+e.toString(16).toUpperCase():`-0x`+e.toString(16).toUpperCase().slice(1)}},defaultStyle:`decimal`,styleAliases:{binary:[2,`bin`],octal:[8,`oct`],decimal:[10,`dec`],hexadecimal:[16,`hex`]}}),zn}var Hn,Un;function Wn(){if(Un)return Hn;Un=1;let e=cn(),t=_n(),n=RegExp(`^(?:[-+]?(?:[0-9]+)(?:\\.[0-9]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$`),r=RegExp(`^(?:[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$`);function i(e){return e===null||!n.test(e)?!1:isFinite(parseFloat(e,10))?!0:r.test(e)}function a(e){let t=e.toLowerCase(),n=t[0]===`-`?-1:1;return`+-`.indexOf(t[0])>=0&&(t=t.slice(1)),t===`.inf`?n===1?1/0:-1/0:t===`.nan`?NaN:n*parseFloat(t,10)}let o=/^[-+]?[0-9]+e/;function s(t,n){if(isNaN(t))switch(n){case`lowercase`:return`.nan`;case`uppercase`:return`.NAN`;case`camelcase`:return`.NaN`}else if(t===1/0)switch(n){case`lowercase`:return`.inf`;case`uppercase`:return`.INF`;case`camelcase`:return`.Inf`}else if(t===-1/0)switch(n){case`lowercase`:return`-.inf`;case`uppercase`:return`-.INF`;case`camelcase`:return`-.Inf`}else if(e.isNegativeZero(t))return`-0.0`;let r=t.toString(10);return o.test(r)?r.replace(`e`,`.e`):r}function c(t){return Object.prototype.toString.call(t)===`[object Number]`&&(t%1!=0||e.isNegativeZero(t))}return Hn=new t(`tag:yaml.org,2002:float`,{kind:`scalar`,resolve:i,construct:a,predicate:c,represent:s,defaultStyle:`lowercase`}),Hn}var Gn,Kn;function qn(){return Kn||(Kn=1,Gn=Mn().extend({implicit:[Fn(),Rn(),Vn(),Wn()]})),Gn}var Jn,Yn;function Xn(){return Yn||(Yn=1,Jn=qn()),Jn}var Zn,Qn;function $n(){if(Qn)return Zn;Qn=1;let e=_n(),t=RegExp(`^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$`),n=RegExp(`^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$`);function r(e){return e===null?!1:t.exec(e)!==null||n.exec(e)!==null}function i(e){let r=0,i=null,a=t.exec(e);if(a===null&&(a=n.exec(e)),a===null)throw Error(`Date resolve error`);let o=+a[1],s=a[2]-1,c=+a[3];if(!a[4])return new Date(Date.UTC(o,s,c));let l=+a[4],u=+a[5],d=+a[6];if(a[7]){for(r=a[7].slice(0,3);r.length<3;)r+=`0`;r=+r}if(a[9]){let e=+a[10],t=+(a[11]||0);i=(e*60+t)*6e4,a[9]===`-`&&(i=-i)}let f=new Date(Date.UTC(o,s,c,l,u,d,r));return i&&f.setTime(f.getTime()-i),f}function a(e){return e.toISOString()}return Zn=new e(`tag:yaml.org,2002:timestamp`,{kind:`scalar`,resolve:r,construct:i,instanceOf:Date,represent:a}),Zn}var er,tr;function nr(){if(tr)return er;tr=1;let e=_n();function t(e){return e===`<<`||e===null}return er=new e(`tag:yaml.org,2002:merge`,{kind:`scalar`,resolve:t}),er}var rr,ir;function ar(){if(ir)return rr;ir=1;let e=_n();function t(e){if(e===null)return!1;let t=0,n=e.length;for(let r=0;r<n;r++){let n=`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`.indexOf(e.charAt(r));if(!(n>64)){if(n<0)return!1;t+=6}}return t%8==0}function n(e){let t=e.replace(/[\r\n=]/g,``),n=t.length,r=0,i=[];for(let e=0;e<n;e++)e%4==0&&e&&(i.push(r>>16&255),i.push(r>>8&255),i.push(r&255)),r=r<<6|`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`.indexOf(t.charAt(e));let a=n%4*6;return a===0?(i.push(r>>16&255),i.push(r>>8&255),i.push(r&255)):a===18?(i.push(r>>10&255),i.push(r>>2&255)):a===12&&i.push(r>>4&255),new Uint8Array(i)}function r(e){let t=``,n=0,r=e.length,i=`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`;for(let a=0;a<r;a++)a%3==0&&a&&(t+=i[n>>18&63],t+=i[n>>12&63],t+=i[n>>6&63],t+=i[n&63]),n=(n<<8)+e[a];let a=r%3;return a===0?(t+=i[n>>18&63],t+=i[n>>12&63],t+=i[n>>6&63],t+=i[n&63]):a===2?(t+=i[n>>10&63],t+=i[n>>4&63],t+=i[n<<2&63],t+=i[64]):a===1&&(t+=i[n>>2&63],t+=i[n<<4&63],t+=i[64],t+=i[64]),t}function i(e){return Object.prototype.toString.call(e)===`[object Uint8Array]`}return rr=new e(`tag:yaml.org,2002:binary`,{kind:`scalar`,resolve:t,construct:n,predicate:i,represent:r}),rr}var or,sr;function cr(){if(sr)return or;sr=1;let e=_n(),t=Object.prototype.hasOwnProperty,n=Object.prototype.toString;function r(e){if(e===null)return!0;let r={},i=e;for(let e=0,a=i.length;e<a;e+=1){let a=i[e],o=!1;if(n.call(a)!==`[object Object]`)return!1;let s;for(s in a)if(t.call(a,s)){if(!o)o=!0;else return!1}if(!o||t.call(r,s))return!1;Object.defineProperty(r,s,{value:!0})}return!0}function i(e){return e===null?[]:e}return or=new e(`tag:yaml.org,2002:omap`,{kind:`sequence`,resolve:r,construct:i}),or}var lr,ur;function dr(){if(ur)return lr;ur=1;let e=_n(),t=Object.prototype.toString;function n(e){if(e===null)return!0;let n=e,r=Array(n.length);for(let e=0,i=n.length;e<i;e+=1){let i=n[e];if(t.call(i)!==`[object Object]`)return!1;let a=Object.keys(i);if(a.length!==1)return!1;r[e]=[a[0],i[a[0]]]}return!0}function r(e){if(e===null)return[];let t=e,n=Array(t.length);for(let e=0,r=t.length;e<r;e+=1){let r=t[e],i=Object.keys(r);n[e]=[i[0],r[i[0]]]}return n}return lr=new e(`tag:yaml.org,2002:pairs`,{kind:`sequence`,resolve:n,construct:r}),lr}var fr,pr;function mr(){if(pr)return fr;pr=1;let e=_n(),t=Object.prototype.hasOwnProperty;function n(e){if(e===null)return!0;let n=e;for(let e in n)if(t.call(n,e)&&n[e]!==null)return!1;return!0}function r(e){return e===null?{}:e}return fr=new e(`tag:yaml.org,2002:set`,{kind:`mapping`,resolve:n,construct:r}),fr}var hr,gr;function _r(){return gr||(gr=1,hr=Xn().extend({implicit:[$n(),nr()],explicit:[ar(),cr(),dr(),mr()]})),hr}var vr;function yr(){if(vr)return an;vr=1;let e=cn(),t=dn(),n=mn(),r=_r(),i=Object.prototype.hasOwnProperty,a=/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/,o=/[\x85\u2028\u2029]/,s=/[,\[\]{}]/,c=/^(?:!|!!|![0-9A-Za-z-]+!)$/,l=/^(?:!|[^,\[\]{}])(?:%[0-9a-f]{2}|[0-9a-z\-#;/?:@&=+$,_.!~*'()\[\]])*$/i;function u(e){return Object.prototype.toString.call(e)}function d(e){return e===10||e===13}function f(e){return e===9||e===32}function p(e){return e===9||e===32||e===10||e===13}function m(e){return e===44||e===91||e===93||e===123||e===125}function h(e){if(e>=48&&e<=57)return e-48;let t=e|32;return t>=97&&t<=102?t-97+10:-1}function g(e){return e===120?2:e===117?4:e===85?8:0}function _(e){return e>=48&&e<=57?e-48:-1}function v(e){switch(e){case 48:return`\0`;case 97:return`\x07`;case 98:return`\b`;case 116:return`	`;case 9:return`	`;case 110:return`
`;case 118:return`\v`;case 102:return`\f`;case 114:return`\r`;case 101:return`\x1B`;case 32:return` `;case 34:return`"`;case 47:return`/`;case 92:return`\\`;case 78:return``;case 95:return`\xA0`;case 76:return`\u2028`;case 80:return`\u2029`;default:return``}}function y(e){return e<=65535?String.fromCharCode(e):String.fromCharCode((e-65536>>10)+55296,(e-65536&1023)+56320)}function b(e,t,n){t===`__proto__`?Object.defineProperty(e,t,{configurable:!0,enumerable:!0,writable:!0,value:n}):e[t]=n}let x=Array(256),S=Array(256);for(let e=0;e<256;e++)x[e]=+!!v(e),S[e]=v(e);function C(e,t){this.input=e,this.filename=t.filename||null,this.schema=t.schema||r,this.onWarning=t.onWarning||null,this.legacy=t.legacy||!1,this.json=t.json||!1,this.listener=t.listener||null,this.maxDepth=typeof t.maxDepth==`number`?t.maxDepth:100,this.maxTotalMergeKeys=typeof t.maxTotalMergeKeys==`number`?t.maxTotalMergeKeys:1e4,this.implicitTypes=this.schema.compiledImplicit,this.typeMap=this.schema.compiledTypeMap,this.length=e.length,this.position=0,this.line=0,this.lineStart=0,this.lineIndent=0,this.depth=0,this.totalMergeKeys=0,this.firstTabInLine=-1,this.documents=[],this.anchorMapTransactions=[]}function w(e,r){let i={name:e.filename,buffer:e.input.slice(0,-1),position:e.position,line:e.line,column:e.position-e.lineStart};return i.snippet=n(i),new t(r,i)}function T(e,t){throw w(e,t)}function E(e,t){e.onWarning&&e.onWarning.call(null,w(e,t))}function D(e,t,n){let r=e.anchorMapTransactions;if(r.length!==0){let n=r[r.length-1];i.call(n,t)||(n[t]={existed:i.call(e.anchorMap,t),value:e.anchorMap[t]})}e.anchorMap[t]=n}function O(e){e.anchorMapTransactions.push(Object.create(null))}function k(e){let t=e.anchorMapTransactions.pop(),n=e.anchorMapTransactions;if(n.length===0)return;let r=n[n.length-1],a=Object.keys(t);for(let e=0,n=a.length;e<n;e+=1){let n=a[e];i.call(r,n)||(r[n]=t[n])}}function A(e){let t=e.anchorMapTransactions.pop(),n=Object.keys(t);for(let r=n.length-1;r>=0;--r){let i=t[n[r]];i.existed?e.anchorMap[n[r]]=i.value:delete e.anchorMap[n[r]]}}function j(e){return{position:e.position,line:e.line,lineStart:e.lineStart,lineIndent:e.lineIndent,firstTabInLine:e.firstTabInLine,tag:e.tag,anchor:e.anchor,kind:e.kind,result:e.result}}function M(e,t){e.position=t.position,e.line=t.line,e.lineStart=t.lineStart,e.lineIndent=t.lineIndent,e.firstTabInLine=t.firstTabInLine,e.tag=t.tag,e.anchor=t.anchor,e.kind=t.kind,e.result=t.result}let N={YAML:function(e,t,n){e.version!==null&&T(e,`duplication of %YAML directive`),n.length!==1&&T(e,`YAML directive accepts exactly one argument`);let r=/^([0-9]+)\.([0-9]+)$/.exec(n[0]);r===null&&T(e,`ill-formed argument of the YAML directive`);let i=parseInt(r[1],10),a=parseInt(r[2],10);i!==1&&T(e,`unacceptable YAML version of the document`),e.version=n[0],e.checkLineBreaks=a<2,a!==1&&a!==2&&E(e,`unsupported YAML version of the document`)},TAG:function(e,t,n){let r;n.length!==2&&T(e,`TAG directive accepts exactly two arguments`);let a=n[0];r=n[1],c.test(a)||T(e,`ill-formed tag handle (first argument) of the TAG directive`),i.call(e.tagMap,a)&&T(e,`there is a previously declared suffix for "`+a+`" tag handle`),l.test(r)||T(e,`ill-formed tag prefix (second argument) of the TAG directive`);try{r=decodeURIComponent(r)}catch{T(e,`tag prefix is malformed: `+r)}e.tagMap[a]=r}};function P(e,t,n,r){if(t<n){let i=e.input.slice(t,n);if(r)for(let t=0,n=i.length;t<n;t+=1){let n=i.charCodeAt(t);n===9||n>=32&&n<=1114111||T(e,`expected valid JSON character`)}else a.test(i)&&T(e,`the stream contains non-printable characters`);e.result+=i}}function F(e){e.totalMergeKeys++,e.maxTotalMergeKeys!==-1&&e.totalMergeKeys>e.maxTotalMergeKeys&&T(e,`merge keys exceeded maxTotalMergeKeys (`+e.maxTotalMergeKeys+`)`)}function ee(t,n,r,a){e.isObject(r)||T(t,`cannot merge mappings; the provided source object is unacceptable`),F(t);let o=Object.keys(r);for(let e=0,s=o.length;e<s;e+=1){let s=o[e];F(t),i.call(n,s)||(b(n,s,r[s]),a[s]=!0)}}function I(e,t,n,r,a,o,s,c,l){if(Array.isArray(a)){a=Array.prototype.slice.call(a);for(let t=0,n=a.length;t<n;t+=1)Array.isArray(a[t])&&T(e,`nested arrays are not supported inside keys`),typeof a==`object`&&u(a[t])===`[object Object]`&&(a[t]=`[object Object]`)}if(typeof a==`object`&&u(a)===`[object Object]`&&(a=`[object Object]`),a=String(a),t===null&&(t={}),r===`tag:yaml.org,2002:merge`){if(Array.isArray(o)){o.length>100&&T(e,`abnormal merge sequence size`);for(let r=0,i=o.length;r<i;r+=1)ee(e,t,o[r],n)}else ee(e,t,o,n)}else!e.json&&!i.call(n,a)&&i.call(t,a)&&(e.line=s||e.line,e.lineStart=c||e.lineStart,e.position=l||e.position,T(e,`duplicated mapping key`)),b(t,a,o),delete n[a];return t}function L(e){let t=e.input.charCodeAt(e.position);t===10?e.position++:t===13?(e.position++,e.input.charCodeAt(e.position)===10&&e.position++):T(e,`a line break is expected`),e.line+=1,e.lineStart=e.position,e.firstTabInLine=-1}function R(e,t,n){let r=0,i=e.input.charCodeAt(e.position);for(;i!==0;){for(;f(i);)i===9&&e.firstTabInLine===-1&&(e.firstTabInLine=e.position),i=e.input.charCodeAt(++e.position);if(t&&i===35)do i=e.input.charCodeAt(++e.position);while(i!==10&&i!==13&&i!==0);if(d(i))for(L(e),i=e.input.charCodeAt(e.position),r++,e.lineIndent=0;i===32;)e.lineIndent++,i=e.input.charCodeAt(++e.position);else break}return n!==-1&&r!==0&&e.lineIndent<n&&E(e,`deficient indentation`),r}function te(e){let t=e.position,n=e.input.charCodeAt(t);return!!((n===45||n===46)&&n===e.input.charCodeAt(t+1)&&n===e.input.charCodeAt(t+2)&&(t+=3,n=e.input.charCodeAt(t),n===0||p(n)))}function ne(t,n){n===1?t.result+=` `:n>1&&(t.result+=e.repeat(`
`,n-1))}function re(e,t,n){let r,i,a,o,s,c,l=e.kind,u=e.result,h=e.input.charCodeAt(e.position);if(p(h)||m(h)||h===35||h===38||h===42||h===33||h===124||h===62||h===39||h===34||h===37||h===64||h===96)return!1;if(h===63||h===45){let t=e.input.charCodeAt(e.position+1);if(p(t)||n&&m(t))return!1}for(e.kind=`scalar`,e.result=``,r=i=e.position,a=!1;h!==0;){if(h===58){let t=e.input.charCodeAt(e.position+1);if(p(t)||n&&m(t))break}else if(h===35){if(p(e.input.charCodeAt(e.position-1)))break}else if(e.position===e.lineStart&&te(e)||n&&m(h))break;else if(d(h)){if(o=e.line,s=e.lineStart,c=e.lineIndent,R(e,!1,-1),e.lineIndent>=t){a=!0,h=e.input.charCodeAt(e.position);continue}e.position=i,e.line=o,e.lineStart=s,e.lineIndent=c;break}a&&=(P(e,r,i,!1),ne(e,e.line-o),r=i=e.position,!1),f(h)||(i=e.position+1),h=e.input.charCodeAt(++e.position)}return P(e,r,i,!1),e.result?!0:(e.kind=l,e.result=u,!1)}function z(e,t){let n,r,i=e.input.charCodeAt(e.position);if(i!==39)return!1;for(e.kind=`scalar`,e.result=``,e.position++,n=r=e.position;(i=e.input.charCodeAt(e.position))!==0;)if(i===39){if(P(e,n,e.position,!0),i=e.input.charCodeAt(++e.position),i===39)n=e.position,e.position++,r=e.position;else return!0}else d(i)?(P(e,n,r,!0),ne(e,R(e,!1,t)),n=r=e.position):e.position===e.lineStart&&te(e)?T(e,`unexpected end of the document within a single quoted scalar`):(e.position++,f(i)||(r=e.position));T(e,`unexpected end of the stream within a single quoted scalar`)}function ie(e,t){let n,r,i,a=e.input.charCodeAt(e.position);if(a!==34)return!1;for(e.kind=`scalar`,e.result=``,e.position++,n=r=e.position;(a=e.input.charCodeAt(e.position))!==0;)if(a===34)return P(e,n,e.position,!0),e.position++,!0;else if(a===92){if(P(e,n,e.position,!0),a=e.input.charCodeAt(++e.position),d(a))R(e,!1,t);else if(a<256&&x[a])e.result+=S[a],e.position++;else if((i=g(a))>0){let t=i,n=0;for(;t>0;t--)a=e.input.charCodeAt(++e.position),(i=h(a))>=0?n=(n<<4)+i:T(e,`expected hexadecimal character`);e.result+=y(n),e.position++}else T(e,`unknown escape sequence`);n=r=e.position}else d(a)?(P(e,n,r,!0),ne(e,R(e,!1,t)),n=r=e.position):e.position===e.lineStart&&te(e)?T(e,`unexpected end of the document within a double quoted scalar`):(e.position++,f(a)||(r=e.position));T(e,`unexpected end of the stream within a double quoted scalar`)}function ae(e,t){let n=!0,r,i,a,o=e.tag,s,c=e.anchor,l,u,d,f,m=Object.create(null),h,g,_,v=e.input.charCodeAt(e.position);if(v===91)l=93,f=!1,s=[];else if(v===123)l=125,f=!0,s={};else return!1;for(e.anchor!==null&&D(e,e.anchor,s),v=e.input.charCodeAt(++e.position);v!==0;){if(R(e,!0,t),v=e.input.charCodeAt(e.position),v===l)return e.position++,e.tag=o,e.anchor=c,e.kind=f?`mapping`:`sequence`,e.result=s,!0;n?v===44&&T(e,`expected the node content, but found ','`):T(e,`missed comma between flow collection entries`),g=h=_=null,u=d=!1,v===63&&p(e.input.charCodeAt(e.position+1))&&(u=d=!0,e.position++,R(e,!0,t)),r=e.line,i=e.lineStart,a=e.position,pe(e,t,1,!1,!0),g=e.tag,h=e.result,R(e,!0,t),v=e.input.charCodeAt(e.position),(d||e.line===r)&&v===58&&(u=!0,v=e.input.charCodeAt(++e.position),R(e,!0,t),pe(e,t,1,!1,!0),_=e.result),f?I(e,s,m,g,h,_,r,i,a):u?s.push(I(e,null,m,g,h,_,r,i,a)):s.push(h),R(e,!0,t),v=e.input.charCodeAt(e.position),v===44?(n=!0,v=e.input.charCodeAt(++e.position)):n=!1}T(e,`unexpected end of the stream within a flow collection`)}function oe(t,n){let r,i=1,a=!1,o=!1,s=n,c=0,l=!1,u,p=t.input.charCodeAt(t.position);if(p===124)r=!1;else if(p===62)r=!0;else return!1;for(t.kind=`scalar`,t.result=``;p!==0;)if(p=t.input.charCodeAt(++t.position),p===43||p===45)i===1?i=p===43?3:2:T(t,`repeat of a chomping mode identifier`);else if((u=_(p))>=0)u===0?T(t,`bad explicit indentation width of a block scalar; it cannot be less than one`):o?T(t,`repeat of an indentation width identifier`):(s=n+u-1,o=!0);else break;if(f(p)){do p=t.input.charCodeAt(++t.position);while(f(p));if(p===35)do p=t.input.charCodeAt(++t.position);while(!d(p)&&p!==0)}for(;p!==0;){for(L(t),t.lineIndent=0,p=t.input.charCodeAt(t.position);(!o||t.lineIndent<s)&&p===32;)t.lineIndent++,p=t.input.charCodeAt(++t.position);if(!o&&t.lineIndent>s&&(s=t.lineIndent),d(p)){c++;continue}if(!o&&s===0&&T(t,`missing indentation for block scalar`),t.lineIndent<s){i===3?t.result+=e.repeat(`
`,a?1+c:c):i===1&&a&&(t.result+=`
`);break}r?f(p)?(l=!0,t.result+=e.repeat(`
`,a?1+c:c)):l?(l=!1,t.result+=e.repeat(`
`,c+1)):c===0?a&&(t.result+=` `):t.result+=e.repeat(`
`,c):t.result+=e.repeat(`
`,a?1+c:c),a=!0,o=!0,c=0;let n=t.position;for(;!d(p)&&p!==0;)p=t.input.charCodeAt(++t.position);P(t,n,t.position,!1)}return!0}function se(e,t){let n=e.tag,r=e.anchor,i=[],a=!1;if(e.firstTabInLine!==-1)return!1;e.anchor!==null&&D(e,e.anchor,i);let o=e.input.charCodeAt(e.position);for(;o!==0&&(e.firstTabInLine!==-1&&(e.position=e.firstTabInLine,T(e,`tab characters must not be used in indentation`)),o===45&&p(e.input.charCodeAt(e.position+1)));){if(a=!0,e.position++,R(e,!0,-1)&&e.lineIndent<=t){i.push(null),o=e.input.charCodeAt(e.position);continue}let n=e.line;if(pe(e,t,3,!1,!0),i.push(e.result),R(e,!0,-1),o=e.input.charCodeAt(e.position),(e.line===n||e.lineIndent>t)&&o!==0)T(e,`bad indentation of a sequence entry`);else if(e.lineIndent<t)break}return a?(e.tag=n,e.anchor=r,e.kind=`sequence`,e.result=i,!0):!1}function ce(e,t,n){let r,i,a,o,s=e.tag,c=e.anchor,l={},u=Object.create(null),d=null,m=null,h=null,g=!1,_=!1;if(e.firstTabInLine!==-1)return!1;e.anchor!==null&&D(e,e.anchor,l);let v=e.input.charCodeAt(e.position);for(;v!==0;){!g&&e.firstTabInLine!==-1&&(e.position=e.firstTabInLine,T(e,`tab characters must not be used in indentation`));let y=e.input.charCodeAt(e.position+1),b=e.line;if((v===63||v===58)&&p(y))v===63?(g&&(I(e,l,u,d,m,null,i,a,o),d=m=h=null),_=!0,g=!0,r=!0):g?(g=!1,r=!0):T(e,`incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line`),e.position+=1,v=y;else{if(i=e.line,a=e.lineStart,o=e.position,!pe(e,n,2,!1,!0))break;if(e.line===b){for(v=e.input.charCodeAt(e.position);f(v);)v=e.input.charCodeAt(++e.position);if(v===58)v=e.input.charCodeAt(++e.position),p(v)||T(e,`a whitespace character is expected after the key-value separator within a block mapping`),g&&(I(e,l,u,d,m,null,i,a,o),d=m=h=null),_=!0,g=!1,r=!1,d=e.tag,m=e.result;else if(_)T(e,`can not read an implicit mapping pair; a colon is missed`);else return e.tag=s,e.anchor=c,!0}else if(_)T(e,`can not read a block mapping entry; a multiline key may not be an implicit key`);else return e.tag=s,e.anchor=c,!0}if((e.line===b||e.lineIndent>t)&&(g&&(i=e.line,a=e.lineStart,o=e.position),pe(e,t,4,!0,r)&&(g?m=e.result:h=e.result),g||(I(e,l,u,d,m,h,i,a,o),d=m=h=null),R(e,!0,-1),v=e.input.charCodeAt(e.position)),(e.line===b||e.lineIndent>t)&&v!==0)T(e,`bad indentation of a mapping entry`);else if(e.lineIndent<t)break}return g&&I(e,l,u,d,m,null,i,a,o),_&&(e.tag=s,e.anchor=c,e.kind=`mapping`,e.result=l),_}function le(e){let t=!1,n=!1,r,a,o=e.input.charCodeAt(e.position);if(o!==33)return!1;e.tag!==null&&T(e,`duplication of a tag property`),o=e.input.charCodeAt(++e.position),o===60?(t=!0,o=e.input.charCodeAt(++e.position)):o===33?(n=!0,r=`!!`,o=e.input.charCodeAt(++e.position)):r=`!`;let u=e.position;if(t){do o=e.input.charCodeAt(++e.position);while(o!==0&&o!==62);e.position<e.length?(a=e.input.slice(u,e.position),o=e.input.charCodeAt(++e.position)):T(e,`unexpected end of the stream within a verbatim tag`)}else{for(;o!==0&&!p(o);)o===33&&(n?T(e,`tag suffix cannot contain exclamation marks`):(r=e.input.slice(u-1,e.position+1),c.test(r)||T(e,`named tag handle cannot contain such characters`),n=!0,u=e.position+1)),o=e.input.charCodeAt(++e.position);a=e.input.slice(u,e.position),s.test(a)&&T(e,`tag suffix cannot contain flow indicator characters`)}a&&!l.test(a)&&T(e,`tag name cannot contain such characters: `+a);try{a=decodeURIComponent(a)}catch{T(e,`tag name is malformed: `+a)}return t?e.tag=a:i.call(e.tagMap,r)?e.tag=e.tagMap[r]+a:r===`!`?e.tag=`!`+a:r===`!!`?e.tag=`tag:yaml.org,2002:`+a:T(e,`undeclared tag handle "`+r+`"`),!0}function ue(e){let t=e.input.charCodeAt(e.position);if(t!==38)return!1;e.anchor!==null&&T(e,`duplication of an anchor property`),t=e.input.charCodeAt(++e.position);let n=e.position;for(;t!==0&&!p(t)&&!m(t);)t=e.input.charCodeAt(++e.position);return e.position===n&&T(e,`name of an anchor node must contain at least one character`),e.anchor=e.input.slice(n,e.position),!0}function de(e){let t=e.input.charCodeAt(e.position);if(t!==42)return!1;t=e.input.charCodeAt(++e.position);let n=e.position;for(;t!==0&&!p(t)&&!m(t);)t=e.input.charCodeAt(++e.position);e.position===n&&T(e,`name of an alias node must contain at least one character`);let r=e.input.slice(n,e.position);return i.call(e.anchorMap,r)||T(e,`unidentified alias "`+r+`"`),e.result=e.anchorMap[r],R(e,!0,-1),!0}function fe(e,t,n,r){let i=j(e);return O(e),M(e,t),e.tag=null,e.anchor=null,e.kind=null,e.result=null,ce(e,n,r)&&e.kind===`mapping`?(k(e),!0):(A(e),M(e,i),!1)}function pe(e,t,n,r,a){let o,s,c=1,l=!1,u=!1,d=null,f,p,m;e.depth>=e.maxDepth&&T(e,`nesting exceeded maxDepth (`+e.maxDepth+`)`),e.depth+=1,e.listener!==null&&e.listener(`open`,e),e.tag=null,e.anchor=null,e.kind=null,e.result=null;let h=o=s=n===4||n===3;if(r&&R(e,!0,-1)&&(l=!0,e.lineIndent>t?c=1:e.lineIndent===t?c=0:e.lineIndent<t&&(c=-1)),c===1)for(;;){let n=e.input.charCodeAt(e.position),r=j(e);if(l&&(n===33&&e.tag!==null||n===38&&e.anchor!==null)||!le(e)&&!ue(e))break;d===null&&(d=r),R(e,!0,-1)?(l=!0,s=h,e.lineIndent>t?c=1:e.lineIndent===t?c=0:e.lineIndent<t&&(c=-1)):s=!1}if(s&&=l||a,c===1||n===4){if(p=n===1||n===2?t:t+1,m=e.position-e.lineStart,c===1){if(s&&(se(e,m)||ce(e,m,p))||ae(e,p))u=!0;else{let t=e.input.charCodeAt(e.position);d!==null&&h&&!s&&t!==124&&t!==62&&fe(e,d,d.position-d.lineStart,p)||o&&oe(e,p)||z(e,p)||ie(e,p)?u=!0:de(e)?(u=!0,(e.tag!==null||e.anchor!==null)&&T(e,`alias node should not have any properties`)):re(e,p,n===1)&&(u=!0,e.tag===null&&(e.tag=`?`)),e.anchor!==null&&D(e,e.anchor,e.result)}}else c===0&&(u=s&&se(e,m))}if(e.tag===null)e.anchor!==null&&D(e,e.anchor,e.result);else if(e.tag===`?`){e.result!==null&&e.kind!==`scalar`&&T(e,`unacceptable node kind for !<?> tag; it should be "scalar", not "`+e.kind+`"`);for(let t=0,n=e.implicitTypes.length;t<n;t+=1)if(f=e.implicitTypes[t],f.resolve(e.result)){e.result=f.construct(e.result),e.tag=f.tag,e.anchor!==null&&D(e,e.anchor,e.result);break}}else if(e.tag!==`!`){if(i.call(e.typeMap[e.kind||`fallback`],e.tag))f=e.typeMap[e.kind||`fallback`][e.tag];else{f=null;let t=e.typeMap.multi[e.kind||`fallback`];for(let n=0,r=t.length;n<r;n+=1)if(e.tag.slice(0,t[n].tag.length)===t[n].tag){f=t[n];break}}f||T(e,`unknown tag !<`+e.tag+`>`),e.result!==null&&f.kind!==e.kind&&T(e,`unacceptable node kind for !<`+e.tag+`> tag; it should be "`+f.kind+`", not "`+e.kind+`"`),f.resolve(e.result,e.tag)?(e.result=f.construct(e.result,e.tag),e.anchor!==null&&D(e,e.anchor,e.result)):T(e,`cannot resolve a node with !<`+e.tag+`> explicit tag`)}return e.listener!==null&&e.listener(`close`,e),--e.depth,e.tag!==null||e.anchor!==null||u}function me(e){let t=e.position,n=!1,r;for(e.version=null,e.checkLineBreaks=e.legacy,e.tagMap=Object.create(null),e.anchorMap=Object.create(null);(r=e.input.charCodeAt(e.position))!==0&&(R(e,!0,-1),r=e.input.charCodeAt(e.position),!(e.lineIndent>0||r!==37));){n=!0,r=e.input.charCodeAt(++e.position);let t=e.position;for(;r!==0&&!p(r);)r=e.input.charCodeAt(++e.position);let a=e.input.slice(t,e.position),o=[];for(a.length<1&&T(e,`directive name must not be less than one character in length`);r!==0;){for(;f(r);)r=e.input.charCodeAt(++e.position);if(r===35){do r=e.input.charCodeAt(++e.position);while(r!==0&&!d(r));break}if(d(r))break;for(t=e.position;r!==0&&!p(r);)r=e.input.charCodeAt(++e.position);o.push(e.input.slice(t,e.position))}r!==0&&L(e),i.call(N,a)?N[a](e,a,o):E(e,`unknown document directive "`+a+`"`)}R(e,!0,-1),e.lineIndent===0&&e.input.charCodeAt(e.position)===45&&e.input.charCodeAt(e.position+1)===45&&e.input.charCodeAt(e.position+2)===45?(e.position+=3,R(e,!0,-1)):n&&T(e,`directives end mark is expected`),pe(e,e.lineIndent-1,4,!1,!0),R(e,!0,-1),e.checkLineBreaks&&o.test(e.input.slice(t,e.position))&&E(e,`non-ASCII line breaks are interpreted as content`),e.documents.push(e.result),e.position===e.lineStart&&te(e)?e.input.charCodeAt(e.position)===46&&(e.position+=3,R(e,!0,-1)):e.position<e.length-1&&T(e,`end of the stream or a document separator is expected`)}function he(e,t){e=String(e),t||={},e.length!==0&&(e.charCodeAt(e.length-1)!==10&&e.charCodeAt(e.length-1)!==13&&(e+=`
`),e.charCodeAt(0)===65279&&(e=e.slice(1)));let n=new C(e,t),r=e.indexOf(`\0`);for(r!==-1&&(n.position=r,T(n,`null byte is not allowed in input`)),n.input+=`\0`;n.input.charCodeAt(n.position)===32;)n.lineIndent+=1,n.position+=1;for(;n.position<n.length-1;)me(n);return n.documents}function ge(e,t,n){typeof t==`object`&&t&&n===void 0&&(n=t,t=null);let r=he(e,n);if(typeof t!=`function`)return r;for(let e=0,n=r.length;e<n;e+=1)t(r[e])}function _e(e,n){let r=he(e,n);if(r.length!==0){if(r.length===1)return r[0];throw new t(`expected a single document in the stream, but found more`)}}return an.loadAll=ge,an.load=_e,an}var br={},xr;function Sr(){if(xr)return br;xr=1;let e=cn(),t=dn(),n=_r(),r=Object.prototype.toString,i=Object.prototype.hasOwnProperty,a=65279,o={};o[0]=`\\0`,o[7]=`\\a`,o[8]=`\\b`,o[9]=`\\t`,o[10]=`\\n`,o[11]=`\\v`,o[12]=`\\f`,o[13]=`\\r`,o[27]=`\\e`,o[34]=`\\"`,o[92]=`\\\\`,o[133]=`\\N`,o[160]=`\\_`,o[8232]=`\\L`,o[8233]=`\\P`;let s=[`y`,`Y`,`yes`,`Yes`,`YES`,`on`,`On`,`ON`,`n`,`N`,`no`,`No`,`NO`,`off`,`Off`,`OFF`],c=/^[-+]?[0-9_]+(?::[0-9_]+)+(?:\.[0-9_]*)?$/;function l(e,t){if(t===null)return{};let n={},r=Object.keys(t);for(let a=0,o=r.length;a<o;a+=1){let o=r[a],s=String(t[o]);o.slice(0,2)===`!!`&&(o=`tag:yaml.org,2002:`+o.slice(2));let c=e.compiledTypeMap.fallback[o];c&&i.call(c.styleAliases,s)&&(s=c.styleAliases[s]),n[o]=s}return n}function u(n){let r,i,a=n.toString(16).toUpperCase();if(n<=255)r=`x`,i=2;else if(n<=65535)r=`u`,i=4;else if(n<=4294967295)r=`U`,i=8;else throw new t(`code point within a string may not be greater than 0xFFFFFFFF`);return`\\`+r+e.repeat(`0`,i-a.length)+a}function d(t){this.schema=t.schema||n,this.indent=Math.max(1,t.indent||2),this.noArrayIndent=t.noArrayIndent||!1,this.skipInvalid=t.skipInvalid||!1,this.flowLevel=e.isNothing(t.flowLevel)?-1:t.flowLevel,this.styleMap=l(this.schema,t.styles||null),this.sortKeys=t.sortKeys||!1,this.lineWidth=t.lineWidth||80,this.noRefs=t.noRefs||!1,this.noCompatMode=t.noCompatMode||!1,this.condenseFlow=t.condenseFlow||!1,this.quotingType=t.quotingType===`"`?2:1,this.forceQuotes=t.forceQuotes||!1,this.replacer=typeof t.replacer==`function`?t.replacer:null,this.implicitTypes=this.schema.compiledImplicit,this.explicitTypes=this.schema.compiledExplicit,this.tag=null,this.result=``,this.duplicates=[],this.usedDuplicates=null}function f(t,n){let r=e.repeat(` `,n),i=0,a=``,o=t.length;for(;i<o;){let e,n=t.indexOf(`
`,i);n===-1?(e=t.slice(i),i=o):(e=t.slice(i,n+1),i=n+1),e.length&&e!==`
`&&(a+=r),a+=e}return a}function p(t,n){return`
`+e.repeat(` `,t.indent*n)}function m(e,t){for(let n=0,r=e.implicitTypes.length;n<r;n+=1)if(e.implicitTypes[n].resolve(t))return!0;return!1}function h(e){return e===32||e===9}function g(e){return e>=32&&e<=126||e>=161&&e<=55295&&e!==8232&&e!==8233||e>=57344&&e<=65533&&e!==a||e>=65536&&e<=1114111}function _(e){return g(e)&&e!==a&&e!==13&&e!==10}function v(e,t,n){let r=_(e),i=r&&!h(e);return(n?r:r&&e!==44&&e!==91&&e!==93&&e!==123&&e!==125)&&e!==35&&!(t===58&&!i)||_(t)&&!h(t)&&e===35||t===58&&i}function y(e){return g(e)&&e!==a&&!h(e)&&e!==45&&e!==63&&e!==58&&e!==44&&e!==91&&e!==93&&e!==123&&e!==125&&e!==35&&e!==38&&e!==42&&e!==33&&e!==124&&e!==61&&e!==62&&e!==39&&e!==34&&e!==37&&e!==64&&e!==96}function b(e){return!h(e)&&e!==58}function x(e,t){let n=e.charCodeAt(t),r;return n>=55296&&n<=56319&&t+1<e.length&&(r=e.charCodeAt(t+1),r>=56320&&r<=57343)?(n-55296)*1024+r-56320+65536:n}function S(e){return/^\n* /.test(e)}function C(e,t,n,r,i,a,o,s){let c,l=0,u=null,d=!1,f=!1,p=r!==-1,m=-1,h=y(x(e,0))&&b(x(e,e.length-1));if(t||o)for(c=0;c<e.length;l>=65536?c+=2:c++){if(l=x(e,c),!g(l))return 5;h&&=v(l,u,s),u=l}else{for(c=0;c<e.length;l>=65536?c+=2:c++){if(l=x(e,c),l===10)d=!0,p&&(f||=c-m-1>r&&e[m+1]!==` `,m=c);else if(!g(l))return 5;h&&=v(l,u,s),u=l}f||=p&&c-m-1>r&&e[m+1]!==` `}return!d&&!f?h&&!o&&!i(e)?1:a===2?5:2:n>9&&S(e)?5:o?a===2?5:2:f?4:3}function w(e,n,r,i,a){e.dump=(function(){if(n.length===0)return e.quotingType===2?`""`:`''`;if(!e.noCompatMode&&(s.indexOf(n)!==-1||c.test(n)))return e.quotingType===2?`"`+n+`"`:`'`+n+`'`;let o=e.indent*Math.max(1,r),l=e.lineWidth===-1?-1:Math.max(Math.min(e.lineWidth,40),e.lineWidth-o),u=i||e.flowLevel>-1&&r>=e.flowLevel;function d(t){return m(e,t)}switch(C(n,u,e.indent,l,d,e.quotingType,e.forceQuotes&&!i,a)){case 1:return n;case 2:return`'`+n.replace(/'/g,`''`)+`'`;case 3:return`|`+T(n,e.indent)+E(f(n,o));case 4:return`>`+T(n,e.indent)+E(f(D(n,l),o));case 5:return`"`+k(n)+`"`;default:throw new t(`impossible error: invalid scalar style`)}})()}function T(e,t){let n=S(e)?String(t):``,r=e[e.length-1]===`
`;return n+(r&&(e[e.length-2]===`
`||e===`
`)?`+`:r?``:`-`)+`
`}function E(e){return e[e.length-1]===`
`?e.slice(0,-1):e}function D(e,t){let n=/(\n+)([^\n]*)/g,r=(function(){let r=e.indexOf(`
`);return r=r===-1?e.length:r,n.lastIndex=r,O(e.slice(0,r),t)})(),i=e[0]===`
`||e[0]===` `,a,o;for(;o=n.exec(e);){let e=o[1],n=o[2];a=n[0]===` `,r+=e+(!i&&!a&&n!==``?`
`:``)+O(n,t),i=a}return r}function O(e,t){if(e===``||e[0]===` `)return e;let n=/ [^ ]/g,r,i=0,a,o=0,s=0,c=``;for(;r=n.exec(e);)s=r.index,s-i>t&&(a=o>i?o:s,c+=`
`+e.slice(i,a),i=a+1),o=s;return c+=`
`,e.length-i>t&&o>i?c+=e.slice(i,o)+`
`+e.slice(o+1):c+=e.slice(i),c.slice(1)}function k(e){let t=``,n=0;for(let r=0;r<e.length;n>=65536?r+=2:r++){n=x(e,r);let i=o[n];!i&&g(n)?(t+=e[r],n>=65536&&(t+=e[r+1])):t+=i||u(n)}return t}function A(e,t,n){let r=``,i=e.tag;for(let i=0,a=n.length;i<a;i+=1){let a=n[i];e.replacer&&(a=e.replacer.call(n,String(i),a)),(F(e,t,a,!1,!1)||a===void 0&&F(e,t,null,!1,!1))&&(r!==``&&(r+=`,`+(e.condenseFlow?``:` `)),r+=e.dump)}e.tag=i,e.dump=`[`+r+`]`}function j(e,t,n,r){let i=``,a=e.tag;for(let a=0,o=n.length;a<o;a+=1){let o=n[a];e.replacer&&(o=e.replacer.call(n,String(a),o)),(F(e,t+1,o,!0,!0,!1,!0)||o===void 0&&F(e,t+1,null,!0,!0,!1,!0))&&(r&&i===``||(i+=p(e,t)),e.dump&&e.dump.charCodeAt(0)===10?i+=`-`:i+=`- `,i+=e.dump)}e.tag=a,e.dump=i||`[]`}function M(e,t,n){let r=``,i=e.tag,a=Object.keys(n);for(let i=0,o=a.length;i<o;i+=1){let o=``;r!==``&&(o+=`, `),e.condenseFlow&&(o+=`"`);let s=a[i],c=n[s];e.replacer&&(c=e.replacer.call(n,s,c)),F(e,t,s,!1,!1)&&(e.dump.length>1024&&(o+=`? `),o+=e.dump+(e.condenseFlow?`"`:``)+`:`+(e.condenseFlow?``:` `),F(e,t,c,!1,!1)&&(o+=e.dump,r+=o))}e.tag=i,e.dump=`{`+r+`}`}function N(e,n,r,i){let a=``,o=e.tag,s=Object.keys(r);if(e.sortKeys===!0)s.sort();else if(typeof e.sortKeys==`function`)s.sort(e.sortKeys);else if(e.sortKeys)throw new t(`sortKeys must be a boolean or a function`);for(let t=0,o=s.length;t<o;t+=1){let o=``;i&&a===``||(o+=p(e,n));let c=s[t],l=r[c];if(e.replacer&&(l=e.replacer.call(r,c,l)),!F(e,n+1,c,!0,!0,!0))continue;let u=e.tag!==null&&e.tag!==`?`||e.dump&&e.dump.length>1024;u&&(e.dump&&e.dump.charCodeAt(0)===10?o+=`?`:o+=`? `),o+=e.dump,u&&(o+=p(e,n)),F(e,n+1,l,!0,u)&&(e.dump&&e.dump.charCodeAt(0)===10?o+=`:`:o+=`: `,o+=e.dump,a+=o)}e.tag=o,e.dump=a||`{}`}function P(e,n,a){let o=a?e.explicitTypes:e.implicitTypes;for(let s=0,c=o.length;s<c;s+=1){let c=o[s];if((c.instanceOf||c.predicate)&&(!c.instanceOf||typeof n==`object`&&n instanceof c.instanceOf)&&(!c.predicate||c.predicate(n))){if(e.tag=a?c.multi&&c.representName?c.representName(n):c.tag:`?`,c.represent){let a=e.styleMap[c.tag]||c.defaultStyle,o;if(r.call(c.represent)===`[object Function]`)o=c.represent(n,a);else if(i.call(c.represent,a))o=c.represent[a](n,a);else throw new t(`!<`+c.tag+`> tag resolver accepts not "`+a+`" style`);e.dump=o}return!0}}return!1}function F(e,n,i,a,o,s,c){e.tag=null,e.dump=i,P(e,i,!1)||P(e,i,!0);let l=r.call(e.dump),u=a;a&&=e.flowLevel<0||e.flowLevel>n;let d=l===`[object Object]`||l===`[object Array]`,f,p;if(d&&(f=e.duplicates.indexOf(i),p=f!==-1),(e.tag!==null&&e.tag!==`?`||p||e.indent!==2&&n>0)&&(o=!1),p&&e.usedDuplicates[f])e.dump=`*ref_`+f;else{if(d&&p&&!e.usedDuplicates[f]&&(e.usedDuplicates[f]=!0),l===`[object Object]`)a&&Object.keys(e.dump).length!==0?(N(e,n,e.dump,o),p&&(e.dump=`&ref_`+f+e.dump)):(M(e,n,e.dump),p&&(e.dump=`&ref_`+f+` `+e.dump));else if(l===`[object Array]`)a&&e.dump.length!==0?(e.noArrayIndent&&!c&&n>0?j(e,n-1,e.dump,o):j(e,n,e.dump,o),p&&(e.dump=`&ref_`+f+e.dump)):(A(e,n,e.dump),p&&(e.dump=`&ref_`+f+` `+e.dump));else if(l===`[object String]`)e.tag!==`?`&&w(e,e.dump,n,s,u);else if(l===`[object Undefined]`)return!1;else{if(e.skipInvalid)return!1;throw new t(`unacceptable kind of an object to dump `+l)}if(e.tag!==null&&e.tag!==`?`){let t=encodeURI(e.tag[0]===`!`?e.tag.slice(1):e.tag).replace(/!/g,`%21`);t=e.tag[0]===`!`?`!`+t:t.slice(0,18)===`tag:yaml.org,2002:`?`!!`+t.slice(18):`!<`+t+`>`,e.dump=t+` `+e.dump}}return!0}function ee(e,t){let n=[],r=[];I(e,n,r);let i=r.length;for(let e=0;e<i;e+=1)t.duplicates.push(n[r[e]]);t.usedDuplicates=Array(i)}function I(e,t,n){if(typeof e==`object`&&e){let r=t.indexOf(e);if(r!==-1)n.indexOf(r)===-1&&n.push(r);else if(t.push(e),Array.isArray(e))for(let r=0,i=e.length;r<i;r+=1)I(e[r],t,n);else{let r=Object.keys(e);for(let i=0,a=r.length;i<a;i+=1)I(e[r[i]],t,n)}}}function L(e,t){t||={};let n=new d(t);n.noRefs||ee(e,n);let r=e;return n.replacer&&(r=n.replacer.call({"":r},``,r)),F(n,0,r,!0,!0)?n.dump+`
`:``}return br.dump=L,br}var Cr;function wr(){if(Cr)return rn;Cr=1;let e=yr(),t=Sr();function n(e,t){return function(){throw Error(`Function yaml.`+e+` is removed in js-yaml 4. Use yaml.`+t+` instead, which is now safe by default.`)}}return rn.Type=_n(),rn.Schema=bn(),rn.FAILSAFE_SCHEMA=Mn(),rn.JSON_SCHEMA=qn(),rn.CORE_SCHEMA=Xn(),rn.DEFAULT_SCHEMA=_r(),rn.load=e.load,rn.loadAll=e.loadAll,rn.dump=t.dump,rn.YAMLException=dn(),rn.types={binary:ar(),float:Wn(),map:kn(),null:Fn(),pairs:dr(),set:mr(),timestamp:$n(),bool:Rn(),int:Vn(),merge:nr(),omap:cr(),seq:En(),str:Cn()},rn.safeLoad=n(`safeLoad`,`load`),rn.safeLoadAll=n(`safeLoadAll`,`loadAll`),rn.safeDump=n(`safeDump`,`dump`),rn}var Tr=nn(wr()),{Type:Er,Schema:Dr,FAILSAFE_SCHEMA:Or,JSON_SCHEMA:kr,CORE_SCHEMA:Ar,DEFAULT_SCHEMA:jr,load:Mr,loadAll:Nr,dump:Pr,YAMLException:Fr,types:Ir,safeLoad:Lr,safeLoadAll:Rr,safeDump:zr}=Tr,Br={};Object.entries(Object.assign({"../openapi/openapi.json":tn})).forEach(([e,t])=>{let n=e.split(`/`).pop()?.replace(/\.(json|yaml|yml)$/,``)||`default`;Br[n]=t});function Vr(){let e={};return Object.entries(Br).forEach(([t,n])=>{try{let r;try{r=JSON.parse(n)}catch{r=Tr.load(n)}r&&r.openapi&&r.info&&r.paths?e[t]=r:console.warn(`Invalid OpenAPI specification in file: ${t}`)}catch(e){console.error(`Error parsing OpenAPI file ${t}:`,e)}}),e}var Hr=(e=`en`)=>{let[t,n]=(0,_.useState)(`default`),[r,i]=(0,_.useState)({});(0,_.useEffect)(()=>{let e=Vr();if(Object.keys(e).length>0){i(e);let t=Object.keys(e)[0];n(t)}else console.warn(`No OpenAPI specifications found in /src/openapi/ directory`),i({})},[]);let a=(0,_.useMemo)(()=>r[t]||null,[r,t]);return{currentSpec:a,categories:(0,_.useMemo)(()=>a?en(a,e):[],[a,e]),baseUrl:(0,_.useMemo)(()=>a?.servers?.[0]?.url||`https://ecom-api-test.paynet.md`,[a]),selectedSpec:t,setSelectedSpec:n,availableSpecs:Object.keys(r),specInfo:a?.info||{title:`No API Spec`,version:`1.0.0`,description:`No specification loaded`}}},Ur={ecommerce:`#/guides/integration-options`,"server-server":`#/guides/server-to-server`,"client-server":`#/guides/hosted-checkout`,"order-request-v05":`#/guides/hosted-checkout`,"order-request-v06":`#/page/checkout-form`,notifications:`#/page/notification-simulator`},Wr=[`plugins`,`checkout-form`,`notification-simulator`],Gr=e=>{let[,t,n]=e.match(/^#\/(guides|page|api)\/(.+)$/)||[];if(t===`guides`&&n)return{kind:`guide`,slug:decodeURIComponent(n)};if(t===`page`&&n){if(Wr.includes(n))return{kind:`page`,page:n};if(Ur[n])return{redirect:Ur[n]}}return t===`api`&&n?{kind:`api`,endpointId:decodeURIComponent(n)}:{kind:`home`}};function Kr(e){let t=`(min-width: ${e}px)`,[n,r]=_.useState(()=>typeof window<`u`&&window.matchMedia(t).matches);return _.useEffect(()=>{let e=window.matchMedia(t),n=()=>r(e.matches);return n(),e.addEventListener(`change`,n),()=>e.removeEventListener(`change`,n)},[t]),n}function qr(){let{language:e,changeLanguage:t,t:n,apiInfo:r}=Yt(),{categories:i,baseUrl:a,currentSpec:o}=Hr(e),[s,c]=(0,_.useState)(``),[l,u]=(0,_.useState)({kind:`home`}),[d,f]=(0,_.useState)(!1),p=Kr(768),m=Kr(1280),h=_.useRef(null),g=_.useCallback(e=>{let t=Gr(e);`redirect`in t?window.location.replace(t.redirect):(u(t),h.current&&(h.current.scrollTop=0))},[]);_.useEffect(()=>{g(window.location.hash);let e=()=>g(window.location.hash);return window.addEventListener(`hashchange`,e),()=>window.removeEventListener(`hashchange`,e)},[g]);let v=e=>{window.location.hash===e||e===`#/`&&!window.location.hash?g(e):window.location.hash=e},y=e=>{e.startsWith(`#/`)?v(e):document.getElementById(e.replace(/^#/,``))?.scrollIntoView({behavior:`smooth`,block:`start`})},b=(0,_.useMemo)(()=>i.flatMap(e=>e.endpoints),[i]),x=l.kind===`api`?b.find(e=>e.id===l.endpointId):void 0,S=l.kind===`guide`?Pe(e,l.slug):void 0,C=()=>l.kind===`guide`?S?(0,B.jsx)(Wt,{guide:S,language:e,onNavigate:y}):(0,B.jsx)(Gt,{language:e,onNavigate:v}):l.kind===`page`?l.page===`plugins`?(0,B.jsx)(ct,{}):l.page===`checkout-form`?(0,B.jsx)(xt,{language:e}):(0,B.jsx)(At,{language:e}):l.kind===`api`?x?(0,B.jsx)(ot,{endpoint:x,baseUrl:a,servers:o?.servers,t:n,language:e,spec:o,onNavigate:v}):null:(0,B.jsx)(Gt,{language:e,onNavigate:v}),w=e=>{f(!1),v(e)},T=x?(0,B.jsx)(It,{endpoint:x,baseUrl:a,spec:o,t:n}):null;return(0,B.jsxs)(`div`,{className:`h-dvh bg-gradient-to-br from-paynet-gray-50 to-paynet-light overflow-hidden flex flex-col`,children:[(0,B.jsx)(Le,{language:e,onLanguageChange:t,apiInfo:r,onHome:()=>w(`#/`),onMenu:()=>f(e=>!e),menuOpen:d}),(0,B.jsxs)(`div`,{className:`flex flex-1 min-h-0 min-w-0`,children:[(0,B.jsxs)(`div`,{className:p?`flex min-h-0`:`fixed inset-0 z-40 flex transition-opacity ${d?`opacity-100`:`opacity-0 pointer-events-none`}`,"aria-hidden":!p&&!d,children:[(0,B.jsx)(`div`,{className:p?`flex min-h-0`:`w-[86vw] max-w-sm h-full flex shadow-xl transition-transform ${d?`translate-x-0`:`-translate-x-full`}`,children:(0,B.jsx)(Ge,{language:e,categories:i,currentSpec:o,route:l,navigate:w,searchQuery:s,onSearchChange:c})}),!p&&(0,B.jsx)(`button`,{type:`button`,"aria-label":`Close menu`,className:`flex-1 bg-black/40`,onClick:()=>f(!1)})]}),(0,B.jsxs)(`div`,{className:`flex-1 min-h-0 min-w-0 flex`,children:[(0,B.jsx)(`div`,{ref:h,className:`flex-1 min-h-0 min-w-0 overflow-y-auto bg-white xl:border-r border-paynet-gray-200`,children:(0,B.jsxs)(`div`,{className:`px-4 py-5 sm:p-6 lg:p-8 min-h-full flex flex-col`,children:[(0,B.jsx)(`div`,{className:`flex-1 w-full min-w-0`,children:C()}),T&&!m&&(0,B.jsx)(`div`,{className:`mt-8 pt-6 border-t border-paynet-gray-200 min-w-0`,children:T}),!p&&(0,B.jsx)(`div`,{className:`-mx-4 mt-8`,children:(0,B.jsx)(Re,{author:r.author,version:r.version})})]})}),T&&m&&(0,B.jsx)(`div`,{className:`w-144 bg-white overflow-y-auto flex-shrink-0 border-l border-paynet-gray-200`,children:(0,B.jsx)(`div`,{className:`p-6`,children:T})})]})]}),p&&(0,B.jsx)(Re,{author:r.author,version:r.version})]})}(0,Te.createRoot)(document.getElementById(`root`)).render((0,B.jsx)(_.StrictMode,{children:(0,B.jsx)(qr,{})}));